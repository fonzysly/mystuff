"""Celery tasks for AWX job monitoring and workflow execution."""

import time
import traceback

import requests
from django.conf import settings
from django.utils import timezone
from nautobot.core.celery import app  # In RQ setups, adjust to RQ equivalent
from nautobot.extras.models import ExternalIntegration

from .executors import parse_awx_auth
from .models import AwxRun, WorkflowRun

PLUGIN_CFG = settings.PLUGINS_CONFIG.get("nautobot_workflow_launcher", {})


@app.task
def poll_awx_job(awx_run_pk: int):
    """Poll AWX job status until completion and update workflow run status."""
    poll_seconds = int(PLUGIN_CFG.get("awx_poll_seconds", 10))
    ar = AwxRun.objects.select_related("workflow_run").get(pk=awx_run_pk)
    integ = ExternalIntegration.objects.get(name=PLUGIN_CFG["awx_external_integration_name"])
    url = integ.remote_url.rstrip("/")
    verify = integ.verify_ssl
    username, password = parse_awx_auth(integ)

    while True:
        r = requests.get(f"{url}/api/v2/jobs/{ar.job_id}/", auth=(username, password), verify=verify, timeout=15)
        r.raise_for_status()
        payload = r.json()
        status = payload.get("status")
        ar.status = status
        ar.raw = payload
        ar.save(update_fields=["status", "raw"])

        if status in {"successful", "failed", "error", "canceled"}:
            rr = ar.workflow_run
            # Append to existing logs instead of overwriting
            rr.log += f"\nAWX polling task: job {ar.job_id} -> {status}"

            # Log artifacts info if present for debugging
            if status == "successful" and payload.get("artifacts"):
                rr.log += f"\nAWX job artifacts captured: {list(payload['artifacts'].keys())}"
            elif status == "successful":
                rr.log += "\nAWX job completed without artifacts"

            rr.save(update_fields=["log"])
            break
        time.sleep(poll_seconds)


@app.task(bind=True)
def execute_workflow_task(self, workflow_run_id):
    """Execute a complete workflow in the background."""
    from .executors import _run_workflow_synchronous

    try:
        workflow_run = WorkflowRun.objects.get(pk=workflow_run_id)
        workflow_run.status = "running"
        workflow_run.save()

        # Execute the workflow using the synchronous version
        _run_workflow_synchronous(workflow_run)

    except Exception as exc:
        try:
            workflow_run = WorkflowRun.objects.get(pk=workflow_run_id)
            workflow_run.status = "failed"
            workflow_run.log += f"\nTask execution failed: {exc}\n{traceback.format_exc()}"
            workflow_run.finished = timezone.now()
            workflow_run.save()
        except Exception:  # noqa: S110
            # If we can't even update the workflow run, just let the task fail
            pass
        raise
