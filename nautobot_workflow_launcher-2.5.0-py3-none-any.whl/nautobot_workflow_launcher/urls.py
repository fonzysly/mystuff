"""URL configuration for the workflow launcher plugin."""

from django.templatetags.static import static
from django.urls import include, path
from django.views.generic import RedirectView
from nautobot.apps.urls import NautobotUIViewSetRouter

from . import views

app_name = "nautobot_workflow_launcher"

# Create router and register WorkflowUIViewSet
router = NautobotUIViewSetRouter()
router.register("workflow", views.WorkflowUIViewSet)

urlpatterns = [
    path("api/workflow-launcher/ai/catalog", views.AIWorkflowCatalogView.as_view(), name="ai_catalog"),
    path(
        "api/workflow-launcher/ai/conversations", views.AIConversationCollectionView.as_view(), name="ai_conversations"
    ),
    path(
        "api/workflow-launcher/ai/conversations/<uuid:pk>",
        views.AIConversationDetailView.as_view(),
        name="ai_conversation_detail",
    ),
    path(
        "api/workflow-launcher/ai/conversations/<uuid:pk>/messages",
        views.AIConversationMessageView.as_view(),
        name="ai_conversation_messages",
    ),
    path(
        "api/workflow-launcher/ai/conversations/<uuid:pk>/approve",
        views.AIConversationApproveView.as_view(),
        name="ai_conversation_approve",
    ),
    path(
        "api/workflow-launcher/ai/conversations/<uuid:pk>/create-change",
        views.AIConversationCreateChangeView.as_view(),
        name="ai_conversation_create_change",
    ),
    path(
        "api/workflow-launcher/ai/conversations/<uuid:pk>/close-change",
        views.AIConversationCloseChangeView.as_view(),
        name="ai_conversation_close_change",
    ),
    path(
        "api/workflow-launcher/ai/servicenow/search",
        views.AIServiceNowSearchView.as_view(),
        name="ai_servicenow_search",
    ),
    path("api/workflow-launcher/ai/gaps", views.AIGapListView.as_view(), name="ai_gaps"),
    path("api/workflow-launcher/ai/metrics", views.AIMetricsView.as_view(), name="ai_metrics"),
    path("ai/assistant/", views.AIAssistantView.as_view(), name="ai_assistant"),
    path("workflows_list/", views.WorkflowListView.as_view(), name="workflows_list"),
    path("workflows/<slug:key>/launch/", views.WorkflowRunCreateView.as_view(), name="workflow_launch"),
    path("workflows/<slug:key>/inputs/<slug:child>/options/", views.InputOptionsView.as_view(), name="input_options"),
    path("runs/", views.WorkflowRunListView.as_view(), name="workflow_run_list"),
    path("runs/<uuid:pk>/", views.WorkflowRunDetailView.as_view(), name="workflow_run"),
    path("runs/<uuid:pk>/progress/", views.WorkflowRunProgressView.as_view(), name="workflow_run_progress"),
    path("runs/<uuid:pk>/cancel/", views.WorkflowRunCancelView.as_view(), name="workflow_run_cancel"),
    path("reports/", views.WorkflowReportView.as_view(), name="workflow_report"),
    path("docs/", RedirectView.as_view(url=static("nautobot_workflow_launcher/docs/index.html")), name="docs"),
    path("", include(router.urls)),
]
