"""Conversation orchestration helpers for the AI assistant."""

from __future__ import annotations

from django.utils.text import Truncator

from nautobot_workflow_launcher.ai.gaps import record_capability_gap, serialize_gap
from nautobot_workflow_launcher.ai.planner import build_plan
from nautobot_workflow_launcher.ai.servicenow import (
    ServiceNowConfigurationError,
    build_change_context,
    draft_change_for_conversation,
    extract_change_number,
    fetch_change_record,
    validate_change_for_execution,
)
from nautobot_workflow_launcher.ai.tasks import get_complete_json_task_result, schedule_complete_json
from nautobot_workflow_launcher.models import AIConversationMessage


def serialize_message(message):
    """Serialize a conversation message for API responses."""
    return {
        "id": str(message.pk),
        "role": message.role,
        "content": message.content,
        "payload": message.payload or {},
    }


def serialize_conversation(conversation, include_messages=False):
    """Serialize a conversation and optionally embed its message history."""
    data = {
        "id": str(conversation.pk),
        "title": conversation.title,
        "status": conversation.status,
        "latest_user_request": conversation.latest_user_request,
        "state": conversation.state or {},
    }
    if include_messages:
        data["messages"] = [serialize_message(message) for message in conversation.messages.all()]
    return data


def format_assistant_response(plan):
    """Render a human-readable assistant response from a plan payload."""
    if plan["kind"] == "gap":
        proposal = plan["proposal"]
        lines = [
            "I could not map that request to an executable workflow in the current catalog.",
            f"Recorded capability gap: {plan['gap']['capability_name']}",
            f"Draft proposal: {proposal['workflow_name']}",
        ]
        if proposal.get("inputs"):
            lines.append("Suggested inputs: " + ", ".join(item["label"] for item in proposal["inputs"]))
        return "\n".join(lines)

    lines = ["Recommended plan:"]
    for step in plan.get("steps", []):
        lines.append(
            f"{step['sequence']}. {step['workflow_title']} "
            f"(risk: {step['risk_level']}, est: {step['estimated_runtime_minutes']}m)"
        )
    if plan.get("missing_inputs"):
        lines.append("Missing inputs: " + ", ".join(item["label"] for item in plan["missing_inputs"]))
        lines.append("Reply with values such as key=value to continue planning.")
    else:
        lines.append("All required inputs are present. Approve to execute this workflow plan.")
    return "\n".join(lines)


def _reorder_plan_by_keys(plan, selected_keys, reason=None):
    if not isinstance(selected_keys, list) or not selected_keys:
        if reason:
            plan["llm_reasoning"] = reason
        return plan

    recommendation_map = {item["workflow_key"]: item for item in plan.get("recommendations", [])}
    step_map = {item["workflow_key"]: item for item in plan.get("steps", [])}
    ordered_recommendations = []
    ordered_steps = []
    seen = set()
    for key in selected_keys:
        if key in recommendation_map and key not in seen:
            ordered_recommendations.append(recommendation_map[key])
            seen.add(key)
        if key in step_map and key not in {item["workflow_key"] for item in ordered_steps}:
            ordered_steps.append(step_map[key])

    ordered_recommendations.extend(item for item in plan.get("recommendations", []) if item["workflow_key"] not in seen)
    ordered_steps.extend(
        item
        for item in plan.get("steps", [])
        if item["workflow_key"] not in {step["workflow_key"] for step in ordered_steps}
    )

    for index, step in enumerate(ordered_steps, start=1):
        step["sequence"] = index

    plan["recommendations"] = ordered_recommendations
    plan["steps"] = ordered_steps
    if reason:
        plan["llm_reasoning"] = reason
    return plan


def _queue_planner_rerank(plan, request_text):
    if plan.get("kind") != "workflow_plan" or len(plan.get("recommendations", [])) < 2:
        return None
    task_id = schedule_complete_json(
        "planner",
        "Choose the best existing workflow-backed candidate order for this request. Only use workflow keys from the provided candidate list.",
        context={
            "request_text": request_text,
            "candidates": plan.get("recommendations", []),
        },
    )
    if not task_id:
        return None
    return {"task_id": task_id, "status": "pending", "request_text": request_text}


def reconcile_async_updates(conversation):
    """Reconcile any queued async LLM tasks into conversation state."""
    state = conversation.state or {}
    async_llm = dict(state.get("async_llm", {}) or {})
    if not async_llm:
        return conversation

    changed = False
    plan = state.get("plan") or {}
    execution = state.get("execution") or {}

    planner_task = async_llm.get("planner") or {}
    if planner_task.get("task_id") and planner_task.get("status") == "pending":
        result = get_complete_json_task_result(planner_task["task_id"])
        if result.get("ready"):
            changed = True
            if result.get("result"):
                response = result["result"] if isinstance(result["result"], dict) else {}
                _reorder_plan_by_keys(
                    plan,
                    response.get("selected_workflow_keys") or response.get("workflow_keys") or [],
                    reason=response.get("reason"),
                )
                planner_task["status"] = "completed"
            else:
                planner_task.update({"status": "failed", "error": result.get("error", "Async planner task failed.")})
            async_llm["planner"] = planner_task

    summarizer_task = async_llm.get("summarizer") or {}
    if summarizer_task.get("task_id") and summarizer_task.get("status") == "pending":
        result = get_complete_json_task_result(summarizer_task["task_id"])
        if result.get("ready"):
            changed = True
            if isinstance(result.get("result"), dict) and result["result"].get("summary"):
                execution["summary"] = result["result"]["summary"]
                execution["summary_pending"] = False
                summarizer_task["status"] = "completed"
            else:
                execution["summary_pending"] = False
                summarizer_task.update(
                    {"status": "failed", "error": result.get("error", "Async summarizer task failed.")}
                )
            async_llm["summarizer"] = summarizer_task

    if changed:
        state["plan"] = plan
        if execution:
            state["execution"] = execution
        state["async_llm"] = async_llm
        conversation.state = state
        conversation.save(update_fields=["state"])

    return conversation


def _resolve_servicenow_context(request_text):
    change_number = extract_change_number(request_text)
    if not change_number:
        return None, None

    try:
        record = fetch_change_record(change_number)
    except (ServiceNowConfigurationError, LookupError, RuntimeError) as exc:
        return {"change_number": change_number, "error": str(exc)}, None

    return None, build_change_context(record)


def apply_user_message(conversation, request_text, catalog_entries):
    """Append a user message, re-plan, and append the assistant response."""
    AIConversationMessage.objects.create(
        conversation=conversation,
        role="user",
        content=request_text,
    )

    prior_state = conversation.state or {}
    service_now_error, service_now_context = _resolve_servicenow_context(request_text)
    planning_text = request_text
    if service_now_context and service_now_context.get("summary_text"):
        planning_text = f"{request_text}\n\nServiceNow change context:\n{service_now_context['summary_text']}"

    plan = build_plan(planning_text, catalog_entries, conversation_state=prior_state, allow_llm=False)
    if plan["kind"] == "gap":
        gap = record_capability_gap(conversation.requested_by, request_text, plan["gap"]["capability_name"])
        plan["gap"] = serialize_gap(gap)
        conversation.status = "blocked"
    elif plan.get("missing_inputs"):
        conversation.status = "needs_input"
    else:
        conversation.status = "ready"

    if service_now_context:
        plan["service_now"] = service_now_context
    elif service_now_error:
        plan["service_now"] = service_now_error

    service_now_draft = None
    if plan.get("kind") == "workflow_plan" and not (
        service_now_context or (prior_state.get("service_now") or {}).get("change_number")
    ):
        service_now_draft = draft_change_for_conversation(
            conversation,
            request_text=request_text,
            plan_override=plan,
        )
        plan["service_now_draft"] = service_now_draft

    service_now_warning = None
    if service_now_context:
        service_now_warning = validate_change_for_execution(service_now_context)
        if service_now_warning:
            plan["approval_ready"] = False
            plan["service_now_warning"] = service_now_warning
            conversation.status = "blocked"

    assistant_content = format_assistant_response(plan)
    if service_now_context:
        assistant_content = (
            f"ServiceNow change {service_now_context['change_number']} loaded"
            f" (state: {service_now_context.get('state') or 'unknown'}).\n"
            f"{assistant_content}"
        )
        if service_now_warning:
            assistant_content = (
                f"{assistant_content}\n{service_now_warning}\nExecution remains blocked until the change is ready."
            )
    elif service_now_error:
        assistant_content = f"ServiceNow change lookup warning: {service_now_error['error']}\n" f"{assistant_content}"

    if service_now_draft and service_now_draft.get("missing_fields"):
        assistant_content = (
            f"{assistant_content}\n"
            "To create a ServiceNow change from this plan, reply with values such as "
            + ", ".join(f"{field['key']}=<value>" for field in service_now_draft["missing_fields"])
            + "."
        )

    async_llm = dict(prior_state.get("async_llm", {}) or {})
    planner_task = _queue_planner_rerank(plan, planning_text)
    if planner_task:
        async_llm["planner"] = planner_task
        plan["async_llm"] = {"planner": {"status": "pending"}}
        assistant_content = f"{assistant_content}\nModel-backed ranking refinement is running in the background."

    assistant_message = AIConversationMessage.objects.create(
        conversation=conversation,
        role="assistant",
        content=assistant_content,
        payload=plan,
    )
    conversation.latest_user_request = request_text
    if not conversation.title:
        conversation.title = Truncator(request_text).chars(80)
    conversation.state = {
        **prior_state,
        "collected_inputs": plan.get("collected_inputs", {}),
        "plan": plan,
    }
    if service_now_context:
        conversation.state["service_now"] = service_now_context
    elif service_now_error:
        conversation.state["service_now"] = service_now_error
    if service_now_draft:
        conversation.state["service_now_draft"] = service_now_draft
    if async_llm:
        conversation.state["async_llm"] = async_llm
    conversation.save(update_fields=["title", "latest_user_request", "status", "state"])
    return assistant_message
