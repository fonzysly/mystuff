"""Lightweight retrieval helpers for AI workflow recommendations."""

from __future__ import annotations

import re

TOKEN_RE = re.compile(r"[a-z0-9][a-z0-9_-]+")
INTENT_KEYWORDS = {
    "decommissioning": {"decommission", "retire", "remove", "delete", "tear", "shutdown"},
    "provisioning": {"create", "add", "provision", "deploy", "enable", "build"},
    "migration": {"migrate", "move", "cutover", "transition"},
    "maintenance": {"upgrade", "patch", "restart", "rotate", "renew"},
    "auditing": {"audit", "report", "check", "verify", "inspect", "review"},
    "troubleshooting": {"fix", "debug", "investigate", "troubleshoot", "repair"},
    "change management": {"change", "ticket", "servicenow", "chg"},
}


def tokenize_text(text):
    """Tokenize freeform text into lowercase search terms."""
    return TOKEN_RE.findall(str(text or "").lower())


def classify_intent(text):
    """Infer the coarse operational intent from the request text."""
    token_set = set(tokenize_text(text))
    best_intent = "general"
    best_score = 0
    for intent, keywords in INTENT_KEYWORDS.items():
        score = len(token_set & keywords)
        if score > best_score:
            best_intent = intent
            best_score = score
    return best_intent


def _score_text_blob(tokens, text_blob, multiplier=1):
    text_blob = str(text_blob or "").lower()
    return sum(multiplier for token in tokens if token in text_blob)


def score_catalog_entry(request_text, intent, entry):
    """Score a catalog entry against a freeform request."""
    tokens = tokenize_text(request_text)
    score = 0
    score += _score_text_blob(tokens, entry.get("title"), multiplier=4)
    score += _score_text_blob(tokens, entry.get("name"), multiplier=5)
    score += _score_text_blob(tokens, entry.get("description"), multiplier=2)
    score += _score_text_blob(tokens, " ".join(entry.get("aliases", [])), multiplier=3)
    score += _score_text_blob(tokens, " ".join(entry.get("examples", [])), multiplier=2)
    score += _score_text_blob(tokens, " ".join(entry.get("tags", [])), multiplier=2)
    score += _score_text_blob(tokens, " ".join(entry.get("schema_terms", [])), multiplier=2)
    score += _score_text_blob(tokens, " ".join(entry.get("history_examples", [])), multiplier=1)

    if intent != "general":
        category_text = " ".join(
            filter(
                None,
                [entry.get("category", ""), *entry.get("tags", [])],
            )
        )
        score += _score_text_blob([intent], category_text, multiplier=4)

    if request_text.strip().lower() in {alias.lower() for alias in entry.get("aliases", [])}:
        score += 10

    return score


def retrieve_candidate_workflows(request_text, catalog_entries, limit=5):
    """Retrieve top matching workflow candidates for a request."""
    intent = classify_intent(request_text)
    scored_entries = []
    for entry in catalog_entries:
        score = score_catalog_entry(request_text, intent, entry)
        if score > 0:
            enriched = dict(entry)
            enriched["score"] = score
            scored_entries.append(enriched)

    scored_entries.sort(key=lambda item: (-item["score"], item["title"].lower(), item["key"]))
    return intent, scored_entries[:limit]
