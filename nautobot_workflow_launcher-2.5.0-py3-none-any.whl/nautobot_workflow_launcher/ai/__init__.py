"""AI assistant services for workflow discovery, planning, and approval."""
