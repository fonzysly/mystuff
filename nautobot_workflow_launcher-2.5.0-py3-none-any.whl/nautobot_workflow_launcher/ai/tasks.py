"""Celery tasks for asynchronous AI provider interactions."""

from celery.exceptions import CeleryError
from nautobot.core.celery import app

from .llm import UnavailableLLMProvider, complete_json_for_role, get_llm_provider


@app.task
def complete_json_task(role, prompt, context=None):
    """Execute one structured LLM completion asynchronously for the configured role."""
    return complete_json_for_role(role, prompt, context=context)


def schedule_complete_json(role, prompt, context=None):
    """Queue a structured completion task when the role is configured."""
    provider = get_llm_provider(role)
    if isinstance(provider, UnavailableLLMProvider):
        return None
    try:
        return complete_json_task.delay(role, prompt, context=context).id
    except CeleryError:
        return None


def get_complete_json_task_result(task_id):
    """Return the state and result of a queued structured completion task."""
    async_result = app.AsyncResult(task_id)
    state = str(async_result.state or "PENDING")
    if not async_result.ready():
        return {"ready": False, "state": state}
    if async_result.successful():
        return {"ready": True, "state": state, "result": async_result.result}
    return {"ready": True, "state": state, "error": str(async_result.result)}
