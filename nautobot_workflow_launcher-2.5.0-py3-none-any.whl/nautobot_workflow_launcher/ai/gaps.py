"""Capability gap persistence helpers."""

from __future__ import annotations

from nautobot_workflow_launcher.models import CapabilityGap


def record_capability_gap(user, request_text, capability_name):
    """Create or update an aggregated capability-gap record."""
    gap, created = CapabilityGap.objects.get_or_create(
        capability_name=capability_name,
        defaults={
            "requested_by": user,
            "request_text": request_text,
        },
    )
    if not created:
        gap.frequency += 1
        gap.requested_by = user
        gap.request_text = request_text
        gap.save(update_fields=["frequency", "requested_by", "request_text", "last_seen"])
    return gap


def serialize_gap(gap):
    """Serialize a capability gap for JSON responses."""
    return {
        "id": str(gap.pk),
        "capability_name": gap.capability_name,
        "request_text": gap.request_text,
        "frequency": gap.frequency,
        "first_seen": gap.first_seen.isoformat() if gap.first_seen else None,
        "last_seen": gap.last_seen.isoformat() if gap.last_seen else None,
        "status": gap.status,
    }
