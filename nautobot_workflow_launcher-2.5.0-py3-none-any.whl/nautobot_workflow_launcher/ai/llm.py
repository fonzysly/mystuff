"""LLM provider abstraction and ExternalIntegration-backed provider resolution."""

from __future__ import annotations

import json

import requests
from django.conf import settings
from nautobot.extras.choices import SecretsGroupAccessTypeChoices, SecretsGroupSecretTypeChoices
from nautobot.extras.models import ExternalIntegration, SecretsGroupAssociation

PLUGIN_CFG_KEY = "nautobot_workflow_launcher"
ROLE_CONFIG_KEYS = {
    "planner": "planner_llm_integration",
    "summarizer": "summarizer_llm_integration",
    "embedding": "embedding_llm_integration",
}


class LLMConfigurationError(RuntimeError):
    """Raised when an LLM role or provider is misconfigured."""


def _plugin_cfg():
    return settings.PLUGINS_CONFIG.get(PLUGIN_CFG_KEY, {})


def _integration_name_for_role(role):
    config_key = ROLE_CONFIG_KEYS.get(role)
    if not config_key:
        raise LLMConfigurationError(f"Unsupported LLM role '{role}'.")
    return str(_plugin_cfg().get(config_key, "") or "").strip()


def _parse_secret_credentials(integration):
    if not getattr(integration, "secrets_group", None):
        return {}

    secrets = {}
    try:
        username = integration.secrets_group.get_secret_value(
            access_type=SecretsGroupAccessTypeChoices.TYPE_GENERIC,
            secret_type=SecretsGroupSecretTypeChoices.TYPE_USERNAME,
        )
        if username:
            secrets["username"] = username
    except SecretsGroupAssociation.DoesNotExist:
        pass

    try:
        password = integration.secrets_group.get_secret_value(
            access_type=SecretsGroupAccessTypeChoices.TYPE_GENERIC,
            secret_type=SecretsGroupSecretTypeChoices.TYPE_PASSWORD,
        )
        if password:
            secrets["password"] = password
    except SecretsGroupAssociation.DoesNotExist:
        pass

    return secrets


def _parse_json_content(content):
    if isinstance(content, dict):
        return content
    if not isinstance(content, str):
        raise RuntimeError("LLM response did not contain JSON content.")
    try:
        return json.loads(content)
    except json.JSONDecodeError as exc:
        raise RuntimeError("LLM response content was not valid JSON.") from exc


class LLMProvider:
    """Abstract provider interface for future model-backed AI tasks."""

    provider_name = "generic"

    def __init__(self, integration=None, config=None, credentials=None):
        """Store provider integration metadata and request defaults."""
        self.integration = integration
        self.config = config or {}
        self.credentials = credentials or {}
        self.timeout = int(_plugin_cfg().get("llm_timeout_seconds", 30) or 30)

    def complete_json(self, prompt, context=None):
        """Return a structured completion result."""
        raise NotImplementedError()


class HTTPLLMProvider(LLMProvider):
    """Base class for HTTP-backed model providers."""

    def complete_json(self, prompt, context=None):
        """Require subclasses to implement structured JSON completion."""
        raise NotImplementedError()

    def _base_url(self):
        return str(self.config.get("api_base") or getattr(self.integration, "remote_url", "") or "").rstrip("/")

    def _model(self):
        model = self.config.get("model")
        if not model:
            raise LLMConfigurationError(
                f"LLM ExternalIntegration '{self.integration.name}' is missing a model in extra_config."
            )
        return model

    def _temperature(self):
        return float(self.config.get("temperature", 0.2))

    def _max_tokens(self):
        return int(self.config.get("max_tokens", 4000))

    def _verify_ssl(self):
        return getattr(self.integration, "verify_ssl", True)

    def _request(self, method, url, **kwargs):
        response = requests.request(method, url, timeout=self.timeout, verify=self._verify_ssl(), **kwargs)
        response.raise_for_status()
        return response.json()


class OpenAIProvider(HTTPLLMProvider):
    """Provider for OpenAI-compatible chat completion endpoints."""

    provider_name = "openai"

    def _headers(self):
        api_key = self.credentials.get("password")
        if not api_key:
            raise LLMConfigurationError(
                f"LLM ExternalIntegration '{self.integration.name}' requires the API key in the secrets-group password field."
            )
        return {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

    def complete_json(self, prompt, context=None):
        """Submit an OpenAI-compatible chat completion and parse JSON output."""
        payload = {
            "model": self._model(),
            "temperature": self._temperature(),
            "max_tokens": self._max_tokens(),
            "messages": [
                {
                    "role": "system",
                    "content": "Return only valid JSON matching the caller's requested structure.",
                },
                {
                    "role": "user",
                    "content": json.dumps({"prompt": prompt, "context": context or {}}, default=str),
                },
            ],
            "response_format": {"type": "json_object"},
        }
        data = self._request("POST", f"{self._base_url()}/chat/completions", headers=self._headers(), json=payload)
        message = ((data.get("choices") or [{}])[0].get("message") or {}).get("content")
        return _parse_json_content(message)


class AzureOpenAIProvider(OpenAIProvider):
    """Provider for Azure OpenAI deployments."""

    provider_name = "azure_openai"

    def _headers(self):
        api_key = self.credentials.get("password")
        if not api_key:
            raise LLMConfigurationError(
                f"LLM ExternalIntegration '{self.integration.name}' requires the API key in the secrets-group password field."
            )
        return {
            "api-key": api_key,
            "Content-Type": "application/json",
        }

    def complete_json(self, prompt, context=None):
        """Submit a JSON-formatted completion to an Azure OpenAI deployment."""
        deployment = self.config.get("deployment") or self._model()
        api_version = self.config.get("api_version", "2024-02-15-preview")
        payload = {
            "temperature": self._temperature(),
            "max_tokens": self._max_tokens(),
            "messages": [
                {
                    "role": "system",
                    "content": "Return only valid JSON matching the caller's requested structure.",
                },
                {
                    "role": "user",
                    "content": json.dumps({"prompt": prompt, "context": context or {}}, default=str),
                },
            ],
            "response_format": {"type": "json_object"},
        }
        url = f"{self._base_url()}/openai/deployments/{deployment}/chat/completions?api-version={api_version}"
        data = self._request("POST", url, headers=self._headers(), json=payload)
        message = ((data.get("choices") or [{}])[0].get("message") or {}).get("content")
        return _parse_json_content(message)


class AnthropicProvider(HTTPLLMProvider):
    """Provider for Anthropic message endpoints."""

    provider_name = "anthropic"

    def _headers(self):
        api_key = self.credentials.get("password")
        if not api_key:
            raise LLMConfigurationError(
                f"LLM ExternalIntegration '{self.integration.name}' requires the API key in the secrets-group password field."
            )
        return {
            "x-api-key": api_key,
            "anthropic-version": str(self.config.get("anthropic_version", "2023-06-01")),
            "Content-Type": "application/json",
        }

    def complete_json(self, prompt, context=None):
        """Submit a JSON-formatted completion to the Anthropic messages API."""
        payload = {
            "model": self._model(),
            "temperature": self._temperature(),
            "max_tokens": self._max_tokens(),
            "system": "Return only valid JSON matching the caller's requested structure.",
            "messages": [
                {
                    "role": "user",
                    "content": json.dumps({"prompt": prompt, "context": context or {}}, default=str),
                }
            ],
        }
        data = self._request("POST", f"{self._base_url()}/messages", headers=self._headers(), json=payload)
        content = (data.get("content") or [{}])[0].get("text")
        return _parse_json_content(content)


class OllamaProvider(HTTPLLMProvider):
    """Provider for Ollama generate endpoints."""

    provider_name = "ollama"

    def complete_json(self, prompt, context=None):
        """Submit a JSON-formatted completion to an Ollama generate endpoint."""
        payload = {
            "model": self._model(),
            "format": "json",
            "stream": False,
            "options": {
                "temperature": self._temperature(),
            },
            "prompt": json.dumps({"prompt": prompt, "context": context or {}}, default=str),
        }
        data = self._request("POST", f"{self._base_url()}/api/generate", json=payload)
        return _parse_json_content(data.get("response"))


class VLLMProvider(OpenAIProvider):
    """Provider for vLLM OpenAI-compatible endpoints."""

    provider_name = "vllm"


PROVIDER_CLASSES = {
    OpenAIProvider.provider_name: OpenAIProvider,
    AnthropicProvider.provider_name: AnthropicProvider,
    AzureOpenAIProvider.provider_name: AzureOpenAIProvider,
    OllamaProvider.provider_name: OllamaProvider,
    VLLMProvider.provider_name: VLLMProvider,
}


def get_llm_provider(role="planner"):
    """Resolve and instantiate the configured provider for an AI role."""
    integration_name = _integration_name_for_role(role)
    if not integration_name:
        return UnavailableLLMProvider()

    integration = ExternalIntegration.objects.get(name=integration_name)
    config = getattr(integration, "extra_config", None) or {}
    provider_name = str(config.get("provider") or "").strip().lower()
    if not provider_name:
        raise LLMConfigurationError(
            f"LLM ExternalIntegration '{integration.name}' is missing a provider in extra_config."
        )

    provider_class = PROVIDER_CLASSES.get(provider_name)
    if not provider_class:
        supported = ", ".join(sorted(PROVIDER_CLASSES))
        raise LLMConfigurationError(
            f"Unsupported LLM provider '{provider_name}' on ExternalIntegration '{integration.name}'. Supported providers: {supported}."
        )

    return provider_class(integration=integration, config=config, credentials=_parse_secret_credentials(integration))


def complete_json_for_role(role, prompt, context=None):
    """Convenience wrapper that executes a structured completion for one AI role."""
    provider = get_llm_provider(role)
    return provider.complete_json(prompt, context=context)


class UnavailableLLMProvider(LLMProvider):
    """Fallback provider used until external LLM integrations are configured."""

    def complete_json(self, prompt, context=None):
        """Reject model-backed requests until an integration is configured."""
        raise RuntimeError("No LLM provider is configured for this deployment.")
