"""Operational metrics for the AI assistant."""

from __future__ import annotations

from django.db.models import Count

from nautobot_workflow_launcher.models import AIConversation, CapabilityGap


def build_metrics_payload():
    """Return lightweight AI-assistant metrics for reporting endpoints."""
    top_gaps = list(
        CapabilityGap.objects.values("capability_name", "status")
        .annotate(frequency=Count("id"))
        .order_by("-frequency")[:5]
    )
    return {
        "total_conversations": AIConversation.objects.count(),
        "active_conversations": AIConversation.objects.exclude(status="executed").count(),
        "ready_for_approval": AIConversation.objects.filter(status="ready").count(),
        "executed_conversations": AIConversation.objects.filter(status="executed").count(),
        "total_capability_gaps": CapabilityGap.objects.count(),
        "new_capability_gaps": CapabilityGap.objects.filter(status="new").count(),
        "top_gaps": top_gaps,
    }
