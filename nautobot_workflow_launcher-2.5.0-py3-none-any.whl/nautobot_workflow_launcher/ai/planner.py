"""Rule-based planner for workflow discovery and approval-safe execution plans."""

from __future__ import annotations

import logging
import re

from .catalog import combine_risk_levels
from .llm import LLMConfigurationError, complete_json_for_role
from .proposals import build_workflow_proposal, infer_capability_name
from .rag import classify_intent, retrieve_candidate_workflows

CHANGE_RE = re.compile(r"\b(CHG\d+)\b", re.IGNORECASE)
KV_RE = re.compile(r"\b([a-zA-Z][a-zA-Z0-9_-]*)\s*=\s*(.+?)(?=\s+[a-zA-Z][a-zA-Z0-9_-]*\s*=|$)")
NUMBER_RE = re.compile(r"\b(\d{1,6})\b")
SITE_RE = re.compile(r"\bin\s+([A-Za-z][A-Za-z0-9_-]*(?:\s+[A-Za-z][A-Za-z0-9_-]*)?)")
HOST_RE = re.compile(r"\b([A-Za-z]{2,}[A-Za-z0-9_-]*-[A-Za-z0-9_-]+)\b")

logger = logging.getLogger(__name__)


def _normalize_key(text):
    return str(text or "").strip().lower().replace("-", "_").replace(" ", "_")


def _extract_explicit_assignments(message_text):
    assignments = {}
    for raw_key, raw_value in KV_RE.findall(message_text or ""):
        assignments[_normalize_key(raw_key)] = raw_value.strip().strip("\"'")
    return assignments


def _infer_input_value(message_text, input_spec):
    lowered = (message_text or "").lower()
    key = input_spec["key"].lower()
    label = input_spec["label"].lower()

    ticket_match = CHANGE_RE.search(message_text or "")
    if ticket_match and any(token in f"{key} {label}" for token in ["change", "ticket"]):
        return ticket_match.group(1).upper()

    if any(token in f"{key} {label}" for token in ["site", "location"]):
        match = SITE_RE.search(message_text or "")
        if match:
            return match.group(1).strip()

    if any(token in f"{key} {label}" for token in ["device", "hostname", "switch", "router", "firewall"]):
        match = HOST_RE.search(message_text or "")
        if match:
            return match.group(1)

    if any(token in f"{key} {label}" for token in ["vlan", "id", "number", "port", "asn"]):
        match = NUMBER_RE.search(message_text or "")
        if match:
            return match.group(1)

    if input_spec.get("choices"):
        for choice in input_spec["choices"]:
            value = str(choice.get("value", ""))
            label_value = str(choice.get("label", value))
            if value.lower() in lowered or label_value.lower() in lowered:
                return value

    return None


def _resolve_step_inputs(step, message_text, collected_inputs):
    resolved_inputs = {}
    missing_inputs = []
    aliases = {_normalize_key(item["label"]): item["key"] for item in step.get("inputs", [])}

    for input_spec in step.get("inputs", []):
        key = input_spec["key"]
        normalized_key = _normalize_key(key)
        value = collected_inputs.get(normalized_key)
        if value in (None, ""):
            label_key = _normalize_key(input_spec["label"])
            value = collected_inputs.get(label_key)
        if value in (None, ""):
            value = collected_inputs.get(aliases.get(label_key, "")) if input_spec.get("label") else None
        if value in (None, ""):
            value = _infer_input_value(message_text, input_spec)
        if value not in (None, ""):
            resolved_inputs[key] = value
            collected_inputs[normalized_key] = value
        elif input_spec.get("required"):
            missing_inputs.append({"key": key, "label": input_spec["label"], "type": input_spec["type"]})

    return resolved_inputs, missing_inputs


def _build_plan_steps(request_text, candidates, conversation_state):
    collected_inputs = dict(conversation_state.get("collected_inputs", {}))
    collected_inputs.update(_extract_explicit_assignments(request_text))

    plan_candidates = list(candidates)
    if len(plan_candidates) > 1 and plan_candidates[0]["score"] >= 8:
        top_score = plan_candidates[0]["score"]
        composable_candidates = [
            item for item in plan_candidates if item.get("composable") and item["score"] >= max(4, top_score - 3)
        ]
        if len(composable_candidates) > 1:
            plan_candidates = composable_candidates[:3]
        else:
            plan_candidates = plan_candidates[:1]
    else:
        plan_candidates = plan_candidates[:1]

    steps = []
    all_missing = []
    total_duration = 0
    risk_levels = []
    for index, candidate in enumerate(plan_candidates, start=1):
        resolved_inputs, missing_inputs = _resolve_step_inputs(candidate, request_text, collected_inputs)
        total_duration += int(candidate.get("estimated_runtime_minutes") or 0)
        risk_levels.append(candidate.get("risk_level"))
        steps.append(
            {
                "sequence": index,
                "workflow_id": candidate["workflow_id"],
                "workflow_key": candidate["key"],
                "workflow_title": candidate["title"],
                "description": candidate.get("description", ""),
                "launch_url": candidate["launch_url"],
                "risk_level": candidate.get("risk_level", "medium"),
                "estimated_runtime_minutes": int(candidate.get("estimated_runtime_minutes") or 0),
                "collected_inputs": resolved_inputs,
                "missing_inputs": missing_inputs,
                "required_inputs": candidate.get("required_inputs", []),
            }
        )
        all_missing.extend(missing_inputs)

    unique_missing = []
    seen = set()
    for missing_input in all_missing:
        token = (missing_input["key"], missing_input["label"])
        if token in seen:
            continue
        seen.add(token)
        unique_missing.append(missing_input)

    return {
        "collected_inputs": collected_inputs,
        "steps": steps,
        "missing_inputs": unique_missing,
        "estimated_duration_minutes": total_duration,
        "risk_level": combine_risk_levels(*risk_levels),
    }


def _rerank_candidates_with_llm(request_text, candidates):
    if len(candidates) < 2:
        return candidates, None

    try:
        response = complete_json_for_role(
            "planner",
            "Choose the best existing workflow-backed candidate order for this request. "
            "Only use workflow keys from the provided candidate list.",
            context={
                "request_text": request_text,
                "candidates": [
                    {
                        "key": candidate["key"],
                        "title": candidate["title"],
                        "description": candidate.get("description", ""),
                        "required_inputs": candidate.get("required_inputs", []),
                        "score": candidate.get("score", 0),
                    }
                    for candidate in candidates[:5]
                ],
            },
        )
    except (LLMConfigurationError, RuntimeError, ValueError) as exc:
        logger.warning("Planner LLM rerank unavailable: %s", exc)
        return candidates, None

    selected_keys = response.get("selected_workflow_keys") or response.get("workflow_keys") or []
    if not isinstance(selected_keys, list):
        return candidates, None

    candidate_map = {candidate["key"]: candidate for candidate in candidates}
    ordered = []
    seen = set()
    for key in selected_keys:
        if key in candidate_map and key not in seen:
            ordered.append(candidate_map[key])
            seen.add(key)

    if not ordered:
        return candidates, response.get("reason")

    ordered.extend(candidate for candidate in candidates if candidate["key"] not in seen)
    return ordered, response.get("reason")


def build_plan(request_text, catalog_entries, conversation_state=None, allow_llm=True):
    """Build an approval-gated execution plan for a user request."""
    conversation_state = conversation_state or {}
    intent = classify_intent(request_text)
    _, candidates = retrieve_candidate_workflows(request_text, catalog_entries)
    llm_reason = None
    if allow_llm:
        candidates, llm_reason = _rerank_candidates_with_llm(request_text, candidates)
    if not candidates or candidates[0]["score"] < 4:
        capability_name = infer_capability_name(request_text, intent=intent)
        return {
            "kind": "gap",
            "intent": intent,
            "confidence": 0.0,
            "requires_approval": False,
            "approval_ready": False,
            "executable": False,
            "collected_inputs": dict(conversation_state.get("collected_inputs", {})),
            "recommendations": [],
            "missing_inputs": [],
            "proposal": build_workflow_proposal(request_text, intent=intent),
            "gap": {
                "capability_name": capability_name,
                "request_text": request_text,
            },
            "summary": "No executable workflow or workflow composition matched this request.",
            "llm_reasoning": llm_reason,
        }

    plan_details = _build_plan_steps(request_text, candidates, conversation_state)
    top_score = candidates[0]["score"]
    confidence = min(0.99, round(top_score / 14.0, 2))
    return {
        "kind": "workflow_plan",
        "intent": intent,
        "confidence": confidence,
        "requires_approval": True,
        "approval_ready": not plan_details["missing_inputs"],
        "executable": True,
        "recommendations": [
            {
                "workflow_key": candidate["key"],
                "workflow_title": candidate["title"],
                "score": candidate["score"],
            }
            for candidate in candidates
        ],
        "steps": plan_details["steps"],
        "missing_inputs": plan_details["missing_inputs"],
        "collected_inputs": plan_details["collected_inputs"],
        "estimated_duration_minutes": plan_details["estimated_duration_minutes"],
        "risk_level": plan_details["risk_level"],
        "llm_reasoning": llm_reason,
        "summary": "A workflow-backed plan is available for approval."
        if not plan_details["missing_inputs"]
        else "Additional inputs are required before approval.",
    }
