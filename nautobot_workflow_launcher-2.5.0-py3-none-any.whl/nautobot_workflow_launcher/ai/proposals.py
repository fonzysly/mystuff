"""Proposal generation for unsupported workflow requests."""

from __future__ import annotations

import re

from django.utils.text import slugify


def infer_capability_name(request_text, intent="general"):
    """Generate a stable capability identifier from a request."""
    base = slugify(request_text or "requested capability").replace("-", "_")
    if not base:
        base = slugify(intent or "capability").replace("-", "_") or "capability_gap"
    return base[:50]


def _infer_proposal_inputs(request_text):
    inputs = []
    lowered = (request_text or "").lower()
    if re.search(r"\bchg\d+\b", lowered):
        inputs.append({"key": "change_ticket", "label": "Change Ticket"})
    if any(token in lowered for token in ["device", "switch", "router", "firewall"]):
        inputs.append({"key": "device", "label": "Device"})
    if "site" in lowered or re.search(r"\bin\s+[a-z]", lowered):
        inputs.append({"key": "site", "label": "Site"})
    if not inputs:
        inputs.append({"key": "target", "label": "Target"})
    return inputs


def build_workflow_proposal(request_text, intent="general"):
    """Create a non-executable workflow proposal for an unsupported request."""
    capability_name = infer_capability_name(request_text, intent=intent)
    return {
        "workflow_name": capability_name,
        "intent": intent,
        "inputs": _infer_proposal_inputs(request_text),
        "actions": [
            {"name": "analyze_request", "description": "Translate the requested outcome into automation steps."},
            {"name": "implement_change", "description": "Perform the operational changes required for the outcome."},
            {"name": "verify_result", "description": "Validate the target state after execution."},
        ],
        "executable": False,
    }
