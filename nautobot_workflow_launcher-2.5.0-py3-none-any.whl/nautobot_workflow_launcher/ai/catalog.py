"""Workflow catalog helpers for the AI assistant."""

from __future__ import annotations

from collections.abc import Iterable as IterableABC
from typing import Iterable

RISK_ORDER = {"low": 1, "medium": 2, "high": 3, "critical": 4}


def _workflow_ai_block(workflow):
    raw_definition = getattr(workflow, "raw_definition", {}) or {}
    return raw_definition.get("ai", {}) or {}


def _normalize_choices(choices):
    normalized = []
    for choice in choices or []:
        if isinstance(choice, dict):
            normalized.append({"value": choice.get("value"), "label": choice.get("label", choice.get("value"))})
        else:
            normalized.append({"value": choice, "label": choice})
    return normalized


def _serialize_input(workflow_input):
    return {
        "key": workflow_input.key,
        "label": workflow_input.label,
        "type": workflow_input.input_type,
        "required": bool(workflow_input.required),
        "choices": _normalize_choices(workflow_input.choices),
    }


def _schema_terms(inputs):
    terms = []
    for workflow_input in inputs:
        terms.extend([workflow_input["key"], workflow_input["label"], workflow_input["type"]])
        for choice in workflow_input.get("choices", []):
            terms.extend([choice.get("value"), choice.get("label")])
    return [str(term).strip() for term in terms if str(term or "").strip()]


def _history_examples(workflow):
    examples = []
    explicit_history = getattr(workflow, "ai_history_runs", None)
    if isinstance(explicit_history, IterableABC):
        for item in explicit_history:
            if isinstance(item, str) and item.strip():
                examples.append(item.strip())

    if examples:
        return examples[:3]

    history_manager = getattr(workflow, "workflowrun_set", None)
    if history_manager is None or not hasattr(history_manager, "filter"):
        return []

    try:
        recent_runs = history_manager.filter(status="success").order_by("-started")[:3]
    except Exception:  # noqa: BLE001
        return []

    for run in recent_runs:
        inputs = getattr(run, "inputs", {}) or {}
        if isinstance(inputs, dict) and inputs:
            rendered = " ".join(f"{key} {value}" for key, value in inputs.items() if value not in (None, ""))
            if rendered:
                examples.append(rendered)
    return examples[:3]


def serialize_workflow_catalog_entry(workflow):
    """Serialize a workflow into the normalized AI catalog shape."""
    ai_metadata = _workflow_ai_block(workflow)
    inputs = [_serialize_input(workflow_input) for workflow_input in workflow.inputs.all().order_by("order", "key")]
    estimated_runtime = ai_metadata.get("estimated_runtime_minutes")
    if estimated_runtime in (None, ""):
        estimated_runtime = workflow.manual_duration_minutes or 0

    aliases = [str(alias).strip() for alias in ai_metadata.get("aliases", []) if str(alias).strip()]
    examples = [str(example).strip() for example in ai_metadata.get("examples", []) if str(example).strip()]
    tags = [str(tag).strip() for tag in ai_metadata.get("tags", []) if str(tag).strip()]

    return {
        "workflow_id": str(workflow.pk),
        "key": workflow.key,
        "name": workflow.key,
        "title": workflow.name,
        "description": workflow.description,
        "category": ai_metadata.get("category") or workflow.category or "",
        "aliases": aliases,
        "examples": examples,
        "tags": tags,
        "risk_level": str(ai_metadata.get("risk_level", "medium")).lower(),
        "estimated_runtime_minutes": int(estimated_runtime or 0),
        "composable": bool(ai_metadata.get("composable", False)),
        "required_inputs": [item["key"] for item in inputs if item["required"]],
        "inputs": inputs,
        "schema_terms": _schema_terms(inputs),
        "history_examples": _history_examples(workflow),
        "launch_url": workflow.get_absolute_url(),
    }


def build_workflow_catalog(workflows: Iterable):
    """Build a normalized catalog for AI discovery and planning."""
    return [serialize_workflow_catalog_entry(workflow) for workflow in workflows]


def combine_risk_levels(*risk_levels):
    """Return the highest risk value from a list of risk labels."""
    resolved = "low"
    for risk_level in risk_levels:
        candidate = str(risk_level or "low").lower()
        if RISK_ORDER.get(candidate, 0) >= RISK_ORDER.get(resolved, 0):
            resolved = candidate
    return resolved
