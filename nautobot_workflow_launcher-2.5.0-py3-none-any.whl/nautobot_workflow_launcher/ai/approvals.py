"""Approval-gated plan execution for the AI assistant."""

from __future__ import annotations

from django.utils import timezone

from nautobot_workflow_launcher.ai.llm import LLMConfigurationError, complete_json_for_role
from nautobot_workflow_launcher.ai.servicenow import (
    ServiceNowConfigurationError,
    update_change_for_conversation,
    validate_change_for_execution,
)
from nautobot_workflow_launcher.ai.tasks import schedule_complete_json
from nautobot_workflow_launcher.executors import run_workflow
from nautobot_workflow_launcher.models import AIConversationMessage, Workflow, WorkflowRun


def _fallback_execution_summary(runs):
    success_count = sum(1 for run in runs if run.get("status") == "success")
    failed_count = sum(1 for run in runs if run.get("status") == "failed")
    partial_count = sum(1 for run in runs if run.get("status") not in {"success", "failed"})
    workflow_titles = ", ".join(run.get("workflow_title", run.get("workflow_key", "workflow")) for run in runs)
    parts = [f"Executed {len(runs)} workflow(s): {workflow_titles}."]
    parts.append(f"Successful: {success_count}.")
    if failed_count:
        parts.append(f"Failed: {failed_count}.")
    if partial_count:
        parts.append(f"Other statuses: {partial_count}.")
    return " ".join(parts)


def summarize_execution_runs(runs):
    """Prepare a concise execution summary, optionally using the summarizer LLM role."""
    fallback = _fallback_execution_summary(runs)
    try:
        response = complete_json_for_role(
            "summarizer",
            "Summarize the executed workflow runs for an operator-facing result message. Return JSON.",
            context={"runs": runs, "fallback_summary": fallback},
        )
    except (LLMConfigurationError, RuntimeError, ValueError):
        return fallback

    summary = response.get("summary") if isinstance(response, dict) else None
    return summary or fallback


def execute_approved_plan(conversation):
    """Execute the current approved plan by delegating to Workflow Launcher."""
    plan = (conversation.state or {}).get("plan") or {}
    if plan.get("kind") != "workflow_plan":
        raise ValueError("No executable workflow plan is available for approval.")
    if plan.get("missing_inputs"):
        raise ValueError("Required inputs are still missing from the workflow plan.")
    service_now_warning = validate_change_for_execution((conversation.state or {}).get("service_now") or {})
    if service_now_warning:
        raise ValueError(service_now_warning)

    runs = []
    for step in plan.get("steps", []):
        workflow = Workflow.objects.get(pk=step["workflow_id"], enabled=True)
        run = WorkflowRun.objects.create(
            workflow=workflow,
            requested_by=conversation.requested_by,
            inputs=step.get("collected_inputs", {}),
            status="running",
        )
        run_workflow(workflow, conversation.requested_by, step.get("collected_inputs", {}), run)
        runs.append(
            {
                "workflow_key": workflow.key,
                "workflow_title": workflow.name,
                "run_id": str(run.pk),
                "run_url": run.get_absolute_url(),
                "status": run.status,
            }
        )

    conversation.status = "executed"
    conversation.approved_at = conversation.approved_at or timezone.now()
    conversation.executed_at = timezone.now()
    execution_summary = _fallback_execution_summary(runs)
    conversation.state = {
        **(conversation.state or {}),
        "execution": {"runs": runs, "summary": execution_summary},
    }
    summarizer_task_id = schedule_complete_json(
        "summarizer",
        "Summarize the executed workflow runs for an operator-facing result message. Return JSON.",
        context={"runs": runs, "fallback_summary": execution_summary},
    )
    if summarizer_task_id:
        conversation.state.setdefault("async_llm", {})["summarizer"] = {
            "task_id": summarizer_task_id,
            "status": "pending",
        }
        conversation.state["execution"]["summary_pending"] = True
    try:
        service_now_update = update_change_for_conversation(conversation, runs, execution_summary)
    except (ServiceNowConfigurationError, RuntimeError, ValueError) as exc:
        conversation.state["execution"]["service_now_warning"] = str(exc)
    else:
        if service_now_update:
            conversation.state["execution"]["service_now_update"] = service_now_update
    conversation.save(update_fields=["status", "approved_at", "executed_at", "state"])
    AIConversationMessage.objects.create(
        conversation=conversation,
        role="assistant",
        content=conversation.state["execution"]["summary"],
        payload=conversation.state["execution"],
    )
    return runs
