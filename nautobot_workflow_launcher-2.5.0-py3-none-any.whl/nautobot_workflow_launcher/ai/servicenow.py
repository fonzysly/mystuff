"""Read-only ServiceNow integration helpers for change-governed workflows."""

from __future__ import annotations

import re

import requests
from django.conf import settings
from django.utils.module_loading import import_string
from nautobot.extras.choices import SecretsGroupAccessTypeChoices, SecretsGroupSecretTypeChoices
from nautobot.extras.models import ExternalIntegration, Job, SecretsGroupAssociation

PLUGIN_CFG_KEY = "nautobot_workflow_launcher"
CHANGE_NUMBER_RE = re.compile(r"\b(CHG\d+)\b", re.IGNORECASE)
KV_RE = re.compile(r"\b([a-zA-Z][a-zA-Z0-9_-]*)\s*=\s*(.+?)(?=\s+[a-zA-Z][a-zA-Z0-9_-]*\s*=|$)")
DEFAULT_EXECUTION_READY_STATES = ("scheduled", "implement", "implementation", "authorized", "approved")
CHANGE_DRAFT_FIELDS = (
    {"key": "assignment_group", "label": "Assignment Group"},
    {"key": "implementation_window", "label": "Implementation Window"},
    {"key": "backout_plan", "label": "Backout Plan"},
)
DEFAULT_RELATED_CI_FIELDS = ("cmdb_ci", "affected_ci", "affected_cis", "u_related_cis", "cis")
CHANGE_DRAFT_ALIASES = {
    "assignment_group": "assignment_group",
    "group": "assignment_group",
    "implementation_window": "implementation_window",
    "window": "implementation_window",
    "change_window": "implementation_window",
    "backout_plan": "backout_plan",
    "rollback_plan": "backout_plan",
    "backout": "backout_plan",
    "risk": "risk",
    "short_description": "short_description",
    "description": "description",
}


class ServiceNowConfigurationError(RuntimeError):
    """Raised when the ServiceNow integration is missing required configuration."""


def _normalize_key(text):
    return str(text or "").strip().lower().replace("-", "_").replace(" ", "_")


def _extract_field_assignments(message_text):
    assignments = {}
    for raw_key, raw_value in KV_RE.findall(message_text or ""):
        normalized = CHANGE_DRAFT_ALIASES.get(_normalize_key(raw_key))
        if normalized:
            assignments[normalized] = raw_value.strip().strip("\"'")
    return assignments


def _plugin_cfg():
    return settings.PLUGINS_CONFIG.get(PLUGIN_CFG_KEY, {})


def extract_change_number(text):
    """Extract the first ServiceNow change number from freeform text."""
    match = CHANGE_NUMBER_RE.search(str(text or ""))
    return match.group(1).upper() if match else None


def get_integration():
    """Return the configured ServiceNow ExternalIntegration or None."""
    name = str(_plugin_cfg().get("servicenow_external_integration_name", "") or "").strip()
    if not name:
        return None
    return ExternalIntegration.objects.get(name=name)


def _parse_credentials(integration):
    if not getattr(integration, "secrets_group", None):
        return {}

    credentials = {}
    try:
        credentials["username"] = integration.secrets_group.get_secret_value(
            access_type=SecretsGroupAccessTypeChoices.TYPE_GENERIC,
            secret_type=SecretsGroupSecretTypeChoices.TYPE_USERNAME,
        )
    except SecretsGroupAssociation.DoesNotExist:
        pass

    try:
        credentials["password"] = integration.secrets_group.get_secret_value(
            access_type=SecretsGroupAccessTypeChoices.TYPE_GENERIC,
            secret_type=SecretsGroupSecretTypeChoices.TYPE_PASSWORD,
        )
    except SecretsGroupAssociation.DoesNotExist:
        pass

    return credentials


def _request_kwargs(integration, extra_config):
    credentials = _parse_credentials(integration)
    headers = {"Accept": "application/json"}
    kwargs = {
        "headers": headers,
        "verify": getattr(integration, "verify_ssl", True),
    }
    if credentials.get("username") and credentials.get("password"):
        kwargs["auth"] = (credentials["username"], credentials["password"])
    elif credentials.get("password"):
        headers["Authorization"] = f"Bearer {credentials['password']}"

    token_header = extra_config.get("token_header")
    if token_header and credentials.get("password"):
        headers[token_header] = credentials["password"]

    return kwargs


def _request_timeout():
    return int(_plugin_cfg().get("llm_timeout_seconds", 30) or 30)


def _api_details(integration):
    extra_config = getattr(integration, "extra_config", None) or {}
    api_base = str(extra_config.get("api_base") or integration.remote_url or "").rstrip("/")
    if not api_base:
        raise ServiceNowConfigurationError(
            f"ServiceNow ExternalIntegration '{integration.name}' is missing a remote_url or extra_config.api_base."
        )
    return extra_config, api_base, str(extra_config.get("table_api_path", "/api/now/table")).rstrip("/")


def _display_value(value):
    if isinstance(value, dict):
        return value.get("display_value") or value.get("value") or value.get("name") or ""
    if isinstance(value, list):
        return ", ".join(str(_display_value(item)).strip() for item in value if str(_display_value(item)).strip())
    return str(value or "")


def _extract_related_cis(record, related_ci_fields=None):
    ci_values = []
    fields = related_ci_fields or DEFAULT_RELATED_CI_FIELDS
    for field in fields:
        raw = record.get(field)
        if raw in (None, "", []):
            continue
        if isinstance(raw, list):
            ci_values.extend(_display_value(item) for item in raw)
        else:
            rendered = _display_value(raw)
            if rendered:
                ci_values.extend(part.strip() for part in rendered.split(",") if part.strip())

    unique = []
    seen = set()
    for item in ci_values:
        token = str(item).strip()
        lowered = token.lower()
        if token and lowered not in seen:
            unique.append(token)
            seen.add(lowered)
    return unique


def get_configured_jobs(integration=None):
    """Resolve configured ServiceNow lifecycle jobs from ExternalIntegration extra_config."""
    integration = integration or get_integration()
    if integration is None:
        return {}

    job_paths = (getattr(integration, "extra_config", None) or {}).get("ai_assistant") or {}
    resolved = {}
    for action, class_path in job_paths.items():
        if not class_path:
            continue
        try:
            module_name, job_class_name = class_path.rsplit(".", 1)
        except ValueError as exc:
            raise ServiceNowConfigurationError(
                f"Invalid ServiceNow job class path '{class_path}' for action '{action}'."
            ) from exc
        try:
            resolved[action] = Job.objects.get(module_name=module_name, job_class_name=job_class_name)
        except Job.DoesNotExist as exc:
            raise ServiceNowConfigurationError(
                f"Configured ServiceNow job '{class_path}' for action '{action}' was not found in the Nautobot Job registry."
            ) from exc
    return resolved


def fetch_change_record(change_number, integration=None):
    """Fetch one change record from ServiceNow using the configured ExternalIntegration."""
    integration = integration or get_integration()
    if integration is None:
        raise ServiceNowConfigurationError("No ServiceNow ExternalIntegration is configured for this deployment.")

    extra_config, api_base, path = _api_details(integration)
    table_name = extra_config.get("change_table", "change_request")
    fields = extra_config.get(
        "change_fields",
        [
            "number",
            "short_description",
            "description",
            "implementation_plan",
            "risk",
            "impact",
            "state",
            "assignment_group",
            "start_date",
            "end_date",
            *DEFAULT_RELATED_CI_FIELDS,
        ],
    )

    response = requests.get(
        f"{api_base}{path}/{table_name}",
        params={
            "sysparm_query": f"number={change_number}",
            "sysparm_limit": 1,
            "sysparm_display_value": "true",
            "sysparm_fields": ",".join(fields),
        },
        timeout=_request_timeout(),
        **_request_kwargs(integration, extra_config),
    )
    response.raise_for_status()
    payload = response.json()
    records = payload.get("result") or []
    if not records:
        raise LookupError(f"ServiceNow change '{change_number}' was not found.")

    record = dict(records[0])
    record["change_number"] = record.get("number") or change_number
    return record


def search_change_records(  # pylint: disable=too-many-arguments
    keyword="", requested_by="", assignment_group="", start="", end="", limit=10, integration=None
):
    """Search ServiceNow changes using configured query capabilities."""
    integration = integration or get_integration()
    if integration is None:
        raise ServiceNowConfigurationError("No ServiceNow ExternalIntegration is configured for this deployment.")

    extra_config, api_base, path = _api_details(integration)
    table_name = extra_config.get("change_table", "change_request")
    fields = extra_config.get(
        "change_fields",
        [
            "number",
            "short_description",
            "description",
            "implementation_plan",
            "risk",
            "impact",
            "state",
            "assignment_group",
            "requested_by",
            "start_date",
            "end_date",
            *DEFAULT_RELATED_CI_FIELDS,
        ],
    )

    clauses = []
    if keyword:
        keyword = str(keyword).strip()
        clauses.append(f"short_descriptionLIKE{keyword}^ORdescriptionLIKE{keyword}^ORimplementation_planLIKE{keyword}")
    if requested_by:
        clauses.append(f"requested_by.nameLIKE{str(requested_by).strip()}")
    if assignment_group:
        clauses.append(f"assignment_group.nameLIKE{str(assignment_group).strip()}")
    if start:
        clauses.append(f"start_date>={str(start).strip()}")
    if end:
        clauses.append(f"end_date<={str(end).strip()}")

    response = requests.get(
        f"{api_base}{path}/{table_name}",
        params={
            "sysparm_query": "^".join(clauses),
            "sysparm_limit": int(limit or 10),
            "sysparm_display_value": "true",
            "sysparm_fields": ",".join(fields),
        },
        timeout=_request_timeout(),
        **_request_kwargs(integration, extra_config),
    )
    response.raise_for_status()
    payload = response.json()
    records = payload.get("result") or []
    return [build_change_context(dict(record)) for record in records]


def build_change_context(record):
    """Normalize a change record into assistant planning context."""
    summary_parts = [
        record.get("short_description"),
        record.get("description"),
        record.get("implementation_plan"),
    ]
    summary_text = "\n".join(part.strip() for part in summary_parts if isinstance(part, str) and part.strip())
    context = {
        "change_number": record.get("change_number") or record.get("number"),
        "state": record.get("state"),
        "risk": record.get("risk"),
        "impact": record.get("impact"),
        "assignment_group": _display_value(record.get("assignment_group")),
        "related_cis": _extract_related_cis(record),
        "summary_text": summary_text,
        "record": record,
    }
    warning = validate_change_for_execution(context)
    context["execution_ready"] = warning is None
    if warning:
        context["execution_warning"] = warning
    return context


def _configured_execution_ready_states(integration=None):
    integration = integration or get_integration()
    extra_config = getattr(integration, "extra_config", None) or {} if integration is not None else {}
    states = extra_config.get("execution_ready_states") or DEFAULT_EXECUTION_READY_STATES
    return tuple(str(state).strip().lower() for state in states if str(state).strip()) or DEFAULT_EXECUTION_READY_STATES


def validate_change_for_execution(change_context, integration=None):
    """Return a warning string when a change is not ready for execution, otherwise None."""
    if not change_context or not change_context.get("change_number"):
        return None
    if change_context.get("error"):
        return str(change_context["error"])

    # A change created through the configured Nautobot job may only have a returned
    # change number at this stage. Treat that explicit confirmation path as ready
    # unless a later read supplies a blocking state.
    if change_context.get("create_job_result") and not change_context.get("state"):
        return None

    state = str(change_context.get("state") or "").strip().lower()
    if not state:
        return f"ServiceNow change {change_context['change_number']} does not expose a usable state for execution validation."

    ready_states = _configured_execution_ready_states(integration=integration)
    if any(ready_state in state for ready_state in ready_states):
        return None

    return (
        f"ServiceNow change {change_context['change_number']} is in state '{change_context.get('state')}', "
        "which is not marked as execution-ready."
    )


def suggest_change_type(risk_level):
    """Infer a ServiceNow change type from workflow risk."""
    return "standard" if str(risk_level or "").lower() == "low" else "normal"


def build_change_payload(conversation, overrides=None, request_text=None, plan_override=None):
    """Build a draft payload for a ServiceNow create-change job."""
    state = conversation.state or {}
    plan = plan_override or state.get("plan") or {}
    service_now = state.get("service_now") or {}
    title = getattr(conversation, "title", "")
    latest_user_request = request_text or getattr(conversation, "latest_user_request", "")
    requested_by = getattr(getattr(conversation, "requested_by", None), "username", "")
    steps = plan.get("steps") or []
    implementation_lines = [
        f"{step['sequence']}. {step['workflow_title']}"
        for step in steps
        if step.get("sequence") is not None and step.get("workflow_title")
    ]
    payload = {
        "short_description": service_now.get("record", {}).get("short_description")
        or title
        or latest_user_request
        or "Workflow Launcher AI execution",
        "description": latest_user_request or title or "",
        "implementation_plan": "\n".join(implementation_lines),
        "risk": plan.get("risk_level") or service_now.get("risk") or "medium",
        "change_type": suggest_change_type(plan.get("risk_level")),
        "backout_plan": "Rollback through the corresponding Workflow Launcher recovery workflow or manual change plan.",
        "assignment_group": service_now.get("assignment_group") or "",
        "requested_by": requested_by,
    }
    if overrides:
        payload.update(overrides)
    return payload


def draft_change_for_conversation(conversation, request_text=None, plan_override=None, overrides=None):
    """Build and validate a draft ServiceNow change payload from conversation context and freeform input."""
    state = conversation.state or {}
    existing_draft = dict(state.get("service_now_draft", {}) or {})
    existing_payload = dict(existing_draft.get("payload", {}) or {})
    extracted_assignments = _extract_field_assignments(request_text)
    merged_overrides = {**existing_payload, **extracted_assignments}
    if overrides:
        merged_overrides.update(overrides)

    payload = build_change_payload(
        conversation,
        overrides=merged_overrides,
        request_text=request_text,
        plan_override=plan_override,
    )
    missing_fields = [field for field in CHANGE_DRAFT_FIELDS if not str(payload.get(field["key"], "") or "").strip()]
    return {
        "payload": payload,
        "missing_fields": missing_fields,
        "ready": not missing_fields,
    }


def _extract_change_number_from_result(result):
    if isinstance(result, dict):
        for key in ("change_number", "number", "id"):
            value = result.get(key)
            extracted = extract_change_number(value) if isinstance(value, str) else None
            if extracted:
                return extracted
        nested = result.get("result")
        if nested is not None:
            return _extract_change_number_from_result(nested)
        return None
    if isinstance(result, str):
        return extract_change_number(result)
    return None


def invoke_job(job_model, **kwargs):
    """Invoke a configured Nautobot Job class directly with structured kwargs."""
    job_class = import_string(job_model.class_path)
    job = job_class()
    return job.run(**kwargs)


def create_change_for_conversation(conversation, overrides=None):
    """Trigger the configured create-change job and return the stored change context."""
    job_model = get_configured_jobs().get("create_change_job")
    if job_model is None:
        raise ServiceNowConfigurationError("No create_change_job is configured for this deployment.")

    plan = (conversation.state or {}).get("plan") or {}
    if plan.get("kind") != "workflow_plan":
        raise ValueError("No workflow plan is available to draft a ServiceNow change.")

    draft = draft_change_for_conversation(conversation, plan_override=plan, overrides=overrides)
    if draft["missing_fields"]:
        labels = ", ".join(field["label"] for field in draft["missing_fields"])
        raise ValueError(f"ServiceNow change draft is missing: {labels}.")

    change_payload = draft["payload"]
    result = invoke_job(
        job_model,
        conversation_id=str(getattr(conversation, "pk", "")),
        request_text=conversation.latest_user_request,
        plan=plan,
        change_payload=change_payload,
    )
    change_number = _extract_change_number_from_result(result)
    if not change_number:
        raise RuntimeError("Configured create_change_job did not return a ServiceNow change number.")

    service_now = {**((conversation.state or {}).get("service_now") or {})}
    service_now.update(
        {
            "change_number": change_number,
            "draft_payload": change_payload,
            "create_job_result": result,
        }
    )
    return service_now


def update_change_for_conversation(conversation, runs, summary):
    """Trigger the configured update-change job with execution work notes."""
    service_now = dict((conversation.state or {}).get("service_now") or {})
    change_number = service_now.get("change_number")
    if not change_number:
        return None

    job_model = get_configured_jobs().get("update_change_job")
    if job_model is None:
        return None

    work_notes = {
        "summary": summary,
        "runs": runs,
        "status": "success" if all(run.get("status") == "success" for run in runs) else "failed",
    }
    result = invoke_job(
        job_model,
        conversation_id=str(getattr(conversation, "pk", "")),
        change_number=change_number,
        work_notes=work_notes,
        execution=(conversation.state or {}).get("execution") or {"runs": runs, "summary": summary},
    )
    return {"change_number": change_number, "update_job_result": result, "work_notes": work_notes}


def close_change_for_conversation(conversation, overrides=None):
    """Trigger the configured close-change job after successful execution."""
    service_now = dict((conversation.state or {}).get("service_now") or {})
    change_number = service_now.get("change_number")
    if not change_number:
        raise ValueError("No ServiceNow change is associated with this conversation.")

    execution = (conversation.state or {}).get("execution") or {}
    runs = execution.get("runs") or []
    if not runs:
        raise ValueError("No executed workflow runs are available for change closure.")
    if any(run.get("status") != "success" for run in runs):
        raise ValueError("ServiceNow changes can only be closed after all workflow runs succeed.")

    job_model = get_configured_jobs().get("close_change_job")
    if job_model is None:
        raise ServiceNowConfigurationError("No close_change_job is configured for this deployment.")

    close_notes = {"summary": execution.get("summary", ""), **(overrides or {})}
    result = invoke_job(
        job_model,
        conversation_id=str(getattr(conversation, "pk", "")),
        change_number=change_number,
        close_notes=close_notes,
        execution=execution,
    )
    service_now.update({"close_job_result": result, "close_notes": close_notes, "closed_change_number": change_number})
    return service_now


def is_available():
    """Return whether ServiceNow AI integration is configured."""
    try:
        return get_integration() is not None
    except ExternalIntegration.DoesNotExist:
        return False
