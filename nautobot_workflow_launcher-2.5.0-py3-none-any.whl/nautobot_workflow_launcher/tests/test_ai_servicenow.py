"""Focused tests for ServiceNow-backed AI context helpers."""

import unittest
from types import SimpleNamespace
from unittest.mock import patch

from nautobot_workflow_launcher.ai import servicenow


class _FakeSecretsGroup:
    def __init__(self, username=None, password=None):
        self.username = username
        self.password = password

    def get_secret_value(self, access_type=None, secret_type=None):
        if secret_type == "username":
            if self.username is None:
                raise servicenow.SecretsGroupAssociation.DoesNotExist()
            return self.username
        if secret_type == "password":
            if self.password is None:
                raise servicenow.SecretsGroupAssociation.DoesNotExist()
            return self.password
        raise servicenow.SecretsGroupAssociation.DoesNotExist()


class ServiceNowHelperTestCase(unittest.TestCase):
    """Validate ServiceNow configuration and change record helpers."""

    def test_extract_change_number(self):
        self.assertEqual(servicenow.extract_change_number("Use CHG0012345 as basis"), "CHG0012345")

    def test_fetch_change_record_uses_external_integration_configuration(self):
        integration = SimpleNamespace(
            name="ServiceNow Primary",
            remote_url="https://servicenow.example",
            verify_ssl=True,
            extra_config={"change_fields": ["number", "short_description", "implementation_plan", "state"]},
            secrets_group=_FakeSecretsGroup(username="api-user", password="api-pass"),
        )
        response = SimpleNamespace(
            json=lambda: {
                "result": [
                    {
                        "number": "CHG0012345",
                        "short_description": "Deploy VLAN 150",
                        "implementation_plan": "Create VLAN 150 in Amsterdam",
                        "state": "Scheduled",
                    }
                ]
            },
            raise_for_status=lambda: None,
        )

        with patch.object(servicenow.requests, "get", return_value=response) as mock_get:
            record = servicenow.fetch_change_record("CHG0012345", integration=integration)

        self.assertEqual(record["change_number"], "CHG0012345")
        self.assertEqual(mock_get.call_args.kwargs["auth"], ("api-user", "api-pass"))

    def test_build_change_context_combines_descriptive_fields(self):
        context = servicenow.build_change_context(
            {
                "number": "CHG0012345",
                "short_description": "Replace switch",
                "description": "Decommission AMS-SW-102",
                "implementation_plan": "Backup device and remove DNS.",
                "state": "Scheduled",
                "cmdb_ci": {"display_value": "AMS-SW-102"},
            }
        )

        self.assertEqual(context["change_number"], "CHG0012345")
        self.assertIn("Decommission AMS-SW-102", context["summary_text"])
        self.assertTrue(context["execution_ready"])
        self.assertEqual(context["related_cis"], ["AMS-SW-102"])

    def test_validate_change_for_execution_warns_for_non_ready_state(self):
        warning = servicenow.validate_change_for_execution({"change_number": "CHG0012345", "state": "Assess"})

        self.assertIn("not marked as execution-ready", warning)

    def test_search_change_records_builds_query_and_returns_contexts(self):
        integration = SimpleNamespace(
            name="ServiceNow Primary",
            remote_url="https://servicenow.example",
            verify_ssl=True,
            extra_config={},
            secrets_group=_FakeSecretsGroup(username="api-user", password="api-pass"),
        )
        response = SimpleNamespace(
            json=lambda: {
                "result": [
                    {
                        "number": "CHG0012345",
                        "short_description": "Deploy VLAN 150",
                        "description": "Create VLAN 150 in Amsterdam",
                        "implementation_plan": "Create VLAN 150 in Amsterdam",
                        "state": "Scheduled",
                        "assignment_group": {"display_value": "NetOps"},
                        "cmdb_ci": {"display_value": "AMS-SW-102"},
                    }
                ]
            },
            raise_for_status=lambda: None,
        )

        with patch.object(servicenow.requests, "get", return_value=response) as mock_get:
            results = servicenow.search_change_records(
                keyword="VLAN",
                requested_by="alice",
                assignment_group="NetOps",
                start="2026-06-01 00:00:00",
                end="2026-06-30 23:59:59",
                integration=integration,
            )

        self.assertEqual(results[0]["change_number"], "CHG0012345")
        self.assertEqual(results[0]["related_cis"], ["AMS-SW-102"])
        self.assertIn("requested_by.nameLIKEalice", mock_get.call_args.kwargs["params"]["sysparm_query"])

    def test_create_change_for_conversation_returns_change_number_from_job_result(self):
        conversation = SimpleNamespace(
            pk="11111111-1111-1111-1111-111111111111",
            title="Create VLAN",
            latest_user_request="Create VLAN 150 in Amsterdam",
            requested_by=SimpleNamespace(username="alice"),
            state={
                "plan": {
                    "kind": "workflow_plan",
                    "risk_level": "medium",
                    "steps": [{"sequence": 1, "workflow_title": "Create VLAN"}],
                },
                "service_now_draft": {
                    "payload": {
                        "assignment_group": "NetOps",
                        "implementation_window": "2026-06-04 22:00 UTC",
                        "backout_plan": "Rollback VLAN 150.",
                    }
                },
            },
        )
        job_model = SimpleNamespace(class_path="fake.jobs.CreateChange")
        with patch.object(
            servicenow, "get_configured_jobs", return_value={"create_change_job": job_model}
        ), patch.object(servicenow, "invoke_job", return_value={"change_number": "CHG0099999"}):
            result = servicenow.create_change_for_conversation(conversation)

        self.assertEqual(result["change_number"], "CHG0099999")
        self.assertEqual(result["draft_payload"]["assignment_group"], "NetOps")

    def test_draft_change_for_conversation_collects_assignments_from_message(self):
        conversation = SimpleNamespace(
            title="Create VLAN",
            latest_user_request="Create VLAN 150 in Amsterdam",
            requested_by=SimpleNamespace(username="alice"),
            state={
                "plan": {
                    "kind": "workflow_plan",
                    "risk_level": "medium",
                    "steps": [{"sequence": 1, "workflow_title": "Create VLAN"}],
                }
            },
        )

        draft = servicenow.draft_change_for_conversation(
            conversation,
            request_text="assignment_group=NetOps implementation_window=2026-06-04 backout_plan=Rollback VLAN 150",
            plan_override=conversation.state["plan"],
        )

        self.assertTrue(draft["ready"])
        self.assertEqual(draft["payload"]["assignment_group"], "NetOps")

    def test_create_change_for_conversation_requires_missing_draft_fields(self):
        conversation = SimpleNamespace(
            title="Create VLAN",
            latest_user_request="Create VLAN 150 in Amsterdam",
            requested_by=SimpleNamespace(username="alice"),
            state={
                "plan": {
                    "kind": "workflow_plan",
                    "risk_level": "medium",
                    "steps": [{"sequence": 1, "workflow_title": "Create VLAN"}],
                }
            },
        )

        with patch.object(servicenow, "get_configured_jobs", return_value={"create_change_job": SimpleNamespace()}):
            with self.assertRaises(ValueError):
                servicenow.create_change_for_conversation(conversation)

    def test_close_change_for_conversation_requires_all_success(self):
        conversation = SimpleNamespace(
            state={
                "service_now": {"change_number": "CHG0012345"},
                "execution": {
                    "summary": "Execution failed.",
                    "runs": [{"status": "failed", "workflow_title": "Create VLAN"}],
                },
            }
        )

        with self.assertRaises(ValueError):
            servicenow.close_change_for_conversation(conversation)
