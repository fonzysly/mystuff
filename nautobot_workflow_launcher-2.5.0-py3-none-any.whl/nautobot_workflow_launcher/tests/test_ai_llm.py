"""Focused tests for the AI provider integration layer."""

import unittest
from types import SimpleNamespace
from unittest.mock import patch

from nautobot_workflow_launcher.ai import llm


class _FakeSecretsGroup:
    def __init__(self, username=None, password=None):
        self.username = username
        self.password = password

    def get_secret_value(self, access_type=None, secret_type=None):
        if secret_type == "username":
            if self.username is None:
                raise llm.SecretsGroupAssociation.DoesNotExist()
            return self.username
        if secret_type == "password":
            if self.password is None:
                raise llm.SecretsGroupAssociation.DoesNotExist()
            return self.password
        raise llm.SecretsGroupAssociation.DoesNotExist()


class LLMProviderResolutionTestCase(unittest.TestCase):
    """Validate ExternalIntegration-backed provider resolution."""

    def test_get_llm_provider_returns_unavailable_without_configured_role(self):
        with patch.object(llm.settings, "PLUGINS_CONFIG", {"nautobot_workflow_launcher": {}}):
            provider = llm.get_llm_provider("planner")

        self.assertIsInstance(provider, llm.UnavailableLLMProvider)

    def test_get_llm_provider_builds_openai_provider_from_external_integration(self):
        integration = SimpleNamespace(
            name="OpenAI Primary",
            remote_url="https://api.openai.example/v1",
            verify_ssl=True,
            extra_config={"provider": "openai", "model": "gpt-4.1-mini", "temperature": 0.1},
            secrets_group=_FakeSecretsGroup(password="test-key"),
        )

        plugin_cfg = {"nautobot_workflow_launcher": {"planner_llm_integration": "OpenAI Primary"}}
        with patch.object(llm.settings, "PLUGINS_CONFIG", plugin_cfg), patch.object(
            llm.ExternalIntegration.objects, "get", return_value=integration
        ):
            provider = llm.get_llm_provider("planner")

        self.assertIsInstance(provider, llm.OpenAIProvider)
        self.assertEqual(provider.credentials["password"], "test-key")


class OpenAIProviderCompletionTestCase(unittest.TestCase):
    """Validate JSON completion handling for OpenAI-compatible providers."""

    def test_complete_json_parses_response_content(self):
        integration = SimpleNamespace(
            name="OpenAI Primary", remote_url="https://api.openai.example/v1", verify_ssl=True
        )
        provider = llm.OpenAIProvider(
            integration=integration,
            config={"provider": "openai", "model": "gpt-4.1-mini", "temperature": 0.2, "max_tokens": 1000},
            credentials={"password": "secret-key"},
        )

        response = SimpleNamespace(
            json=lambda: {"choices": [{"message": {"content": '{"summary": "ok"}'}}]},
            raise_for_status=lambda: None,
        )
        with patch.object(llm.requests, "request", return_value=response) as mock_request, patch.object(
            llm.settings, "PLUGINS_CONFIG", {"nautobot_workflow_launcher": {"llm_timeout_seconds": 15}}
        ):
            provider.timeout = 15
            payload = provider.complete_json("Summarize this", context={"workflow": "create_vlan"})

        self.assertEqual(payload, {"summary": "ok"})
        self.assertEqual(mock_request.call_args.kwargs["headers"]["Authorization"], "Bearer secret-key")
