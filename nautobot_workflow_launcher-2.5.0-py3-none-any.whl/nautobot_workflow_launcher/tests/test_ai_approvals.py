"""Focused tests for AI approval summaries."""

import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from nautobot_workflow_launcher.ai.approvals import execute_approved_plan, summarize_execution_runs


class ApprovalSummaryTestCase(unittest.TestCase):
    """Validate operator-facing execution summaries."""

    def test_summarize_execution_runs_uses_llm_summary_when_available(self):
        runs = [{"workflow_title": "Create VLAN", "workflow_key": "create_vlan", "status": "success"}]
        with patch(
            "nautobot_workflow_launcher.ai.approvals.complete_json_for_role",
            return_value={"summary": "Created VLAN successfully."},
        ):
            summary = summarize_execution_runs(runs)

        self.assertEqual(summary, "Created VLAN successfully.")

    def test_summarize_execution_runs_falls_back_without_llm(self):
        runs = [{"workflow_title": "Create VLAN", "workflow_key": "create_vlan", "status": "success"}]
        with patch(
            "nautobot_workflow_launcher.ai.approvals.complete_json_for_role",
            side_effect=RuntimeError("not configured"),
        ):
            summary = summarize_execution_runs(runs)

        self.assertIn("Executed 1 workflow", summary)

    def test_execute_approved_plan_records_servicenow_update_when_change_exists(self):
        workflow = SimpleNamespace(key="create_vlan", name="Create VLAN")
        run = SimpleNamespace(pk="run-1", status="success", get_absolute_url=lambda: "/runs/run-1/")
        conversation = SimpleNamespace(
            requested_by=SimpleNamespace(username="alice"),
            state={
                "plan": {
                    "kind": "workflow_plan",
                    "missing_inputs": [],
                    "steps": [{"workflow_id": "wf-1", "collected_inputs": {"site": "Amsterdam"}}],
                },
                "service_now": {"change_number": "CHG0012345", "state": "Scheduled"},
            },
            status="ready",
            approved_at=None,
            executed_at=None,
            save=MagicMock(),
        )

        with patch("nautobot_workflow_launcher.ai.approvals.Workflow.objects.get", return_value=workflow), patch(
            "nautobot_workflow_launcher.ai.approvals.WorkflowRun.objects.create", return_value=run
        ), patch("nautobot_workflow_launcher.ai.approvals.run_workflow"), patch(
            "nautobot_workflow_launcher.ai.approvals.schedule_complete_json", return_value="summary-task-1"
        ), patch(
            "nautobot_workflow_launcher.ai.approvals.update_change_for_conversation",
            return_value={"change_number": "CHG0012345", "update_job_result": {"ok": True}},
        ) as mock_update, patch("nautobot_workflow_launcher.ai.approvals.AIConversationMessage.objects.create"):
            execute_approved_plan(conversation)

        self.assertEqual(conversation.state["execution"]["service_now_update"]["change_number"], "CHG0012345")
        self.assertTrue(conversation.state["execution"]["summary_pending"])
        self.assertEqual(conversation.state["async_llm"]["summarizer"]["task_id"], "summary-task-1")
        mock_update.assert_called_once()

    def test_execute_approved_plan_blocks_non_ready_servicenow_change(self):
        conversation = SimpleNamespace(
            state={
                "plan": {"kind": "workflow_plan", "missing_inputs": [], "steps": []},
                "service_now": {"change_number": "CHG0012345", "state": "Assess"},
            }
        )

        with self.assertRaises(ValueError):
            execute_approved_plan(conversation)
