"""Focused tests for AI assistant cataloging and planning."""

import unittest
from types import SimpleNamespace
from unittest.mock import patch

from nautobot_workflow_launcher.ai.catalog import build_workflow_catalog
from nautobot_workflow_launcher.ai.planner import build_plan


class _FakeInputManager:
    def __init__(self, items):
        self._items = list(items)

    def all(self):
        return self

    def order_by(self, *_args):
        return list(self._items)


def _workflow_input(**overrides):
    defaults = {
        "key": "site",
        "label": "Site",
        "input_type": "string",
        "required": True,
        "choices": None,
    }
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


def _workflow(**overrides):
    defaults = {
        "pk": "11111111-1111-1111-1111-111111111111",
        "key": "create_vlan",
        "name": "Create VLAN",
        "description": "Create a VLAN on switching infrastructure",
        "category": "switching",
        "enabled": True,
        "manual_duration_minutes": 5,
        "raw_definition": {
            "ai": {
                "aliases": ["add vlan", "provision vlan"],
                "examples": ["Create VLAN 150 in Amsterdam"],
                "tags": ["switching", "provisioning"],
                "risk_level": "medium",
                "estimated_runtime_minutes": 5,
                "composable": True,
            }
        },
        "inputs": _FakeInputManager(
            [
                _workflow_input(key="site", label="Site"),
                _workflow_input(key="vlan_id", label="VLAN ID", input_type="integer"),
                _workflow_input(key="change_ticket", label="Change Ticket"),
            ]
        ),
        "get_absolute_url": lambda: "/plugins/workflow-launcher/workflows/create_vlan/launch/",
    }
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


class WorkflowCatalogTestCase(unittest.TestCase):
    """Validate AI catalog serialization from workflow metadata."""

    def test_build_workflow_catalog_serializes_ai_metadata(self):
        workflow = _workflow()

        catalog = build_workflow_catalog([workflow])

        self.assertEqual(len(catalog), 1)
        self.assertEqual(catalog[0]["key"], "create_vlan")
        self.assertEqual(catalog[0]["aliases"], ["add vlan", "provision vlan"])
        self.assertEqual(catalog[0]["required_inputs"], ["site", "vlan_id", "change_ticket"])

    def test_build_workflow_catalog_serializes_schema_and_history_terms(self):
        workflow = _workflow(ai_history_runs=["change_ticket CHG0012345 site Amsterdam"])

        catalog = build_workflow_catalog([workflow])

        self.assertIn("Change Ticket", catalog[0]["schema_terms"])
        self.assertEqual(catalog[0]["history_examples"], ["change_ticket CHG0012345 site Amsterdam"])


class WorkflowPlannerTestCase(unittest.TestCase):
    """Validate grounded assistant planning behavior."""

    def test_build_plan_extracts_known_inputs_and_requests_missing_fields(self):
        catalog = build_workflow_catalog([_workflow()])

        plan = build_plan("Create VLAN 150 in Amsterdam", catalog)

        self.assertEqual(plan["kind"], "workflow_plan")
        self.assertTrue(plan["executable"])
        self.assertFalse(plan["approval_ready"])
        self.assertEqual(plan["steps"][0]["collected_inputs"]["site"], "Amsterdam")
        self.assertEqual(plan["steps"][0]["collected_inputs"]["vlan_id"], "150")
        self.assertEqual(plan["missing_inputs"], [{"key": "change_ticket", "label": "Change Ticket", "type": "string"}])

    def test_build_plan_composes_multiple_workflows_for_decommissioning(self):
        backup_workflow = _workflow(
            pk="22222222-2222-2222-2222-222222222222",
            key="backup_device",
            name="Backup Device",
            description="Backup a device before removal",
            raw_definition={
                "ai": {
                    "aliases": ["backup device", "decommission device backup"],
                    "tags": ["decommissioning"],
                    "risk_level": "low",
                    "estimated_runtime_minutes": 10,
                    "composable": True,
                }
            },
            inputs=_FakeInputManager([_workflow_input(key="device", label="Device")]),
            get_absolute_url=lambda: "/backup/",
        )
        remove_workflow = _workflow(
            pk="33333333-3333-3333-3333-333333333333",
            key="remove_dns",
            name="Remove DNS",
            description="Remove DNS records during device decommissioning",
            raw_definition={
                "ai": {
                    "aliases": ["remove dns", "decommission dns"],
                    "tags": ["decommissioning"],
                    "risk_level": "medium",
                    "estimated_runtime_minutes": 5,
                    "composable": True,
                }
            },
            inputs=_FakeInputManager([_workflow_input(key="device", label="Device")]),
            get_absolute_url=lambda: "/remove-dns/",
        )

        catalog = build_workflow_catalog([backup_workflow, remove_workflow])
        plan = build_plan("Decommission switch AMS-SW-102", catalog)

        self.assertEqual(plan["kind"], "workflow_plan")
        self.assertEqual(len(plan["steps"]), 2)
        self.assertEqual(plan["steps"][0]["collected_inputs"]["device"], "AMS-SW-102")
        self.assertTrue(plan["approval_ready"])

    def test_build_plan_can_rerank_candidates_with_configured_llm(self):
        backup_workflow = _workflow(
            pk="22222222-2222-2222-2222-222222222222",
            key="backup_device",
            name="Backup Device",
            description="Backup a device before removal",
            raw_definition={
                "ai": {
                    "aliases": ["backup device", "decommission device backup"],
                    "tags": ["decommissioning"],
                    "risk_level": "low",
                    "estimated_runtime_minutes": 10,
                    "composable": True,
                }
            },
            inputs=_FakeInputManager([_workflow_input(key="device", label="Device")]),
            get_absolute_url=lambda: "/backup/",
        )
        remove_workflow = _workflow(
            pk="33333333-3333-3333-3333-333333333333",
            key="remove_dns",
            name="Remove DNS",
            description="Remove DNS records during device decommissioning",
            raw_definition={
                "ai": {
                    "aliases": ["remove dns", "decommission dns"],
                    "tags": ["decommissioning"],
                    "risk_level": "medium",
                    "estimated_runtime_minutes": 5,
                    "composable": True,
                }
            },
            inputs=_FakeInputManager([_workflow_input(key="device", label="Device")]),
            get_absolute_url=lambda: "/remove-dns/",
        )

        catalog = build_workflow_catalog([backup_workflow, remove_workflow])
        with patch(
            "nautobot_workflow_launcher.ai.planner.complete_json_for_role",
            return_value={"selected_workflow_keys": ["remove_dns", "backup_device"], "reason": "DNS removal first."},
        ):
            plan = build_plan("Decommission switch AMS-SW-102", catalog)

        self.assertEqual(plan["steps"][0]["workflow_key"], "remove_dns")
        self.assertEqual(plan["llm_reasoning"], "DNS removal first.")

    def test_build_plan_records_gap_when_catalog_has_no_match(self):
        catalog = build_workflow_catalog([_workflow()])

        plan = build_plan("Rotate F5 admin passwords", catalog)

        self.assertEqual(plan["kind"], "gap")
        self.assertFalse(plan["executable"])
        self.assertEqual(plan["proposal"]["workflow_name"], "rotate_f5_admin_passwords")

    def test_build_plan_can_match_workflow_from_schema_terms(self):
        workflow = _workflow(
            key="network_change",
            name="Network Change",
            description="Execute approved network work",
            raw_definition={"ai": {"risk_level": "medium", "estimated_runtime_minutes": 10, "composable": True}},
        )

        catalog = build_workflow_catalog([workflow])
        plan = build_plan("Execute work with change ticket CHG0012345", catalog)

        self.assertEqual(plan["kind"], "workflow_plan")
        self.assertEqual(plan["steps"][0]["workflow_key"], "network_change")

    def test_build_plan_can_match_workflow_from_history_examples(self):
        workflow = _workflow(
            key="bulk_port_disable",
            name="Bulk Port Disable",
            description="Administrative port shutdown workflow",
            raw_definition={"ai": {"risk_level": "medium", "estimated_runtime_minutes": 15, "composable": True}},
            ai_history_runs=["device AMS-SW-102 interface Ethernet1/10 action disable"],
            inputs=_FakeInputManager(
                [
                    _workflow_input(key="device", label="Device"),
                    _workflow_input(key="interface", label="Interface"),
                ]
            ),
        )

        catalog = build_workflow_catalog([workflow])
        plan = build_plan("Disable interface Ethernet1/10 on AMS-SW-102", catalog)

        self.assertEqual(plan["kind"], "workflow_plan")
        self.assertEqual(plan["steps"][0]["workflow_key"], "bulk_port_disable")
