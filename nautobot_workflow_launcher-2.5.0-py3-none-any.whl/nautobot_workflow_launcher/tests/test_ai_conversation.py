"""Focused tests for AI assistant conversation orchestration."""

import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from nautobot_workflow_launcher.ai.conversation import apply_user_message, reconcile_async_updates


class ConversationServiceNowTestCase(unittest.TestCase):
    """Validate ServiceNow change context enrichment in conversations."""

    def test_apply_user_message_adds_servicenow_context_to_plan_and_state(self):
        conversation = SimpleNamespace(
            requested_by=SimpleNamespace(username="alice"),
            state={},
            status="active",
            title="",
            latest_user_request="",
            save=MagicMock(),
        )
        user_message = SimpleNamespace()
        assistant_message = SimpleNamespace()
        plan = {
            "kind": "workflow_plan",
            "missing_inputs": [],
            "collected_inputs": {"change_ticket": "CHG0012345"},
            "steps": [
                {
                    "sequence": 1,
                    "workflow_title": "Create VLAN",
                    "risk_level": "medium",
                    "estimated_runtime_minutes": 5,
                }
            ],
        }

        with patch(
            "nautobot_workflow_launcher.ai.conversation.AIConversationMessage.objects.create",
            side_effect=[user_message, assistant_message],
        ), patch(
            "nautobot_workflow_launcher.ai.conversation.fetch_change_record",
            return_value={
                "number": "CHG0012345",
                "short_description": "Create VLAN 150",
                "implementation_plan": "Create VLAN 150 in Amsterdam",
                "state": "Scheduled",
            },
        ), patch(
            "nautobot_workflow_launcher.ai.conversation.build_plan",
            return_value=plan,
        ) as mock_build_plan:
            apply_user_message(conversation, "Use CHG0012345 as the basis for this work", [])

        self.assertIn("ServiceNow change context", mock_build_plan.call_args.args[0])
        self.assertEqual(conversation.state["service_now"]["change_number"], "CHG0012345")
        self.assertEqual(plan["service_now"]["state"], "Scheduled")
        self.assertEqual(conversation.status, "ready")

    def test_apply_user_message_blocks_execution_when_change_is_not_ready(self):
        conversation = SimpleNamespace(
            requested_by=SimpleNamespace(username="alice"),
            state={},
            status="active",
            title="",
            latest_user_request="",
            save=MagicMock(),
        )
        user_message = SimpleNamespace()
        assistant_message = SimpleNamespace()
        plan = {
            "kind": "workflow_plan",
            "approval_ready": True,
            "missing_inputs": [],
            "collected_inputs": {},
            "steps": [
                {
                    "sequence": 1,
                    "workflow_title": "Create VLAN",
                    "risk_level": "medium",
                    "estimated_runtime_minutes": 5,
                }
            ],
        }

        with patch(
            "nautobot_workflow_launcher.ai.conversation.AIConversationMessage.objects.create",
            side_effect=[user_message, assistant_message],
        ), patch(
            "nautobot_workflow_launcher.ai.conversation.fetch_change_record",
            return_value={
                "number": "CHG0012345",
                "short_description": "Create VLAN 150",
                "implementation_plan": "Create VLAN 150 in Amsterdam",
                "state": "Assess",
            },
        ), patch(
            "nautobot_workflow_launcher.ai.conversation.build_plan",
            return_value=plan,
        ):
            apply_user_message(conversation, "Use CHG0012345 as the basis for this work", [])

        self.assertFalse(plan["approval_ready"])
        self.assertIn("service_now_warning", plan)
        self.assertEqual(conversation.status, "blocked")

    def test_apply_user_message_collects_servicenow_draft_fields_from_message(self):
        conversation = SimpleNamespace(
            requested_by=SimpleNamespace(username="alice"),
            state={},
            status="active",
            title="",
            latest_user_request="",
            save=MagicMock(),
        )
        user_message = SimpleNamespace()
        assistant_message = SimpleNamespace()
        plan = {
            "kind": "workflow_plan",
            "approval_ready": True,
            "missing_inputs": [],
            "collected_inputs": {},
            "steps": [
                {
                    "sequence": 1,
                    "workflow_title": "Create VLAN",
                    "risk_level": "medium",
                    "estimated_runtime_minutes": 5,
                }
            ],
        }

        with patch(
            "nautobot_workflow_launcher.ai.conversation.AIConversationMessage.objects.create",
            side_effect=[user_message, assistant_message],
        ), patch(
            "nautobot_workflow_launcher.ai.conversation.build_plan",
            return_value=plan,
        ):
            apply_user_message(
                conversation,
                "assignment_group=NetOps implementation_window=2026-06-04 backout_plan=Rollback VLAN 150",
                [],
            )

        self.assertTrue(conversation.state["service_now_draft"]["ready"])
        self.assertEqual(conversation.state["service_now_draft"]["payload"]["assignment_group"], "NetOps")

    def test_apply_user_message_queues_async_planner_refinement(self):
        conversation = SimpleNamespace(
            requested_by=SimpleNamespace(username="alice"),
            state={},
            status="active",
            title="",
            latest_user_request="",
            save=MagicMock(),
        )
        user_message = SimpleNamespace()
        assistant_message = SimpleNamespace()
        plan = {
            "kind": "workflow_plan",
            "approval_ready": True,
            "missing_inputs": [],
            "collected_inputs": {},
            "recommendations": [
                {"workflow_key": "create_vlan", "workflow_title": "Create VLAN"},
                {"workflow_key": "create_svi", "workflow_title": "Create SVI"},
            ],
            "steps": [
                {
                    "sequence": 1,
                    "workflow_key": "create_vlan",
                    "workflow_title": "Create VLAN",
                    "risk_level": "medium",
                    "estimated_runtime_minutes": 5,
                }
            ],
        }

        with patch(
            "nautobot_workflow_launcher.ai.conversation.AIConversationMessage.objects.create",
            side_effect=[user_message, assistant_message],
        ), patch(
            "nautobot_workflow_launcher.ai.conversation.build_plan",
            return_value=plan,
        ) as mock_build_plan, patch(
            "nautobot_workflow_launcher.ai.conversation.schedule_complete_json",
            return_value="task-123",
        ):
            apply_user_message(conversation, "Create VLAN 150 in Amsterdam", [])

        self.assertFalse(mock_build_plan.call_args.kwargs["allow_llm"])
        self.assertEqual(conversation.state["async_llm"]["planner"]["task_id"], "task-123")
        self.assertEqual(conversation.state["async_llm"]["planner"]["status"], "pending")

    def test_reconcile_async_updates_applies_summarizer_result(self):
        conversation = SimpleNamespace(
            state={
                "plan": {"kind": "workflow_plan", "steps": [], "recommendations": []},
                "execution": {"summary": "Fallback summary", "summary_pending": True},
                "async_llm": {"summarizer": {"task_id": "task-456", "status": "pending"}},
            },
            save=MagicMock(),
        )

        with patch(
            "nautobot_workflow_launcher.ai.conversation.get_complete_json_task_result",
            return_value={"ready": True, "state": "SUCCESS", "result": {"summary": "Refined summary"}},
        ):
            reconcile_async_updates(conversation)

        self.assertEqual(conversation.state["execution"]["summary"], "Refined summary")
        self.assertFalse(conversation.state["execution"]["summary_pending"])
        self.assertEqual(conversation.state["async_llm"]["summarizer"]["status"], "completed")
