---
name: ✨ Feature Request
about: Propose a new feature or enhancement
labels:
  - "type: feature"
---

### Environment
* Nautobot version:  <!-- Example: 3.0.0 -->
* nautobot-workflow-launcher version:  <!-- Example: 1.0.0 -->

<!--
    Describe in detail the new functionality you are proposing.
-->
### Proposed Functionality

<!--
    Convey an example use case for your proposed feature. Write from the
    perspective of a user who would benefit from the proposed
    functionality and describe how.
--->
### Use Case

