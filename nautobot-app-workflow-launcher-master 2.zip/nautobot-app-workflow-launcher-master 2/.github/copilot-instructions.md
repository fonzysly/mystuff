---
applyTo: "**"
---
# Project Standards

## Overview
This is a Nautobot 2.4+ app that provides Git-synced workflow automation with dynamic form generation and multi-platform execution (Nautobot scripts + AWX). The development environment runs in Docker containers not directly accessible from this system.

## Architecture & Core Components

### Data Flow
1. **Git Sync** (`datasources.py`) → Workflows defined in YAML → Database models
2. **Dynamic Forms** (`forms.py`) → User input collection with dependency resolution
3. **Execution Engine** (`executors.py`) → Script execution with Jinja templating
4. **Monitoring** (`tasks.py`) → AWX job tracking and status updates

### Key Models (`models.py`)
- `Workflow`: Core workflow definition with Git repo source
- `WorkflowInput`: Dynamic input field definitions (string, integer, boolean, choice, multichoice, object, multiobject, list)
- `WorkflowAction`: Individual workflow steps (Nautobot scripts or AWX jobs)
- `WorkflowHelper`: Store python scripts from git repository for later use in execution
- `WorkflowRun`: Execution tracking with logs and status
- `AwxRun`: AWX-specific job monitoring

### Form System (`forms.py`)
- `DynamicWorkflowForm`: Builds forms from workflow definitions
- `DependentChoiceField`: Handles cascading input dependencies
- Supports object lookups (e.g., Device → Interface filtering)
- Client-side progressive disclosure via `data-show-if-*` attributes

## Development Patterns

### Environment Constraints
- Development runs in isolated Docker containers not accessible from the host system
- **NEVER** suggest: migrations, package installs, Nautobot shell, container access, or any other commands to execute code
- User will use `invoke` tasks for development operations: `invoke start`, `invoke tests`, AI Agent should never execute these
- Local code changes auto-reload in development container

### Workflow YAML Structure
```yaml
key: unique-identifier
name: "Display Name"  
category: "Grouping Category"
manual_duration_minutes: 30  # Time savings tracking
enabled: true
inputs:
  - key: request_type
    label: Request Type
    type: choice
    choices:
      - { value: permanent, label: "Permanent New Installation" }
      - { value: reservation, label: "90-Day Reservation" }
      - { value: move, label: "Move Existing Equipment" }
      - { value: decommission, label: "Decommission Existing Equipment" }

  - key: device
    type: object
    model: dcim.Device
    depends_on: ["site"]  # Creates cascading filters
    filter:
      query: {"site_id": "{{ inputs.site.id }}"}
    show_if:
        request_type: permanent

  - key: devices
    type: multiobject
    label: Devices
    model: dcim.Device
    required: true
    depends_on: ["site"]
    filter:
      query: {"site_id": "{{ inputs.site.id }}"}

  - key: tags
    type: multichoice
    label: Tags
    choices:
      - { value: production, label: "Production" }
      - { value: staging, label: "Staging" }
      - { value: development, label: "Development" }

  - key: students
    type: listdict
    label: Students
    required: true
    columns:
      - key: name
        label: Name
        type: string
        required: true
        unique: true
        validators:
          - regex: "^[A-Za-z\\s]+$"
            message: "Name must be letters only"
      - key: age
        label: Age
        type: integer
        required: true

actions:
  - type: nautobot
    script: "scripts/example.py" 
    with:
      device: "{{ inputs.device }}"
```

### Script Execution Context (`executors.py`)
- Scripts run with enhanced Jinja environment
- IP address utilities: `ip_address()`, `ip_network()`, `network_address()`
- Access to previous action results: `{{ actions.step_name.result }}`
- Nautobot model imports automatically available
- Helper modules loaded from Git repo `/scripts/lib/`

### Git Repository Integration
- Workflows sync from Git repos configured in Nautobot Admin
- Directory structure: `/workflows/*.yaml` for definitions, `/scripts/` for Python code
- `WorkflowHelper` model stores reusable script modules
- Jinja include support: `{% include "templates/common.yaml" %}`

## Common Patterns
- Input validation via regex in YAML: `validators: [{regex: "pattern", message: "error"}]`
- Object field filtering: Use `filter.query` with Jinja templates for dependent dropdowns
- Error handling: Scripts should return descriptive messages on failure
- AWX integration: Jobs monitored via ExternalIntegration model
- Time tracking: Include `manual_duration_minutes` for automation ROI reporting

## Invoke / Docker Development Constraints
All execution, testing, and linting should occur through existing invoke commands inside Docker. Do not rely on direct local Python interpreter execution.
Common tasks: invoke start, invoke restart, invoke nbshell, invoke build.
Add any new dev tasks to tasks.py under the existing namespace; maintain consistent naming sync-panorama or similar for job execution wrappers.
Available Invoke Commands
autoformat (a) Run code autoformatting.
backup-db Dump database into output_file file from db container.
build Build Nautobot docker image.
build-and-check-docs Build documentation to be available within Nautobot.
check-migrations Check for missing migrations.
cli Launch a bash shell inside the container.
coverage-lcov Generate an LCOV coverage report.
coverage-xml Generate an XML coverage report.
createsuperuser Create a new Nautobot superuser account (default: "admin"), will prompt for password.
dbshell Start database CLI inside the running db container.
debug Start specified or all services and its dependencies in debug mode.
destroy (down) Destroy all containers and volumes.
djhtml Run djhtml to format Django HTML templates.
djlint Run djlint to lint Django templates.
docs Build and serve docs locally for development.
exec Launch a command inside the running container (defaults to bash shell inside nautobot container).
export Export docker compose configuration to compose.yaml file.
generate-app-config-schema Generate the app config schema from the current app config.
generate-packages Generate all Python packages inside docker and copy the file locally under dist/.
generate-release-notes Generate Release Notes using Towncrier.
hadolint Check Dockerfile for hadolint compliance and other style issues.
help Print the help of available tasks.
import-db Stop Nautobot containers and replace the current database with the dump into db container.
lock Generate poetry.lock; optionally constrain Nautobot and/or Python (with patch).
logs View the logs of a docker compose service.
makemigrations Perform makemigrations operation in Django.
markdownlint Lint Markdown files.
migrate Perform migrate operation in Django.
nbshell Launch an interactive nbshell session.
post-upgrade Performs Nautobot common post-upgrade operations using a single entrypoint.
ps List containers.
pylint Run pylint code analysis.
restart Gracefully restart specified or all services.
ruff Run ruff to perform code formatting and/or linting.
shell-plus Launch an interactive shell_plus session.
start Start specified or all services and its dependencies in detached mode.
stop Stop specified or all services, if service is not specified, remove all containers.
tests Run all tests for this app.
unittest Run Nautobot unit tests.
unittest-coverage Report on code test coverage as measured by 'invoke unittest --coverage'.
validate-app-config Validate the app config based on the app config schema.
vscode Launch Visual Studio Code with the appropriate Environment variables to run in a container.
yamllint Run yamllint to validate formatting adheres to NTC defined YAML standards.
Testing Strategy (Planned)
Add unit tests under nautobot_ssot_panorama/tests/ for:
Model identifier/attribute completeness.
Panorama adapter load() logic using mocked API responses.
Diff integrity: adding objects and verifying relationships.
Use existing test fixtures folder for sample Panorama JSON/XML payloads.
Documentation Updates
Update README.md and docs/ pages to reflect object mappings, limitations, and configuration steps (Panorama credentials, device groups, etc.).
Include a data flow diagram (future) in docs/images/.

## Release Workflow (When Requested)
When the user asks to “release the code,” perform the following steps in order:

Use poetry version to increment the version number.
Update all documentation and release notes as needed with changes made since the last release.
Run invoke ruff (format + lint) and invoke pylint.
Run invoke build-and-check-docs to ensure docs build cleanly.
Run all unit tests and ensure they pass, including ruff warnings.
Run invoke generate-packages to create the distribution release if everything else checks out.
Commit the changes and the newly generated packages with a message like Release vX.Y.Z and push to the main branch.