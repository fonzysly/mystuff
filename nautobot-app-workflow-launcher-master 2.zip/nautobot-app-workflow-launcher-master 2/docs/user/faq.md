# Frequently Asked Questions

## Can I cancel a running workflow?

No. Running workflows cannot be interrupted.

## What can be canceled?

Only runs in **Scheduled** status can be canceled from the run detail page.

## What permission is required to cancel?

Users need **Workflow Run → Can Change** (`change_workflowrun`) to cancel scheduled runs.
