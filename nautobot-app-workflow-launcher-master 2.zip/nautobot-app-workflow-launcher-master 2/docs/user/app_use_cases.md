# Using the App

This document describes common use-cases and scenarios for this App.

## General Usage

The Workflow Launcher lets you define multi-step workflows in YAML files stored in a Git repository. Once synced, each workflow generates a dynamic form in the Nautobot UI where users provide inputs, and the plugin executes the configured actions (Nautobot scripts or AWX jobs) using those inputs.

## Defining Workflows

Workflows are defined as YAML files under `/workflows/` in a Git repository configured in Nautobot's **Git Repositories** admin page. Each file contains a single workflow definition.

### Basic Workflow Structure

```yaml
key: unique-identifier        # URL-safe slug, must be unique
name: "Display Name"          # Shown in the UI
category: "Grouping Category" # Groups workflows in the listing page
description: "What this workflow does"
manual_duration_minutes: 30   # Estimated time to do manually (for ROI tracking)
enabled: true                 # Set to false to disable without deleting

inputs:
  - key: field_key
    label: "Field Label"
    type: string
    required: true

actions:
  - type: nautobot
    script: "scripts/my_script.py"
    with:
      param: "{{ inputs.field_key }}"
```

## Workflow Input Types

The following input types are available for building dynamic forms. Each input is defined in the `inputs:` section of the workflow YAML.

### String

A simple text input field.

```yaml
- key: hostname
  label: Hostname
  type: string
  required: true
  default: "switch-01"
  validators:
    - regex: "^[a-zA-Z0-9-]+$"
      message: "Hostname must contain only letters, numbers, and hyphens."
```

### Integer

A numeric input field.

```yaml
- key: vlan_id
  label: VLAN ID
  type: integer
  required: true
  default: 100
```

### Boolean

A checkbox for true/false values.

```yaml
- key: enable_dhcp
  label: Enable DHCP
  type: boolean
  default: true
```

### Choice

A single-selection dropdown.

```yaml
- key: request_type
  label: Request Type
  type: choice
  required: true
  choices:
    - { value: permanent, label: "Permanent New Installation" }
    - { value: reservation, label: "90-Day Reservation" }
    - { value: move, label: "Move Existing Equipment" }
    - { value: decommission, label: "Decommission Existing Equipment" }
```

### Multi-Choice

A multi-selection dropdown allowing the user to select one or more values from a predefined list.

```yaml
- key: tags
  label: Tags
  type: multichoice
  choices:
    - { value: production, label: "Production" }
    - { value: staging, label: "Staging" }
    - { value: development, label: "Development" }
```

### Object

A searchable dropdown bound to a Nautobot model. Returns the selected object's primary key.

```yaml
- key: device
  label: Device
  type: object
  model: dcim.Device
  required: true
  depends_on: ["site"]
  filter:
    query: {"site_id": "{{ inputs.site.id }}"}
```

### Multi-Object

Like `object`, but allows selecting multiple Nautobot model instances.

```yaml
- key: devices
  label: Devices
  type: multiobject
  model: dcim.Device
  required: true
  depends_on: ["site"]
  filter:
    query: {"site_id": "{{ inputs.site.id }}"}
```

### List

A dynamic list of string values. Users can add and remove items.

```yaml
- key: dns_servers
  label: DNS Servers
  type: list
  required: true
  validators:
    - regex: "^(?:[0-9]{1,3}\\.){3}[0-9]{1,3}$"
      message: "Must be a valid IPv4 address."
```

### List of Dictionaries (listdict)

A dynamic table where each row represents a dictionary with predefined columns. Users can add and remove rows, and each cell is validated according to its column definition. This is ideal for collecting structured, tabular data such as endpoint lists, user rosters, or port mappings.

```yaml
- key: endpoints
  label: Endpoints
  type: listdict
  required: true
  columns:
    - key: name
      label: Endpoint Name
      type: string
      required: true
      unique: true
      validators:
        - regex: "^.+$"
          message: "Endpoint name cannot be empty."
    - key: ip_address
      label: IP Address
      type: string
      required: true
      validators:
        - regex: '^(?:[0-9]{1,3}\.){3}[0-9]{1,3}(?:\/(3[0-2]|[12]?[0-9]))?$'
          message: "Must be a valid IPv4 address with optional CIDR (e.g., 10.0.0.1 or 10.0.0.1/32)."
    - key: enabled
      label: Enabled
      type: boolean
```

#### Column Properties

Each column in a `listdict` input supports the following properties:

| Property     | Type    | Required | Description                                                  |
| ------------ | ------- | -------- | ------------------------------------------------------------ |
| `key`        | string  | Yes      | Unique identifier for the column (used in script context).   |
| `label`      | string  | No       | Display label shown in the table header. Defaults to `key`.  |
| `type`       | string  | No       | Column data type: `string` (default), `integer`, `boolean`, or `choice`. |
| `required`   | boolean | No       | Whether the cell must have a value. Default `false`.         |
| `unique`     | boolean | No       | Whether values in this column must be unique across all rows. Duplicates are highlighted visually. Default `false`. |
| `choices`    | list    | No       | For `choice` columns only. List of `{value, label}` objects. |
| `validators` | list    | No       | List of `{regex, message}` objects for pattern validation.   |

#### Column Types

- **`string`** — Renders a text input. Supports `validators` for regex validation.
- **`integer`** — Renders a numeric input. Validates that the value is a number.
- **`boolean`** — Renders a checkbox. Any boolean value is accepted; `required` has no effect.
- **`choice`** — Renders a dropdown. Requires a `choices` list with `{value, label}` items.

#### How It Works

The `listdict` field renders as a table in the workflow form:

- **Column headers** are derived from each column's `label` (or `key` if no label is specified).
- **Add Row** appends a new empty row to the table.
- **Remove** deletes a specific row.
- Cells with validation errors are highlighted in red with a tooltip describing the error.
- Columns marked `unique: true` show a warning banner when duplicate values are detected.

The submitted data is a JSON array of objects, where each object's keys correspond to the column `key` values. For example:

```json
[
  {"name": "fw-edge-01", "ip_address": "10.0.1.1/32", "enabled": true},
  {"name": "fw-edge-02", "ip_address": "10.0.1.2/32", "enabled": false}
]
```

Scripts can access this data via Jinja: `{{ inputs.endpoints }}`, and iterate over it in Python scripts as a standard list of dictionaries.

## Conditional Visibility

Fields can be shown or hidden based on the value of another field using `show_if`:

```yaml
- key: request_type
  label: Request Type
  type: choice
  choices:
    - { value: new, label: "New Installation" }
    - { value: decommission, label: "Decommission" }

- key: device_name
  label: Device Name
  type: string
  required: true
  show_if:
    request_type: new
```

In this example, `device_name` is only shown when the user selects "New Installation".

## Cascading Dependencies

Object and choice fields can depend on other fields using `depends_on` and Jinja-templated `filter.query` values:

```yaml
- key: site
  label: Site
  type: object
  model: dcim.Site

- key: device
  label: Device
  type: object
  model: dcim.Device
  depends_on: ["site"]
  filter:
    query: {"site_id": "{{ inputs.site.id }}"}
```

When the user selects a site, the device dropdown is automatically filtered to show only devices at that site.

## Input Validation

All text-based input types (`string`, `list`, and `listdict` columns) support regex validation:

```yaml
validators:
  - regex: "^[A-Za-z0-9_-]+$"
    message: "Only letters, numbers, underscores, and hyphens are allowed."
    flags: ["IGNORECASE"]  # Optional regex flags
```

Validation is performed client-side in real time and again at form submission.

## Workflow Actions

Actions define what happens when the workflow is executed. Each action runs in sequence, and the results of previous actions are available to subsequent ones via `{{ actions.step_name.result }}`.

### Nautobot Script Action

Executes a Python script stored in the Git repository:

```yaml
actions:
  - type: nautobot
    name: "Configure Device"
    script: "scripts/configure_device.py"
    with:
      device: "{{ inputs.device }}"
      vlan_id: "{{ inputs.vlan_id }}"
```

### AWX Job Action

Launches a job template on an AWX/Ansible Tower instance:

```yaml
actions:
  - type: awx
    name: "Deploy Configuration"
    template: "Deploy Network Config"
    with:
      device_name: "{{ inputs.device.name }}"
```

## Custom Jinja Filters

Custom Jinja filters are loaded from Python modules under the repository's top-level `filters/` directory by default. Each module must expose a `FILTERS` dictionary that maps the filter name used in YAML to a callable.

```python
# filters/string_filters.py
from scripts.lib.text_helpers import normalize_hostname


def normalize_for_dns(value):
    """Normalize a user-provided hostname for DNS-safe usage."""
    return normalize_hostname(value).replace("_", "-")


FILTERS = {
    "normalize_for_dns": normalize_for_dns,
}
```

Once synced, these filters are available anywhere the app renders Jinja:

- Action `with` parameters
- Action `when` expressions
- Input `filter.query` values
- Dynamic choice definitions

Example usage in workflow YAML:

```yaml
actions:
  - type: nautobot
    name: "Prepare Hostname"
    script: "scripts/create_device.py"
    with:
      hostname: "{{ inputs.hostname | normalize_for_dns }}"
```

### Importing Shared Modules from `scripts/lib`

Filter modules can import repo-local helper code that ships in the same workflow repository. When shared code lives under `scripts/lib`, use normal absolute Python imports that match the materialized package layout:

```python
from scripts.lib.text_helpers import normalize_hostname
```

Avoid relying on plugin-internal modules for custom filters. Instead, place reusable code in the workflow repository and import it from there.

### Dependency Rules

- Python standard-library modules are supported.
- Repo-local helper modules are supported, including shared modules under `scripts/lib`.
- Third-party packages must already be installed in the Nautobot runtime. If a filter imports a package that is missing, Git sync fails early with an import error.
