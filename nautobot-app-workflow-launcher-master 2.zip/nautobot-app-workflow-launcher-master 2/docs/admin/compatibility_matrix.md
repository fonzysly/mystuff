# Compatibility Matrix

!!! warning "Developer Note - Remove Me!"
    Explain how the release models of the app and of Nautobot work together, how releases are supported, how features and older releases are deprecated etc.

| Workflow Launcher Version | Nautobot First Support Version | Nautobot Last Support Version |
| ------------- | -------------------- | ------------- |
| 1.0.X         | 2.0.0                | 2.99.99        |
| 2.0.X         | 3.0.0                | 3.99.99        |
| 2.2.X         | 3.0.0                | 3.99.99        |
| 2.1.X         | 3.0.0                | 3.99.99        |
