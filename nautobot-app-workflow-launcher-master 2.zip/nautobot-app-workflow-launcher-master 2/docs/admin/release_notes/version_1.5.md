# v1.5 Release Notes

This document describes all new features and changes in the release `1.5`. The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## Release Overview

- Added new input type `list`
- Added automation time savings reporting

## [v1.5.4 (2025-08-18)](https://github.com/Network-Operations/nautobot-app-workflow-launcher/releases/tag/v1.5.4)

Added field `enabled` to workflow templates
Moved execution of workflows to asynchronous with reporting

## [v1.5.5 (2025-08-18)](https://github.com/Network-Operations/nautobot-app-workflow-launcher/releases/tag/v1.5.4)

Add new line before appending log results dictionary
