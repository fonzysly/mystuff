
# v1.7 Release Notes

This document describes all new features and changes in the release. The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## Release Overview

- Major features or milestones
- Changes to compatibility with Nautobot and/or other apps, libraries etc.

## [v1.7.6 (2025-11-24)](https://github.com/Network-Operations/nautobot-app-workflow-launcher/releases/tag/v1.7.6)

- Bug Fixes
- Reporting by month for minutes saved

## [v1.7.7 (2025-11-24)](https://github.com/Network-Operations/nautobot-app-workflow-launcher/releases/tag/v1.7.7)

- Fix multichoice input type
- Add multiobject input type
- Documentation updates