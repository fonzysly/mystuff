
# v2.0 Release Notes

This document describes all new features and changes in the release. The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## Release Overview

- Upgrade to Nautobot 3.x support

## [v2.0.1 (2026-1-13)](https://github.com/Network-Operations/nautobot-app-workflow-launcher/releases/tag/v2.0.1)

- Correct filter dropdowns z-indexing
