# v1.6 Release Notes

This document describes all new features and changes in the release `1.6`. The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## Release Overview

- Added ability to schedule workflows to execute in the future
- Enhanced permissions structure to allow for granular permissions support


