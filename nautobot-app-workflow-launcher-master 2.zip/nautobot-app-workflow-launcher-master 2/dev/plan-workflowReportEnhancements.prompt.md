Dynamic Workflow Reporting Plan

Overview
- Objective: Make the workflow dashboard interactive with flexible filters, richer analytics, and clear visualizations — all respecting object-level permissions and existing project patterns.
- Scope: Enhance `views.py:WorkflowReportView` (and helpers), and update `templates/nautobot_workflow_launcher/workflow_report.html`. Optionally extend `WorkflowRunListView` and add export endpoints.

Current State (References)
- `views.py:WorkflowReportView.get_context_data` provides:
  - Fixed 30-day window (`thirty_days_ago`).
  - `status_summary`: counts by `WorkflowRun.status`.
  - `workflow_summary`: top workflows by run count.
  - `recent_runs`: last 20 runs.
  - `workflows_with_stats`: per-workflow success rate.
  - `time_savings`: via `_calculate_time_savings()` on successful runs.
  - `monthly_time_savings`: via `_calculate_monthly_time_savings()` (last 12 months).
- `views.py:WorkflowRunListView` supports filters by `workflow`, `status`, `user` and applies permissions.
- Models (`models.py`):
  - `Workflow`: `key`, `name`, `category`, `enabled`, `manual_duration_minutes`, etc.
  - `WorkflowRun`: `workflow`, `requested_by`, `status`, `started`, `scheduled_for`, etc.

Goals
- Add dynamic filtering (category, time range, user, status) and ensure all aggregates reflect the filtered scope.
- Provide per-user and per-category analytics, trends, and success/failure breakdowns.
- Improve time savings visibility across filters and time windows.
- Offer optional export of the currently filtered dataset and aggregates.

Filters & Query Params
- `category`: filter by `workflow__category` (include "Uncategorized").
- `time_range`: presets (`7d`, `30d`, `90d`, `365d`).
- `start`, `end`: custom ISO datetimes (UTC) overriding `time_range`.
- `user`: filter by requestor (username or pk; choose one consistently, e.g., pk).
- `status`: filter by run status (single value initially; consider multi-select later).
- All filters applied to a base queryset with object-level permission filtering at the start.

View Changes (views.py)
- `WorkflowReportView.get_context_data`:
  - Parse query params and build a single filtered base queryset `base_qs = WorkflowRun.objects.select_related('workflow','requested_by')...`.
  - Apply permissions: filter IDs to those user can view (consistent with current pattern).
  - Apply filters: category, time window (preset or `start`/`end`), user, status.
  - Derive aggregates from `base_qs` to keep scope consistent:
    - `status_summary`: `base_qs.values('status').annotate(count=Count('id'))`.
    - `workflow_summary`: `base_qs.values('workflow__name','workflow__key').annotate(count=Count('id')).order_by('-count')[:10]`.
    - `recent_runs`: `base_qs.order_by('-started')[:20]`.
    - `workflows_with_stats`: per-workflow `{total_runs, successful_runs, success_rate}` within filtered scope.
    - `category_summary`: `base_qs.values('workflow__category').annotate(count=Count('id'))`.
    - `user_summary`: `base_qs.values('requested_by__username','requested_by__pk').annotate(count=Count('id')).order_by('-count')[:10]`.
    - `success_by_category`: grouped by `workflow__category` and `status` to compute rates.
    - `usage_over_time`: bucket counts per day/week/month (based on window length), for charts.
  - Provide filter option lists: distinct categories, users, statuses, plus selected values.
  - Keep existing `_get_workflow_queryset()` usage for workflow metadata where appropriate.
- `_calculate_time_savings(recent_runs)`:
  - Accept an already-filtered queryset (e.g., `base_qs.filter(status='success')`).
  - Compute totals in the current filter scope; leave minute/hour breakdown as-is.
- `_calculate_monthly_time_savings()`:
  - Respect selected `start`/`end`; cap to a 12-month span.
  - Prefer DB-side grouping (e.g., TruncMonth) if available; otherwise keep current iteration.
- `WorkflowRunListView.get_queryset`:
  - Add optional `category` and `time_range`/`start`/`end` filters for consistency with the dashboard.

Template Changes (workflow_report.html)
- Add a filter bar (GET form) at the top:
  - `category` select (from distinct categories).
  - `time_range` preset select; `start`/`end` datetime pickers (UTC) shown when "Custom" selected.
  - `user` select (from distinct requestors).
  - `status` select.
  - "Apply" and "Reset" buttons.
- Update sections to reflect filtered scope:
  - Status summary reflects `status_summary` from `base_qs`.
  - Time savings reflects current scope; hide when none.
  - Most popular workflows reflect `workflow_summary`.
- Add new chart panels (Chart.js via CDN):
  - Usage by category (bar chart of `category_summary`).
  - Top users (horizontal bar of `user_summary`).
  - Success vs failure by category (stacked bar).
  - Usage over time (line/bar based on `usage_over_time`).
- Keep recent runs list, updated to filtered scope.
- Optional: add export buttons (CSV/JSON) for aggregates and raw runs, visible only with proper permission.

Exports & Permissions
- Export endpoints (optional) via `ReportExportView` or `format=` query on `workflow_report` returning CSV/JSON of current aggregates and/or raw runs.
- Respect object-level permissions on all exports.
- Consider adding a dedicated permission (e.g., `nautobot_workflow_launcher.view_reports`) to gate user analytics visibility.

Performance & Robustness
- Centralize `base_qs` application of permissions and filters; reuse for all subsections to avoid mismatches.
- Use DB-side aggregation (`annotate`, `values`) to minimize Python loops.
- Cap lists (top N users/categories/workflows) to 10 for readability; consider pagination for raw runs.
- Ensure distinct where joins may cause duplicates.

Open Questions
- Should `status`, `category`, and `workflow` filters allow multi-select?
  - Yes allow multi-select for better flexibility.
- Preferred default time range (30 days)? Support timezone display beyond UTC?
  - Keep UTC for consistency; consider user timezone settings later.
- Export formats and scope: which aggregates and raw data to include?
  - CSV and JSON for both aggregates and raw runs.
- Trend granularity: daily vs weekly when range is >90 days?
  - Use weekly granularity for ranges over 90 days to reduce data points.

Acceptance Criteria
- Dashboard shows filter controls and updates all sections when filters change.
- Aggregates and charts respect filters and permissions.
- Time savings and monthly charts reflect selected window.
- Optional exports deliver CSV/JSON aligned to the current filter scope.
