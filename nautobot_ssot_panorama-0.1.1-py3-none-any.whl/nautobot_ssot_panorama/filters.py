"""Filtering for nautobot_ssot_panorama."""

from nautobot.apps.filters import NameSearchFilterSet, NautobotFilterSet

from nautobot_ssot_panorama import models


class PanoramaPolicyFilterSet(NameSearchFilterSet, NautobotFilterSet):  # pylint: disable=too-many-ancestors
    """Filter for PanoramaPolicy."""

    class Meta:
        """Meta attributes for filter."""

        model = models.PanoramaPolicy

        # add any fields from the model that you would like to filter your searches by using those
        fields = "__all__"
