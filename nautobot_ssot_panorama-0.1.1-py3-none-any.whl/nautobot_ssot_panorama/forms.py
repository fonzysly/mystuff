"""Forms for nautobot_ssot_panorama."""

from django import forms
from nautobot.apps.constants import CHARFIELD_MAX_LENGTH
from nautobot.apps.forms import NautobotBulkEditForm, NautobotFilterForm, NautobotModelForm, TagsBulkEditFormMixin

from nautobot_ssot_panorama import models


class PanoramaPolicyForm(NautobotModelForm):  # pylint: disable=too-many-ancestors
    """PanoramaPolicy creation/edit form."""

    class Meta:
        """Meta attributes."""

        model = models.PanoramaPolicy
        fields = "__all__"


class PanoramaPolicyBulkEditForm(TagsBulkEditFormMixin, NautobotBulkEditForm):  # pylint: disable=too-many-ancestors
    """PanoramaPolicy bulk edit form."""

    pk = forms.ModelMultipleChoiceField(queryset=models.PanoramaPolicy.objects.all(), widget=forms.MultipleHiddenInput)
    description = forms.CharField(required=False, max_length=CHARFIELD_MAX_LENGTH)

    class Meta:
        """Meta attributes."""

        nullable_fields = [
            "description",
        ]


class PanoramaPolicyFilterForm(NautobotFilterForm):  # pylint: disable=too-many-ancestors
    """Filter form to filter searches."""

    model = models.PanoramaPolicy
    field_order = ["q", "name"]

    q = forms.CharField(
        required=False,
        label="Search",
        help_text="Search within Name.",
    )
    name = forms.CharField(required=False, label="Name")
