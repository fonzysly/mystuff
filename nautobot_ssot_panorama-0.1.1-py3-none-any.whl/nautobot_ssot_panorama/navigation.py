"""Menu items."""

from nautobot.apps.ui import NavMenuAddButton, NavMenuGroup, NavMenuItem, NavMenuTab

items = (
    NavMenuItem(
        link="plugins:nautobot_ssot_panorama:panoramapolicy_list",
        name="Nautobot Ssot Panorama",
        permissions=["nautobot_ssot_panorama.view_panoramapolicy"],
        buttons=(
            NavMenuAddButton(
                link="plugins:nautobot_ssot_panorama:panoramapolicy_add",
                permissions=["nautobot_ssot_panorama.add_panoramapolicy"],
            ),
        ),
    ),
)

menu_items = (
    NavMenuTab(
        name="Apps",
        groups=(NavMenuGroup(name="Nautobot Ssot Panorama", items=tuple(items)),),
    ),
)
