"""Bulk creation utilities for optimizing large-scale object synchronization.

This module provides utilities to batch-create objects using Django's bulk_create,
significantly improving performance when synchronizing thousands of objects from Panorama.
"""

# pylint: disable=too-many-locals,too-many-branches,too-many-statements,broad-exception-caught

from ipaddress import ip_network

from nautobot.extras.models import Tag
from nautobot.ipam.models import IPAddress, Prefix
from nautobot_firewall_models.models import (
    FQDN as OrmFQDN,
)
from nautobot_firewall_models.models import (
    AddressObject as OrmAddressObject,
)
from nautobot_firewall_models.models import (
    ApplicationObject as OrmApplicationObject,
)
from nautobot_firewall_models.models import (
    IPRange as OrmIPRange,
)
from nautobot_firewall_models.models import (
    ServiceObject as OrmServiceObject,
)

from nautobot_ssot_panorama.utils.nautobot import find_best_cidr, get_active_status, get_parent_prefix

PANORAMA_TAG_NAME = "Panorama SSoT"


def _get_tag():
    """Get or create the Panorama SSoT tag."""
    return Tag.objects.get_or_create(name=PANORAMA_TAG_NAME)[0]


def bulk_create_address_objects(queued_objects, adapter):
    """Bulk create AddressObjects from queued data.

    Args:
        queued_objects: List of (ids, attrs) tuples for AddressObjects
        adapter: Adapter instance for logging

    Returns:
        Number of objects created
    """
    if not queued_objects:
        return 0

    tag = _get_tag()
    objects_to_create = []
    objects_to_update = []
    existing_names = set(OrmAddressObject.objects.values_list("name", flat=True))

    adapter.job.logger.info(f"Processing {len(queued_objects)} AddressObjects in bulk mode...")

    for ids, attrs in queued_objects:
        name = ids["name"]

        # Skip if already exists - will update separately
        if name in existing_names:
            objects_to_update.append((ids, attrs))
            continue

        # Resolve underlying address reference
        kwargs = {"name": name, "description": attrs.get("description", ""), "status": get_active_status()}

        if attrs.get("fqdn"):
            try:
                kwargs["fqdn"] = OrmFQDN.objects.get(name=attrs["fqdn"])
            except OrmFQDN.DoesNotExist:
                adapter.job.logger.warning(f"FQDN {attrs['fqdn']} not found for AddressObject {name}")
                continue
        elif attrs.get("ip_range") and "-" in attrs["ip_range"]:
            start, end = attrs["ip_range"].split("-", 1)
            try:
                kwargs["ip_range"] = OrmIPRange.objects.get(start_address=start, end_address=end)
            except OrmIPRange.DoesNotExist:
                adapter.job.logger.warning(f"IPRange {attrs['ip_range']} not found for AddressObject {name}")
                continue
        elif attrs.get("prefix") and ("/" not in attrs["prefix"] or "/32" in attrs["prefix"]):
            address = attrs["prefix"].split("/")[0]
            prefix = get_parent_prefix(address)
            if prefix:
                cidr = prefix.prefix_length
            else:
                cidr = find_best_cidr(address)
                if cidr != 32:
                    try:
                        subnet = ip_network(f"{address}/{cidr}", strict=False).with_prefixlen
                    except ValueError as exc:
                        adapter.job.logger.warning(
                            f"Invalid address/prefix {address}/{cidr} for AddressObject {name}: {exc}"
                        )
                        continue
                else:
                    subnet = f"{address}/32"
                prefix, _ = Prefix.objects.get_or_create(
                    prefix=subnet,
                    namespace__name="Global",
                    status=get_active_status(),
                )
            addressobject, _ = IPAddress.objects.get_or_create(
                host=address,
                parent__namespace__name="Global",
                defaults={"status": get_active_status(), "parent": prefix, "mask_length": cidr},
            )
            kwargs["ip_address"] = addressobject
        elif attrs.get("prefix"):
            try:
                subnet = ip_network(attrs["prefix"], strict=False).with_prefixlen
            except ValueError as exc:
                adapter.job.logger.warning(
                    f"Invalid prefix {attrs['prefix']} for AddressObject {name}, attrs: {attrs}, error: {exc}"
                )
                continue
            try:
                prefix, _ = Prefix.objects.get_or_create(
                    prefix=subnet,
                    namespace__name="Global",
                    status=get_active_status(),
                )
                kwargs["prefix"] = prefix
            except Exception as exc:
                adapter.job.logger.warning(
                    f"Prefix {attrs['prefix']} not found for AddressObject {name}, attrs: {attrs}, error: {exc}"
                )
                continue

        try:
            objects_to_create.append(OrmAddressObject(**kwargs))
        except Exception as exc:
            adapter.job.logger.error(
                f"Error preparing AddressObject {name} for bulk creation: {exc}, attrs: {attrs}, kwargs: {kwargs}"
            )

    # Bulk create new objects
    if objects_to_create:
        adapter.job.logger.info(f"Bulk creating {len(objects_to_create)} new AddressObjects...")
        created_objects = OrmAddressObject.objects.bulk_create(objects_to_create, batch_size=500)

        # Add tags to created objects (bulk_create doesn't handle M2M)
        adapter.job.logger.info(f"Adding tags to {len(created_objects)} AddressObjects...")
        for obj in created_objects:
            obj.tags.add(tag)

    # Update existing objects if needed
    if objects_to_update:
        adapter.job.logger.info(f"Updating {len(objects_to_update)} existing AddressObjects...")
        for ids, attrs in objects_to_update:
            try:
                obj = OrmAddressObject.objects.get(name=ids["name"])
                changed = False
                if obj.description != (attrs.get("description", "") or ""):
                    obj.description = attrs.get("description", "") or ""
                    changed = True
                if changed:
                    obj.validated_save()
                obj.tags.add(tag)
            except Exception as exc:
                adapter.job.logger.warning(f"Error updating AddressObject {ids['name']}: {exc}")

    return len(objects_to_create)


def bulk_create_service_objects(queued_objects, adapter):
    """Bulk create ServiceObjects from queued data.

    Args:
        queued_objects: List of (ids, attrs) tuples for ServiceObjects
        adapter: Adapter instance for logging

    Returns:
        Number of objects created
    """
    if not queued_objects:
        return 0

    tag = _get_tag()
    objects_to_create = []
    existing_names = set(OrmServiceObject.objects.values_list("name", flat=True))

    adapter.job.logger.info(f"Processing {len(queued_objects)} ServiceObjects in bulk mode...")

    for ids, attrs in queued_objects:
        name = ids["name"]

        # Skip if already exists
        if name in existing_names:
            continue

        description = attrs.get("description", "")
        ip_protocol = attrs.get("ip_protocol")
        port = attrs.get("port")

        # Handle application-default placeholder
        if name == "application-default":
            if not ip_protocol:
                ip_protocol = "Reserved"
            if not description:
                description = "Placeholder for Panorama 'application-default' dynamic service"
            if port is None:
                port = "0"

        try:
            objects_to_create.append(
                OrmServiceObject(
                    name=name,
                    description=description,
                    port=port,
                    ip_protocol=ip_protocol,
                    status=get_active_status(),
                )
            )
        except Exception as exc:
            adapter.job.logger.error(f"Error preparing ServiceObject {name} for bulk creation: {exc}")

    # Bulk create
    if objects_to_create:
        adapter.job.logger.info(f"Bulk creating {len(objects_to_create)} new ServiceObjects...")
        created_objects = OrmServiceObject.objects.bulk_create(objects_to_create, batch_size=500)

        # Add tags
        adapter.job.logger.info(f"Adding tags to {len(created_objects)} ServiceObjects...")
        for obj in created_objects:
            obj.tags.add(tag)

    return len(objects_to_create)


def bulk_create_application_objects(queued_objects, adapter):
    """Bulk create ApplicationObjects from queued data.

    Args:
        queued_objects: List of (ids, attrs) tuples for ApplicationObjects
        adapter: Adapter instance for logging

    Returns:
        Number of objects created
    """
    if not queued_objects:
        return 0

    tag = _get_tag()
    objects_to_create = []
    existing_names = set(OrmApplicationObject.objects.values_list("name", flat=True))

    adapter.job.logger.info(f"Processing {len(queued_objects)} ApplicationObjects in bulk mode...")

    for ids, attrs in queued_objects:
        name = ids["name"]

        # Skip if already exists
        if name in existing_names:
            continue

        # Ensure required fields are coerced to empty string if None
        description = attrs.get("description") or ""
        category = attrs.get("category") or ""
        subcategory = attrs.get("subcategory") or ""
        technology = attrs.get("technology") or ""
        risk = attrs.get("risk")  # May be int or None

        try:
            objects_to_create.append(
                OrmApplicationObject(
                    name=name,
                    description=description,
                    category=category,
                    subcategory=subcategory,
                    technology=technology,
                    risk=risk,
                )
            )
        except Exception as exc:
            adapter.job.logger.error(f"Error preparing ApplicationObject {name} for bulk creation: {exc}")

    # Bulk create
    if objects_to_create:
        adapter.job.logger.info(f"Bulk creating {len(objects_to_create)} new ApplicationObjects...")
        created_objects = OrmApplicationObject.objects.bulk_create(objects_to_create, batch_size=500)

        # Add tags
        adapter.job.logger.info(f"Adding tags to {len(created_objects)} ApplicationObjects...")
        for obj in created_objects:
            obj.tags.add(tag)

    return len(objects_to_create)
