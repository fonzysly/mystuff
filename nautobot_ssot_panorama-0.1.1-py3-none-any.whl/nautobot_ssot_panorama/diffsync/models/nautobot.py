"""Nautobot-side DiffSync model implementations for Panorama SSoT.

Each class subclasses the base schema-only models and implements create/update/delete
against Nautobot firewall plugin ORM. Deletions are appended to adapter.objects_to_delete
for ordered cleanup.
"""

import logging
import threading
from ipaddress import ip_network

from django.contrib.contenttypes.models import ContentType
from nautobot.extras.models import Relationship, RelationshipAssociation
from nautobot.extras.models import Tag as OrmTag
from nautobot.ipam.models import IPAddress, Prefix
from nautobot_firewall_models.models import (
    FQDN as OrmFQDN,
)
from nautobot_firewall_models.models import (
    AddressObject as OrmAddressObject,
)
from nautobot_firewall_models.models import (
    AddressObjectGroup as OrmAddressObjectGroup,
)
from nautobot_firewall_models.models import (
    ApplicationObject as OrmApplicationObject,
)
from nautobot_firewall_models.models import (
    ApplicationObjectGroup as OrmApplicationObjectGroup,
)
from nautobot_firewall_models.models import (
    IPRange as OrmIPRange,
)
from nautobot_firewall_models.models import (
    NATPolicy as OrmNATPolicy,
)
from nautobot_firewall_models.models import (
    NATPolicyRule as OrmNATPolicyRule,
)
from nautobot_firewall_models.models import (
    Policy as OrmPolicy,
)
from nautobot_firewall_models.models import (
    PolicyRule as OrmPolicyRule,
)
from nautobot_firewall_models.models import (
    ServiceObject as OrmServiceObject,
)
from nautobot_firewall_models.models import (
    ServiceObjectGroup as OrmServiceObjectGroup,
)
from nautobot_firewall_models.models import (
    UserObject as OrmUserObject,
)
from nautobot_firewall_models.models import (
    Zone as OrmZone,
)

from nautobot_ssot_panorama.utils.nautobot import find_best_cidr, get_active_status, get_parent_prefix

from .base import (
    AddressObjectBase,
    AddressObjectGroupBase,
    ApplicationObjectBase,
    ApplicationObjectGroupBase,
    FQDNBase,
    IPRangeBase,
    NATPolicyBase,
    NATPolicyRuleBase,
    PolicyBase,
    PolicyRuleBase,
    ServiceObjectBase,
    ServiceObjectGroupBase,
    UserObjectBase,
    ZoneBase,
)

PANORAMA_TAG_NAME = "Panorama SSoT"

logger = logging.getLogger(__name__)

# Cache for firewall model content types to avoid repeated lookups
# Thread-safe via lock to prevent race conditions during parallel sync operations
_firewall_content_types_cache = None
_firewall_content_types_lock = threading.Lock()


def _get_firewall_content_types():
    """Get ContentTypes for all firewall models that need tagging.

    This function is thread-safe and uses double-checked locking to minimize
    lock contention while ensuring the cache is only populated once.

    Returns:
        List of ContentType objects for firewall models.
    """
    global _firewall_content_types_cache  # pylint: disable=global-statement

    # Fast path: return cached value without acquiring lock
    if _firewall_content_types_cache is not None:
        return _firewall_content_types_cache

    # Slow path: acquire lock and populate cache
    with _firewall_content_types_lock:
        # Double-check after acquiring lock
        if _firewall_content_types_cache is not None:
            return _firewall_content_types_cache

        firewall_models = [
            OrmFQDN,
            OrmIPRange,
            OrmAddressObject,
            OrmAddressObjectGroup,
            OrmServiceObject,
            OrmServiceObjectGroup,
            OrmApplicationObject,
            OrmApplicationObjectGroup,
            OrmUserObject,
            OrmZone,
            OrmPolicy,
            OrmPolicyRule,
            OrmNATPolicy,
            OrmNATPolicyRule,
        ]
        content_types = []
        for model in firewall_models:
            try:
                ct = ContentType.objects.get_for_model(model)
                content_types.append(ct)
            except ContentType.DoesNotExist:
                # Model's content type not yet created - skip
                pass
            except Exception as exc:  # noqa: BLE001
                # Defensive: don't fail sync if content type lookup fails
                logger.debug("Failed to get ContentType for %s: %s", model, exc)
        _firewall_content_types_cache = content_types
        return content_types


def _get_tag():
    """Get or create the Panorama SSoT tag with proper content types.

    Ensures the tag has content_types set to include all firewall models,
    which allows the tag to be applied to those objects without being
    removed on manual edits.
    """
    tag, created = OrmTag.objects.get_or_create(name=PANORAMA_TAG_NAME)

    # Ensure tag has content_types for firewall models
    firewall_cts = _get_firewall_content_types()
    if firewall_cts:
        # Get current content types on the tag
        current_cts = set(tag.content_types.all())
        missing_cts = [ct for ct in firewall_cts if ct not in current_cts]
        if missing_cts:
            tag.content_types.add(*missing_cts)

    return tag


def _set_nested_group_members(parent_obj, member_names, relationship_key, group_model_class):
    """Set nested group members via Nautobot Relationship.

    This function manages the many-to-many self-referential relationship between
    group objects (e.g., AddressObjectGroup containing other AddressObjectGroups).

    Args:
        parent_obj: The parent group object instance.
        member_names: List of member group names to set.
        relationship_key: The key of the self-referential relationship.
        group_model_class: The model class for the group type.
    """
    try:
        relationship = Relationship.objects.filter(key=relationship_key).first()
        if not relationship:
            # Relationship not created yet (signals haven't run) - skip silently
            return

        content_type = ContentType.objects.get_for_model(group_model_class)

        # Remove existing associations where this group is the source (parent)
        RelationshipAssociation.objects.filter(
            relationship=relationship,
            source_type=content_type,
            source_id=parent_obj.pk,
        ).delete()

        # Create new associations for each member group
        for member_name in member_names or []:
            try:
                member_obj = group_model_class.objects.get(name=member_name)
                RelationshipAssociation.objects.get_or_create(
                    relationship=relationship,
                    source_type=content_type,
                    source_id=parent_obj.pk,
                    destination_type=content_type,
                    destination_id=member_obj.pk,
                )
            except group_model_class.DoesNotExist:
                # Member group doesn't exist yet - will be created later in sync
                pass
    except Exception as exc:  # pylint: disable=broad-except
        # Defensive: don't fail the sync if relationship management fails
        logger.debug(
            "Failed to set nested group members for relationship %s on %s: %s",
            relationship_key,
            getattr(parent_obj, "name", parent_obj),
            exc,
        )


def _resolve_objects_with_group_fallback(object_cls, group_cls, names, label_obj, label_group, logger=None, context=""):
    """Resolve names that may refer to either objects or groups.

    PAN-OS rules don't distinguish between objects and groups in source/destination
    lists - everything goes into one list. This function tries objects first, then groups.

    Also handles cases where Panorama rules reference FQDN/IP values directly instead of
    AddressObject names (e.g., rule references 'server.example.com' but AddressObject is named 'server').

    Args:
        object_cls: The ORM model class for individual objects (e.g., OrmAddressObject).
        group_cls: The ORM model class for groups (e.g., OrmAddressObjectGroup).
        names: List of names to resolve.
        label_obj: Human-readable label for objects (for logging).
        label_group: Human-readable label for groups (for logging).
        logger: Optional logger instance for debug/warning messages.
        context: Optional context string for log messages (e.g., rule identifier).

    Returns:
        Tuple of (resolved_objects, resolved_groups).
    """
    if names and "any" in names:
        return [], []

    resolved_objects = []
    resolved_groups = []

    for n in names or []:
        found = False

        # First try exact name match for object
        try:
            found_obj = object_cls.objects.get(name=n)
            resolved_objects.append(found_obj)
            found = True
            continue
        except object_cls.DoesNotExist:
            pass
        except Exception as e:  # noqa: BLE001
            if logger:
                logger.debug(f"Unexpected error looking up {label_obj} '{n}': {e}")

        # For AddressObjects, try looking up by FQDN reference value
        # This handles cases where rule references 'server.example.com' but AddressObject is named 'server'
        if not found and object_cls == OrmAddressObject:
            try:
                # Look for AddressObject that has this value as its FQDN reference
                found_obj = OrmAddressObject.objects.filter(fqdn__name=n).first()
                if found_obj:
                    resolved_objects.append(found_obj)
                    if logger:
                        logger.debug(f"Resolved '{n}' to AddressObject '{found_obj.name}' via FQDN reference{context}")
                    found = True
                    continue
                # Also try case-insensitive FQDN lookup
                found_obj = OrmAddressObject.objects.filter(fqdn__name__iexact=n).first()
                if found_obj:
                    resolved_objects.append(found_obj)
                    if logger:
                        logger.debug(
                            f"Resolved '{n}' to AddressObject '{found_obj.name}' via FQDN reference (case-insensitive){context}"
                        )
                    found = True
                    continue
            except Exception as e:  # noqa: BLE001
                if logger:
                    logger.debug(f"Error during FQDN lookup for '{n}': {e}")

        # Try group fallback if object not found
        if not found:
            try:
                grp = group_cls.objects.get(name=n)
                resolved_groups.append(grp)
                found = True
                continue
            except group_cls.DoesNotExist:
                pass
            except Exception as e:  # noqa: BLE001
                if logger:
                    logger.debug(f"Unexpected error looking up {label_group} '{n}': {e}")

        # Not found in either - log detailed warning
        if not found and logger:
            # Check if object exists with case-insensitive search to help debug
            exists_case_insensitive = (
                object_cls.objects.filter(name__iexact=n).exists() or group_cls.objects.filter(name__iexact=n).exists()
            )
            if exists_case_insensitive:
                logger.warning(
                    f"Referenced {label_obj}/{label_group} '{n}' not found (case-sensitive){context}. "
                    f"A case-insensitive match exists - check for case mismatch."
                )
            else:
                logger.warning(
                    f"Referenced {label_obj}/{label_group} '{n}' not found in Nautobot{context}. "
                    f"Verify object exists and sync order is correct."
                )

    return resolved_objects, resolved_groups


class NautobotFQDN(FQDNBase):
    """Nautobot FQDN implementation."""

    @classmethod
    def create(cls, adapter, ids, attrs):  # noqa: D401
        """Create FQDN in Nautobot, apply Panorama tag, return DiffSync instance."""
        # TODO: Find a way to handle FQDN preservation when Nautobot wants an IPAddress object in the FQDN object
        tag = _get_tag()
        obj, _ = OrmFQDN.objects.get_or_create(
            name=ids["name"], defaults={"description": attrs.get("description", ""), "status": get_active_status()}
        )
        obj.tags.add(tag)
        obj.validated_save()
        return super().create(ids=ids, adapter=adapter, attrs=attrs)

    def update(self, attrs):
        """Update existing FQDN attributes (description) if changed."""
        obj = OrmFQDN.objects.get(name=self.name)
        if "description" in attrs:
            obj.description = attrs["description"] or ""
        obj.validated_save()
        return super().update(attrs)

    def delete(self):
        """Schedule FQDN for deletion after sync complete (ordered cleanup)."""
        obj = OrmFQDN.objects.get(name=self.name)
        self.adapter.objects_to_delete.setdefault("fqdn", []).append(obj)
        return super().delete()


class NautobotIPRange(IPRangeBase):
    """Nautobot IPRange implementation."""

    @classmethod
    def create(cls, adapter, ids, attrs):
        """Create IPRange (start/end) and tag; return DiffSync instance."""
        tag = _get_tag()
        obj, _ = OrmIPRange.objects.get_or_create(
            start_address=ids["start_address"],
            end_address=ids["end_address"],
            defaults={"description": attrs.get("description", ""), "status": get_active_status()},
        )
        obj.tags.add(tag)
        obj.validated_save()
        return super().create(ids=ids, adapter=adapter, attrs=attrs)

    def update(self, attrs):
        """Update IPRange description if modified."""
        obj = OrmIPRange.objects.get(start_address=self.start_address, end_address=self.end_address)
        if "description" in attrs:
            obj.description = attrs["description"] or ""
        obj.validated_save()
        return super().update(attrs)

    def delete(self):
        """Schedule IPRange for deletion post-sync."""
        obj = OrmIPRange.objects.get(start_address=self.start_address, end_address=self.end_address)
        self.adapter.objects_to_delete.setdefault("iprange", []).append(obj)
        return super().delete()


class NautobotAddressObject(AddressObjectBase):
    """Nautobot AddressObject implementation."""

    @classmethod
    def create(cls, adapter, ids, attrs):
        """Create AddressObject referencing exactly one underlying address type (if present)."""
        tag = _get_tag()
        # Check if this is an auto-created inline IP reference
        is_auto_created = "(auto-created)" in attrs.get("description", "")
        # Resolve underlying address reference
        kwargs = {"name": ids["name"], "description": attrs.get("description", ""), "status": get_active_status()}
        if attrs.get("fqdn"):
            # Auto-create FQDN if it doesn't exist (common when Panorama AddressObjects reference FQDNs)
            fqdn_obj, fqdn_created = OrmFQDN.objects.get_or_create(
                name=attrs["fqdn"],
                defaults={
                    "description": f"Auto-created for AddressObject {ids['name']}",
                    "status": get_active_status(),
                },
            )
            if fqdn_created:
                adapter.job.logger.info(f"Auto-created FQDN '{attrs['fqdn']}' for AddressObject {ids['name']}")
            kwargs["fqdn"] = fqdn_obj
        elif attrs.get("ip_range") and "-" in attrs["ip_range"]:
            start, end = attrs["ip_range"].split("-", 1)
            # Auto-create IPRange if it doesn't exist
            ip_range_obj, iprange_created = OrmIPRange.objects.get_or_create(
                start_address=start.strip(),
                end_address=end.strip(),
                defaults={
                    "description": f"Auto-created for AddressObject {ids['name']}",
                    "status": get_active_status(),
                },
            )
            if iprange_created:
                adapter.job.logger.info(f"Auto-created IPRange '{attrs['ip_range']}' for AddressObject {ids['name']}")
            kwargs["ip_range"] = ip_range_obj
        elif attrs.get("ip_address"):
            # Host address (typically /32) - store as IPAddress with explicit /32 mask
            # This handles the ip_address field from SDK which contains /32 addresses
            addr_value = attrs["ip_address"]
            if "/" in addr_value:
                address = addr_value.split("/")[0]
                # Always use /32 for host addresses to match Panorama semantics
                mask_length = 32
            else:
                address = addr_value
                mask_length = 32
            # Find or create parent prefix for the IPAddress
            prefix = get_parent_prefix(address)
            if not prefix:
                # Create a parent prefix if none exists
                parent_cidr = find_best_cidr(address)
                if parent_cidr != 32:
                    subnet = ip_network(f"{address}/{parent_cidr}", strict=False).with_prefixlen
                else:
                    subnet = f"{address}/32"
                prefix, _ = Prefix.objects.get_or_create(
                    prefix=subnet,
                    namespace__name="Global",
                    status=get_active_status(),
                )
            # Create IPAddress with /32 mask to match Panorama host representation
            ip_obj, _ = IPAddress.objects.get_or_create(
                host=address,
                parent__namespace__name="Global",
                defaults={"status": get_active_status(), "parent": prefix, "mask_length": mask_length},
            )
            kwargs["ip_address"] = ip_obj
        elif attrs.get("prefix") and ("/" not in attrs["prefix"] or "/32" in attrs["prefix"]):
            address = attrs["prefix"].split("/")[0]
            prefix = get_parent_prefix(address)
            if prefix:
                cidr = prefix.prefix_length
            else:
                cidr = find_best_cidr(address)
                # adapter.job.logger.warning(
                #     f"No parent Prefix found for IP address; attrs: {attrs} in AddressObject {ids['name']}, address: {address}, cidr: {cidr}"
                # )
                if cidr != 32:
                    subnet = ip_network(f"{address}/{cidr}", strict=False).with_prefixlen
                else:
                    subnet = f"{address}/32"
                prefix, _ = Prefix.objects.get_or_create(
                    prefix=subnet,
                    namespace__name="Global",
                    status=get_active_status(),
                )
            # TODO: Handle case where prefix length differs from established subnets
            addressobject, _ = IPAddress.objects.get_or_create(
                host=address,
                parent__namespace__name="Global",
                defaults={"status": get_active_status(), "parent": prefix, "mask_length": cidr},
            )
            kwargs["ip_address"] = addressobject
        elif attrs.get("prefix"):
            subnet = ip_network(attrs["prefix"], strict=False).with_prefixlen
            try:
                prefix, _ = Prefix.objects.get_or_create(
                    prefix=subnet,
                    namespace__name="Global",
                    status=get_active_status(),
                )
                kwargs["prefix"] = prefix
            except (Prefix.DoesNotExist, Prefix.MultipleObjectsReturned, ValueError) as exc:
                adapter.job.logger.warning(
                    f"Prefix {attrs['prefix']} could not be created/found for AddressObject {ids['name']}: {exc}, attrs: {attrs}"
                )
        try:
            obj, _ = OrmAddressObject.objects.get_or_create(name=ids["name"], defaults=kwargs)
        except Exception as exc:
            adapter.job.logger.error(
                f"Error creating AddressObject {ids['name']}: {exc}, attrs: {attrs}, kwargs: {kwargs}"
            )
            raise
        # If already exists, update description only (do not change underlying type automatically)
        if not _:
            changed = False
            if obj.description != kwargs["description"]:
                obj.description = kwargs["description"]
                changed = True
            if changed:
                obj.validated_save()

        # Defer tag assignment for batch processing at end of sync
        if hasattr(adapter, "objects_pending_tags") and "addressobject" in adapter.objects_pending_tags:
            adapter.objects_pending_tags["addressobject"].append(obj)
        else:
            # Fallback to immediate tagging if deferred tags not supported
            obj.tags.add(tag)
            obj.validated_save()

        # If this is an auto-created inline IP, also tag it for tracking and cleanup
        if is_auto_created:
            auto_tag, _ = OrmTag.objects.get_or_create(
                name="Auto-Created Inline IP",
                defaults={"description": "AddressObject auto-created from inline IP reference in policy rule"},
            )
            # Ensure the tag has all firewall model content types
            firewall_cts = _get_firewall_content_types()
            if firewall_cts:
                existing_ct_ids = set(auto_tag.content_types.values_list("id", flat=True))
                missing_cts = [ct for ct in firewall_cts if ct.id not in existing_ct_ids]
                if missing_cts:
                    auto_tag.content_types.add(*missing_cts)
            obj.tags.add(auto_tag)
            obj.validated_save()

        return super().create(ids=ids, adapter=adapter, attrs=attrs)

    def update(self, attrs):
        """Update AddressObject description only (underlying type changes ignored)."""
        obj = OrmAddressObject.objects.get(name=self.name)
        changed = False
        if "description" in attrs and obj.description != attrs["description"]:
            obj.description = attrs["description"] or ""
            changed = True
        if changed:
            obj.validated_save()
        return super().update(attrs)

    def delete(self):
        """Schedule AddressObject for deletion post-sync."""
        obj = OrmAddressObject.objects.get(name=self.name)
        self.adapter.objects_to_delete.setdefault("addressobject", []).append(obj)
        return super().delete()


class NautobotServiceObject(ServiceObjectBase):
    """Nautobot ServiceObject implementation."""

    @classmethod
    def create(cls, adapter, ids, attrs):
        """Create ServiceObject (port/ip_protocol) and apply tag.

        Special handling is applied for the Panorama keyword 'application-default'. When rules
        specify service 'application-default', a placeholder ServiceObject is created with:
            ip_protocol = 'Reserved'
            description noting placeholder semantics
            status = Active
        This preserves rule references while documenting that dynamic application-specific
        ports are implied rather than enumerated.
        """
        tag = _get_tag()
        name = ids["name"]
        description = attrs.get("description", "")
        ip_protocol = attrs.get("ip_protocol")
        port = attrs.get("port")
        if name == "application-default":
            # Override with placeholder semantics
            if not ip_protocol:
                ip_protocol = "Reserved"
            if not description:
                description = "Placeholder for Panorama 'application-default' dynamic service"
            # Port stored as string; only set sentinel if missing (None). Avoid treating existing '0' as missing.
            if port is None:
                port = "0"
        defaults = {
            "description": description,
            "port": port,
            "ip_protocol": ip_protocol,
            "status": get_active_status(),
        }
        obj, _ = OrmServiceObject.objects.get_or_create(name=name, defaults=defaults)

        # Defer tag assignment for batch processing at end of sync
        if hasattr(adapter, "objects_pending_tags") and "serviceobject" in adapter.objects_pending_tags:
            adapter.objects_pending_tags["serviceobject"].append(obj)
        else:
            # Fallback to immediate tagging if deferred tags not supported
            obj.tags.add(tag)
            obj.validated_save()

        return super().create(ids=ids, adapter=adapter, attrs=attrs)

    def update(self, attrs):
        """Update ServiceObject fields that changed (description/port/ip_protocol)."""
        obj = OrmServiceObject.objects.get(name=self.name)
        changed = False
        for field in ("description", "port", "ip_protocol"):
            if field in attrs and getattr(obj, field) != attrs[field]:
                setattr(obj, field, attrs[field])
                changed = True
        if changed:
            obj.validated_save()
        return super().update(attrs)

    def delete(self):
        """Schedule ServiceObject for deletion post-sync."""
        obj = OrmServiceObject.objects.get(name=self.name)
        self.adapter.objects_to_delete.setdefault("serviceobject", []).append(obj)
        return super().delete()


class NautobotApplicationObject(ApplicationObjectBase):
    """Nautobot ApplicationObject implementation."""

    @classmethod
    def create(cls, adapter, ids, attrs):  # noqa: D401
        """Create ApplicationObject and tag it."""
        tag = _get_tag()
        # Ensure required Panorama fields are coerced to empty string if None to satisfy NOT NULL constraints.
        description = attrs.get("description") or ""
        category = attrs.get("category") or ""
        subcategory = attrs.get("subcategory") or ""
        technology = attrs.get("technology") or ""
        risk = attrs.get("risk")  # risk may be int or None; leave None if missing
        obj, created = OrmApplicationObject.objects.get_or_create(
            name=ids["name"],
            defaults={
                "description": description,
                "category": category,
                "subcategory": subcategory,
                "technology": technology,
                "risk": risk,
            },
        )
        if not created:
            changed = False
            if obj.description != description:
                obj.description = description
                changed = True
            if obj.category != category:
                obj.category = category
                changed = True
            if obj.subcategory != subcategory:
                obj.subcategory = subcategory
                changed = True
            if obj.technology != technology:
                obj.technology = technology
                changed = True
            # Only update risk if provided (None means leave existing)
            if risk is not None and obj.risk != risk:
                obj.risk = risk
                changed = True
            if changed:
                obj.validated_save()

        # Defer tag assignment for batch processing at end of sync
        if hasattr(adapter, "objects_pending_tags") and "applicationobject" in adapter.objects_pending_tags:
            adapter.objects_pending_tags["applicationobject"].append(obj)
        else:
            # Fallback to immediate tagging if deferred tags not supported
            obj.tags.add(tag)
            obj.validated_save()

        return super().create(ids=ids, adapter=adapter, attrs=attrs)

    def update(self, attrs):
        """Update ApplicationObject fields if changed."""
        obj = OrmApplicationObject.objects.get(name=self.name)
        changed = False
        if "description" in attrs and obj.description != (attrs.get("description") or ""):
            obj.description = attrs.get("description") or ""
            changed = True
        if "category" in attrs and obj.category != (attrs.get("category") or ""):
            obj.category = attrs.get("category") or ""
            changed = True
        if "subcategory" in attrs and obj.subcategory != (attrs.get("subcategory") or ""):
            obj.subcategory = attrs.get("subcategory") or ""
            changed = True
        if "technology" in attrs and obj.technology != (attrs.get("technology") or ""):
            obj.technology = attrs.get("technology") or ""
            changed = True
        if "risk" in attrs and attrs.get("risk") is not None and obj.risk != attrs.get("risk"):
            obj.risk = attrs.get("risk")
            changed = True
        if changed:
            obj.validated_save()
        return super().update(attrs)

    def delete(self):
        """Schedule ApplicationObject for deletion post-sync."""
        obj = OrmApplicationObject.objects.get(name=self.name)
        self.adapter.objects_to_delete.setdefault("applicationobject", []).append(obj)
        return super().delete()


class NautobotUserObject(UserObjectBase):
    """Nautobot UserObject implementation."""

    @classmethod
    def create(cls, adapter, ids, attrs):  # noqa: D401
        """Create UserObject and tag it."""
        tag = _get_tag()
        username = ids["name"]
        obj = OrmUserObject.objects.filter(username=username).first()
        if obj is None:
            obj, _ = OrmUserObject.objects.get_or_create(username=username)
        # Defer tag assignment for batch processing at end of sync
        if hasattr(adapter, "objects_pending_tags") and "userobject" in adapter.objects_pending_tags:
            adapter.objects_pending_tags["userobject"].append(obj)
        else:
            obj.tags.add(tag)
            obj.validated_save()
        return super().create(ids=ids, adapter=adapter, attrs=attrs)

    def update(self, attrs):
        """Update UserObject (no mutable fields currently synced)."""
        OrmUserObject.objects.filter(username=self.name).first()
        return super().update(attrs)

    def delete(self):
        """Schedule UserObject for deletion post-sync."""
        obj = OrmUserObject.objects.get(username=self.name)
        self.adapter.objects_to_delete.setdefault("userobject", []).append(obj)
        return super().delete()


class NautobotZone(ZoneBase):
    """Nautobot Zone implementation."""

    @classmethod
    def create(cls, adapter, ids, attrs):  # noqa: D401
        """Create Zone and tag it."""
        tag = _get_tag()
        obj, _ = OrmZone.objects.get_or_create(
            name=ids["name"],
            defaults={
                "description": attrs.get("description", ""),
                "status": get_active_status(),
            },
        )
        obj.tags.add(tag)
        obj.validated_save()
        return super().create(ids=ids, adapter=adapter, attrs=attrs)

    def update(self, attrs):
        """Update Zone description if changed (interfaces/vrfs future)."""
        obj = OrmZone.objects.get(name=self.name)
        if "description" in attrs and obj.description != attrs["description"]:
            obj.description = attrs["description"] or ""
            obj.validated_save()
        return super().update(attrs)

    def delete(self):
        """Schedule Zone for deletion post-sync."""
        obj = OrmZone.objects.get(name=self.name)
        self.adapter.objects_to_delete.setdefault("zone", []).append(obj)
        return super().delete()


class NautobotAddressObjectGroup(AddressObjectGroupBase):
    """Nautobot AddressObjectGroup implementation."""

    @classmethod
    def create(cls, adapter, ids, attrs):
        """Create AddressObjectGroup, tag it, and attach member AddressObjects and nested groups."""
        tag = _get_tag()
        obj, _ = OrmAddressObjectGroup.objects.get_or_create(
            name=ids["name"], defaults={"description": attrs.get("description", "")}
        )
        obj.tags.add(tag)

        # Add member address objects (individual addresses)
        address_object_names = attrs.get("address_objects", [])
        if address_object_names:
            members = OrmAddressObject.objects.filter(name__in=address_object_names)
            obj.address_objects.set(members)

        obj.validated_save()

        # Add nested group members via Relationship
        address_object_group_names = attrs.get("address_object_groups", [])
        if address_object_group_names:
            _set_nested_group_members(
                obj,
                address_object_group_names,
                "address_object_group_to_address_object_group",
                OrmAddressObjectGroup,
            )

        return super().create(ids=ids, adapter=adapter, attrs=attrs)

    def update(self, attrs):
        """Update AddressObjectGroup description, members, and nested groups if changed."""
        obj = OrmAddressObjectGroup.objects.get(name=self.name)
        changed = False

        if "description" in attrs and obj.description != attrs["description"]:
            obj.description = attrs["description"] or ""
            changed = True

        # Update member address objects if provided
        if "address_objects" in attrs:
            address_object_names = attrs.get("address_objects", [])
            members = OrmAddressObject.objects.filter(name__in=address_object_names)
            obj.address_objects.set(members)
            changed = True

        # Update nested group members via Relationship
        if "address_object_groups" in attrs:
            _set_nested_group_members(
                obj,
                attrs.get("address_object_groups", []),
                "address_object_group_to_address_object_group",
                OrmAddressObjectGroup,
            )
            changed = True

        if changed:
            obj.validated_save()
        return super().update(attrs)

    def delete(self):
        """Schedule AddressObjectGroup for deletion post-sync."""
        obj = OrmAddressObjectGroup.objects.get(name=self.name)
        self.adapter.objects_to_delete.setdefault("addressobjectgroup", []).append(obj)
        return super().delete()


class NautobotServiceObjectGroup(ServiceObjectGroupBase):
    """Nautobot ServiceObjectGroup implementation."""

    @classmethod
    def create(cls, adapter, ids, attrs):
        """Create ServiceObjectGroup, tag it, and attach member ServiceObjects and nested groups."""
        tag = _get_tag()
        obj, _ = OrmServiceObjectGroup.objects.get_or_create(
            name=ids["name"], defaults={"description": attrs.get("description", "")}
        )
        obj.tags.add(tag)

        # Add member service objects (individual services)
        service_object_names = attrs.get("service_objects", [])
        if service_object_names:
            members = OrmServiceObject.objects.filter(name__in=service_object_names)
            obj.service_objects.set(members)

        obj.validated_save()

        # Add nested group members via Relationship
        service_object_group_names = attrs.get("service_object_groups", [])
        if service_object_group_names:
            _set_nested_group_members(
                obj,
                service_object_group_names,
                "service_object_group_to_service_object_group",
                OrmServiceObjectGroup,
            )

        return super().create(ids=ids, adapter=adapter, attrs=attrs)

    def update(self, attrs):
        """Update ServiceObjectGroup description, members, and nested groups if changed."""
        obj = OrmServiceObjectGroup.objects.get(name=self.name)
        changed = False

        if "description" in attrs and obj.description != attrs["description"]:
            obj.description = attrs["description"] or ""
            changed = True

        # Update member service objects if provided
        if "service_objects" in attrs:
            service_object_names = attrs.get("service_objects", [])
            members = OrmServiceObject.objects.filter(name__in=service_object_names)
            obj.service_objects.set(members)
            changed = True

        # Update nested group members via Relationship
        if "service_object_groups" in attrs:
            _set_nested_group_members(
                obj,
                attrs.get("service_object_groups", []),
                "service_object_group_to_service_object_group",
                OrmServiceObjectGroup,
            )
            changed = True

        if changed:
            obj.validated_save()
        return super().update(attrs)

    def delete(self):
        """Schedule ServiceObjectGroup for deletion post-sync."""
        obj = OrmServiceObjectGroup.objects.get(name=self.name)
        self.adapter.objects_to_delete.setdefault("serviceobjectgroup", []).append(obj)
        return super().delete()


class NautobotApplicationObjectGroup(ApplicationObjectGroupBase):
    """Nautobot ApplicationObjectGroup implementation."""

    @classmethod
    def create(cls, adapter, ids, attrs):
        """Create ApplicationObjectGroup, tag it, and attach member ApplicationObjects and nested groups."""
        tag = _get_tag()
        obj, _ = OrmApplicationObjectGroup.objects.get_or_create(
            name=ids["name"], defaults={"description": attrs.get("description", "")}
        )
        obj.tags.add(tag)

        # Add member application objects (individual applications)
        application_object_names = attrs.get("application_objects", [])
        if application_object_names:
            members = OrmApplicationObject.objects.filter(name__in=application_object_names)
            obj.application_objects.set(members)

        obj.validated_save()

        # Add nested group members via Relationship
        application_object_group_names = attrs.get("application_object_groups", [])
        if application_object_group_names:
            _set_nested_group_members(
                obj,
                application_object_group_names,
                "application_object_group_to_application_object_group",
                OrmApplicationObjectGroup,
            )

        return super().create(ids=ids, adapter=adapter, attrs=attrs)

    def update(self, attrs):
        """Update ApplicationObjectGroup description, members, and nested groups if changed."""
        obj = OrmApplicationObjectGroup.objects.get(name=self.name)
        changed = False

        if "description" in attrs and obj.description != attrs["description"]:
            obj.description = attrs["description"] or ""
            changed = True

        # Update member application objects if provided
        if "application_objects" in attrs:
            application_object_names = attrs.get("application_objects", [])
            members = OrmApplicationObject.objects.filter(name__in=application_object_names)
            obj.application_objects.set(members)
            changed = True

        # Update nested group members via Relationship
        if "application_object_groups" in attrs:
            _set_nested_group_members(
                obj,
                attrs.get("application_object_groups", []),
                "application_object_group_to_application_object_group",
                OrmApplicationObjectGroup,
            )
            changed = True

        if changed:
            obj.validated_save()
        return super().update(attrs)

    def delete(self):
        """Schedule ApplicationObjectGroup for deletion post-sync."""
        obj = OrmApplicationObjectGroup.objects.get(name=self.name)
        self.adapter.objects_to_delete.setdefault("applicationobjectgroup", []).append(obj)
        return super().delete()


class NautobotPolicy(PolicyBase):
    """Nautobot Policy implementation."""

    @classmethod
    def create(cls, adapter, ids, attrs):
        """Create Policy by name and tag it; store descriptive context."""
        tag = _get_tag()
        obj, _ = OrmPolicy.objects.get_or_create(
            name=ids["name"], defaults={"description": attrs.get("description", "")}
        )
        obj.tags.add(tag)
        obj.validated_save()
        return super().create(ids=ids, adapter=adapter, attrs=attrs)

    def update(self, attrs):
        """Update Policy description if changed."""
        obj = OrmPolicy.objects.get(name=self.name)
        if "description" in attrs and obj.description != attrs["description"]:
            obj.description = attrs["description"] or ""
            obj.validated_save()
        return super().update(attrs)

    def delete(self):
        """Schedule Policy for deletion post-sync."""
        obj = OrmPolicy.objects.get(name=self.name)
        self.adapter.objects_to_delete.setdefault("policy", []).append(obj)
        return super().delete()


class NautobotPolicyRule(PolicyRuleBase):
    """Nautobot PolicyRule implementation."""

    @classmethod
    def create(cls, adapter, ids, attrs):
        """Create PolicyRule linked to parent Policy (by policy_name) and tag it."""
        tag = _get_tag()

        # policy_name is now in ids (as an identifier), not attrs
        policy_name = ids.get("policy_name", "unknown")

        # Helper to format rule context for logging
        def _format_rule_context():
            """Format comprehensive rule context for debugging."""
            rule_name = attrs.get("name", "<unnamed>")
            rule_index = ids.get("index", "?")
            # Policy name now directly from SDK (e.g., "SEC-PRE-DFW DataCenter")
            return f"Rule '{rule_name}' (index {rule_index}) in policy '{policy_name}'"

        try:
            parent = OrmPolicy.objects.get(name=policy_name)
        except OrmPolicy.DoesNotExist:
            adapter.job.logger.warning(f"Parent Policy not found for {_format_rule_context()}")
            return None
        # Ensure required DB fields exist at creation time to avoid integrity errors.
        defaults = {
            "name": attrs.get("name", "") or "",
            "action": attrs.get("action") or "",
            # Coerce None to empty string to satisfy NOT NULL constraint.
            "description": (attrs.get("description") or ""),
            "status": get_active_status(),
        }

        if not attrs.get("action"):
            adapter.job.logger.warning(
                "PolicyRule %s created without 'action' in attrs; defaulting to empty string",
                ids["index"],
            )
        # Look for existing rule in this specific policy to avoid index collision across policies
        obj = None
        if parent:
            obj = parent.policy_rules.filter(index=ids["index"]).first()
        if not obj:
            try:
                obj = OrmPolicyRule.objects.create(
                    index=ids["index"],
                    name=defaults["name"],
                    action=defaults["action"],
                    description=defaults["description"],
                    status=defaults["status"],
                )
            except Exception as exc:
                adapter.job.logger.error(f"Error creating PolicyRule {ids['index']}: {exc}, defaults: {defaults}")
                raise
        else:
            # Ensure description is non-null on existing rows
            if obj.description is None:
                obj.description = defaults["description"]
                obj.validated_save()
        # Attach to parent via M2M if not already present
        if parent and obj not in parent.policy_rules.all():
            parent.policy_rules.add(obj)
        # Populate scalar fields
        if "action" in attrs:
            obj.action = attrs.get("action") or ""
        if "description" in attrs:
            obj.description = attrs.get("description") or ""

        # Helper to resolve named objects for M2M fields
        def _resolve_qs(model_cls, names, field_label):
            # Treat Panorama wildcard 'any' as empty list overriding other entries if present.
            if names and "any" in names:
                return []
            resolved = []
            for n in names or []:
                try:
                    if model_cls == OrmUserObject:
                        resolved.append(model_cls.objects.get(username=n))
                    else:
                        resolved.append(model_cls.objects.get(name=n))
                except model_cls.DoesNotExist:
                    pass
                except Exception:  # noqa: BLE001 - broad except to capture DoesNotExist and DB errors
                    adapter.job.logger.warning(f"Referenced {field_label} '{n}' not found for {_format_rule_context()}")
            return resolved

        # Zones (FKs)
        if attrs.get("source_zone") and attrs.get("source_zone") != "any":
            try:
                obj.source_zone = OrmZone.objects.get(name=attrs.get("source_zone"))
            except OrmZone.DoesNotExist:
                adapter.job.logger.warning(
                    f"Source Zone '{attrs.get('source_zone')}' not found for {_format_rule_context()}"
                )
        if attrs.get("destination_zone") and attrs.get("destination_zone") != "any":
            try:
                obj.destination_zone = OrmZone.objects.get(name=attrs.get("destination_zone"))
            except OrmZone.DoesNotExist:
                adapter.job.logger.warning(
                    f"Destination Zone '{attrs.get('destination_zone')}' not found for {_format_rule_context()}"
                )

        # M2M collections - use module-level helper with context for logging
        rule_context = f" for {_format_rule_context()}"

        # Source address/services/applications with fallback
        if "source_addresses" in attrs:
            objs, grps_fallback = _resolve_objects_with_group_fallback(
                OrmAddressObject,
                OrmAddressObjectGroup,
                attrs.get("source_addresses", []),
                "AddressObject",
                "AddressObjectGroup",
                logger=adapter.job.logger,
                context=rule_context,
            )
            obj.source_addresses.set(objs)
            # Merge explicit group list + fallback groups
            if "source_address_groups" in attrs:
                explicit_groups = _resolve_qs(
                    OrmAddressObjectGroup, attrs.get("source_address_groups", []), "AddressObjectGroup"
                )
                merged = {g.pk for g in explicit_groups + grps_fallback}
                obj.source_address_groups.set(list(OrmAddressObjectGroup.objects.filter(pk__in=merged)))
            elif grps_fallback:
                obj.source_address_groups.set(grps_fallback)
        else:
            if "source_address_groups" in attrs:
                obj.source_address_groups.set(
                    _resolve_qs(OrmAddressObjectGroup, attrs.get("source_address_groups", []), "AddressObjectGroup")
                )

        if "source_services" in attrs:
            objs, grps_fallback = _resolve_objects_with_group_fallback(
                OrmServiceObject,
                OrmServiceObjectGroup,
                attrs.get("source_services", []),
                "ServiceObject",
                "ServiceObjectGroup",
                logger=adapter.job.logger,
                context=rule_context,
            )
            obj.source_services.set(objs)
            if "source_service_groups" in attrs:
                explicit_groups = _resolve_qs(
                    OrmServiceObjectGroup, attrs.get("source_service_groups", []), "ServiceObjectGroup"
                )
                merged = {g.pk for g in explicit_groups + grps_fallback}
                obj.source_service_groups.set(list(OrmServiceObjectGroup.objects.filter(pk__in=merged)))
            elif grps_fallback:
                obj.source_service_groups.set(grps_fallback)
        else:
            if "source_service_groups" in attrs:
                obj.source_service_groups.set(
                    _resolve_qs(OrmServiceObjectGroup, attrs.get("source_service_groups", []), "ServiceObjectGroup")
                )

        if "destination_addresses" in attrs:
            objs, grps_fallback = _resolve_objects_with_group_fallback(
                OrmAddressObject,
                OrmAddressObjectGroup,
                attrs.get("destination_addresses", []),
                "AddressObject",
                "AddressObjectGroup",
                logger=adapter.job.logger,
                context=rule_context,
            )
            obj.destination_addresses.set(objs)
            if "destination_address_groups" in attrs:
                explicit_groups = _resolve_qs(
                    OrmAddressObjectGroup, attrs.get("destination_address_groups", []), "AddressObjectGroup"
                )
                merged = {g.pk for g in explicit_groups + grps_fallback}
                obj.destination_address_groups.set(list(OrmAddressObjectGroup.objects.filter(pk__in=merged)))
            elif grps_fallback:
                obj.destination_address_groups.set(grps_fallback)
        else:
            if "destination_address_groups" in attrs:
                obj.destination_address_groups.set(
                    _resolve_qs(
                        OrmAddressObjectGroup, attrs.get("destination_address_groups", []), "AddressObjectGroup"
                    )
                )

        if "destination_services" in attrs:
            objs, grps_fallback = _resolve_objects_with_group_fallback(
                OrmServiceObject,
                OrmServiceObjectGroup,
                attrs.get("destination_services", []),
                "ServiceObject",
                "ServiceObjectGroup",
                logger=adapter.job.logger,
                context=rule_context,
            )
            obj.destination_services.set(objs)
            if "destination_service_groups" in attrs:
                explicit_groups = _resolve_qs(
                    OrmServiceObjectGroup, attrs.get("destination_service_groups", []), "ServiceObjectGroup"
                )
                merged = {g.pk for g in explicit_groups + grps_fallback}
                obj.destination_service_groups.set(list(OrmServiceObjectGroup.objects.filter(pk__in=merged)))
            elif grps_fallback:
                obj.destination_service_groups.set(grps_fallback)
        else:
            if "destination_service_groups" in attrs:
                obj.destination_service_groups.set(
                    _resolve_qs(
                        OrmServiceObjectGroup, attrs.get("destination_service_groups", []), "ServiceObjectGroup"
                    )
                )

        if "applications" in attrs:
            objs, grps_fallback = _resolve_objects_with_group_fallback(
                OrmApplicationObject,
                OrmApplicationObjectGroup,
                attrs.get("applications", []),
                "ApplicationObject",
                "ApplicationObjectGroup",
                logger=adapter.job.logger,
                context=rule_context,
            )
            obj.applications.set(objs)
            if "application_groups" in attrs:
                explicit_groups = _resolve_qs(
                    OrmApplicationObjectGroup, attrs.get("application_groups", []), "ApplicationObjectGroup"
                )
                merged = {g.pk for g in explicit_groups + grps_fallback}
                obj.application_groups.set(list(OrmApplicationObjectGroup.objects.filter(pk__in=merged)))
            elif grps_fallback:
                obj.application_groups.set(grps_fallback)
        else:
            if "application_groups" in attrs:
                obj.application_groups.set(
                    _resolve_qs(
                        OrmApplicationObjectGroup, attrs.get("application_groups", []), "ApplicationObjectGroup"
                    )
                )

        # Users (M2M) - optional in firewall models
        if hasattr(obj, "source_users") and "source_users" in attrs:
            obj.source_users.set(_resolve_qs(OrmUserObject, attrs.get("source_users", []), "UserObject"))
        if hasattr(obj, "destination_users") and "destination_users" in attrs:
            obj.destination_users.set(_resolve_qs(OrmUserObject, attrs.get("destination_users", []), "UserObject"))

        obj.tags.add(tag)
        obj.validated_save()
        return super().create(ids=ids, adapter=adapter, attrs=attrs)

    def delete(self):
        """Schedule PolicyRule for deletion post-sync if found."""
        # Look up rule via parent policy to handle non-unique indices across policies
        policy_name = getattr(self, "policy_name", None)
        obj = None
        if policy_name:
            try:
                parent = OrmPolicy.objects.get(name=policy_name)
                obj = parent.policy_rules.filter(index=self.index).first()
            except OrmPolicy.DoesNotExist:
                pass
        # Fallback to direct lookup if policy lookup fails
        if not obj:
            try:
                obj = OrmPolicyRule.objects.get(index=self.index, name=self.name)
            except OrmPolicyRule.DoesNotExist:
                pass
        if obj:
            self.adapter.objects_to_delete.setdefault("policyrule", []).append(obj)
        return super().delete()

    def update(self, attrs):  # noqa: D401
        """Update mutable PolicyRule attributes and relationships.

        Supports changes to: name, action, description, zones and all M2M
        collections. Only attributes present in attrs are processed.
        """

        # Helper to format rule context for logging (similar to create method)
        def _format_rule_context():
            """Format comprehensive rule context for debugging."""
            rule_name = self.name or "<unnamed>"
            rule_index = self.index
            policy_name = getattr(self, "policy_name", "unknown")
            # Policy name now directly from SDK (e.g., "SEC-PRE-DFW DataCenter")
            return f"Rule '{rule_name}' (index {rule_index}) in policy '{policy_name}'"

        # Look up rule via parent policy to handle non-unique indices across policies
        policy_name = getattr(self, "policy_name", None)
        obj = None
        if policy_name:
            try:
                parent = OrmPolicy.objects.get(name=policy_name)
                obj = parent.policy_rules.filter(index=self.index).first()
            except OrmPolicy.DoesNotExist:
                pass
        # Fallback to direct index lookup if policy lookup fails
        if not obj:
            try:
                obj = OrmPolicyRule.objects.get(index=self.index)
            except OrmPolicyRule.DoesNotExist:
                pass
        if not obj:
            self.adapter.job.logger.debug(f"PolicyRule index={self.index} not found for update, skipping")
            return super().update(attrs)

        changed = False
        scalar_fields = {"name", "action", "description"}
        for field in scalar_fields:
            if field in attrs and getattr(obj, field) != attrs[field]:
                setattr(obj, field, attrs[field] or "")
                changed = True

        # Zones
        if "source_zone" in attrs:
            if attrs["source_zone"]:
                if attrs["source_zone"] == "any":
                    if obj.source_zone is not None:
                        obj.source_zone = None
                        changed = True
                else:
                    try:
                        zone = OrmZone.objects.get(name=attrs["source_zone"])
                        if obj.source_zone != zone:
                            obj.source_zone = zone
                            changed = True
                    except OrmZone.DoesNotExist:
                        self.adapter.job.logger.warning(
                            f"Update: Source Zone '{attrs['source_zone']}' not found for {_format_rule_context()}"
                        )
            else:
                if obj.source_zone is not None:
                    obj.source_zone = None
                    changed = True
        if "destination_zone" in attrs:
            if attrs["destination_zone"]:
                if attrs["destination_zone"] == "any":
                    if obj.destination_zone is not None:
                        obj.destination_zone = None
                        changed = True
                else:
                    try:
                        zone = OrmZone.objects.get(name=attrs["destination_zone"])
                        if obj.destination_zone != zone:
                            obj.destination_zone = zone
                            changed = True
                    except OrmZone.DoesNotExist:
                        self.adapter.job.logger.warning(
                            f"Update: Destination Zone '{attrs['destination_zone']}' not found for {_format_rule_context()}"
                        )
            else:
                if obj.destination_zone is not None:
                    obj.destination_zone = None
                    changed = True

        # Helper for M2M sets
        def _resolve(model_cls, names, label):
            if names and "any" in names:
                return []
            resolved = []
            for n in names or []:
                try:
                    if model_cls == OrmUserObject:
                        resolved.append(model_cls.objects.get(username=n))
                    else:
                        resolved.append(model_cls.objects.get(name=n))
                except model_cls.DoesNotExist:
                    pass
                except Exception:
                    self.adapter.job.logger.warning(
                        f"Update: Referenced {label} '{n}' not found for {_format_rule_context()}"
                    )
            return resolved

        # Enhanced update with fallback: process paired object/group attrs together
        def _update_with_fallback(
            object_attr, group_attr, object_cls, group_cls, rel_obj_mgr, rel_grp_mgr, label_obj, label_grp
        ):
            nonlocal changed
            obj_names = attrs.get(object_attr) if object_attr in attrs else None
            grp_names = attrs.get(group_attr) if group_attr in attrs else None
            if obj_names is None and grp_names is None:
                return
            if obj_names and "any" in obj_names:
                obj_names = []
            if grp_names and "any" in grp_names:
                grp_names = []
            resolved_objs = []
            fallback_groups = []
            for n in obj_names or []:
                try:
                    resolved_objs.append(object_cls.objects.get(name=n))
                except Exception:  # noqa: BLE001
                    try:
                        fallback_groups.append(group_cls.objects.get(name=n))
                    except Exception:  # noqa: BLE001
                        self.adapter.job.logger.warning(
                            f"Update: Referenced {label_obj}/{label_grp} '{n}' not found for {_format_rule_context()}"
                        )
            if obj_names is not None:
                rel_obj_mgr.set(resolved_objs)
                changed = True
            explicit_groups = []
            if grp_names is not None:
                for n in grp_names:
                    try:
                        explicit_groups.append(group_cls.objects.get(name=n))
                    except Exception:  # noqa: BLE001
                        self.adapter.job.logger.warning(
                            f"Update: Referenced {label_grp} '{n}' not found for {_format_rule_context()}"
                        )
                changed = True
            merged = {g.pk for g in (explicit_groups + fallback_groups)}
            if grp_names is not None or fallback_groups:
                rel_grp_mgr.set(list(group_cls.objects.filter(pk__in=merged)))
                changed = True

        _update_with_fallback(
            "source_addresses",
            "source_address_groups",
            OrmAddressObject,
            OrmAddressObjectGroup,
            obj.source_addresses,
            obj.source_address_groups,
            "AddressObject",
            "AddressObjectGroup",
        )
        _update_with_fallback(
            "source_services",
            "source_service_groups",
            OrmServiceObject,
            OrmServiceObjectGroup,
            obj.source_services,
            obj.source_service_groups,
            "ServiceObject",
            "ServiceObjectGroup",
        )
        _update_with_fallback(
            "destination_addresses",
            "destination_address_groups",
            OrmAddressObject,
            OrmAddressObjectGroup,
            obj.destination_addresses,
            obj.destination_address_groups,
            "AddressObject",
            "AddressObjectGroup",
        )
        _update_with_fallback(
            "destination_services",
            "destination_service_groups",
            OrmServiceObject,
            OrmServiceObjectGroup,
            obj.destination_services,
            obj.destination_service_groups,
            "ServiceObject",
            "ServiceObjectGroup",
        )
        _update_with_fallback(
            "applications",
            "application_groups",
            OrmApplicationObject,
            OrmApplicationObjectGroup,
            obj.applications,
            obj.application_groups,
            "ApplicationObject",
            "ApplicationObjectGroup",
        )

        # Users (M2M) - optional in firewall models
        if hasattr(obj, "source_users") and "source_users" in attrs:
            obj.source_users.set(_resolve(OrmUserObject, attrs.get("source_users", []), "UserObject"))
            changed = True
        if hasattr(obj, "destination_users") and "destination_users" in attrs:
            obj.destination_users.set(_resolve(OrmUserObject, attrs.get("destination_users", []), "UserObject"))
            changed = True

        if changed:
            obj.validated_save()
        return super().update(attrs)


class NautobotNATPolicy(NATPolicyBase):
    """Nautobot NATPolicy implementation."""

    @classmethod
    def create(cls, adapter, ids, attrs):
        """Create NATPolicy and tag; store description."""
        tag = _get_tag()
        obj, _ = OrmNATPolicy.objects.get_or_create(
            name=ids["name"], defaults={"description": attrs.get("description", "")}
        )
        obj.tags.add(tag)
        obj.validated_save()
        return super().create(ids=ids, adapter=adapter, attrs=attrs)

    def delete(self):
        """Schedule NATPolicy for deletion post-sync."""
        obj = OrmNATPolicy.objects.get(name=self.name)
        self.adapter.objects_to_delete.setdefault("natpolicy", []).append(obj)
        return super().delete()

    def update(self, attrs):  # noqa: D401
        """Update NATPolicy description if changed."""
        obj = OrmNATPolicy.objects.get(name=self.name)
        changed = False
        if "description" in attrs and obj.description != attrs["description"]:
            obj.description = attrs["description"] or ""
            changed = True
        if changed:
            obj.validated_save()
        return super().update(attrs)


class NautobotNATPolicyRule(NATPolicyRuleBase):
    """Nautobot NATPolicyRule implementation."""

    @classmethod
    def create(cls, adapter, ids, attrs):
        """Create NATPolicyRule linked to parent NATPolicy (by nat_policy_name) and tag it."""
        tag = _get_tag()

        # nat_policy_name is now in ids (as an identifier), not attrs
        nat_policy_name = ids.get("nat_policy_name", "unknown")

        # Debug: Log all attrs being passed to create to help diagnose population issues
        addr_fields = [
            "original_source_addresses",
            "original_destination_addresses",
            "translated_source_addresses",
            "translated_destination_addresses",
        ]
        non_empty_attrs = {k: v for k, v in attrs.items() if v and k in addr_fields}
        if non_empty_attrs:
            adapter.job.logger.debug(
                f"NATPolicyRule create index={ids['index']}: non-empty address attrs: {non_empty_attrs}"
            )
        else:
            adapter.job.logger.debug(
                f"NATPolicyRule create index={ids['index']}: no address attrs populated. "
                f"Zones: src={attrs.get('source_zone')}, dst={attrs.get('destination_zone')}"
            )

        try:
            parent = OrmNATPolicy.objects.get(name=nat_policy_name)
        except OrmNATPolicy.DoesNotExist:
            adapter.job.logger.warning(f"Parent NATPolicy {nat_policy_name} not found for rule index {ids['index']}")
            return None
        # Ensure required DB fields exist at creation time
        defaults = {
            "name": attrs.get("name", "") or "",
            # Coerce None to empty string for NOT NULL description column
            "description": (attrs.get("description") or ""),
            "status": get_active_status(),
        }

        # Look for existing rule in this specific NAT policy to avoid index collision across policies
        obj = None
        if parent:
            obj = parent.nat_policy_rules.filter(index=ids["index"]).first()
        if not obj:
            try:
                obj = OrmNATPolicyRule.objects.create(
                    index=ids["index"],
                    name=defaults.get("name", ""),
                    description=defaults.get("description", ""),
                    status=defaults.get("status"),
                )
            except Exception as exc:
                adapter.job.logger.error(f"Error creating NATPolicyRule {ids['index']}: {exc}, defaults: {defaults}")
                raise
        else:
            # Ensure description is non-null on existing rows
            if obj.description is None:
                obj.description = defaults["description"]
                obj.validated_save()
        if parent and obj not in parent.nat_policy_rules.all():
            parent.nat_policy_rules.add(obj)

        # Helper to resolve named objects for M2M fields
        def _resolve_qs(model_cls, names, field_label):
            if names and "any" in names:
                return []
            resolved = []
            for n in names or []:
                try:
                    if model_cls == OrmUserObject:
                        resolved.append(model_cls.objects.get(username=n))
                    else:
                        resolved.append(model_cls.objects.get(name=n))
                except model_cls.DoesNotExist:
                    pass
                except Exception:
                    adapter.job.logger.warning(
                        f"Referenced {field_label} {n} not found for NATPolicyRule {ids['index']}"
                    )
            return resolved

        # Context string for logging in module-level helper
        nat_rule_context = f" for NATPolicyRule {ids['index']}"

        # Zones (FKs) - Create placeholder zones if they don't exist
        if attrs.get("source_zone") and attrs.get("source_zone") != "any":
            zone_name = attrs.get("source_zone")
            try:
                obj.source_zone = OrmZone.objects.get(name=zone_name)
            except OrmZone.DoesNotExist:
                # Create placeholder zone for NAT rules
                adapter.job.logger.info(f"Creating placeholder Zone '{zone_name}' for NATPolicyRule {ids['index']}")
                zone, _ = OrmZone.objects.get_or_create(
                    name=zone_name,
                    defaults={
                        "description": "(auto-created) Referenced by NAT policy rule",
                        "status": get_active_status(),
                    },
                )
                obj.source_zone = zone
        if attrs.get("destination_zone") and attrs.get("destination_zone") != "any":
            zone_name = attrs.get("destination_zone")
            try:
                obj.destination_zone = OrmZone.objects.get(name=zone_name)
            except OrmZone.DoesNotExist:
                # Create placeholder zone for NAT rules
                adapter.job.logger.info(f"Creating placeholder Zone '{zone_name}' for NATPolicyRule {ids['index']}")
                zone, _ = OrmZone.objects.get_or_create(
                    name=zone_name,
                    defaults={
                        "description": "(auto-created) Referenced by NAT policy rule",
                        "status": get_active_status(),
                    },
                )
                obj.destination_zone = zone

        # Save FK changes before M2M operations
        if obj.source_zone or obj.destination_zone:
            obj.validated_save()

        # Translations and M2M lists - with debug logging
        # Use module-level _resolve_objects_with_group_fallback for addresses since Panorama doesn't distinguish objects vs groups
        m2m_operations = 0
        if "original_source_addresses" in attrs:
            objs, grps_fallback = _resolve_objects_with_group_fallback(
                OrmAddressObject,
                OrmAddressObjectGroup,
                attrs.get("original_source_addresses", []),
                "AddressObject",
                "AddressObjectGroup",
                logger=adapter.job.logger,
                context=nat_rule_context,
            )
            adapter.job.logger.debug(
                f"NATPolicyRule {ids['index']}: Setting original_source_addresses ({len(attrs.get('original_source_addresses', []))} names -> {len(objs)} objects, {len(grps_fallback)} groups)"
            )
            obj.original_source_addresses.set(objs)
            # Merge explicit groups + fallback groups from address list
            if "original_source_address_groups" in attrs:
                explicit_groups = _resolve_qs(
                    OrmAddressObjectGroup, attrs.get("original_source_address_groups", []), "AddressObjectGroup"
                )
                merged = {g.pk for g in explicit_groups + grps_fallback}
                obj.original_source_address_groups.set(list(OrmAddressObjectGroup.objects.filter(pk__in=merged)))
            elif grps_fallback:
                obj.original_source_address_groups.set(grps_fallback)
            m2m_operations += 1
        else:
            if "original_source_address_groups" in attrs:
                resolved = _resolve_qs(
                    OrmAddressObjectGroup, attrs.get("original_source_address_groups", []), "AddressObjectGroup"
                )
                adapter.job.logger.debug(
                    f"NATPolicyRule {ids['index']}: Setting original_source_address_groups ({len(attrs.get('original_source_address_groups', []))} names -> {len(resolved)} resolved)"
                )
                obj.original_source_address_groups.set(resolved)
                m2m_operations += 1
        if "original_source_services" in attrs:
            obj.original_source_services.set(
                _resolve_qs(OrmServiceObject, attrs.get("original_source_services", []), "ServiceObject")
            )
        if "original_source_service_groups" in attrs:
            obj.original_source_service_groups.set(
                _resolve_qs(
                    OrmServiceObjectGroup, attrs.get("original_source_service_groups", []), "ServiceObjectGroup"
                )
            )

        if "original_destination_addresses" in attrs:
            objs, grps_fallback = _resolve_objects_with_group_fallback(
                OrmAddressObject,
                OrmAddressObjectGroup,
                attrs.get("original_destination_addresses", []),
                "AddressObject",
                "AddressObjectGroup",
                logger=adapter.job.logger,
                context=nat_rule_context,
            )
            adapter.job.logger.debug(
                f"NATPolicyRule {ids['index']}: Setting original_destination_addresses ({len(attrs.get('original_destination_addresses', []))} names -> {len(objs)} objects, {len(grps_fallback)} groups)"
            )
            obj.original_destination_addresses.set(objs)
            # Merge explicit groups + fallback groups
            if "original_destination_address_groups" in attrs:
                explicit_groups = _resolve_qs(
                    OrmAddressObjectGroup, attrs.get("original_destination_address_groups", []), "AddressObjectGroup"
                )
                merged = {g.pk for g in explicit_groups + grps_fallback}
                obj.original_destination_address_groups.set(list(OrmAddressObjectGroup.objects.filter(pk__in=merged)))
            elif grps_fallback:
                obj.original_destination_address_groups.set(grps_fallback)
            m2m_operations += 1
        else:
            if "original_destination_address_groups" in attrs:
                obj.original_destination_address_groups.set(
                    _resolve_qs(
                        OrmAddressObjectGroup,
                        attrs.get("original_destination_address_groups", []),
                        "AddressObjectGroup",
                    )
                )
        if "original_destination_services" in attrs:
            obj.original_destination_services.set(
                _resolve_qs(OrmServiceObject, attrs.get("original_destination_services", []), "ServiceObject")
            )
        if "original_destination_service_groups" in attrs:
            obj.original_destination_service_groups.set(
                _resolve_qs(
                    OrmServiceObjectGroup, attrs.get("original_destination_service_groups", []), "ServiceObjectGroup"
                )
            )

        # Users (M2M) - optional in firewall models
        if hasattr(obj, "source_users") and "source_users" in attrs:
            obj.source_users.set(_resolve_qs(OrmUserObject, attrs.get("source_users", []), "UserObject"))
        if hasattr(obj, "destination_users") and "destination_users" in attrs:
            obj.destination_users.set(_resolve_qs(OrmUserObject, attrs.get("destination_users", []), "UserObject"))

        if "translated_source_addresses" in attrs:
            objs, grps_fallback = _resolve_objects_with_group_fallback(
                OrmAddressObject,
                OrmAddressObjectGroup,
                attrs.get("translated_source_addresses", []),
                "AddressObject",
                "AddressObjectGroup",
                logger=adapter.job.logger,
                context=nat_rule_context,
            )
            adapter.job.logger.debug(
                f"NATPolicyRule {ids['index']}: Setting translated_source_addresses ({len(attrs.get('translated_source_addresses', []))} names -> {len(objs)} objects, {len(grps_fallback)} groups)"
            )
            obj.translated_source_addresses.set(objs)
            if "translated_source_address_groups" in attrs:
                explicit_groups = _resolve_qs(
                    OrmAddressObjectGroup, attrs.get("translated_source_address_groups", []), "AddressObjectGroup"
                )
                merged = {g.pk for g in explicit_groups + grps_fallback}
                obj.translated_source_address_groups.set(list(OrmAddressObjectGroup.objects.filter(pk__in=merged)))
            elif grps_fallback:
                obj.translated_source_address_groups.set(grps_fallback)
            m2m_operations += 1
        else:
            if "translated_source_address_groups" in attrs:
                obj.translated_source_address_groups.set(
                    _resolve_qs(
                        OrmAddressObjectGroup, attrs.get("translated_source_address_groups", []), "AddressObjectGroup"
                    )
                )
        if "translated_destination_addresses" in attrs:
            objs, grps_fallback = _resolve_objects_with_group_fallback(
                OrmAddressObject,
                OrmAddressObjectGroup,
                attrs.get("translated_destination_addresses", []),
                "AddressObject",
                "AddressObjectGroup",
                logger=adapter.job.logger,
                context=nat_rule_context,
            )
            adapter.job.logger.debug(
                f"NATPolicyRule {ids['index']}: Setting translated_destination_addresses ({len(attrs.get('translated_destination_addresses', []))} names -> {len(objs)} objects, {len(grps_fallback)} groups)"
            )
            obj.translated_destination_addresses.set(objs)
            if "translated_destination_address_groups" in attrs:
                explicit_groups = _resolve_qs(
                    OrmAddressObjectGroup, attrs.get("translated_destination_address_groups", []), "AddressObjectGroup"
                )
                merged = {g.pk for g in explicit_groups + grps_fallback}
                obj.translated_destination_address_groups.set(list(OrmAddressObjectGroup.objects.filter(pk__in=merged)))
            elif grps_fallback:
                obj.translated_destination_address_groups.set(grps_fallback)
            m2m_operations += 1
        else:
            if "translated_destination_address_groups" in attrs:
                obj.translated_destination_address_groups.set(
                    _resolve_qs(
                        OrmAddressObjectGroup,
                        attrs.get("translated_destination_address_groups", []),
                        "AddressObjectGroup",
                    )
                )

        obj.tags.add(tag)
        obj.validated_save()
        return super().create(ids=ids, adapter=adapter, attrs=attrs)

    def delete(self):
        """Schedule NATPolicyRule for deletion post-sync if it exists."""
        # Look up rule via parent NAT policy to handle non-unique indices across policies
        nat_policy_name = getattr(self, "nat_policy_name", None)
        obj = None
        if nat_policy_name:
            try:
                parent = OrmNATPolicy.objects.get(name=nat_policy_name)
                obj = parent.nat_policy_rules.filter(index=self.index).first()
            except OrmNATPolicy.DoesNotExist:
                pass
        # Fallback to direct lookup if policy lookup fails
        if not obj:
            try:
                obj = OrmNATPolicyRule.objects.get(index=self.index, name=self.name)
            except OrmNATPolicyRule.DoesNotExist:
                pass
        if obj:
            self.adapter.objects_to_delete.setdefault("natpolicyrule", []).append(obj)
        return super().delete()

    def update(self, attrs):  # noqa: D401
        """Update mutable NATPolicyRule attributes and relationships."""
        # Look up rule via parent NAT policy to handle non-unique indices across policies
        nat_policy_name = getattr(self, "nat_policy_name", None)
        obj = None
        if nat_policy_name:
            try:
                parent = OrmNATPolicy.objects.get(name=nat_policy_name)
                obj = parent.nat_policy_rules.filter(index=self.index).first()
            except OrmNATPolicy.DoesNotExist:
                pass
        # Fallback to direct index lookup if policy lookup fails
        if not obj:
            try:
                obj = OrmNATPolicyRule.objects.get(index=self.index)
            except OrmNATPolicyRule.DoesNotExist:
                pass
        if not obj:
            self.adapter.job.logger.debug(f"NATPolicyRule index={self.index} not found for update, skipping")
            return super().update(attrs)

        changed = False
        if "name" in attrs and attrs["name"] and obj.name != attrs["name"]:
            obj.name = attrs["name"]
            changed = True
        if "description" in attrs and obj.description != attrs["description"]:
            obj.description = attrs["description"] or ""
            changed = True
        # Note: source_translation and destination_translation are not actual ORM fields
        # They're kept as model attributes but not persisted

        # Zones
        if "source_zone" in attrs:
            if attrs["source_zone"]:
                if attrs["source_zone"] == "any":
                    if obj.source_zone is not None:
                        obj.source_zone = None
                        changed = True
                else:
                    try:
                        zone = OrmZone.objects.get(name=attrs["source_zone"])
                        if obj.source_zone != zone:
                            obj.source_zone = zone
                            changed = True
                    except OrmZone.DoesNotExist:
                        self.adapter.job.logger.warning(
                            f"Update: Source Zone {attrs['source_zone']} not found for NATPolicyRule {self.index}"
                        )
            else:
                if obj.source_zone is not None:
                    obj.source_zone = None
                    changed = True
        if "destination_zone" in attrs:
            if attrs["destination_zone"]:
                if attrs["destination_zone"] == "any":
                    if obj.destination_zone is not None:
                        obj.destination_zone = None
                        changed = True
                else:
                    try:
                        zone = OrmZone.objects.get(name=attrs["destination_zone"])
                        if obj.destination_zone != zone:
                            obj.destination_zone = zone
                            changed = True
                    except OrmZone.DoesNotExist:
                        self.adapter.job.logger.warning(
                            f"Update: Destination Zone {attrs['destination_zone']} not found for NATPolicyRule {self.index}"
                        )
            else:
                if obj.destination_zone is not None:
                    obj.destination_zone = None
                    changed = True

        def _resolve(model_cls, names, label):
            """Simple resolve for services (where objects and groups are truly separate)."""
            if names and "any" in names:
                return []
            resolved = []
            for n in names or []:
                try:
                    if model_cls == OrmUserObject:
                        resolved.append(model_cls.objects.get(username=n))
                    else:
                        resolved.append(model_cls.objects.get(name=n))
                except model_cls.DoesNotExist:
                    pass
                except Exception:
                    self.adapter.job.logger.warning(
                        f"Update: Referenced {label} {n} not found for NATPolicyRule {self.index}"
                    )
            return resolved

        # Context string for logging in module-level helper
        update_context = f" for NATPolicyRule {self.index}"

        # Handle address M2M fields with object/group fallback
        # original_source_addresses may contain AddressObjectGroup names due to PAN-OS not distinguishing
        if "original_source_addresses" in attrs:
            objs, grps = _resolve_objects_with_group_fallback(
                OrmAddressObject,
                OrmAddressObjectGroup,
                attrs.get("original_source_addresses", []),
                "AddressObject",
                "AddressObjectGroup",
                logger=self.adapter.job.logger,
                context=update_context,
            )
            obj.original_source_addresses.set(objs)
            # Merge with explicit groups
            if "original_source_address_groups" in attrs:
                explicit = _resolve(
                    OrmAddressObjectGroup, attrs.get("original_source_address_groups", []), "AddressObjectGroup"
                )
                merged = {g.pk for g in explicit + grps}
                obj.original_source_address_groups.set(list(OrmAddressObjectGroup.objects.filter(pk__in=merged)))
            elif grps:
                # Add fallback groups to current set
                existing = set(obj.original_source_address_groups.values_list("pk", flat=True))
                merged = existing.union({g.pk for g in grps})
                obj.original_source_address_groups.set(list(OrmAddressObjectGroup.objects.filter(pk__in=merged)))
            changed = True
        elif "original_source_address_groups" in attrs:
            obj.original_source_address_groups.set(
                _resolve(OrmAddressObjectGroup, attrs.get("original_source_address_groups", []), "AddressObjectGroup")
            )
            changed = True

        if "original_destination_addresses" in attrs:
            objs, grps = _resolve_objects_with_group_fallback(
                OrmAddressObject,
                OrmAddressObjectGroup,
                attrs.get("original_destination_addresses", []),
                "AddressObject",
                "AddressObjectGroup",
                logger=self.adapter.job.logger,
                context=update_context,
            )
            obj.original_destination_addresses.set(objs)
            if "original_destination_address_groups" in attrs:
                explicit = _resolve(
                    OrmAddressObjectGroup, attrs.get("original_destination_address_groups", []), "AddressObjectGroup"
                )
                merged = {g.pk for g in explicit + grps}
                obj.original_destination_address_groups.set(list(OrmAddressObjectGroup.objects.filter(pk__in=merged)))
            elif grps:
                existing = set(obj.original_destination_address_groups.values_list("pk", flat=True))
                merged = existing.union({g.pk for g in grps})
                obj.original_destination_address_groups.set(list(OrmAddressObjectGroup.objects.filter(pk__in=merged)))
            changed = True
        elif "original_destination_address_groups" in attrs:
            obj.original_destination_address_groups.set(
                _resolve(
                    OrmAddressObjectGroup, attrs.get("original_destination_address_groups", []), "AddressObjectGroup"
                )
            )
            changed = True

        if "translated_source_addresses" in attrs:
            objs, grps = _resolve_objects_with_group_fallback(
                OrmAddressObject,
                OrmAddressObjectGroup,
                attrs.get("translated_source_addresses", []),
                "AddressObject",
                "AddressObjectGroup",
                logger=self.adapter.job.logger,
                context=update_context,
            )
            obj.translated_source_addresses.set(objs)
            if "translated_source_address_groups" in attrs:
                explicit = _resolve(
                    OrmAddressObjectGroup, attrs.get("translated_source_address_groups", []), "AddressObjectGroup"
                )
                merged = {g.pk for g in explicit + grps}
                obj.translated_source_address_groups.set(list(OrmAddressObjectGroup.objects.filter(pk__in=merged)))
            elif grps:
                existing = set(obj.translated_source_address_groups.values_list("pk", flat=True))
                merged = existing.union({g.pk for g in grps})
                obj.translated_source_address_groups.set(list(OrmAddressObjectGroup.objects.filter(pk__in=merged)))
            changed = True
        elif "translated_source_address_groups" in attrs:
            obj.translated_source_address_groups.set(
                _resolve(OrmAddressObjectGroup, attrs.get("translated_source_address_groups", []), "AddressObjectGroup")
            )
            changed = True

        if "translated_destination_addresses" in attrs:
            objs, grps = _resolve_objects_with_group_fallback(
                OrmAddressObject,
                OrmAddressObjectGroup,
                attrs.get("translated_destination_addresses", []),
                "AddressObject",
                "AddressObjectGroup",
                logger=self.adapter.job.logger,
                context=update_context,
            )
            obj.translated_destination_addresses.set(objs)
            if "translated_destination_address_groups" in attrs:
                explicit = _resolve(
                    OrmAddressObjectGroup, attrs.get("translated_destination_address_groups", []), "AddressObjectGroup"
                )
                merged = {g.pk for g in explicit + grps}
                obj.translated_destination_address_groups.set(list(OrmAddressObjectGroup.objects.filter(pk__in=merged)))
            elif grps:
                existing = set(obj.translated_destination_address_groups.values_list("pk", flat=True))
                merged = existing.union({g.pk for g in grps})
                obj.translated_destination_address_groups.set(list(OrmAddressObjectGroup.objects.filter(pk__in=merged)))
            changed = True
        elif "translated_destination_address_groups" in attrs:
            obj.translated_destination_address_groups.set(
                _resolve(
                    OrmAddressObjectGroup, attrs.get("translated_destination_address_groups", []), "AddressObjectGroup"
                )
            )
            changed = True

        # Handle service M2M fields (these truly are separate object vs group)
        service_m2m_map = {
            "original_source_services": (OrmServiceObject, obj.original_source_services, "ServiceObject"),
            "original_source_service_groups": (
                OrmServiceObjectGroup,
                obj.original_source_service_groups,
                "ServiceObjectGroup",
            ),
            "original_destination_services": (OrmServiceObject, obj.original_destination_services, "ServiceObject"),
            "original_destination_service_groups": (
                OrmServiceObjectGroup,
                obj.original_destination_service_groups,
                "ServiceObjectGroup",
            ),
        }
        for attr_name, (model_cls, rel_manager, label) in service_m2m_map.items():
            if attr_name in attrs:
                rel_manager.set(_resolve(model_cls, attrs.get(attr_name, []), label))
                changed = True

        # Users (M2M) - optional in firewall models
        if hasattr(obj, "source_users") and "source_users" in attrs:
            obj.source_users.set(_resolve(OrmUserObject, attrs.get("source_users", []), "UserObject"))
            changed = True
        if hasattr(obj, "destination_users") and "destination_users" in attrs:
            obj.destination_users.set(_resolve(OrmUserObject, attrs.get("destination_users", []), "UserObject"))
            changed = True

        if changed:
            obj.validated_save()
        return super().update(attrs)
