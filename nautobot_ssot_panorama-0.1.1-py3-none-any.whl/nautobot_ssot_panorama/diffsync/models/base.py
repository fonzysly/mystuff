"""Base DiffSync model definitions (side-agnostic) for Panorama SSoT.

Each class declares identifiers, attributes, and child relationships only. CRUD
logic is implemented in side-specific subclasses (e.g. Nautobot or Panorama). This
pattern mirrors other Nautobot SSoT integrations (e.g. ACI) enabling clear separation
of schema vs adapter behaviors.
"""

from typing import ClassVar, List, Optional

from diffsync import DiffSyncModel


class _ListDefaultsMixin:
    """Ensure list-typed attributes are unique per instance.

    DiffSync models aren't dataclasses; class-level list defaults are shared
    across instances. This mixin replaces None/missing list fields with new
    empty lists to prevent cross-instance mutation.
    """

    _list_fields: ClassVar[tuple[str, ...]] = ()

    def __init__(self, *args, **kwargs):  # noqa: D401
        super().__init__(*args, **kwargs)
        for field in self._list_fields:
            if getattr(self, field, None) is None:
                setattr(self, field, [])


class FQDNBase(DiffSyncModel):
    """FQDN object (fully-qualified domain name)."""

    _modelname = "fqdn"
    _identifiers = ("name",)
    _attributes = ("description",)

    name: str
    description: Optional[str] = None


class IPRangeBase(DiffSyncModel):
    """IP range (start/end addresses)."""

    _modelname = "iprange"
    _identifiers = ("start_address", "end_address")
    _attributes = ("description",)

    start_address: str
    end_address: str
    description: Optional[str] = None


class AddressObjectBase(DiffSyncModel):
    """AddressObject aggregating exactly one underlying address type."""

    _modelname = "addressobject"
    _identifiers = ("name",)
    _attributes = ("description", "fqdn", "ip_range", "ip_address", "prefix")

    name: str
    description: Optional[str] = None
    fqdn: Optional[str] = None
    ip_range: Optional[str] = None  # represented as start-end string or unique key
    ip_address: Optional[str] = None
    prefix: Optional[str] = None


class AddressObjectGroupBase(_ListDefaultsMixin, DiffSyncModel):
    """Group of AddressObjects.

    Supports both individual AddressObject members and nested AddressObjectGroup members.
    Panorama returns all members in a flat list without type information, so the remote
    adapter classifies them by looking up names in tracking sets.
    """

    _modelname = "addressobjectgroup"
    _identifiers = ("name",)
    _attributes = ("description", "address_objects", "address_object_groups")

    name: str
    description: Optional[str] = None
    _list_fields = ("address_objects", "address_object_groups")

    address_objects: Optional[List[str]] = None  # Member AddressObjects (individual addresses)
    address_object_groups: Optional[List[str]] = None  # Member AddressObjectGroups (nested groups)


class ServiceObjectBase(DiffSyncModel):
    """ServiceObject describing protocol/port(s)."""

    _modelname = "serviceobject"
    _identifiers = ("name",)
    _attributes = ("description", "port", "ip_protocol")

    name: str
    description: Optional[str] = None
    port: Optional[str] = None
    ip_protocol: Optional[str] = None


class ServiceObjectGroupBase(_ListDefaultsMixin, DiffSyncModel):
    """Group of ServiceObjects.

    Supports both individual ServiceObject members and nested ServiceObjectGroup members.
    Panorama returns all members in a flat list without type information, so the remote
    adapter classifies them by looking up names in tracking sets.
    """

    _modelname = "serviceobjectgroup"
    _identifiers = ("name",)
    _attributes = ("description", "service_objects", "service_object_groups")

    name: str
    description: Optional[str] = None
    _list_fields = ("service_objects", "service_object_groups")

    service_objects: Optional[List[str]] = None  # Member ServiceObjects (individual services)
    service_object_groups: Optional[List[str]] = None  # Member ServiceObjectGroups (nested groups)


class ApplicationObjectBase(DiffSyncModel):
    """ApplicationObject (Layer-7 application descriptor)."""

    _modelname = "applicationobject"
    _identifiers = ("name",)
    _attributes = ("description", "category", "subcategory", "technology", "risk")

    name: str
    description: Optional[str] = None
    category: Optional[str] = None
    subcategory: Optional[str] = None
    technology: Optional[str] = None
    risk: Optional[int] = None


class ApplicationObjectGroupBase(_ListDefaultsMixin, DiffSyncModel):
    """Group of ApplicationObjects.

    Supports both individual ApplicationObject members and nested ApplicationObjectGroup members.
    Panorama returns all members in a flat list without type information, so the remote
    adapter classifies them by looking up names in tracking sets.
    """

    _modelname = "applicationobjectgroup"
    _identifiers = ("name",)
    _attributes = ("description", "application_objects", "application_object_groups")

    name: str
    description: Optional[str] = None
    _list_fields = ("application_objects", "application_object_groups")

    application_objects: Optional[List[str]] = None  # Member ApplicationObjects (individual apps)
    application_object_groups: Optional[List[str]] = None  # Member ApplicationObjectGroups (nested groups)


class UserObjectBase(DiffSyncModel):
    """UserObject (user identity reference in policy rules)."""

    _modelname = "userobject"
    _identifiers = ("name",)
    _attributes: tuple = ()

    name: str


class ZoneBase(DiffSyncModel):
    """Zone object."""

    _modelname = "zone"
    _identifiers = ("name",)
    _attributes = ("description",)

    name: str
    description: Optional[str] = None


class PolicyRuleBase(_ListDefaultsMixin, DiffSyncModel):
    """Security policy rule; identified by policy name and index within parent policy."""

    _modelname = "policyrule"
    _identifiers = ("policy_name", "index")
    _attributes = (
        "name",
        "action",
        "description",
        "source_addresses",
        "source_address_groups",
        "source_zone",
        "source_services",
        "source_service_groups",
        "destination_addresses",
        "destination_address_groups",
        "destination_zone",
        "destination_services",
        "destination_service_groups",
        "applications",
        "application_groups",
        "source_users",
        "destination_users",
    )
    policy_name: Optional[str] = None

    index: int
    name: Optional[str] = None
    action: Optional[str] = None
    description: Optional[str] = None
    _list_fields = (
        "source_addresses",
        "source_address_groups",
        "source_services",
        "source_service_groups",
        "destination_addresses",
        "destination_address_groups",
        "destination_services",
        "destination_service_groups",
        "applications",
        "application_groups",
        "source_users",
        "destination_users",
    )

    source_addresses: Optional[List[str]] = None
    source_address_groups: Optional[List[str]] = None
    source_zone: Optional[str] = None
    source_services: Optional[List[str]] = None
    source_service_groups: Optional[List[str]] = None
    destination_addresses: Optional[List[str]] = None
    destination_address_groups: Optional[List[str]] = None
    destination_zone: Optional[str] = None
    destination_services: Optional[List[str]] = None
    destination_service_groups: Optional[List[str]] = None
    applications: Optional[List[str]] = None
    application_groups: Optional[List[str]] = None
    source_users: Optional[List[str]] = None
    destination_users: Optional[List[str]] = None


class PolicyBase(_ListDefaultsMixin, DiffSyncModel):
    """Security policy containing ordered rule children."""

    _modelname = "policy"
    _identifiers = ("name",)
    _attributes = ("description", "panorama_name", "device_group", "direction")
    _children = {"policyrule": "policy_rules"}

    name: str
    description: Optional[str] = None
    panorama_name: Optional[str] = None
    device_group: Optional[str] = None
    direction: Optional[str] = None

    _list_fields = ("policy_rules",)

    policy_rules: Optional[List[PolicyRuleBase]] = None
    policyrule: ClassVar[PolicyRuleBase] = PolicyRuleBase


class NATPolicyRuleBase(_ListDefaultsMixin, DiffSyncModel):
    """NAT policy rule; original vs translated objects + zones."""

    _modelname = "natpolicyrule"
    _identifiers = ("nat_policy_name", "index")
    # Note: source_translation/destination_translation excluded from _attributes because
    # the Nautobot Firewall Models NATPolicyRule ORM model doesn't have these fields.
    # They're metadata about translation type (e.g., "dynamic-ip-and-port") from Panorama
    # that can't be persisted to Nautobot currently.
    _attributes = (
        "name",
        "description",
        "source_users",
        "destination_users",
        "original_source_addresses",
        "original_source_address_groups",
        "original_source_services",
        "original_source_service_groups",
        "original_destination_addresses",
        "original_destination_address_groups",
        "original_destination_services",
        "original_destination_service_groups",
        "translated_source_addresses",
        "translated_source_address_groups",
        "translated_source_services",
        "translated_source_service_groups",
        "translated_destination_addresses",
        "translated_destination_address_groups",
        "translated_destination_services",
        "translated_destination_service_groups",
        "source_zone",
        "destination_zone",
    )
    nat_policy_name: Optional[str] = None

    index: int
    name: Optional[str] = None
    description: Optional[str] = None
    # Kept as model attributes for potential future use, but not in _attributes for diff comparison
    source_translation: Optional[str] = None
    destination_translation: Optional[str] = None
    _list_fields = (
        "source_users",
        "destination_users",
        "original_source_addresses",
        "original_source_address_groups",
        "original_source_services",
        "original_source_service_groups",
        "original_destination_addresses",
        "original_destination_address_groups",
        "original_destination_services",
        "original_destination_service_groups",
        "translated_source_addresses",
        "translated_source_address_groups",
        "translated_source_services",
        "translated_source_service_groups",
        "translated_destination_addresses",
        "translated_destination_address_groups",
        "translated_destination_services",
        "translated_destination_service_groups",
    )

    source_users: Optional[List[str]] = None
    destination_users: Optional[List[str]] = None
    original_source_addresses: Optional[List[str]] = None
    original_source_address_groups: Optional[List[str]] = None
    original_source_services: Optional[List[str]] = None
    original_source_service_groups: Optional[List[str]] = None
    original_destination_addresses: Optional[List[str]] = None
    original_destination_address_groups: Optional[List[str]] = None
    original_destination_services: Optional[List[str]] = None
    original_destination_service_groups: Optional[List[str]] = None
    translated_source_addresses: Optional[List[str]] = None
    translated_source_address_groups: Optional[List[str]] = None
    translated_source_services: Optional[List[str]] = None
    translated_source_service_groups: Optional[List[str]] = None
    translated_destination_addresses: Optional[List[str]] = None
    translated_destination_address_groups: Optional[List[str]] = None
    translated_destination_services: Optional[List[str]] = None
    translated_destination_service_groups: Optional[List[str]] = None
    source_zone: Optional[str] = None
    destination_zone: Optional[str] = None


class NATPolicyBase(_ListDefaultsMixin, DiffSyncModel):
    """NAT policy containing ordered NAT rule children."""

    _modelname = "natpolicy"
    _identifiers = ("name",)
    _attributes = ("description", "panorama_name", "direction", "device_group")
    _children = {"natpolicyrule": "nat_policy_rules"}

    name: str
    description: Optional[str] = None
    panorama_name: Optional[str] = None
    direction: Optional[str] = None
    device_group: Optional[str] = None

    _list_fields = ("nat_policy_rules",)

    nat_policy_rules: Optional[List[NATPolicyRuleBase]] = None
    natpolicyrule: ClassVar[NATPolicyRuleBase] = NATPolicyRuleBase
