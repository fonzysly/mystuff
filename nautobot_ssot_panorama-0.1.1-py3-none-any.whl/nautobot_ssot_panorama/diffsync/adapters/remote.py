"""Panorama remote adapter.

This adapter ingests configuration data from a Panorama instance and converts
it into base DiffSync model instances. It performs no Nautobot ORM writes and
contains no placeholder creation logic; Panorama is assumed authoritative and
consistent (references exist prior to rules being processed).
"""

from __future__ import annotations

import ipaddress
import logging

from diffsync import Adapter

from nautobot_ssot_panorama.diffsync.models.base import (
    AddressObjectBase,
    AddressObjectGroupBase,
    ApplicationObjectBase,
    ApplicationObjectGroupBase,
    FQDNBase,
    IPRangeBase,
    NATPolicyBase,
    NATPolicyRuleBase,
    PolicyBase,
    PolicyRuleBase,
    ServiceObjectBase,
    ServiceObjectGroupBase,
    UserObjectBase,
    ZoneBase,
)
from nautobot_ssot_panorama.utils.panorama_sdk import PanoramaSdkClient

# Panorama "any" keyword values that represent wildcards - these map to null/empty in Nautobot
PANORAMA_ANY_KEYWORDS = {"any", "ANY", "Any"}


def _normalize_str(val):
    """Normalize string values: None -> '', strip whitespace, 'any' -> ''."""
    if val is None:
        return ""
    val_str = str(val).strip()
    # Panorama "any" keyword maps to empty/null in Nautobot
    if val_str in PANORAMA_ANY_KEYWORDS:
        return ""
    return val_str


def _normalize_list(val):
    """Normalize list values: None -> [], filter out 'any', ensure all elements are strings, and sort."""
    if val is None:
        return []
    if not isinstance(val, list):
        val = [val]
    # Filter out "any" keywords as they map to empty in Nautobot, then sort for consistent comparison
    return sorted([str(v) for v in val if str(v).strip() not in PANORAMA_ANY_KEYWORDS])


class PanoramaRemoteAdapter(Adapter):
    """Adapter for Panorama data source."""

    fqdn = FQDNBase
    iprange = IPRangeBase
    addressobject = AddressObjectBase
    serviceobject = ServiceObjectBase
    applicationobject = ApplicationObjectBase
    addressobjectgroup = AddressObjectGroupBase
    serviceobjectgroup = ServiceObjectGroupBase
    applicationobjectgroup = ApplicationObjectGroupBase
    userobject = UserObjectBase
    zone = ZoneBase
    policy = PolicyBase
    policyrule = PolicyRuleBase
    natpolicy = NATPolicyBase
    natpolicyrule = NATPolicyRuleBase

    top_level = [
        "fqdn",
        "iprange",
        "addressobject",
        "serviceobject",
        "applicationobject",
        "userobject",
        "zone",
        "addressobjectgroup",
        "serviceobjectgroup",
        "applicationobjectgroup",
        "policy",
        "natpolicy",
    ]

    def __init__(self, *args, client: PanoramaSdkClient | None = None, job=None, sync=None, **kwargs):  # pylint: disable=too-many-arguments
        """Initialize remote adapter.

        Args:
            client: PanoramaSdkClient instance used to retrieve configuration data.
            job: Nautobot Job instance (for logging convenience) if provided.
            sync: Optional Nautobot SSoT sync object (stored, not passed to base Adapter).
            *args: Positional arguments passed to Adapter.
            **kwargs: Keyword arguments passed to Adapter.
        """
        # Extract and discard unsupported Adapter kwargs (e.g. sync) before calling super
        kwargs.pop("sync", None)
        super().__init__(*args, **kwargs)
        self.client = client
        self.job = job
        self.sync = sync  # stored for potential future use (not used by base Adapter)
        # Track known object names to avoid duplicate synthetic/placeholder creations
        self._addressobject_names: set[str] = set()
        self._addressobjectgroup_names: set[str] = set()
        self._region_names: set[str] = set()  # Panorama geographic regions
        self._serviceobject_names: set[str] = set()
        self._serviceobjectgroup_names: set[str] = set()
        self._applicationobject_names: set[str] = set()
        self._applicationobjectgroup_names: set[str] = set()
        self._userobject_names: set[str] = set()
        self._zone_names: set[str] = set()
        # Map FQDN/IP values to AddressObject names for reference resolution
        # Panorama rules may reference FQDN values directly instead of AddressObject names
        self._fqdn_to_addressobject: dict[str, str] = {}
        self._ip_to_addressobject: dict[str, str] = {}
        # Track direct IP usage in policy rules for reporting
        self._direct_ip_usage: list = []
        self._direct_ip_count = 0  # Counter for auto-created inline IP objects
        # Determine debug flag once (default False if job not provided or lacks attribute)
        self._debug_enabled = bool(getattr(job, "debug", False))

    # ---- Internal logging helper ----
    def _dbg(self, msg: str, *args):  # pragma: no cover - thin wrapper
        """Emit debug message only when job.debug flag enabled.

        Falls back to module logging if no job but still requires explicit enabling via _debug_enabled.
        """
        if not self._debug_enabled:
            return
        if self.job and hasattr(self.job, "logger"):
            try:
                # Some Nautobot job logger implementations expose log_debug; use if available
                if hasattr(self.job.logger, "debug"):
                    self.job.logger.debug(msg % args if args else msg)
                else:  # Fallback
                    logging.getLogger(__name__).debug(msg, *args)
            except Exception:  # noqa: BLE001
                logging.getLogger(__name__).debug(msg, *args)
        else:
            logging.getLogger(__name__).debug(msg, *args)

    # ---- Synthetic helpers ----
    def _ensure_synthetic_address(self, addr_str: str):
        """Create a synthetic AddressObject for direct IP/CIDR/range references in rules.

        Panorama rules may directly reference an IP address (e.g. '192.0.2.10'), CIDR
        (e.g. '192.0.2.0/24'), or IP range (e.g. '10.0.0.1-10.0.0.254') instead of
        referencing a named AddressObject. This violates Nautobot Firewall Models constraints
        which require all policy rule references to point to actual objects.

        Solution: Auto-create AddressObjects with INLINE- prefix for tracking and cleanup.

        Args:
            addr_str: The IP/CIDR/range string from the policy rule

        Side effects:
            - Creates AddressObject in DiffSync with name matching addr_str
            - Adds to _addressobject_names tracking set
            - Logs creation for visibility and reporting
            - Increments _direct_ip_count for summary statistics
        """
        if not addr_str or not str(addr_str).strip():
            return
        addr_str = str(addr_str).strip()

        # Skip if already exists
        if addr_str in self._addressobject_names:
            return

        # Only create synthetic for actual IP/CIDR/range values
        if not self._is_ip_or_range(addr_str):
            return

        try:
            import ipaddress

            # Determine the correct field to populate based on address type
            ip_address_val = None
            prefix_val = None
            ip_range_val = None

            if "/" in addr_str:
                # CIDR notation - /32 goes to ip_address, others to prefix (normalized)
                if addr_str.endswith("/32"):
                    ip_address_val = addr_str
                else:
                    # Normalize prefix to network address
                    try:
                        from ipaddress import ip_network

                        prefix_val = ip_network(addr_str, strict=False).with_prefixlen
                    except ValueError:
                        prefix_val = addr_str
            elif "-" in addr_str:
                # IP range - use ip_range field
                ip_range_val = addr_str
            else:
                # Single IP - convert to /32 and use ip_address field
                try:
                    ip_obj = ipaddress.ip_address(addr_str)
                    if ip_obj.version == 4:
                        ip_address_val = f"{addr_str}/32"
                    else:
                        ip_address_val = f"{addr_str}/128"
                except ValueError:
                    # Fallback to ip_address field if ipaddress parsing fails
                    ip_address_val = addr_str

            # Create synthetic AddressObject with normalized name
            synthetic = self.addressobject(
                name=addr_str,  # Keep original reference as name for lookup
                description="(auto-created) Inline IP reference from policy rule - should be replaced with named object",
                prefix=prefix_val,
                ip_address=ip_address_val,
                ip_range=ip_range_val,
            )
            self.add(synthetic)
            self._addressobject_names.add(addr_str)

            # Track for reporting
            self._direct_ip_count = getattr(self, "_direct_ip_count", 0) + 1

        except Exception as exc:  # pylint: disable=broad-except
            if self.job:
                self.job.logger.warning(f"Failed creating synthetic AddressObject for {addr_str}: {exc}")

    def _ensure_synthetic_fqdn(self, fqdn_str: str):
        """Create a synthetic AddressObject for direct FQDN references in rules.

        Panorama rules may directly reference an FQDN (e.g. 'server.example.com') instead of
        referencing a named AddressObject. This violates Nautobot Firewall Models constraints
        which require all policy rule references to point to actual objects.

        Solution: Auto-create FQDN + AddressObject with appropriate description.

        Args:
            fqdn_str: The FQDN string from the policy rule

        Side effects:
            - Creates FQDN object in DiffSync
            - Creates AddressObject referencing the FQDN
            - Adds to _addressobject_names tracking set
            - Logs creation for visibility
            - Increments _direct_ip_count for summary (reusing same counter)
        """
        if not fqdn_str or not str(fqdn_str).strip():
            return
        fqdn_str = str(fqdn_str).strip()

        # Skip if already exists
        if fqdn_str in self._addressobject_names:
            return

        # Only create for actual FQDN values
        if not self._is_fqdn(fqdn_str):
            if self.job and self._debug_enabled:
                self._dbg("Value '%s' not detected as FQDN, skipping synthetic creation", fqdn_str)
            return

        try:
            # First create or get the FQDN object
            try:
                self.get(self.fqdn, fqdn_str)
            except Exception:
                # FQDN doesn't exist, create it
                self.add(self.fqdn(name=fqdn_str, description="(auto-created) Inline FQDN reference from policy rule"))
                self._dbg("Created FQDN %s for inline reference", fqdn_str)

            # Create AddressObject referencing this FQDN
            synthetic = self.addressobject(
                name=fqdn_str,  # Keep original reference as name for lookup
                description="(auto-created) Inline FQDN reference from policy rule - should be replaced with named object",
                fqdn=fqdn_str,
                prefix=None,
                ip_address=None,
                ip_range=None,
            )
            self.add(synthetic)
            self._addressobject_names.add(fqdn_str)

            # Track for reporting (reuse direct_ip_count)
            self._direct_ip_count = getattr(self, "_direct_ip_count", 0) + 1

            if self.job:
                self.job.logger.info(f"Auto-created AddressObject for inline FQDN reference: {fqdn_str}")
        except Exception as exc:  # pylint: disable=broad-except
            if self.job:
                self.job.logger.warning(f"Failed creating synthetic AddressObject for FQDN {fqdn_str}: {exc}")

    def _ensure_application_default_service(self):
        """Create placeholder ServiceObject representing Panorama's 'application-default'.

        Panorama uses special keyword 'application-default' in service lists to indicate that
        the rule should match the ports/protocols intrinsic to each referenced application.
        Nautobot firewall models don't have dynamic service semantics, so we create a
        placeholder ServiceObject named exactly 'application-default' to retain reference
        fidelity. This object is created only once per adapter load if referenced by any rule.
        """
        name = "application-default"
        if name in self._serviceobject_names:
            return
        try:
            self.add(
                self.serviceobject(
                    name=name,
                    description="(placeholder) Panorama application-default dynamic service",
                    port="0",
                    ip_protocol="Reserved",
                )
            )
            self._serviceobject_names.add(name)
            if self.job:
                # Use gated debug helper to respect job.debug flag
                self._dbg("Created placeholder ServiceObject 'application-default'")
        except Exception as exc:  # pylint: disable=broad-except
            if self.job:
                self.job.logger.warning(f"Failed creating placeholder ServiceObject 'application-default': {exc}")

    def _ensure_zone(self, name: str | None):
        """Create placeholder Zone if referenced by a rule but not previously loaded."""
        if not name or not str(name).strip():
            return
        if str(name) in self._zone_names:
            return
        try:
            self.add(self.zone(name=str(name), description="(placeholder) referenced by policy"))
            self._dbg("Created placeholder Zone %s", name)
        except Exception as exc:
            # Safe to ignore duplicates; log at debug for visibility
            self._dbg("Zone placeholder creation failed for %s: %s", name, exc)

    def _ensure_user_object(self, name: str | None):
        """Create placeholder UserObject if referenced by a rule but not previously loaded."""
        if not name or not str(name).strip():
            return
        user_name = str(name).strip()
        if user_name in self._userobject_names:
            return
        try:
            self.add(
                self.userobject(
                    name=user_name,
                )
            )
            self._userobject_names.add(user_name)
            self._dbg("Created placeholder UserObject %s", user_name)
        except Exception as exc:  # pylint: disable=broad-except
            self._dbg("UserObject placeholder creation failed for %s: %s", user_name, exc)

    @staticmethod
    def _is_fqdn(value: str) -> bool:
        """Check if value looks like a Fully Qualified Domain Name.

        Returns True for domain-like strings:
        - azrwcvmap141.corp.standard.com
        - server01.example.org
        - host.subdomain.domain.tld

        Returns False for:
        - IP addresses (with or without CIDR)
        - Named objects without dots
        - Strings with underscores (likely Panorama object names)
        """
        if not value:
            return False
        value = value.strip()

        # Must contain at least one dot to be FQDN
        if "." not in value:
            return False

        # Reject if contains underscore (common in Panorama object names)
        if "_" in value:
            return False

        # Reject if it's an IP address or CIDR
        try:
            import ipaddress

            # Try parsing as IP or network
            if "/" in value:
                ipaddress.ip_network(value, strict=False)
                return False
            else:
                ipaddress.ip_address(value)
                return False
        except ValueError:
            # Not an IP, continue FQDN checks
            pass

        # Basic FQDN pattern: contains letters and dots, looks domain-like
        # Accept if it has multiple parts separated by dots and contains letters
        parts = value.split(".")
        if len(parts) < 2:
            return False

        # Each part should be alphanumeric (with hyphens allowed)
        for part in parts:
            if not part:  # Empty part (e.g., "example..com")
                return False
            # Allow alphanumeric and hyphens
            if not all(c.isalnum() or c == "-" for c in part):
                return False
            # Must start and end with alphanumeric
            if not part[0].isalnum() or not part[-1].isalnum():
                return False

        return True

    @staticmethod
    def _is_ip_or_range(value: str) -> bool:
        """Check if value is a direct IP address, CIDR, or IP range.

        Uses Python's ipaddress library for robust validation.

        Returns True for:
        - Single IPs: 10.25.52.4, 2001:db8::1
        - CIDR notation: 10.0.0.0/8, 192.168.1.0/24
        - IP ranges with dash: 10.0.0.0-10.255.255.255

        Returns False for named objects like:
        - "Server-A"
        - "40.78.240.8_Azure" (IP with non-IP characters)
        - "Beyondtrustwsfc.standard.com-AZR" (FQDN)
        - "10.98.2.9_host" (IP with underscore suffix)
        """
        if not value:
            return False
        value = value.strip()

        # Quick reject: if contains underscore, it's a named object (common in Panorama)
        # Examples: "10.98.2.9_host", "40.78.240.8_Azure"
        if "_" in value:
            return False

        # Quick reject: if contains alphabetic characters (except in hex IPv6), likely a name
        # This catches "Beyondtrustwsfc.standard.com-AZR", "Server-A", etc.
        # Allow hex digits (a-f, A-F) for IPv6, but reject other letters
        has_non_hex_letter = any(c.isalpha() and c.lower() not in "abcdef" for c in value)
        if has_non_hex_letter:
            return False

        # Try parsing as CIDR (network with prefix)
        if "/" in value:
            try:
                ipaddress.ip_network(value, strict=False)
                return True
            except ValueError:
                return False

        # Try parsing as IP range with dash (e.g., 10.0.0.0-10.255.255.255)
        if "-" in value:
            parts = value.split("-", 1)
            if len(parts) == 2:
                try:
                    # Both parts must be valid IP addresses
                    ipaddress.ip_address(parts[0].strip())
                    ipaddress.ip_address(parts[1].strip())
                    return True
                except ValueError:
                    return False

        # Try parsing as single IP address
        try:
            ipaddress.ip_address(value)
            return True
        except ValueError:
            return False

    def _resolve_address_reference(self, ref: str, policy_name: str, rule_name: str, field: str) -> str:
        """Resolve address reference to determine its type and ensure it exists.

        Resolution order:
        1. Check if exists in loaded AddressObjects (pre-loaded from Panorama)
        2. Check if exists in loaded AddressObjectGroups (pre-loaded from Panorama)
        3. Check if exists in loaded Regions (pre-loaded from Panorama)
        4. Check if it's a direct IP/CIDR/range (create synthetic AddressObject)
        5. Create placeholder AddressObjectGroup as last resort

        Args:
            ref: Reference string from policy rule
            policy_name: Policy name for logging
            rule_name: Rule name for logging
            field: Field name (e.g., 'source_addresses') for logging

        Returns:
            The reference string (unchanged), after ensuring appropriate object exists.

        Side effects:
            - Creates synthetic AddressObject for direct IPs
            - Creates placeholder AddressObjectGroup if not found in any loaded type
            - Logs direct IP usage for reporting
        """
        ref = str(ref).strip()
        if not ref or ref.lower() == "any":
            return ref

        # FIRST: Check if it exists in loaded AddressObject names
        if ref in self._addressobject_names:
            return ref

        # SECOND: Check if it exists in loaded AddressObjectGroup names
        if ref in self._addressobjectgroup_names:
            return ref

        # THIRD: Check if it's a region (geographic location)
        if ref in self._region_names:
            # Regions are valid address references in Panorama but not supported in Nautobot firewall models
            # Create as AddressObject placeholder with description indicating it's a region
            self._dbg("Creating placeholder for region reference: %s in %s/%s", ref, policy_name, rule_name)
            if ref not in self._addressobject_names:
                try:
                    # Create FQDN object first for referential integrity
                    fqdn_value = f"region-{ref.lower()}.placeholder.local"
                    try:
                        self.get(self.fqdn, fqdn_value)
                    except Exception:
                        # FQDN doesn't exist, create it
                        self.add(self.fqdn(name=fqdn_value, description=f"Region {ref} placeholder"))
                        self._dbg("Created FQDN %s for region %s", fqdn_value, ref)

                    # Create AddressObject with ONLY fqdn set (don't pass None for other fields)
                    self.add(
                        self.addressobject(
                            name=ref,
                            description=f"(placeholder - region) referenced by policy {policy_name}",
                            fqdn=fqdn_value,
                            ip_range=None,
                            ip_address=None,
                            prefix=None,
                        )
                    )
                    self._addressobject_names.add(ref)
                    self._dbg("Created AddressObject placeholder for region %s", ref)
                except Exception as exc:
                    self._dbg("Region placeholder creation failed for %s: %s", ref, exc)
            return ref

        # FOURTH: Check if it's a direct IP/CIDR/range (only after checking all named objects)
        if self._is_ip_or_range(ref):
            # Log direct IP usage for reporting
            self._direct_ip_usage.append(
                {"policy": policy_name, "rule": rule_name, "field": field, "value": ref, "type": "direct_ip"}
            )
            self._ensure_synthetic_address(ref)
            return ref

        # FIFTH: Check if it's a direct FQDN reference
        if self._is_fqdn(ref):
            # Log direct FQDN usage for reporting
            self._direct_ip_usage.append(
                {"policy": policy_name, "rule": rule_name, "field": field, "value": ref, "type": "direct_fqdn"}
            )
            self._ensure_synthetic_fqdn(ref)
            return ref

        # LAST RESORT: Not found in any loaded object type - create placeholder AddressObjectGroup
        self._dbg("Address reference %s not found in loaded objects, creating placeholder group", ref)
        self._ensure_address_group(ref)
        return ref

    def _ensure_application(self, name: str | None):
        """Create placeholder ApplicationObject if referenced by a rule."""
        if not name or not str(name).strip():
            return
        # Check if already exists as ApplicationObject
        try:
            self.get(self.applicationobject, str(name))
            return  # Already exists
        except Exception:  # noqa: S110
            pass
        # Create placeholder only if not found
        try:
            self.add(
                self.applicationobject(
                    name=str(name),
                    description="(placeholder) referenced by policy",
                    category="",
                    subcategory="",
                    technology="",
                    risk=None,
                )
            )
            self._dbg("Created placeholder ApplicationObject %s", name)
        except Exception as exc:
            self._dbg("Application placeholder creation failed for %s: %s", name, exc)

    def _ensure_address_group(self, name: str | None):
        """Create placeholder AddressObjectGroup for named references; direct IP/CIDR handled elsewhere."""
        if not name or not str(name).strip():
            return
        val = str(name)
        if "/" in val:
            self._ensure_synthetic_address(val)
            return
        # Check if already exists as AddressObject or AddressObjectGroup
        try:
            self.get(self.addressobject, val)
            return  # Exists as AddressObject, no placeholder needed
        except Exception:  # noqa: S110
            pass
        try:
            self.get(self.addressobjectgroup, val)
            return  # Already exists as AddressObjectGroup
        except Exception:  # noqa: S110
            pass
        # Create placeholder only if not found
        try:
            self.add(
                self.addressobjectgroup(
                    name=val,
                    description="(placeholder) referenced by policy",
                    address_objects=[],
                )
            )
            self._dbg("Created placeholder AddressObjectGroup %s", name)
        except Exception as exc:
            self._dbg("Address group placeholder creation failed for %s: %s", name, exc)

    def _classify_address_list(self, members: list) -> tuple[list[str], list[str]]:
        """Classify a list of address references into objects vs groups.

        Panorama returns all addresses in a flat list without type information.
        We classify each member by looking up names in tracking sets.

        Args:
            members: List of address names from a policy rule

        Returns:
            Tuple of (address_objects, address_object_groups)
        """
        address_objects = []
        address_object_groups = []
        for member in members or []:
            member_str = str(member).strip()
            if not member_str or member_str in PANORAMA_ANY_KEYWORDS:
                continue
            if member_str in self._addressobjectgroup_names:
                address_object_groups.append(member_str)
            elif member_str in self._addressobject_names:
                address_objects.append(member_str)
            else:
                # Unknown member - could be a direct IP, FQDN value, or missing reference
                # Check if it looks like an IP/CIDR
                if "/" in member_str or member_str.replace(".", "").isdigit():
                    # Direct IP reference - treat as address object (will be synthesized)
                    address_objects.append(member_str)
                else:
                    # Named reference not found in either set - default to group (safer)
                    self._dbg(
                        "Address reference '%s' not found in known objects or groups, treating as group",
                        member_str,
                    )
                    address_object_groups.append(member_str)
        return address_objects, address_object_groups

    def _classify_service_list(self, members: list) -> tuple[list[str], list[str]]:
        """Classify a list of service references into objects vs groups.

        Panorama returns all services in a flat list without type information.
        We classify each member by looking up names in tracking sets.

        Args:
            members: List of service names from a policy rule

        Returns:
            Tuple of (service_objects, service_object_groups)
        """
        service_objects = []
        service_object_groups = []
        for member in members or []:
            member_str = str(member).strip()
            if not member_str or member_str in PANORAMA_ANY_KEYWORDS:
                continue
            if member_str in self._serviceobjectgroup_names:
                service_object_groups.append(member_str)
            elif member_str in self._serviceobject_names:
                service_objects.append(member_str)
            else:
                # Unknown member - default to object (services don't reference groups by name typically)
                self._dbg(
                    "Service reference '%s' not found in known objects or groups, treating as object",
                    member_str,
                )
                service_objects.append(member_str)
        return service_objects, service_object_groups

    def _classify_application_list(self, members: list) -> tuple[list[str], list[str]]:
        """Classify a list of application references into objects vs groups.

        Panorama returns all applications in a flat list without type information.
        We classify each member by looking up names in tracking sets.

        Args:
            members: List of application names from a policy rule

        Returns:
            Tuple of (application_objects, application_object_groups)
        """
        application_objects = []
        application_object_groups = []
        for member in members or []:
            member_str = str(member).strip()
            if not member_str or member_str in PANORAMA_ANY_KEYWORDS:
                continue
            if member_str in self._applicationobjectgroup_names:
                application_object_groups.append(member_str)
            elif member_str in self._applicationobject_names:
                application_objects.append(member_str)
            else:
                # Unknown member - default to object (predefined apps may not be in our set)
                self._dbg(
                    "Application reference '%s' not found in known objects or groups, treating as object",
                    member_str,
                )
                application_objects.append(member_str)
        return application_objects, application_object_groups

    def load(self):  # noqa: D401
        """Orchestrate per-object loading methods in dependency order."""
        if not self.client:
            if self.job:
                self.job.logger.failure("Panorama client missing; aborting load.")
            return
        # Pre-populate group name tracking sets BEFORE loading groups
        # This ensures we can properly classify nested group members
        self._prepopulate_group_names()
        # Load regions first for reference resolution
        self.load_regions()
        # Load base objects
        self.load_addresses()
        self.load_services()
        self.load_applications()
        self.load_zones()
        # Load groups (depend on base objects)
        self.load_address_groups()
        self.load_service_groups()
        self.load_application_groups()
        # Load policies last (depend on all objects)
        self.load_policies()
        self.load_nat_policies()
        # Generate direct IP usage report
        self.generate_direct_ip_report()
        if self.job:
            self.job.logger.success("Panorama remote load complete")

            # Debug: Log a sample NAT policy rule from remote adapter
            if getattr(self.job, "debug", False):
                try:
                    for obj in self.get_all("natpolicyrule")[:3]:
                        self.job.logger.warning(
                            f"REMOTE natpolicyrule sample: "
                            f"name={obj.name}, "
                            f"orig_src_addr={obj.original_source_addresses}, "
                            f"orig_dst_addr={obj.original_destination_addresses}, "
                            f"orig_src_svc={obj.original_source_services}, "
                            f"orig_dst_svc={obj.original_destination_services}, "
                            f"src_zone={obj.source_zone!r}, "
                            f"dst_zone={obj.destination_zone!r}"
                        )
                except Exception as exc:  # pylint: disable=broad-except
                    self.job.logger.warning(f"Error sampling remote natpolicyrule: {exc}")

    def _prepopulate_group_names(self):
        """Pre-populate group name tracking sets before loading groups.

        This ensures that when we classify group members, we can correctly identify
        nested group references even if the referenced group appears later in the list.
        Without this pre-population, a group referencing another group that hasn't been
        loaded yet would incorrectly classify that member as an individual object.
        """
        # Pre-populate address group names
        for group in self.client.get_address_groups() or []:  # type: ignore[union-attr]
            name = group.get("name") or ""
            if name.strip():
                self._addressobjectgroup_names.add(name)
        self._dbg("Pre-populated %d address group names", len(self._addressobjectgroup_names))

        # Pre-populate service group names
        for group in self.client.get_service_groups() or []:  # type: ignore[union-attr]
            name = group.get("name") or ""
            if name.strip():
                self._serviceobjectgroup_names.add(name)
        self._dbg("Pre-populated %d service group names", len(self._serviceobjectgroup_names))

        # Pre-populate application group names
        for group in self.client.get_application_groups() or []:  # type: ignore[union-attr]
            name = group.get("name") or ""
            if name.strip():
                self._applicationobjectgroup_names.add(name)
        self._dbg("Pre-populated %d application group names", len(self._applicationobjectgroup_names))

    # ---- Per-object loaders ----

    def load_regions(self):
        """Load Panorama region names for reference resolution."""
        if not hasattr(self.client, "get_regions"):
            return
        try:
            regions = self.client.get_regions() or []  # type: ignore[union-attr]
            self._region_names = set(regions)
            self._dbg("Loaded %s Panorama regions", len(self._region_names))
        except Exception as exc:  # pylint: disable=broad-except
            self._dbg("Failed to load regions: %s", exc)

    def load_addresses(self):
        """Load address-related objects (FQDN, IPRange, AddressObject)."""
        for addr in self.client.get_addresses() or []:  # type: ignore[union-attr]
            try:
                name = addr.get("name") or ""
                if not name.strip():
                    continue
                self._addressobject_names.add(name)  # Track for reference resolution

                # Decide single underlying address attribute based on precedence
                fqdn_val = addr.get("fqdn")
                ip_range_val = addr.get("ip_range")
                ip_addr_val = addr.get("ip_address")
                prefix_val = addr.get("prefix")
                chosen_field = None
                chosen_value = None
                # Precedence: fqdn > ip_address > prefix > ip_range
                for field_name, value in (
                    ("fqdn", fqdn_val),
                    ("ip_address", ip_addr_val),
                    ("prefix", prefix_val),
                    ("ip_range", ip_range_val),
                ):
                    if value:
                        chosen_field = field_name
                        chosen_value = value
                        break
                # Create auxiliary FQDN/IPRange objects only when actually chosen to maintain referential clarity
                if chosen_field == "fqdn":
                    # Check if FQDN already exists before adding (multiple AddressObjects can share same FQDN)
                    try:
                        self.get(self.fqdn, chosen_value)
                        self._dbg(
                            "FQDN '%s' already exists, reusing for AddressObject '%s'", chosen_value, addr["name"]
                        )
                    except Exception:
                        # FQDN doesn't exist yet, create it
                        self.add(self.fqdn(name=chosen_value, description=_normalize_str(addr.get("description", ""))))
                    # Map FQDN value to AddressObject name for rule reference resolution
                    self._fqdn_to_addressobject[chosen_value] = addr["name"]
                    self._fqdn_to_addressobject[chosen_value.lower()] = addr["name"]  # Case-insensitive
                elif chosen_field == "ip_range" and "-" in chosen_value:
                    start, end = chosen_value.split("-", 1)
                    # Check if IPRange already exists before adding (multiple AddressObjects can share same range)
                    try:
                        self.get(self.iprange, {"start_address": start, "end_address": end})
                        self._dbg(
                            "IPRange '%s' already exists, reusing for AddressObject '%s'", chosen_value, addr["name"]
                        )
                    except Exception:
                        # IPRange doesn't exist yet, create it
                        self.add(
                            self.iprange(
                                start_address=start,
                                end_address=end,
                                description=_normalize_str(addr.get("description", "")),
                            )
                        )
                # Build kwargs with only one underlying attribute
                addr_kwargs = {
                    "name": addr["name"],
                    "description": _normalize_str(addr.get("description", "")),
                    "fqdn": chosen_value if chosen_field == "fqdn" else None,
                    "ip_range": chosen_value if chosen_field == "ip_range" else None,
                    "ip_address": chosen_value if chosen_field == "ip_address" else None,
                    "prefix": chosen_value if chosen_field == "prefix" else None,
                }
                # Track IP/prefix values to AddressObject name for rule reference resolution
                if chosen_field in ("ip_address", "prefix") and chosen_value:
                    self._ip_to_addressobject[chosen_value] = addr["name"]
                self.add(self.addressobject(**addr_kwargs))
                self._addressobject_names.add(addr["name"])
            except Exception as exc:  # pylint: disable=broad-except
                # Log at warning level so we can see which AddressObjects fail to load
                if self.job:
                    self.job.logger.warning(f"Failed to load AddressObject '{addr.get('name')}': {exc}")
                self._dbg("Skipping address %s due to exception: %s", addr.get("name"), exc)

    def load_services(self):
        """Load service objects."""
        for svc in self.client.get_services() or []:  # type: ignore[union-attr]
            try:
                # Support both legacy interim keys (protocol/ports) and new normalized (ip_protocol/port)
                raw_proto = svc.get("ip_protocol") or svc.get("protocol")
                proto_map = {
                    None: "Reserved",
                    "": "Reserved",
                    "any": "Reserved",
                    "tcp": "TCP",
                    "udp": "UDP",
                    "icmp": "ICMP",
                    "icmp6": "ICMP",
                    "sctp": "SCTP",
                }
                ip_protocol = proto_map.get(
                    str(raw_proto).lower() if raw_proto is not None else None, str(raw_proto).upper()
                )
                port = svc.get("port") or svc.get("ports")
                name = svc.get("name") or ""
                if not name.strip():  # Skip blank names
                    continue
                self.add(
                    self.serviceobject(
                        name=name,
                        description=_normalize_str(svc.get("description", "")),
                        port=port,
                        ip_protocol=ip_protocol,
                    )
                )
                self._serviceobject_names.add(svc["name"])
            except Exception as exc:  # pylint: disable=broad-except
                self._dbg("Skipping service %s: %s", svc.get("name"), exc)

    def load_applications(self):
        """Load application objects."""
        for app in self.client.get_applications() or []:  # type: ignore[union-attr]
            try:
                name = app.get("name") or ""
                if not name.strip():  # Skip blank names
                    continue
                self._applicationobject_names.add(name)  # Track for group member classification
                self.add(
                    self.applicationobject(
                        name=name,
                        description=_normalize_str(app.get("description", "")),
                        category=_normalize_str(app.get("category")),
                        subcategory=_normalize_str(app.get("subcategory")),
                        technology=_normalize_str(app.get("technology")),
                        risk=app.get("risk"),
                    )
                )
            except Exception as exc:  # pylint: disable=broad-except
                self._dbg("Skipping application %s: %s", app.get("name"), exc)

    def load_zones(self):
        """Load zone objects."""
        for zone in self.client.get_zones() or []:  # type: ignore[union-attr]
            try:
                self.add(self.zone(name=zone["name"], description=_normalize_str(zone.get("description", ""))))
                self._zone_names.add(zone["name"])
            except Exception as exc:  # pylint: disable=broad-except
                self._dbg("Skipping zone %s: %s", zone.get("name"), exc)

    def load_address_groups(self):
        """Load address groups.

        Panorama returns all members in a flat list without type information.
        We classify each member by looking up names in tracking sets:
        - If member name is in _addressobject_names -> it's an AddressObject
        - If member name is in _addressobjectgroup_names -> it's a nested AddressObjectGroup
        - Unknown members are logged and skipped (defensive handling)
        """
        for group in self.client.get_address_groups() or []:  # type: ignore[union-attr]
            try:
                name = group.get("name") or ""
                if not name.strip():  # Skip blank names
                    continue
                self._addressobjectgroup_names.add(name)  # Track for reference resolution

                # Classify members into objects vs nested groups
                all_members = group.get("members", []) or []
                address_objects = []
                address_object_groups = []
                for member in all_members:
                    member_str = str(member).strip()
                    if not member_str or member_str in PANORAMA_ANY_KEYWORDS:
                        continue
                    if member_str in self._addressobjectgroup_names:
                        address_object_groups.append(member_str)
                    elif member_str in self._addressobject_names:
                        address_objects.append(member_str)
                    else:
                        # Unknown member - could be a group not yet loaded or an undefined reference
                        # Default to treating as an object (most common case)
                        self._dbg(
                            "AddressGroup %s member '%s' not found in known objects or groups, treating as object",
                            name,
                            member_str,
                        )
                        address_objects.append(member_str)

                self.add(
                    self.addressobjectgroup(
                        name=name,
                        description=_normalize_str(group.get("description", "")),
                        address_objects=sorted(address_objects),
                        address_object_groups=sorted(address_object_groups),
                    )
                )
            except Exception as exc:  # pylint: disable=broad-except
                self._dbg("Skipping address group %s: %s", group.get("name"), exc)

    def load_service_groups(self):
        """Load service groups.

        Panorama returns all members in a flat list without type information.
        We classify each member by looking up names in tracking sets:
        - If member name is in _serviceobject_names -> it's a ServiceObject
        - If member name is in _serviceobjectgroup_names -> it's a nested ServiceObjectGroup
        - Unknown members are logged and treated as objects (defensive handling)
        """
        for group in self.client.get_service_groups() or []:  # type: ignore[union-attr]
            try:
                name = group.get("name") or ""
                if not name.strip():  # Skip blank names
                    continue
                self._serviceobjectgroup_names.add(name)  # Track for reference resolution

                # Classify members into objects vs nested groups
                all_members = group.get("members", []) or []
                service_objects = []
                service_object_groups = []
                for member in all_members:
                    member_str = str(member).strip()
                    if not member_str or member_str in PANORAMA_ANY_KEYWORDS:
                        continue
                    if member_str in self._serviceobjectgroup_names:
                        service_object_groups.append(member_str)
                    elif member_str in self._serviceobject_names:
                        service_objects.append(member_str)
                    else:
                        # Unknown member - default to treating as an object
                        self._dbg(
                            "ServiceGroup %s member '%s' not found in known objects or groups, treating as object",
                            name,
                            member_str,
                        )
                        service_objects.append(member_str)

                self.add(
                    self.serviceobjectgroup(
                        name=name,
                        description=_normalize_str(group.get("description", "")),
                        service_objects=sorted(service_objects),
                        service_object_groups=sorted(service_object_groups),
                    )
                )
            except Exception as exc:  # pylint: disable=broad-except
                self._dbg("Skipping service group %s: %s", group.get("name"), exc)

    def load_application_groups(self):
        """Load application groups.

        Panorama returns all members in a flat list without type information.
        We classify each member by looking up names in tracking sets:
        - If member name is in _applicationobject_names -> it's an ApplicationObject
        - If member name is in _applicationobjectgroup_names -> it's a nested ApplicationObjectGroup
        - Unknown members are logged and treated as objects (defensive handling)
        """
        for group in self.client.get_application_groups() or []:  # type: ignore[union-attr]
            try:
                name = group.get("name") or ""
                if not name.strip():  # Skip blank names
                    continue
                self._applicationobjectgroup_names.add(name)  # Track for reference resolution

                # Classify members into objects vs nested groups
                all_members = group.get("members", []) or []
                application_objects = []
                application_object_groups = []
                for member in all_members:
                    member_str = str(member).strip()
                    if not member_str or member_str in PANORAMA_ANY_KEYWORDS:
                        continue
                    if member_str in self._applicationobjectgroup_names:
                        application_object_groups.append(member_str)
                    elif member_str in self._applicationobject_names:
                        application_objects.append(member_str)
                    else:
                        # Unknown member - default to treating as an object
                        self._dbg(
                            "ApplicationGroup %s member '%s' not found in known objects or groups, treating as object",
                            name,
                            member_str,
                        )
                        application_objects.append(member_str)

                self.add(
                    self.applicationobjectgroup(
                        name=name,
                        description=_normalize_str(group.get("description", "")),
                        application_objects=sorted(application_objects),
                        application_object_groups=sorted(application_object_groups),
                    )
                )
            except Exception as exc:  # pylint: disable=broad-except
                self._dbg("Skipping application group %s: %s", group.get("name"), exc)

    def load_policies(self):
        """Load security policies and their rules."""
        for device_group in self.client.get_device_groups() or []:  # type: ignore[union-attr]
            for direction in ("pre", "post"):
                for pol in self.client.get_security_policies(device_group=device_group, direction=direction) or []:  # type: ignore[union-attr]
                    try:
                        panorama_name = pol["name"]
                        # Panorama name from SDK already contains device_group and direction (e.g., "SEC-PRE-DFW DataCenter")
                        # Use it directly instead of redundantly composing
                        policy_inst = self.policy(
                            name=panorama_name,
                            description=_normalize_str(pol.get("description", "")),
                            panorama_name=panorama_name,
                            device_group=device_group,
                            direction=direction,
                        )
                        self.add(policy_inst)
                        for rule in pol.get("rules", []) or []:
                            try:
                                # Pre-create placeholders for referenced entities to avoid missing-reference errors
                                # Use _resolve_address_reference for proper type detection

                                # Address references: check loaded objects to determine type
                                for addr_list_key in ("source_addresses", "destination_addresses"):
                                    for addr_val in rule.get(addr_list_key, []) or []:
                                        self._resolve_address_reference(
                                            addr_val,
                                            panorama_name,
                                            rule.get("name", f"rule-{rule['sequence']}"),
                                            addr_list_key,
                                        )

                                # Application references
                                for app_name in rule.get("applications", []) or []:
                                    self._ensure_application(str(app_name))

                                # Create placeholder service object if rule references application-default
                                service_fields = (
                                    "source_services",
                                    "destination_services",
                                )
                                for svc_field in service_fields:
                                    if "application-default" in (rule.get(svc_field) or []):
                                        self._ensure_application_default_service()

                                # Classify address, service, and application references
                                # The SDK returns all members in *_addresses/*_services/*_applications fields
                                # without distinguishing between objects and groups
                                src_addrs, src_addr_groups = self._classify_address_list(
                                    rule.get("source_addresses", [])
                                )
                                dst_addrs, dst_addr_groups = self._classify_address_list(
                                    rule.get("destination_addresses", [])
                                )
                                src_svcs, src_svc_groups = self._classify_service_list(rule.get("source_services", []))
                                dst_svcs, dst_svc_groups = self._classify_service_list(
                                    rule.get("destination_services", [])
                                )
                                apps, app_groups = self._classify_application_list(rule.get("applications", []))

                                # Ensure UserObjects exist for any referenced users
                                for user_name in rule.get("source_users", []) or []:
                                    self._ensure_user_object(user_name)
                                for user_name in rule.get("destination_users", []) or []:
                                    self._ensure_user_object(user_name)

                                rule_inst = self.policyrule(
                                    policy_name=policy_inst.name,
                                    index=rule["sequence"],
                                    name=_normalize_str(rule.get("name")),
                                    action=_normalize_str(rule.get("action")),
                                    description=_normalize_str(rule.get("description", "")),
                                    source_addresses=_normalize_list(src_addrs),
                                    source_address_groups=_normalize_list(src_addr_groups),
                                    source_zone=_normalize_str(rule.get("source_zone")),
                                    source_services=_normalize_list(src_svcs),
                                    source_service_groups=_normalize_list(src_svc_groups),
                                    destination_addresses=_normalize_list(dst_addrs),
                                    destination_address_groups=_normalize_list(dst_addr_groups),
                                    destination_zone=_normalize_str(rule.get("destination_zone")),
                                    destination_services=_normalize_list(dst_svcs),
                                    destination_service_groups=_normalize_list(dst_svc_groups),
                                    applications=_normalize_list(apps),
                                    application_groups=_normalize_list(app_groups),
                                    source_users=_normalize_list(rule.get("source_users", [])),
                                    destination_users=_normalize_list(rule.get("destination_users", [])),
                                )
                                self.add(rule_inst)
                                try:
                                    policy_inst.add_child(rule_inst)
                                except Exception as exc_child:  # pylint: disable=broad-except
                                    self._dbg(
                                        "Failed attaching policy rule child %s:%s due to %s",
                                        policy_inst.name,
                                        rule.get("sequence"),
                                        exc_child,
                                    )
                            except Exception as exc_rule:  # pylint: disable=broad-except
                                self._dbg(
                                    "Skipping rule sequence %s in policy %s: %s",
                                    rule.get("sequence"),
                                    pol.get("name"),
                                    exc_rule,
                                )
                    except Exception as exc_pol:  # pylint: disable=broad-except
                        self._dbg("Skipping policy %s (%s/%s): %s", pol.get("name"), device_group, direction, exc_pol)

    def load_nat_policies(self):
        """Load NAT policies and their rules."""
        for device_group in self.client.get_device_groups() or []:  # type: ignore[union-attr]
            for direction in ("pre", "post"):
                for nat in self.client.get_nat_policies(device_group=device_group, direction=direction) or []:  # type: ignore[union-attr]
                    try:
                        panorama_name = nat["name"]
                        # Panorama name from SDK already contains device_group and direction (e.g., "NAT-PRE-DFW DataCenter")
                        # Use it directly instead of redundantly composing
                        nat_inst = self.natpolicy(
                            name=panorama_name,
                            description=_normalize_str(nat.get("description", "")),
                            panorama_name=panorama_name,
                            device_group=device_group,
                            direction=direction,
                        )
                        self.add(nat_inst)
                        for rule in nat.get("rules", []) or []:
                            try:
                                # Pre-synthesize zones and direct IPs for NAT rule references
                                # Zones must come from object sync; do not create placeholders
                                # Placeholder service object for NAT rules referencing application-default
                                nat_service_fields = (
                                    "original_source_services",
                                    "original_destination_services",
                                )
                                for svc_field in nat_service_fields:
                                    if "application-default" in (rule.get(svc_field) or []):
                                        self._ensure_application_default_service()
                                # Synthetic address handling for NAT rule address fields
                                # Use _resolve_address_reference to handle IPs, FQDNs, and named objects
                                rule_name = rule.get("name", f"rule-{rule['sequence']}")
                                for addr_list_key in (
                                    "original_source_addresses",
                                    "original_destination_addresses",
                                    "translated_source_addresses",
                                    "translated_destination_addresses",
                                ):
                                    for addr_val in rule.get(addr_list_key, []) or []:
                                        self._resolve_address_reference(
                                            addr_val,
                                            panorama_name,
                                            rule_name,
                                            addr_list_key,
                                        )

                                # Classify address references
                                # The SDK returns all members in *_addresses fields without distinguishing
                                # between objects and groups
                                orig_src_addrs, orig_src_addr_groups = self._classify_address_list(
                                    rule.get("original_source_addresses", [])
                                )
                                orig_dst_addrs, orig_dst_addr_groups = self._classify_address_list(
                                    rule.get("original_destination_addresses", [])
                                )
                                trans_src_addrs, trans_src_addr_groups = self._classify_address_list(
                                    rule.get("translated_source_addresses", [])
                                )
                                trans_dst_addrs, trans_dst_addr_groups = self._classify_address_list(
                                    rule.get("translated_destination_addresses", [])
                                )

                                # Ensure UserObjects exist for any referenced users
                                for user_name in rule.get("source_users", []) or []:
                                    self._ensure_user_object(user_name)
                                for user_name in rule.get("destination_users", []) or []:
                                    self._ensure_user_object(user_name)

                                nat_rule = self.natpolicyrule(
                                    nat_policy_name=nat_inst.name,
                                    index=rule["sequence"],
                                    name=_normalize_str(rule.get("name")),
                                    description=_normalize_str(rule.get("description", "")),
                                    source_translation=_normalize_str(rule.get("source_translation")),
                                    destination_translation=_normalize_str(rule.get("destination_translation")),
                                    original_source_addresses=_normalize_list(orig_src_addrs),
                                    original_source_address_groups=_normalize_list(orig_src_addr_groups),
                                    original_destination_addresses=_normalize_list(orig_dst_addrs),
                                    original_destination_address_groups=_normalize_list(orig_dst_addr_groups),
                                    original_source_services=_normalize_list(rule.get("original_source_services", [])),
                                    original_source_service_groups=_normalize_list(
                                        rule.get("original_source_service_groups", [])
                                    ),
                                    original_destination_services=_normalize_list(
                                        rule.get("original_destination_services", [])
                                    ),
                                    original_destination_service_groups=_normalize_list(
                                        rule.get("original_destination_service_groups", [])
                                    ),
                                    translated_source_addresses=_normalize_list(trans_src_addrs),
                                    translated_source_address_groups=_normalize_list(trans_src_addr_groups),
                                    translated_destination_addresses=_normalize_list(trans_dst_addrs),
                                    translated_destination_address_groups=_normalize_list(trans_dst_addr_groups),
                                    # Also normalize missing translated service fields (NAT rules don't have separate service lists)
                                    translated_source_services=_normalize_list([]),
                                    translated_source_service_groups=_normalize_list([]),
                                    translated_destination_services=_normalize_list([]),
                                    translated_destination_service_groups=_normalize_list([]),
                                    source_users=_normalize_list(rule.get("source_users", [])),
                                    destination_users=_normalize_list(rule.get("destination_users", [])),
                                    # Normalize zones: None -> "" to match local adapter
                                    source_zone=_normalize_str(rule.get("source_zone")),
                                    destination_zone=_normalize_str(rule.get("destination_zone")),
                                )
                                self.add(nat_rule)
                                try:
                                    nat_inst.add_child(nat_rule)
                                except Exception as exc_child:  # pylint: disable=broad-except
                                    self._dbg(
                                        "Failed attaching NAT rule child %s:%s due to %s",
                                        nat_inst.name,
                                        rule.get("sequence"),
                                        exc_child,
                                    )
                            except Exception as exc_rule:  # pylint: disable=broad-except
                                self._dbg(
                                    "Skipping NAT rule sequence %s in policy %s: %s",
                                    rule.get("sequence"),
                                    nat.get("name"),
                                    exc_rule,
                                )
                    except Exception as exc_nat:  # pylint: disable=broad-except
                        self._dbg(
                            "Skipping NAT policy %s (%s/%s): %s", nat.get("name"), device_group, direction, exc_nat
                        )

    def generate_direct_ip_report(self):
        """Generate CSV report and summary of inline IP address handling.

        Attaches CSV file to job for download, listing all policy rules that reference
        direct IP addresses/ranges instead of named AddressObjects. Also logs summary
        statistics about auto-created AddressObjects.
        """
        if not self._direct_ip_usage:
            if self.job:
                self.job.logger.info("No direct IP usage found in policy rules")
            return

        if not self.job:
            return

        try:
            import csv
            import io

            output = io.StringIO()
            writer = csv.DictWriter(output, fieldnames=["policy", "rule", "field", "value", "type"])
            writer.writeheader()
            writer.writerows(self._direct_ip_usage)

            csv_content = output.getvalue()

            # Log comprehensive summary
            ip_count = sum(1 for x in self._direct_ip_usage if x.get("type") == "direct_ip")
            fqdn_count = sum(1 for x in self._direct_ip_usage if x.get("type") == "direct_fqdn")
            self.job.logger.warning(
                f"Auto-created {self._direct_ip_count} AddressObject(s) for {len(self._direct_ip_usage)} inline "
                f"reference(s) in policy rules ({ip_count} IPs, {fqdn_count} FQDNs). "
                "These objects are tagged 'Auto-Created Inline IP' for tracking. "
                "Best practice: Replace inline references with proper named AddressObjects in Panorama."
            )

            # Attach CSV to job if supported
            if hasattr(self.job, "create_file"):
                self.job.create_file("direct_ip_usage_report.csv", csv_content)
            else:
                # Log first 10 entries if can't attach file
                self.job.logger.info(f"First 10 of {len(self._direct_ip_usage)} inline IP usage entries:")
                for entry in self._direct_ip_usage[:10]:
                    self.job.logger.info(
                        "  %s / %s / %s: %s (%s)",
                        entry["policy"],
                        entry["rule"],
                        entry["field"],
                        entry["value"],
                        entry["type"],
                    )

        except Exception as exc:  # pylint: disable=broad-except
            if self.job:
                self.job.logger.warning("Failed to generate direct IP usage report: %s", exc)
