"""Nautobot local adapter: loads tagged Nautobot ORM data into CRUD DiffSync models."""

from __future__ import annotations

import ipaddress

from diffsync import Adapter
from nautobot.extras.models import Relationship, RelationshipAssociation, Tag
from nautobot_firewall_models.models import (
    FQDN,
    AddressObject,
    AddressObjectGroup,
    ApplicationObject,
    ApplicationObjectGroup,
    IPRange,
    NATPolicy,
    Policy,
    ServiceObject,
    ServiceObjectGroup,
    UserObject,
    Zone,
)

from nautobot_ssot_panorama.diffsync.models.nautobot import (
    NautobotAddressObject,
    NautobotAddressObjectGroup,
    NautobotApplicationObject,
    NautobotApplicationObjectGroup,
    NautobotFQDN,
    NautobotIPRange,
    NautobotNATPolicy,
    NautobotNATPolicyRule,
    NautobotPolicy,
    NautobotPolicyRule,
    NautobotServiceObject,
    NautobotServiceObjectGroup,
    NautobotUserObject,
    NautobotZone,
)

PANORAMA_TAG_NAME = "Panorama SSoT"


def _normalize_str(val):
    """Normalize string values: None -> '', strip whitespace."""
    if val is None:
        return ""
    return str(val).strip()


def _normalize_list(val):
    """Normalize list values: None -> [], ensure all elements are strings, and sort for consistent comparison."""
    if val is None:
        return []
    if not isinstance(val, list):
        return [str(val)]
    return sorted([str(v) for v in val])


class PanoramaLocalAdapter(Adapter):
    """Adapter for Nautobot local data (CRUD models)."""

    fqdn = NautobotFQDN
    iprange = NautobotIPRange
    addressobject = NautobotAddressObject
    serviceobject = NautobotServiceObject
    policy = NautobotPolicy
    policyrule = NautobotPolicyRule
    natpolicy = NautobotNATPolicy
    natpolicyrule = NautobotNATPolicyRule
    # CRUD-enabled group/application/zone models
    addressobjectgroup = NautobotAddressObjectGroup
    serviceobjectgroup = NautobotServiceObjectGroup
    applicationobjectgroup = NautobotApplicationObjectGroup
    applicationobject = NautobotApplicationObject
    userobject = NautobotUserObject
    zone = NautobotZone

    top_level = [
        "fqdn",
        "iprange",
        "addressobject",
        "serviceobject",
        "applicationobject",
        "userobject",
        "zone",
        "addressobjectgroup",
        "serviceobjectgroup",
        "applicationobjectgroup",
        "policy",
        "natpolicy",
    ]

    def __init__(self, *args, job=None, sync=None, **kwargs):  # pylint: disable=too-many-arguments
        """Initialize local adapter.

        Args:
            job: Nautobot Job instance for logging if provided.
            sync: Optional Nautobot SSoT sync object (stored, not passed to base Adapter).
            *args: Positional args passed to Adapter base.
            **kwargs: Keyword args passed to Adapter base.
        """
        kwargs.pop("sync", None)
        super().__init__(*args, **kwargs)
        self.job = job
        self.sync = sync

        # Track created objects for deferred tag assignment
        self.objects_pending_tags = {
            "addressobject": [],
            "serviceobject": [],
            "applicationobject": [],
            "userobject": [],
            "zone": [],
            "addressobjectgroup": [],
            "serviceobjectgroup": [],
            "applicationobjectgroup": [],
        }

        # Track objects slated for deletion (mirrors remote adapter pattern expected by CRUD models)
        self.objects_to_delete = {
            "fqdn": [],
            "iprange": [],
            "addressobject": [],
            "serviceobject": [],
            "applicationobject": [],
            "userobject": [],
            "zone": [],
            "addressobjectgroup": [],
            "serviceobjectgroup": [],
            "applicationobjectgroup": [],
            "policy": [],
            "policyrule": [],
            "natpolicy": [],
            "natpolicyrule": [],
        }

    def load(self):  # noqa: D401
        """Orchestrate per-object loader methods in dependency order."""
        tag = Tag.objects.filter(name=PANORAMA_TAG_NAME).first()
        self.load_fqdns(tag)
        self.load_ipranges(tag)
        self.load_address_objects(tag)
        self.load_service_objects(tag)
        self.load_application_objects(tag)
        self.load_user_objects(tag)
        self.load_zones(tag)
        # Load object groups after their member objects
        self.load_address_object_groups(tag)
        self.load_service_object_groups(tag)
        self.load_application_object_groups(tag)
        self.load_policies(tag)
        self.load_nat_policies(tag)
        if self.job:
            self.job.logger.success("Local adapter load complete")

            # Debug: Log a sample NAT policy rule from local adapter
            if getattr(self.job, "debug", False):
                try:
                    for obj in self.get_all("natpolicyrule")[:3]:
                        self.job.logger.warning(
                            f"LOCAL (early) natpolicyrule sample: "
                            f"name={obj.name!r}, description={obj.description!r}, "
                            f"source_zone={obj.source_zone!r}, destination_zone={obj.destination_zone!r}, "
                            f"original_source_addresses={obj.original_source_addresses!r}, "
                            f"translated_source_addresses={obj.translated_source_addresses!r}"
                        )
                except Exception as exc:  # pylint: disable=broad-except
                    self.job.logger.warning(f"Error sampling local natpolicyrule: {exc}")

    def apply_deferred_tags(self):
        """Apply tags to all objects that were created during sync.

        This method should be called after sync completes to batch-assign tags,
        which is much faster than assigning tags during individual object creation.
        """
        if self.job:
            self.job.logger.info("Applying deferred tags to created objects...")

        tag = Tag.objects.get_or_create(name=PANORAMA_TAG_NAME)[0]
        total_tagged = 0

        for object_type, objects in self.objects_pending_tags.items():
            if objects:
                if self.job:
                    self.job.logger.info(f"Tagging {len(objects)} {object_type} objects...")
                for obj in objects:
                    obj.tags.add(tag)
                total_tagged += len(objects)
                objects.clear()

        if self.job and total_tagged > 0:
            self.job.logger.success(f"Tagged {total_tagged} objects")

        return total_tagged

    def process_deletions(self):
        """Process all objects scheduled for deletion during sync.

        Objects are deleted in reverse dependency order to avoid FK constraint violations:
        1. Rules (PolicyRule, NATPolicyRule) - depend on policies
        2. Policies (Policy, NATPolicy) - depend on objects/groups
        3. Groups (AddressObjectGroup, ServiceObjectGroup, ApplicationObjectGroup) - depend on objects
        4. Objects (AddressObject, ServiceObject, ApplicationObject, Zone, FQDN, IPRange)

        Returns:
            int: Total number of objects deleted.
        """
        if self.job:
            self.job.logger.info("Processing scheduled deletions...")

        total_deleted = 0

        # Deletion order: rules -> policies -> groups -> base objects
        deletion_order = [
            "policyrule",
            "natpolicyrule",
            "policy",
            "natpolicy",
            "addressobjectgroup",
            "serviceobjectgroup",
            "applicationobjectgroup",
            "addressobject",
            "serviceobject",
            "applicationobject",
            "userobject",
            "zone",
            "fqdn",
            "iprange",
        ]

        for object_type in deletion_order:
            objects = self.objects_to_delete.get(object_type, [])
            if objects:
                if self.job:
                    self.job.logger.info(f"Deleting {len(objects)} {object_type} objects...")
                for obj in objects:
                    try:
                        obj_repr = f"{object_type}:{getattr(obj, 'name', getattr(obj, 'pk', '?'))}"
                        obj.delete()
                        total_deleted += 1
                        if self.job and getattr(self.job, "debug", False):
                            self.job.logger.debug(f"Deleted {obj_repr}")
                    except Exception as exc:  # pylint: disable=broad-except
                        if self.job:
                            self.job.logger.warning(
                                f"Failed to delete {object_type} {getattr(obj, 'name', getattr(obj, 'pk', '?'))}: {exc}"
                            )
                objects.clear()

        if self.job:
            if total_deleted > 0:
                self.job.logger.success(f"Deleted {total_deleted} objects from Nautobot")
            else:
                self.job.logger.info("No objects scheduled for deletion")

        return total_deleted

    # ---- Per-object loaders ----
    def load_fqdns(self, tag):
        """Load tagged `FQDN` objects into DiffSync."""
        for obj in FQDN.objects.filter(tags=tag) if tag else []:
            try:
                self.add(self.fqdn(name=obj.name, description=getattr(obj, "description", "")))
            except Exception as exc:  # pylint: disable=broad-except
                if self.job:
                    self.job.logger.warning(f"Skipping FQDN {obj.name}: {exc}")

    def load_ipranges(self, tag):
        """Load tagged `IPRange` objects into DiffSync."""
        for obj in IPRange.objects.filter(tags=tag) if tag else []:
            try:
                self.add(
                    self.iprange(
                        start_address=obj.start_address,
                        end_address=obj.end_address,
                        description=getattr(obj, "description", ""),
                    )
                )
            except Exception as exc:  # pylint: disable=broad-except
                if self.job:
                    self.job.logger.warning(f"Skipping IPRange {obj}: {exc}")

    def load_address_objects(self, tag):
        """Load tagged `AddressObject` instances; include references to FQDN/IPRange when present."""
        for obj in AddressObject.objects.filter(tags=tag) if tag else []:
            try:
                # For ip_address, normalize to /32 representation to match Panorama host semantics
                # Nautobot may store with parent prefix mask, but we compare as /32
                ip_addr_value = None
                if obj.ip_address:
                    # Get the host address and always format as /32 (IPv4) or /128 (IPv6)
                    host = (
                        str(obj.ip_address.host)
                        if hasattr(obj.ip_address, "host")
                        else str(obj.ip_address).split("/")[0]
                    )
                    try:
                        ip_obj = ipaddress.ip_address(host)
                        suffix = "32" if ip_obj.version == 4 else "128"
                    except ValueError:
                        suffix = "32"
                    ip_addr_value = f"{host}/{suffix}"
                self.add(
                    self.addressobject(
                        name=obj.name,
                        description=getattr(obj, "description", ""),
                        fqdn=obj.fqdn.name if obj.fqdn else None,
                        ip_range=f"{obj.ip_range.start_address}-{obj.ip_range.end_address}" if obj.ip_range else None,
                        ip_address=ip_addr_value,
                        prefix=str(obj.prefix) if obj.prefix else None,
                    )
                )
            except Exception as exc:  # pylint: disable=broad-except
                if self.job:
                    self.job.logger.warning(f"Skipping AddressObject {obj.name}: {exc}")

    def load_service_objects(self, tag):
        """Load tagged `ServiceObject` instances."""
        for obj in ServiceObject.objects.filter(tags=tag) if tag else []:
            try:
                self.add(
                    self.serviceobject(
                        name=obj.name,
                        description=getattr(obj, "description", ""),
                        port=obj.port,
                        ip_protocol=obj.ip_protocol,
                    )
                )
            except Exception as exc:  # pylint: disable=broad-except
                if self.job:
                    self.job.logger.warning(f"Skipping ServiceObject {obj.name}: {exc}")

    def load_application_objects(self, tag):
        """Load tagged `ApplicationObject` instances."""
        for obj in ApplicationObject.objects.filter(tags=tag) if tag else []:
            try:
                self.add(
                    self.applicationobject(
                        name=obj.name,
                        description=getattr(obj, "description", ""),
                        category=_normalize_str(getattr(obj, "category", None)),
                        subcategory=_normalize_str(getattr(obj, "subcategory", None)),
                        technology=_normalize_str(getattr(obj, "technology", None)),
                        risk=getattr(obj, "risk", None),
                    )
                )
            except Exception as exc:  # pylint: disable=broad-except
                if self.job:
                    self.job.logger.warning(f"Skipping ApplicationObject {obj.name}: {exc}")

    def load_user_objects(self, tag):
        """Load tagged `UserObject` instances."""
        for obj in UserObject.objects.filter(tags=tag) if tag else []:
            try:
                self.add(self.userobject(name=obj.username))
            except Exception as exc:  # pylint: disable=broad-except
                if self.job:
                    self.job.logger.warning(f"Skipping UserObject {obj.name}: {exc}")

    def load_zones(self, tag):
        """Load tagged `Zone` objects."""
        for obj in Zone.objects.filter(tags=tag) if tag else []:
            try:
                self.add(self.zone(name=obj.name, description=getattr(obj, "description", "")))
            except Exception as exc:  # pylint: disable=broad-except
                if self.job:
                    self.job.logger.warning(f"Skipping Zone {obj.name}: {exc}")

    def _get_nested_group_members(self, group_obj, relationship_key, group_model_class):
        """Get nested group member names via Nautobot Relationship.

        Args:
            group_obj: The group object instance (e.g., AddressObjectGroup).
            relationship_key: The key of the self-referential relationship.
            group_model_class: The model class for the group type.

        Returns:
            List of nested group member names (sorted).
        """
        try:
            relationship = Relationship.objects.filter(key=relationship_key).first()
            if not relationship:
                return []

            # This group is the source (parent), find destination (member) groups
            from django.contrib.contenttypes.models import ContentType

            content_type = ContentType.objects.get_for_model(group_model_class)
            associations = RelationshipAssociation.objects.filter(
                relationship=relationship,
                source_type=content_type,
                source_id=group_obj.pk,
            )
            member_names = []
            for assoc in associations:
                try:
                    member_group = group_model_class.objects.get(pk=assoc.destination_id)
                    member_names.append(member_group.name)
                except group_model_class.DoesNotExist:
                    pass
            return sorted(member_names)
        except Exception:  # pylint: disable=broad-except
            return []

    def load_address_object_groups(self, tag):
        """Load tagged `AddressObjectGroup` objects including nested group members."""
        for obj in AddressObjectGroup.objects.filter(tags=tag) if tag else []:
            try:
                # Get member address object names (_normalize_list handles sorting)
                address_objects = _normalize_list([a.name for a in obj.address_objects.all()])
                # Get nested group members via Relationship
                address_object_groups = self._get_nested_group_members(
                    obj, "address_object_group_to_address_object_group", AddressObjectGroup
                )
                self.add(
                    self.addressobjectgroup(
                        name=obj.name,
                        description=_normalize_str(getattr(obj, "description", "")),
                        address_objects=address_objects,
                        address_object_groups=address_object_groups,
                    )
                )
            except Exception as exc:  # pylint: disable=broad-except
                if self.job:
                    self.job.logger.warning(f"Skipping AddressObjectGroup {obj.name}: {exc}")

    def load_service_object_groups(self, tag):
        """Load tagged `ServiceObjectGroup` objects including nested group members."""
        for obj in ServiceObjectGroup.objects.filter(tags=tag) if tag else []:
            try:
                # Get member service object names (_normalize_list handles sorting)
                service_objects = _normalize_list([s.name for s in obj.service_objects.all()])
                # Get nested group members via Relationship
                service_object_groups = self._get_nested_group_members(
                    obj, "service_object_group_to_service_object_group", ServiceObjectGroup
                )
                self.add(
                    self.serviceobjectgroup(
                        name=obj.name,
                        description=_normalize_str(getattr(obj, "description", "")),
                        service_objects=service_objects,
                        service_object_groups=service_object_groups,
                    )
                )
            except Exception as exc:  # pylint: disable=broad-except
                if self.job:
                    self.job.logger.warning(f"Skipping ServiceObjectGroup {obj.name}: {exc}")

    def load_application_object_groups(self, tag):
        """Load tagged `ApplicationObjectGroup` objects including nested group members."""
        for obj in ApplicationObjectGroup.objects.filter(tags=tag) if tag else []:
            try:
                # Get member application object names (_normalize_list handles sorting)
                application_objects = _normalize_list([a.name for a in obj.application_objects.all()])
                # Get nested group members via Relationship
                application_object_groups = self._get_nested_group_members(
                    obj, "application_object_group_to_application_object_group", ApplicationObjectGroup
                )
                self.add(
                    self.applicationobjectgroup(
                        name=obj.name,
                        description=_normalize_str(getattr(obj, "description", "")),
                        application_objects=application_objects,
                        application_object_groups=application_object_groups,
                    )
                )
            except Exception as exc:  # pylint: disable=broad-except
                if self.job:
                    self.job.logger.warning(f"Skipping ApplicationObjectGroup {obj.name}: {exc}")

    def load_policies(self, tag):
        """Load tagged `Policy` objects and their `PolicyRule` children."""
        for pol in Policy.objects.filter(tags=tag) if tag else []:
            try:
                # Parse the composed policy name created by remote adapter: SEC-{direction}-{device_group}
                # Examples: SEC-PRE-DFW DataCenter, SEC-POST-Elevance
                panorama_name = pol.name  # Use full name as panorama_name
                device_group = ""
                direction = ""
                if pol.name.startswith("SEC-PRE-"):
                    direction = "pre"
                    device_group = pol.name[8:]  # Remove "SEC-PRE-" prefix
                elif pol.name.startswith("SEC-POST-"):
                    direction = "post"
                    device_group = pol.name[9:]  # Remove "SEC-POST-" prefix
                else:
                    # Fallback: try to extract from description or use name as-is
                    if self.job:
                        self.job.logger.debug(
                            f"Policy {pol.name}: could not parse direction/device_group, using defaults"
                        )
                inst = self.policy(
                    name=pol.name,
                    description=_normalize_str(getattr(pol, "description", "")),
                    panorama_name=panorama_name,
                    device_group=device_group,
                    direction=direction,
                )
                self.add(inst)
                # Access related PolicyRule objects via the reverse M2M/through relation manager. The model does
                # not expose a direct FK named 'policy'; earlier attempt to filter with policy=<obj> raised
                # "Cannot resolve keyword 'policy'". Use the related manager instead for portability.
                for rule in getattr(pol, "policy_rules", []).all() if hasattr(pol, "policy_rules") else []:
                    try:
                        rule_inst = self.policyrule(
                            policy_name=pol.name,
                            index=rule.index,
                            name=_normalize_str(rule.name),
                            action=_normalize_str(rule.action),
                            description=_normalize_str(getattr(rule, "description", "")),
                            source_addresses=_normalize_list([a.name for a in rule.source_addresses.all()]),
                            source_address_groups=_normalize_list(
                                [g.name for g in getattr(rule, "source_address_groups", []).all()]
                                if hasattr(rule, "source_address_groups")
                                else []
                            ),
                            source_zone=_normalize_str(rule.source_zone.name if rule.source_zone else None),
                            source_services=_normalize_list([s.name for s in rule.source_services.all()]),
                            source_service_groups=_normalize_list(
                                [g.name for g in getattr(rule, "source_service_groups", []).all()]
                                if hasattr(rule, "source_service_groups")
                                else []
                            ),
                            destination_addresses=_normalize_list([a.name for a in rule.destination_addresses.all()]),
                            destination_address_groups=_normalize_list(
                                [g.name for g in getattr(rule, "destination_address_groups", []).all()]
                                if hasattr(rule, "destination_address_groups")
                                else []
                            ),
                            destination_zone=_normalize_str(
                                rule.destination_zone.name if rule.destination_zone else None
                            ),
                            destination_services=_normalize_list([s.name for s in rule.destination_services.all()]),
                            destination_service_groups=_normalize_list(
                                [g.name for g in getattr(rule, "destination_service_groups", []).all()]
                                if hasattr(rule, "destination_service_groups")
                                else []
                            ),
                            applications=_normalize_list([a.name for a in rule.applications.all()]),
                            application_groups=_normalize_list(
                                [g.name for g in getattr(rule, "application_groups", []).all()]
                                if hasattr(rule, "application_groups")
                                else []
                            ),
                            source_users=_normalize_list(
                                [u.name for u in getattr(rule, "source_users", []).all()]
                                if hasattr(rule, "source_users")
                                else []
                            ),
                            destination_users=_normalize_list(
                                [u.name for u in getattr(rule, "destination_users", []).all()]
                                if hasattr(rule, "destination_users")
                                else []
                            ),
                        )
                        self.add(rule_inst)
                        inst.add_child(rule_inst)
                    except Exception as exc_rule:  # pylint: disable=broad-except
                        if self.job:
                            self.job.logger.warning(
                                f"Skipping PolicyRule {getattr(rule, 'name', rule.index)} in policy {pol.name}: {exc_rule}"
                            )
            except Exception as exc_pol:  # pylint: disable=broad-except
                if self.job:
                    self.job.logger.warning(f"Skipping Policy {pol.name}: {exc_pol}")

    def load_nat_policies(self, tag):
        """Load tagged `NATPolicy` objects and their `NATPolicyRule` children."""
        for nat in NATPolicy.objects.filter(tags=tag) if tag else []:
            try:
                # Parse the composed policy name created by remote adapter: NAT-{direction}-{device_group}
                # Examples: NAT-PRE-DFW DataCenter, NAT-POST-Elevance
                panorama_name = nat.name  # Use full name as panorama_name
                device_group = ""
                direction = ""
                if nat.name.startswith("NAT-PRE-"):
                    direction = "pre"
                    device_group = nat.name[8:]  # Remove "NAT-PRE-" prefix
                elif nat.name.startswith("NAT-POST-"):
                    direction = "post"
                    device_group = nat.name[9:]  # Remove "NAT-POST-" prefix
                else:
                    # Fallback: try to extract from description or use name as-is
                    if self.job:
                        self.job.logger.debug(
                            f"NATPolicy {nat.name}: could not parse direction/device_group, using defaults"
                        )
                nat_inst = self.natpolicy(
                    name=nat.name,
                    description=_normalize_str(getattr(nat, "description", "")),
                    panorama_name=panorama_name,
                    device_group=device_group,
                    direction=direction,
                )
                self.add(nat_inst)
                # Similar to Policy rules, access NATPolicyRule objects via related manager instead of invalid FK.
                for rule in getattr(nat, "nat_policy_rules", []).all() if hasattr(nat, "nat_policy_rules") else []:
                    try:
                        nat_rule = self.natpolicyrule(
                            nat_policy_name=nat.name,
                            index=rule.index,
                            name=_normalize_str(rule.name),
                            description=_normalize_str(getattr(rule, "description", "")),
                            # source_translation and destination_translation don't exist on Nautobot ORM
                            # They're set by remote adapter but not persisted, so always empty here
                            source_translation="",
                            destination_translation="",
                            original_source_addresses=_normalize_list(
                                [a.name for a in getattr(rule, "original_source_addresses", []).all()]
                                if hasattr(rule, "original_source_addresses")
                                else []
                            ),
                            original_source_address_groups=_normalize_list(
                                [g.name for g in getattr(rule, "original_source_address_groups", []).all()]
                                if hasattr(rule, "original_source_address_groups")
                                else []
                            ),
                            original_destination_addresses=_normalize_list(
                                [a.name for a in getattr(rule, "original_destination_addresses", []).all()]
                                if hasattr(rule, "original_destination_addresses")
                                else []
                            ),
                            original_destination_address_groups=_normalize_list(
                                [g.name for g in getattr(rule, "original_destination_address_groups", []).all()]
                                if hasattr(rule, "original_destination_address_groups")
                                else []
                            ),
                            original_source_services=_normalize_list(
                                [s.name for s in getattr(rule, "original_source_services", []).all()]
                                if hasattr(rule, "original_source_services")
                                else []
                            ),
                            original_source_service_groups=_normalize_list(
                                [g.name for g in getattr(rule, "original_source_service_groups", []).all()]
                                if hasattr(rule, "original_source_service_groups")
                                else []
                            ),
                            original_destination_services=_normalize_list(
                                [s.name for s in getattr(rule, "original_destination_services", []).all()]
                                if hasattr(rule, "original_destination_services")
                                else []
                            ),
                            original_destination_service_groups=_normalize_list(
                                [g.name for g in getattr(rule, "original_destination_service_groups", []).all()]
                                if hasattr(rule, "original_destination_service_groups")
                                else []
                            ),
                            translated_source_addresses=_normalize_list(
                                [a.name for a in getattr(rule, "translated_source_addresses", []).all()]
                                if hasattr(rule, "translated_source_addresses")
                                else []
                            ),
                            translated_source_address_groups=_normalize_list(
                                [g.name for g in getattr(rule, "translated_source_address_groups", []).all()]
                                if hasattr(rule, "translated_source_address_groups")
                                else []
                            ),
                            translated_destination_addresses=_normalize_list(
                                [a.name for a in getattr(rule, "translated_destination_addresses", []).all()]
                                if hasattr(rule, "translated_destination_addresses")
                                else []
                            ),
                            translated_destination_address_groups=_normalize_list(
                                [g.name for g in getattr(rule, "translated_destination_address_groups", []).all()]
                                if hasattr(rule, "translated_destination_address_groups")
                                else []
                            ),
                            # Translated services - these don't exist on NAT rules but must match remote adapter's []
                            translated_source_services=_normalize_list([]),
                            translated_source_service_groups=_normalize_list([]),
                            translated_destination_services=_normalize_list([]),
                            translated_destination_service_groups=_normalize_list([]),
                            source_users=_normalize_list(
                                [u.name for u in getattr(rule, "source_users", []).all()]
                                if hasattr(rule, "source_users")
                                else []
                            ),
                            destination_users=_normalize_list(
                                [u.name for u in getattr(rule, "destination_users", []).all()]
                                if hasattr(rule, "destination_users")
                                else []
                            ),
                            # Normalize zones: None -> "" to match remote adapter
                            source_zone=_normalize_str(rule.source_zone.name if rule.source_zone else None),
                            destination_zone=_normalize_str(
                                rule.destination_zone.name if rule.destination_zone else None
                            ),
                        )
                        self.add(nat_rule)
                        nat_inst.add_child(nat_rule)
                    except Exception as exc_rule:  # pylint: disable=broad-except
                        if self.job:
                            self.job.logger.warning(
                                f"Skipping NATPolicyRule {getattr(rule, 'name', rule.index)} in NAT policy {nat.name}: {exc_rule}"
                            )
            except Exception as exc_nat:  # pylint: disable=broad-except
                if self.job:
                    self.job.logger.warning(f"Skipping NATPolicy {nat.name}: {exc_nat}")

        # Debug: Log sample NAT policy rules for comparison with remote adapter
        if getattr(self.job, "debug", False):
            try:
                nat_rules = self.get_all("natpolicyrule")[:3]
                for obj in nat_rules:
                    self.job.logger.warning(
                        f"LOCAL natpolicyrule sample: "
                        f"name={obj.name}, "
                        f"orig_src_addr={obj.original_source_addresses}, "
                        f"orig_dst_addr={obj.original_destination_addresses}, "
                        f"orig_src_svc={obj.original_source_services}, "
                        f"orig_dst_svc={obj.original_destination_services}, "
                        f"src_zone={obj.source_zone!r}, "
                        f"dst_zone={obj.destination_zone!r}"
                    )
            except Exception as e:  # pylint: disable=broad-except
                self.job.logger.warning(f"Error logging LOCAL NAT rule samples: {e}")
