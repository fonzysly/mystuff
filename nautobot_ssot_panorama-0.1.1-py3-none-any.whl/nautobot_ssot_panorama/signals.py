"""Signal handlers for nautobot_ssot_panorama.

This module defines signal handlers that run when the Nautobot database is ready.
It creates self-referential Relationships for Firewall Models group objects to
support nested groups (e.g., AddressObjectGroup containing other AddressObjectGroups),
which is a common pattern in Panorama but not natively supported by Nautobot Firewall Models.
"""

import logging

from nautobot.extras.choices import RelationshipTypeChoices

logger = logging.getLogger(__name__)

# Define the group models that need self-referential relationships
# Format: (app_label, model_name, relationship_key, label, description)
GROUP_RELATIONSHIP_DEFINITIONS = [
    (
        "nautobot_firewall_models",
        "AddressObjectGroup",
        "address_object_group_to_address_object_group",
        "Address Object Group Members",
        "Allows AddressObjectGroup to contain other AddressObjectGroups as members (nested groups from Panorama).",
    ),
    (
        "nautobot_firewall_models",
        "ServiceObjectGroup",
        "service_object_group_to_service_object_group",
        "Service Object Group Members",
        "Allows ServiceObjectGroup to contain other ServiceObjectGroups as members (nested groups from Panorama).",
    ),
    (
        "nautobot_firewall_models",
        "ApplicationObjectGroup",
        "application_object_group_to_application_object_group",
        "Application Object Group Members",
        "Allows ApplicationObjectGroup to contain other ApplicationObjectGroups as members (nested groups from Panorama).",
    ),
    (
        "nautobot_firewall_models",
        "UserObjectGroup",
        "user_object_group_to_user_object_group",
        "User Object Group Members",
        "Allows UserObjectGroup to contain other UserObjectGroups as members (nested groups from Panorama).",
    ),
]


def create_group_self_relationships(sender, apps, **kwargs):  # pylint: disable=too-many-locals
    """Create self-referential Relationships for Firewall Models group objects.

    This signal handler creates Many-to-Many relationships between group objects
    and themselves (e.g., AddressObjectGroup to AddressObjectGroup) to support
    nested group structures from Panorama that Nautobot Firewall Models doesn't
    natively support.

    Args:
        sender: The NautobotAppConfig instance that sent the signal.
        apps: Django apps registry for model lookups.
        **kwargs: Additional keyword arguments passed by the signal.
    """
    # Use apps.get_model to look up Nautobot core models
    _sender = sender
    content_type_model = apps.get_model("contenttypes", "ContentType")
    relationship_model = apps.get_model("extras", "Relationship")

    for app_label, model_name, rel_key, label, description in GROUP_RELATIONSHIP_DEFINITIONS:
        try:
            # Attempt to get the model from the firewall models app
            group_model = apps.get_model(app_label, model_name)
        except LookupError:
            logger.warning(
                "Model %s.%s not found. Skipping relationship creation for %s. "
                "Ensure nautobot-firewall-models is installed.",
                app_label,
                model_name,
                rel_key,
            )
            continue

        try:
            content_type = content_type_model.objects.get_for_model(group_model)
        except Exception as exc:  # pylint: disable=broad-except
            logger.warning(
                "Failed to get ContentType for %s.%s: %s. Skipping relationship %s.",
                app_label,
                model_name,
                exc,
                rel_key,
            )
            continue

        # Create or update the self-referential relationship
        try:
            _relationship, created = relationship_model.objects.update_or_create(
                key=rel_key,
                defaults={
                    "label": label,
                    "description": description,
                    "type": RelationshipTypeChoices.TYPE_MANY_TO_MANY,
                    "source_type": content_type,
                    "source_label": "Member Groups",
                    "source_filter": None,
                    "source_hidden": False,
                    "destination_type": content_type,
                    "destination_label": "Parent Groups",
                    "destination_filter": None,
                    "destination_hidden": True,
                },
            )
            if created:
                logger.info(
                    "Created self-referential Relationship '%s' for %s.%s",
                    label,
                    app_label,
                    model_name,
                )
            else:
                logger.debug(
                    "Relationship '%s' for %s.%s already exists, updated if needed.",
                    label,
                    app_label,
                    model_name,
                )
        except Exception as exc:  # pylint: disable=broad-except
            logger.error(
                "Failed to create/update Relationship '%s' for %s.%s: %s",
                rel_key,
                app_label,
                model_name,
                exc,
            )
