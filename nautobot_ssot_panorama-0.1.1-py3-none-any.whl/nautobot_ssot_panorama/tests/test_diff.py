"""Unit tests for CustomOrderingDiff class."""

# pylint: disable=duplicate-code

from unittest.mock import MagicMock

from diffsync.enum import DiffSyncActions
from django.test import TestCase

from nautobot_ssot_panorama.diff import CustomOrderingDiff


class TestCustomOrderingDiff(TestCase):
    """Tests for CustomOrderingDiff class."""

    def setUp(self):
        """Set up test fixtures."""
        self.diff = CustomOrderingDiff()

    def test_ordered_create_groups_defined(self):
        """Verify ORDERED_CREATE_GROUPS contains expected groups."""
        expected_groups = [
            "fqdn",
            "iprange",
            "addressobject",
            "serviceobject",
            "applicationobject",
            "zone",
            "addressobjectgroup",
            "serviceobjectgroup",
            "applicationobjectgroup",
            "policy",
            "natpolicy",
        ]
        self.assertEqual(CustomOrderingDiff.ORDERED_CREATE_GROUPS, expected_groups)

    def test_ordered_create_groups_has_base_objects_first(self):
        """Verify base objects come before groups and policies."""
        groups = CustomOrderingDiff.ORDERED_CREATE_GROUPS
        # Base objects should be in first 6 positions
        base_objects = ["fqdn", "iprange", "addressobject", "serviceobject", "applicationobject", "zone"]
        for i, obj in enumerate(base_objects):
            self.assertEqual(groups[i], obj)

    def test_ordered_create_groups_has_groups_before_policies(self):
        """Verify object groups come before policies."""
        groups = CustomOrderingDiff.ORDERED_CREATE_GROUPS
        group_types = ["addressobjectgroup", "serviceobjectgroup", "applicationobjectgroup"]
        policy_types = ["policy", "natpolicy"]

        # Find indices
        group_indices = [groups.index(g) for g in group_types]
        policy_indices = [groups.index(p) for p in policy_types]

        # All groups should come before all policies
        self.assertTrue(max(group_indices) < min(policy_indices))

    def test_get_children_empty_diff(self):
        """Verify empty diff yields no children."""
        children = list(self.diff.get_children())
        self.assertEqual(children, [])

    def test_get_children_create_ordering(self):
        """Verify CREATE operations are yielded in dependency order."""
        # Set up mock children with CREATE action
        mock_fqdn = MagicMock()
        mock_fqdn.action = DiffSyncActions.CREATE
        mock_fqdn.name = "fqdn1"

        mock_address = MagicMock()
        mock_address.action = DiffSyncActions.CREATE
        mock_address.name = "addr1"

        mock_policy = MagicMock()
        mock_policy.action = DiffSyncActions.CREATE
        mock_policy.name = "policy1"

        # Intentionally add in wrong order to verify reordering
        self.diff.children = {
            "policy": {"policy1": mock_policy},
            "fqdn": {"fqdn1": mock_fqdn},
            "addressobject": {"addr1": mock_address},
        }

        children = list(self.diff.get_children())

        # Verify order: fqdn -> addressobject -> policy
        self.assertEqual(len(children), 3)
        self.assertEqual(children[0], mock_fqdn)
        self.assertEqual(children[1], mock_address)
        self.assertEqual(children[2], mock_policy)

    def test_get_children_update_treated_like_create(self):
        """Verify UPDATE operations follow same ordering as CREATE."""
        mock_fqdn = MagicMock()
        mock_fqdn.action = DiffSyncActions.UPDATE
        mock_fqdn.name = "fqdn1"

        mock_policy = MagicMock()
        mock_policy.action = DiffSyncActions.UPDATE
        mock_policy.name = "policy1"

        self.diff.children = {
            "policy": {"policy1": mock_policy},
            "fqdn": {"fqdn1": mock_fqdn},
        }

        children = list(self.diff.get_children())

        # FQDN should come before policy
        self.assertEqual(children[0], mock_fqdn)
        self.assertEqual(children[1], mock_policy)

    def test_get_children_delete_ordering_reversed(self):
        """Verify DELETE operations are yielded in reverse dependency order."""
        mock_fqdn = MagicMock()
        mock_fqdn.action = DiffSyncActions.DELETE
        mock_fqdn.name = "fqdn1"

        mock_address = MagicMock()
        mock_address.action = DiffSyncActions.DELETE
        mock_address.name = "addr1"

        mock_policy = MagicMock()
        mock_policy.action = DiffSyncActions.DELETE
        mock_policy.name = "policy1"

        self.diff.children = {
            "fqdn": {"fqdn1": mock_fqdn},
            "addressobject": {"addr1": mock_address},
            "policy": {"policy1": mock_policy},
        }

        children = list(self.diff.get_children())

        # Verify reverse order: policy -> addressobject -> fqdn
        self.assertEqual(len(children), 3)
        self.assertEqual(children[0], mock_policy)
        self.assertEqual(children[1], mock_address)
        self.assertEqual(children[2], mock_fqdn)

    def test_get_children_mixed_actions(self):
        """Verify mixed CREATE/UPDATE and DELETE are properly ordered."""
        # CREATE actions
        mock_fqdn_create = MagicMock()
        mock_fqdn_create.action = DiffSyncActions.CREATE
        mock_fqdn_create.name = "fqdn_new"

        mock_policy_create = MagicMock()
        mock_policy_create.action = DiffSyncActions.CREATE
        mock_policy_create.name = "policy_new"

        # DELETE actions
        mock_fqdn_delete = MagicMock()
        mock_fqdn_delete.action = DiffSyncActions.DELETE
        mock_fqdn_delete.name = "fqdn_old"

        mock_policy_delete = MagicMock()
        mock_policy_delete.action = DiffSyncActions.DELETE
        mock_policy_delete.name = "policy_old"

        self.diff.children = {
            "fqdn": {"fqdn_new": mock_fqdn_create, "fqdn_old": mock_fqdn_delete},
            "policy": {"policy_new": mock_policy_create, "policy_old": mock_policy_delete},
        }

        children = list(self.diff.get_children())

        # Should be: creates (fqdn, policy), then deletes (policy, fqdn)
        self.assertEqual(len(children), 4)

        # First two should be creates in order
        self.assertEqual(children[0].action, DiffSyncActions.CREATE)
        self.assertEqual(children[0], mock_fqdn_create)
        self.assertEqual(children[1].action, DiffSyncActions.CREATE)
        self.assertEqual(children[1], mock_policy_create)

        # Last two should be deletes in reverse order
        self.assertEqual(children[2].action, DiffSyncActions.DELETE)
        self.assertEqual(children[2], mock_policy_delete)
        self.assertEqual(children[3].action, DiffSyncActions.DELETE)
        self.assertEqual(children[3], mock_fqdn_delete)

    def test_get_children_unlisted_group_create(self):
        """Verify groups not in ORDERED_CREATE_GROUPS are appended after ordered groups."""
        mock_fqdn = MagicMock()
        mock_fqdn.action = DiffSyncActions.CREATE
        mock_fqdn.name = "fqdn1"

        # Custom group not in ORDERED_CREATE_GROUPS
        mock_custom = MagicMock()
        mock_custom.action = DiffSyncActions.CREATE
        mock_custom.name = "custom1"

        mock_policy = MagicMock()
        mock_policy.action = DiffSyncActions.CREATE
        mock_policy.name = "policy1"

        self.diff.children = {
            "custom_group": {"custom1": mock_custom},
            "fqdn": {"fqdn1": mock_fqdn},
            "policy": {"policy1": mock_policy},
        }

        children = list(self.diff.get_children())

        # fqdn and policy are ordered; custom_group should come after all ordered creates
        self.assertEqual(len(children), 3)
        self.assertEqual(children[0], mock_fqdn)
        self.assertEqual(children[1], mock_policy)
        self.assertEqual(children[2], mock_custom)

    def test_get_children_unlisted_group_delete(self):
        """Verify unlisted groups' deletes come after ordered deletes."""
        mock_fqdn = MagicMock()
        mock_fqdn.action = DiffSyncActions.DELETE
        mock_fqdn.name = "fqdn1"

        mock_custom = MagicMock()
        mock_custom.action = DiffSyncActions.DELETE
        mock_custom.name = "custom1"

        self.diff.children = {
            "custom_group": {"custom1": mock_custom},
            "fqdn": {"fqdn1": mock_fqdn},
        }

        children = list(self.diff.get_children())

        # Both are deletes; custom should come first (reversed means unlisted reversed then ordered reversed)
        # Actually the algorithm appends unlisted to ordered_deletions, then reverses all
        # So: ordered_deletions = [fqdn], then append custom -> [fqdn, custom], reverse -> [custom, fqdn]
        self.assertEqual(len(children), 2)
        self.assertEqual(children[0], mock_custom)
        self.assertEqual(children[1], mock_fqdn)

    def test_get_children_all_object_types(self):
        """Test with all standard object types to ensure full ordering."""
        mocks = {}
        for group in CustomOrderingDiff.ORDERED_CREATE_GROUPS:
            mock = MagicMock()
            mock.action = DiffSyncActions.CREATE
            mock.name = f"{group}_1"
            mocks[group] = mock

        # Add in reverse order to verify reordering
        self.diff.children = {
            group: {f"{group}_1": mocks[group]} for group in reversed(CustomOrderingDiff.ORDERED_CREATE_GROUPS)
        }

        children = list(self.diff.get_children())

        # Should be in ORDERED_CREATE_GROUPS order
        self.assertEqual(len(children), len(CustomOrderingDiff.ORDERED_CREATE_GROUPS))
        for i, group in enumerate(CustomOrderingDiff.ORDERED_CREATE_GROUPS):
            self.assertEqual(children[i], mocks[group])
