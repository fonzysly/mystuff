"""Unit tests for signal handlers."""

from unittest.mock import MagicMock, patch

from django.test import TestCase

from nautobot_ssot_panorama.signals import (
    GROUP_RELATIONSHIP_DEFINITIONS,
    create_group_self_relationships,
)


class TestGroupRelationshipDefinitions(TestCase):
    """Tests for GROUP_RELATIONSHIP_DEFINITIONS constant."""

    def test_definitions_not_empty(self):
        """Verify definitions list is not empty."""
        self.assertGreater(len(GROUP_RELATIONSHIP_DEFINITIONS), 0)

    def test_definitions_structure(self):
        """Verify each definition has correct tuple structure."""
        for definition in GROUP_RELATIONSHIP_DEFINITIONS:
            self.assertIsInstance(definition, tuple)
            self.assertEqual(len(definition), 5)
            app_label, model_name, rel_key, label, description = definition
            self.assertIsInstance(app_label, str)
            self.assertIsInstance(model_name, str)
            self.assertIsInstance(rel_key, str)
            self.assertIsInstance(label, str)
            self.assertIsInstance(description, str)

    def test_definitions_contain_address_object_group(self):
        """Verify AddressObjectGroup is included."""
        model_names = [d[1] for d in GROUP_RELATIONSHIP_DEFINITIONS]
        self.assertIn("AddressObjectGroup", model_names)

    def test_definitions_contain_service_object_group(self):
        """Verify ServiceObjectGroup is included."""
        model_names = [d[1] for d in GROUP_RELATIONSHIP_DEFINITIONS]
        self.assertIn("ServiceObjectGroup", model_names)

    def test_definitions_contain_application_object_group(self):
        """Verify ApplicationObjectGroup is included."""
        model_names = [d[1] for d in GROUP_RELATIONSHIP_DEFINITIONS]
        self.assertIn("ApplicationObjectGroup", model_names)

    def test_definitions_contain_user_object_group(self):
        """Verify UserObjectGroup is included."""
        model_names = [d[1] for d in GROUP_RELATIONSHIP_DEFINITIONS]
        self.assertIn("UserObjectGroup", model_names)

    def test_all_definitions_use_firewall_models_app(self):
        """Verify all definitions use nautobot_firewall_models app."""
        for definition in GROUP_RELATIONSHIP_DEFINITIONS:
            self.assertEqual(definition[0], "nautobot_firewall_models")

    def test_relationship_keys_are_unique(self):
        """Verify all relationship keys are unique."""
        rel_keys = [d[2] for d in GROUP_RELATIONSHIP_DEFINITIONS]
        self.assertEqual(len(rel_keys), len(set(rel_keys)))

    def test_relationship_key_format(self):
        """Verify relationship keys follow expected naming pattern."""
        for definition in GROUP_RELATIONSHIP_DEFINITIONS:
            rel_key = definition[2]
            # Should contain 'to' indicating self-reference
            self.assertIn("_to_", rel_key)
            # Should reference same model twice (self-referential)
            parts = rel_key.split("_to_")
            self.assertEqual(len(parts), 2)


class TestCreateGroupSelfRelationships(TestCase):
    """Tests for create_group_self_relationships signal handler."""

    def test_handles_missing_model_gracefully(self):
        """Verify handler continues if model lookup fails."""
        mock_apps = MagicMock()
        mock_content_type_cls = MagicMock()
        mock_relationship_cls = MagicMock()

        def get_model_side_effect(app_label, _model_name):
            if app_label == "contenttypes":
                return mock_content_type_cls
            if app_label == "extras":
                return mock_relationship_cls
            raise LookupError("Model not found")

        mock_apps.get_model.side_effect = get_model_side_effect

        # Should not raise
        create_group_self_relationships(sender=None, apps=mock_apps)

        # Should have attempted to get each firewall model
        # (4 definitions * 1 call each for firewall model + 2 calls for ContentType and Relationship)
        self.assertGreater(mock_apps.get_model.call_count, 0)

    def test_handles_content_type_error_gracefully(self):
        """Verify handler continues if ContentType lookup fails."""
        mock_apps = MagicMock()
        mock_model = MagicMock()
        mock_apps.get_model.return_value = mock_model

        # Make ContentType lookup fail
        mock_content_type_cls = MagicMock()
        mock_content_type_cls.objects.get_for_model.side_effect = Exception("CT error")

        def side_effect(app_label, _model_name):
            if app_label == "contenttypes":
                return mock_content_type_cls
            if app_label == "extras":
                return MagicMock()
            return mock_model

        mock_apps.get_model.side_effect = side_effect

        # Should not raise
        create_group_self_relationships(sender=None, apps=mock_apps)

    def test_creates_relationship_when_all_lookups_succeed(self):
        """Verify relationship is created when all prerequisites exist."""
        mock_apps = MagicMock()
        mock_model = MagicMock()
        mock_content_type = MagicMock()
        mock_relationship_cls = MagicMock()
        mock_relationship = MagicMock()
        mock_relationship_cls.objects.update_or_create.return_value = (mock_relationship, True)

        def get_model_side_effect(app_label, _model_name):
            if app_label == "contenttypes":
                ct_cls = MagicMock()
                ct_cls.objects.get_for_model.return_value = mock_content_type
                return ct_cls
            if app_label == "extras":
                return mock_relationship_cls
            return mock_model

        mock_apps.get_model.side_effect = get_model_side_effect

        create_group_self_relationships(sender=None, apps=mock_apps)

        # Should have created relationships for each definition
        self.assertEqual(
            mock_relationship_cls.objects.update_or_create.call_count,
            len(GROUP_RELATIONSHIP_DEFINITIONS),
        )

    def test_update_or_create_called_with_correct_key(self):
        """Verify update_or_create is called with the correct relationship key."""
        mock_apps = MagicMock()
        mock_model = MagicMock()
        mock_content_type = MagicMock()
        mock_relationship_cls = MagicMock()
        mock_relationship_cls.objects.update_or_create.return_value = (MagicMock(), True)

        def get_model_side_effect(app_label, _model_name):
            if app_label == "contenttypes":
                ct_cls = MagicMock()
                ct_cls.objects.get_for_model.return_value = mock_content_type
                return ct_cls
            if app_label == "extras":
                return mock_relationship_cls
            return mock_model

        mock_apps.get_model.side_effect = get_model_side_effect

        create_group_self_relationships(sender=None, apps=mock_apps)

        # Check that the first call uses the first definition's key
        first_call = mock_relationship_cls.objects.update_or_create.call_args_list[0]
        expected_key = GROUP_RELATIONSHIP_DEFINITIONS[0][2]
        self.assertEqual(first_call.kwargs.get("key") or first_call[1].get("key"), expected_key)

    def test_handles_relationship_creation_error(self):
        """Verify handler continues if relationship creation fails."""
        mock_apps = MagicMock()
        mock_model = MagicMock()
        mock_content_type = MagicMock()
        mock_relationship_cls = MagicMock()
        mock_relationship_cls.objects.update_or_create.side_effect = Exception("DB error")

        def get_model_side_effect(app_label, _model_name):
            if app_label == "contenttypes":
                ct_cls = MagicMock()
                ct_cls.objects.get_for_model.return_value = mock_content_type
                return ct_cls
            if app_label == "extras":
                return mock_relationship_cls
            return mock_model

        mock_apps.get_model.side_effect = get_model_side_effect

        # Should not raise
        create_group_self_relationships(sender=None, apps=mock_apps)

    def test_logs_warning_for_missing_model(self):
        """Verify warning is logged when model is not found."""
        mock_apps = MagicMock()
        mock_content_type_cls = MagicMock()
        mock_relationship_cls = MagicMock()

        def get_model_side_effect(app_label, _model_name):
            if app_label == "contenttypes":
                return mock_content_type_cls
            if app_label == "extras":
                return mock_relationship_cls
            raise LookupError("Model not found")

        mock_apps.get_model.side_effect = get_model_side_effect

        with patch("nautobot_ssot_panorama.signals.logger") as mock_logger:
            create_group_self_relationships(sender=None, apps=mock_apps)
            # Should have logged warnings
            self.assertTrue(mock_logger.warning.called)

    def test_logs_info_for_created_relationship(self):
        """Verify info is logged when relationship is created."""
        mock_apps = MagicMock()
        mock_model = MagicMock()
        mock_content_type = MagicMock()
        mock_relationship_cls = MagicMock()
        mock_relationship_cls.objects.update_or_create.return_value = (MagicMock(), True)

        def get_model_side_effect(app_label, _model_name):
            if app_label == "contenttypes":
                ct_cls = MagicMock()
                ct_cls.objects.get_for_model.return_value = mock_content_type
                return ct_cls
            if app_label == "extras":
                return mock_relationship_cls
            return mock_model

        mock_apps.get_model.side_effect = get_model_side_effect

        with patch("nautobot_ssot_panorama.signals.logger") as mock_logger:
            create_group_self_relationships(sender=None, apps=mock_apps)
            # Should have logged info for each created relationship
            self.assertEqual(mock_logger.info.call_count, len(GROUP_RELATIONSHIP_DEFINITIONS))

    def test_logs_debug_for_existing_relationship(self):
        """Verify debug is logged when relationship already exists."""
        mock_apps = MagicMock()
        mock_model = MagicMock()
        mock_content_type = MagicMock()
        mock_relationship_cls = MagicMock()
        # Return created=False to indicate existing relationship
        mock_relationship_cls.objects.update_or_create.return_value = (MagicMock(), False)

        def get_model_side_effect(app_label, _model_name):
            if app_label == "contenttypes":
                ct_cls = MagicMock()
                ct_cls.objects.get_for_model.return_value = mock_content_type
                return ct_cls
            if app_label == "extras":
                return mock_relationship_cls
            return mock_model

        mock_apps.get_model.side_effect = get_model_side_effect

        with patch("nautobot_ssot_panorama.signals.logger") as mock_logger:
            create_group_self_relationships(sender=None, apps=mock_apps)
            # Should have logged debug for each existing relationship
            self.assertEqual(mock_logger.debug.call_count, len(GROUP_RELATIONSHIP_DEFINITIONS))
