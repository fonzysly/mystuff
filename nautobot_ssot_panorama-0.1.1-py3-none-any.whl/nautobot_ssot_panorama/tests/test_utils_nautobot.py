"""Unit tests for Nautobot utility functions."""

# pylint: disable=import-outside-toplevel

from unittest.mock import MagicMock, patch

from django.test import TestCase


class TestGetActiveStatus(TestCase):
    """Tests for get_active_status function."""

    @patch("nautobot_ssot_panorama.utils.nautobot.Status")
    def test_returns_active_status(self, mock_status):
        """Verify Active status is retrieved."""
        from nautobot_ssot_panorama.utils.nautobot import get_active_status

        mock_active = MagicMock(name="Active")
        mock_status.objects.get.return_value = mock_active

        result = get_active_status()

        mock_status.objects.get.assert_called_once_with(name="Active")
        self.assertEqual(result, mock_active)


class TestFindBestCidr(TestCase):
    """Tests for find_best_cidr function."""

    @patch("nautobot_ssot_panorama.utils.nautobot.Prefix")
    def test_returns_matching_prefix_length(self, mock_prefix):
        """Verify matching prefix length is returned."""
        from nautobot_ssot_panorama.utils.nautobot import find_best_cidr

        mock_prefix_obj = MagicMock()
        mock_prefix_obj.prefix_length = 24
        mock_prefix.objects.filter.return_value = [mock_prefix_obj]

        result = find_best_cidr("192.168.1.100")

        self.assertEqual(result, 24)

    @patch("nautobot_ssot_panorama.utils.nautobot.Prefix")
    def test_returns_32_when_no_match(self, mock_prefix):
        """Verify /32 is returned when no prefix matches."""
        from nautobot_ssot_panorama.utils.nautobot import find_best_cidr

        mock_prefix.objects.filter.return_value = []

        result = find_best_cidr("10.0.0.1")

        self.assertEqual(result, 32)


class TestGetParentPrefix(TestCase):
    """Tests for get_parent_prefix function."""

    @patch("nautobot_ssot_panorama.utils.nautobot.find_best_cidr")
    @patch("nautobot_ssot_panorama.utils.nautobot.Prefix")
    def test_returns_parent_prefix(self, mock_prefix, mock_find_cidr):
        """Verify parent prefix is returned."""
        from nautobot_ssot_panorama.utils.nautobot import get_parent_prefix

        mock_prefix_obj = MagicMock()
        mock_prefix.objects.get.return_value = mock_prefix_obj
        mock_find_cidr.return_value = 24

        result = get_parent_prefix("192.168.1.100")

        self.assertEqual(result, mock_prefix_obj)

    @patch("nautobot_ssot_panorama.utils.nautobot.find_best_cidr")
    @patch("nautobot_ssot_panorama.utils.nautobot.Prefix")
    def test_returns_none_when_not_found(self, mock_prefix, mock_find_cidr):
        """Verify None is returned when prefix doesn't exist."""
        from nautobot_ssot_panorama.utils.nautobot import get_parent_prefix

        mock_prefix.DoesNotExist = Exception
        mock_prefix.objects.get.side_effect = mock_prefix.DoesNotExist
        mock_find_cidr.return_value = 32

        result = get_parent_prefix("192.168.1.100")

        self.assertIsNone(result)

    @patch("nautobot_ssot_panorama.utils.nautobot.find_best_cidr")
    @patch("nautobot_ssot_panorama.utils.nautobot.Prefix")
    def test_strips_32_suffix(self, mock_prefix, mock_find_cidr):
        """Verify /32 suffix is stripped from address."""
        from nautobot_ssot_panorama.utils.nautobot import get_parent_prefix

        mock_prefix_obj = MagicMock()
        mock_prefix.objects.get.return_value = mock_prefix_obj
        mock_find_cidr.return_value = 24

        get_parent_prefix("192.168.1.100/32")

        # Verify find_best_cidr was called with clean address
        mock_find_cidr.assert_called_with(address="192.168.1.100")
