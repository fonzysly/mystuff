"""Unit tests for nautobot.py helper functions.

Tests module-level utility functions used by the DiffSync model implementations.
"""

# pylint: disable=import-outside-toplevel,protected-access,unused-argument

from unittest.mock import MagicMock, patch

from django.test import TestCase


class TestGetFirewallContentTypes(TestCase):
    """Tests for _get_firewall_content_types function."""

    def test_returns_cached_value_on_second_call(self):
        """Verify cache is used on subsequent calls."""
        from nautobot_ssot_panorama.diffsync.models import nautobot

        # Reset cache
        nautobot._firewall_content_types_cache = None

        with patch.object(nautobot.ContentType.objects, "get_for_model") as mock_get:
            mock_ct = MagicMock()
            mock_get.return_value = mock_ct

            # First call should query
            result1 = nautobot._get_firewall_content_types()
            call_count_after_first = mock_get.call_count

            # Second call should use cache
            result2 = nautobot._get_firewall_content_types()
            call_count_after_second = mock_get.call_count

            # Call count should be same (cache used)
            self.assertEqual(call_count_after_first, call_count_after_second)
            self.assertIs(result1, result2)

            # Reset cache for other tests
            nautobot._firewall_content_types_cache = None

    def test_handles_exception_gracefully(self):
        """Verify exceptions during content type lookup are handled."""
        from nautobot_ssot_panorama.diffsync.models import nautobot

        nautobot._firewall_content_types_cache = None

        with patch.object(nautobot.ContentType.objects, "get_for_model") as mock_get:
            mock_get.side_effect = Exception("DB error")

            # Should not raise, returns empty list
            result = nautobot._get_firewall_content_types()
            self.assertEqual(result, [])

            nautobot._firewall_content_types_cache = None


class TestGetTag(TestCase):
    """Tests for _get_tag function."""

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._get_firewall_content_types")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmTag")
    def test_creates_tag_if_not_exists(self, mock_orm_tag, mock_get_cts):
        """Verify tag is created when it doesn't exist."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import _get_tag

        mock_tag = MagicMock()
        mock_tag.content_types.all.return_value = []
        mock_orm_tag.objects.get_or_create.return_value = (mock_tag, True)
        mock_get_cts.return_value = []

        result = _get_tag()

        mock_orm_tag.objects.get_or_create.assert_called_once_with(name="Panorama SSoT")
        self.assertEqual(result, mock_tag)

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._get_firewall_content_types")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmTag")
    def test_adds_missing_content_types(self, mock_orm_tag, mock_get_cts):
        """Verify missing content types are added to tag."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import _get_tag

        mock_ct_existing = MagicMock()
        mock_ct_missing = MagicMock()

        mock_tag = MagicMock()
        mock_tag.content_types.all.return_value = [mock_ct_existing]
        mock_orm_tag.objects.get_or_create.return_value = (mock_tag, False)
        mock_get_cts.return_value = [mock_ct_existing, mock_ct_missing]

        _get_tag()

        # Should add only the missing content type
        mock_tag.content_types.add.assert_called_once_with(mock_ct_missing)


class TestSetNestedGroupMembers(TestCase):
    """Tests for _set_nested_group_members function."""

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.RelationshipAssociation")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.Relationship")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.ContentType")
    def test_creates_associations_for_members(self, mock_ct, mock_rel, mock_rel_assoc):
        """Verify relationship associations are created for group members."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import _set_nested_group_members

        mock_relationship = MagicMock()
        mock_rel.objects.filter.return_value.first.return_value = mock_relationship

        mock_content_type = MagicMock()
        mock_ct.objects.get_for_model.return_value = mock_content_type

        mock_parent = MagicMock()
        mock_parent.pk = 1

        mock_member = MagicMock()
        mock_member.pk = 2

        mock_group_cls = MagicMock()
        mock_group_cls.objects.get.return_value = mock_member

        _set_nested_group_members(
            parent_obj=mock_parent,
            member_names=["member-group-1"],
            relationship_key="test_relationship",
            group_model_class=mock_group_cls,
        )

        # Should delete existing associations
        mock_rel_assoc.objects.filter.assert_called()

        # Should create new association
        mock_rel_assoc.objects.get_or_create.assert_called_once()

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.Relationship")
    def test_skips_when_relationship_not_found(self, mock_rel):
        """Verify function returns early if relationship doesn't exist."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import _set_nested_group_members

        mock_rel.objects.filter.return_value.first.return_value = None

        # Should not raise
        _set_nested_group_members(
            parent_obj=MagicMock(),
            member_names=["member"],
            relationship_key="nonexistent",
            group_model_class=MagicMock(),
        )

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.RelationshipAssociation")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.Relationship")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.ContentType")
    def test_handles_missing_member_gracefully(self, mock_ct, mock_rel, mock_rel_assoc):
        """Verify missing members don't cause failure."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import _set_nested_group_members

        mock_relationship = MagicMock()
        mock_rel.objects.filter.return_value.first.return_value = mock_relationship
        mock_ct.objects.get_for_model.return_value = MagicMock()

        mock_group_cls = MagicMock()
        mock_group_cls.DoesNotExist = Exception
        mock_group_cls.objects.get.side_effect = mock_group_cls.DoesNotExist

        # Should not raise
        _set_nested_group_members(
            parent_obj=MagicMock(),
            member_names=["missing-member"],
            relationship_key="test",
            group_model_class=mock_group_cls,
        )

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.Relationship")
    def test_handles_none_member_names(self, mock_rel):
        """Verify None member_names is handled."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import _set_nested_group_members

        mock_relationship = MagicMock()
        mock_rel.objects.filter.return_value.first.return_value = mock_relationship

        # Should not raise
        _set_nested_group_members(
            parent_obj=MagicMock(),
            member_names=None,
            relationship_key="test",
            group_model_class=MagicMock(),
        )

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.Relationship")
    def test_handles_empty_member_names(self, mock_rel):
        """Verify empty member_names list is handled."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import _set_nested_group_members

        mock_relationship = MagicMock()
        mock_rel.objects.filter.return_value.first.return_value = mock_relationship

        # Should not raise
        _set_nested_group_members(
            parent_obj=MagicMock(),
            member_names=[],
            relationship_key="test",
            group_model_class=MagicMock(),
        )
