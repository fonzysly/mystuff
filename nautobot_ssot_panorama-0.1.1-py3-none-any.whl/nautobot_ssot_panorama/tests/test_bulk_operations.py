"""Unit tests for bulk_operations module."""

from unittest.mock import MagicMock, patch

from django.test import TestCase

from nautobot_ssot_panorama.diffsync.bulk_operations import (
    PANORAMA_TAG_NAME,
    _get_tag,
    bulk_create_address_objects,
    bulk_create_application_objects,
    bulk_create_service_objects,
)


class TestGetTag(TestCase):
    """Tests for _get_tag helper function."""

    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.Tag")
    def test_creates_or_gets_tag(self, mock_tag):
        """Verify _get_tag uses get_or_create."""
        mock_tag_instance = MagicMock()
        mock_tag.objects.get_or_create.return_value = (mock_tag_instance, True)

        result = _get_tag()

        mock_tag.objects.get_or_create.assert_called_once_with(name=PANORAMA_TAG_NAME)
        self.assertEqual(result, mock_tag_instance)

    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.Tag")
    def test_returns_existing_tag(self, mock_tag):
        """Verify _get_tag returns existing tag without creating new one."""
        mock_tag_instance = MagicMock()
        mock_tag.objects.get_or_create.return_value = (mock_tag_instance, False)

        result = _get_tag()

        self.assertEqual(result, mock_tag_instance)


class TestBulkCreateAddressObjects(TestCase):
    """Tests for bulk_create_address_objects function."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_adapter = MagicMock()
        self.mock_adapter.job.logger = MagicMock()

    def test_returns_zero_for_empty_list(self):
        """Verify returns 0 when no objects provided."""
        result = bulk_create_address_objects([], self.mock_adapter)
        self.assertEqual(result, 0)

    def test_returns_zero_for_none(self):
        """Verify returns 0 when None provided."""
        result = bulk_create_address_objects(None, self.mock_adapter)
        self.assertEqual(result, 0)

    @patch("nautobot_ssot_panorama.diffsync.bulk_operations._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.OrmAddressObject")
    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.get_active_status")
    def test_skips_existing_objects(self, mock_status, mock_orm, mock_tag):
        """Verify existing objects are skipped for bulk create."""
        mock_status.return_value = MagicMock()
        mock_tag.return_value = MagicMock()
        # Simulate existing object
        mock_orm.objects.values_list.return_value = {"existing-addr"}
        mock_orm.objects.bulk_create.return_value = []
        mock_orm.objects.get.return_value = MagicMock()

        queued = [
            ({"name": "existing-addr"}, {"description": "test"}),
            ({"name": "new-addr"}, {"description": "test", "prefix": "10.0.0.1/32"}),
        ]

        with patch("nautobot_ssot_panorama.diffsync.bulk_operations.get_parent_prefix") as mock_prefix:
            mock_prefix.return_value = MagicMock(prefix_length=24)
            with patch("nautobot_ssot_panorama.diffsync.bulk_operations.IPAddress") as mock_ip:
                mock_ip.objects.get_or_create.return_value = (MagicMock(), True)
                bulk_create_address_objects(queued, self.mock_adapter)

        # Should log about processing
        self.mock_adapter.job.logger.info.assert_called()

    @patch("nautobot_ssot_panorama.diffsync.bulk_operations._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.OrmAddressObject")
    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.OrmFQDN")
    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.get_active_status")
    def test_handles_fqdn_reference(self, mock_status, mock_fqdn, mock_orm, mock_tag):
        """Verify FQDN references are resolved."""
        mock_status.return_value = MagicMock()
        mock_tag.return_value = MagicMock()
        mock_orm.objects.values_list.return_value = set()
        mock_fqdn_obj = MagicMock()
        mock_fqdn.objects.get.return_value = mock_fqdn_obj
        mock_orm.objects.bulk_create.return_value = [MagicMock()]

        queued = [({"name": "fqdn-addr"}, {"description": "test", "fqdn": "example.com"})]

        _result = bulk_create_address_objects(queued, self.mock_adapter)

        mock_fqdn.objects.get.assert_called_with(name="example.com")

    @patch("nautobot_ssot_panorama.diffsync.bulk_operations._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.OrmAddressObject")
    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.OrmFQDN")
    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.get_active_status")
    def test_logs_warning_for_missing_fqdn(self, mock_status, mock_fqdn, mock_orm, mock_tag):
        """Verify warning is logged when FQDN not found."""
        mock_status.return_value = MagicMock()
        mock_tag.return_value = MagicMock()
        mock_orm.objects.values_list.return_value = set()

        # Create a proper DoesNotExist exception class
        class FQDNDoesNotExist(Exception):
            """Sentinel exception class for missing FQDN objects."""

        mock_fqdn.DoesNotExist = FQDNDoesNotExist
        mock_fqdn.objects.get.side_effect = FQDNDoesNotExist("FQDN not found")
        mock_orm.objects.bulk_create.return_value = []

        queued = [({"name": "fqdn-addr"}, {"description": "test", "fqdn": "missing.com"})]

        bulk_create_address_objects(queued, self.mock_adapter)

        self.mock_adapter.job.logger.warning.assert_called()

    @patch("nautobot_ssot_panorama.diffsync.bulk_operations._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.OrmAddressObject")
    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.OrmIPRange")
    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.get_active_status")
    def test_handles_ip_range_reference(self, mock_status, mock_iprange, mock_orm, mock_tag):
        """Verify IP range references are resolved."""
        mock_status.return_value = MagicMock()
        mock_tag.return_value = MagicMock()
        mock_orm.objects.values_list.return_value = set()
        mock_range_obj = MagicMock()
        mock_iprange.objects.get.return_value = mock_range_obj
        mock_orm.objects.bulk_create.return_value = [MagicMock()]

        queued = [({"name": "range-addr"}, {"description": "test", "ip_range": "10.0.0.1-10.0.0.10"})]

        bulk_create_address_objects(queued, self.mock_adapter)

        mock_iprange.objects.get.assert_called_with(start_address="10.0.0.1", end_address="10.0.0.10")

    @patch("nautobot_ssot_panorama.diffsync.bulk_operations._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.OrmAddressObject")
    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.get_active_status")
    def test_adds_tags_to_created_objects(self, mock_status, mock_orm, mock_tag):
        """Verify tags are added to bulk created objects."""
        mock_status.return_value = MagicMock()
        mock_tag_obj = MagicMock()
        mock_tag.return_value = mock_tag_obj
        mock_orm.objects.values_list.return_value = set()

        # Create mock objects with tags attribute
        mock_created = [MagicMock(), MagicMock()]
        mock_orm.objects.bulk_create.return_value = mock_created

        with patch("nautobot_ssot_panorama.diffsync.bulk_operations.get_parent_prefix") as mock_prefix:
            mock_prefix.return_value = MagicMock(prefix_length=24)
            with patch("nautobot_ssot_panorama.diffsync.bulk_operations.IPAddress") as mock_ip:
                mock_ip.objects.get_or_create.return_value = (MagicMock(), True)

                queued = [
                    ({"name": "addr1"}, {"description": "test", "prefix": "10.0.0.1/32"}),
                    ({"name": "addr2"}, {"description": "test", "prefix": "10.0.0.2/32"}),
                ]

                bulk_create_address_objects(queued, self.mock_adapter)

        # Each created object should have tags.add called
        for obj in mock_created:
            obj.tags.add.assert_called_with(mock_tag_obj)


class TestBulkCreateServiceObjects(TestCase):
    """Tests for bulk_create_service_objects function."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_adapter = MagicMock()
        self.mock_adapter.job.logger = MagicMock()

    def test_returns_zero_for_empty_list(self):
        """Verify returns 0 when no objects provided."""
        result = bulk_create_service_objects([], self.mock_adapter)
        self.assertEqual(result, 0)

    def test_returns_zero_for_none(self):
        """Verify returns 0 when None provided."""
        result = bulk_create_service_objects(None, self.mock_adapter)
        self.assertEqual(result, 0)

    @patch("nautobot_ssot_panorama.diffsync.bulk_operations._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.OrmServiceObject")
    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.get_active_status")
    def test_skips_existing_objects(self, mock_status, mock_orm, mock_tag):
        """Verify existing objects are skipped."""
        mock_status.return_value = MagicMock()
        mock_tag.return_value = MagicMock()
        mock_orm.objects.values_list.return_value = {"existing-svc"}
        mock_orm.objects.bulk_create.return_value = []

        queued = [
            ({"name": "existing-svc"}, {"description": "test", "port": "443", "ip_protocol": "TCP"}),
        ]

        result = bulk_create_service_objects(queued, self.mock_adapter)

        self.assertEqual(result, 0)

    @patch("nautobot_ssot_panorama.diffsync.bulk_operations._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.OrmServiceObject")
    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.get_active_status")
    def test_handles_application_default(self, mock_status, mock_orm, mock_tag):
        """Verify application-default placeholder is handled specially."""
        mock_status.return_value = MagicMock()
        mock_tag.return_value = MagicMock()
        mock_orm.objects.values_list.return_value = set()

        mock_created = MagicMock()
        mock_orm.objects.bulk_create.return_value = [mock_created]

        queued = [
            ({"name": "application-default"}, {"description": "", "port": None, "ip_protocol": None}),
        ]

        bulk_create_service_objects(queued, self.mock_adapter)

        # Check the object was created with special handling
        mock_orm.assert_called()

    @patch("nautobot_ssot_panorama.diffsync.bulk_operations._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.OrmServiceObject")
    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.get_active_status")
    def test_creates_service_with_port_and_protocol(self, mock_status, mock_orm, mock_tag):
        """Verify service is created with port and protocol."""
        mock_status.return_value = MagicMock()
        mock_tag.return_value = MagicMock()
        mock_orm.objects.values_list.return_value = set()

        mock_created = MagicMock()
        mock_orm.objects.bulk_create.return_value = [mock_created]

        queued = [
            ({"name": "https-service"}, {"description": "HTTPS", "port": "443", "ip_protocol": "TCP"}),
        ]

        result = bulk_create_service_objects(queued, self.mock_adapter)

        self.assertEqual(result, 1)


class TestBulkCreateApplicationObjects(TestCase):
    """Tests for bulk_create_application_objects function."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_adapter = MagicMock()
        self.mock_adapter.job.logger = MagicMock()

    def test_returns_zero_for_empty_list(self):
        """Verify returns 0 when no objects provided."""
        result = bulk_create_application_objects([], self.mock_adapter)
        self.assertEqual(result, 0)

    def test_returns_zero_for_none(self):
        """Verify returns 0 when None provided."""
        result = bulk_create_application_objects(None, self.mock_adapter)
        self.assertEqual(result, 0)

    @patch("nautobot_ssot_panorama.diffsync.bulk_operations._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.OrmApplicationObject")
    def test_skips_existing_objects(self, mock_orm, mock_tag):
        """Verify existing objects are skipped."""
        mock_tag.return_value = MagicMock()
        mock_orm.objects.values_list.return_value = {"existing-app"}
        mock_orm.objects.bulk_create.return_value = []

        queued = [
            ({"name": "existing-app"}, {"description": "test", "category": "business"}),
        ]

        result = bulk_create_application_objects(queued, self.mock_adapter)

        self.assertEqual(result, 0)

    @patch("nautobot_ssot_panorama.diffsync.bulk_operations._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.OrmApplicationObject")
    def test_creates_application_with_all_fields(self, mock_orm, mock_tag):
        """Verify application is created with all fields."""
        mock_tag.return_value = MagicMock()
        mock_orm.objects.values_list.return_value = set()

        mock_created = MagicMock()
        mock_orm.objects.bulk_create.return_value = [mock_created]

        queued = [
            (
                {"name": "web-browsing"},
                {
                    "description": "Web browsing",
                    "category": "general-internet",
                    "subcategory": "internet-utility",
                    "technology": "browser-based",
                    "risk": 3,
                },
            ),
        ]

        result = bulk_create_application_objects(queued, self.mock_adapter)

        self.assertEqual(result, 1)

    @patch("nautobot_ssot_panorama.diffsync.bulk_operations._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.OrmApplicationObject")
    def test_coerces_none_to_empty_string(self, mock_orm, mock_tag):
        """Verify None values are coerced to empty strings."""
        mock_tag.return_value = MagicMock()
        mock_orm.objects.values_list.return_value = set()

        mock_created = MagicMock()
        mock_orm.objects.bulk_create.return_value = [mock_created]

        queued = [
            (
                {"name": "minimal-app"},
                {
                    "description": None,
                    "category": None,
                    "subcategory": None,
                    "technology": None,
                    "risk": None,
                },
            ),
        ]

        bulk_create_application_objects(queued, self.mock_adapter)

        # Should have been called to create the object
        mock_orm.assert_called()

    @patch("nautobot_ssot_panorama.diffsync.bulk_operations._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.OrmApplicationObject")
    def test_adds_tags_to_created_objects(self, mock_orm, mock_tag):
        """Verify tags are added to created objects."""
        mock_tag_obj = MagicMock()
        mock_tag.return_value = mock_tag_obj
        mock_orm.objects.values_list.return_value = set()

        mock_created = [MagicMock(), MagicMock()]
        mock_orm.objects.bulk_create.return_value = mock_created

        queued = [
            ({"name": "app1"}, {"description": "test"}),
            ({"name": "app2"}, {"description": "test"}),
        ]

        bulk_create_application_objects(queued, self.mock_adapter)

        for obj in mock_created:
            obj.tags.add.assert_called_with(mock_tag_obj)

    @patch("nautobot_ssot_panorama.diffsync.bulk_operations._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.bulk_operations.OrmApplicationObject")
    def test_logs_error_on_creation_exception(self, mock_orm, mock_tag):
        """Verify errors are logged when object creation fails."""
        mock_tag.return_value = MagicMock()
        mock_orm.objects.values_list.return_value = set()
        mock_orm.side_effect = Exception("Creation error")

        queued = [
            ({"name": "bad-app"}, {"description": "test"}),
        ]

        bulk_create_application_objects(queued, self.mock_adapter)

        self.mock_adapter.job.logger.error.assert_called()
