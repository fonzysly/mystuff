"""Edge case and integration tests for DiffSync models.

Tests boundary conditions, error handling, and complex scenarios.
"""

# pylint: disable=import-outside-toplevel,too-many-arguments,unused-argument,duplicate-code

from unittest.mock import MagicMock, patch

from diffsync import Adapter
from django.test import TestCase


class MockAdapter(Adapter):
    """Mock adapter for testing that satisfies Pydantic validation."""

    top_level = []

    def __init__(self):
        """Initialize the mock adapter."""
        super().__init__()
        self.job = MagicMock()
        self.job.logger = MagicMock()
        self.objects_to_delete = {
            "fqdn": [],
            "iprange": [],
            "addressobject": [],
            "serviceobject": [],
            "applicationobject": [],
            "zone": [],
            "addressobjectgroup": [],
            "serviceobjectgroup": [],
            "applicationobjectgroup": [],
            "policy": [],
            "policyrule": [],
            "natpolicy": [],
            "natpolicyrule": [],
        }
        self.objects_pending_tags = {
            "fqdn": [],
            "iprange": [],
            "addressobject": [],
            "serviceobject": [],
            "applicationobject": [],
            "zone": [],
            "addressobjectgroup": [],
            "serviceobjectgroup": [],
            "applicationobjectgroup": [],
            "policy": [],
            "policyrule": [],
            "natpolicy": [],
            "natpolicyrule": [],
        }


class TestResolveWithGroupFallback(TestCase):
    """Tests for _resolve_objects_with_group_fallback nested function behavior."""

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.get_active_status")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmAddressObjectGroup")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmAddressObject")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmZone")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmPolicy")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmPolicyRule")
    def test_any_wildcard_returns_empty_lists(
        self,
        mock_orm_rule,
        mock_orm_policy,
        mock_orm_zone,
        mock_orm_addr,
        mock_orm_grp,
        mock_status,
        mock_get_tag,
    ):
        """Verify 'any' wildcard results in empty M2M sets."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotPolicyRule

        mock_adapter = MockAdapter()
        mock_parent = MagicMock()
        mock_parent.policy_rules.filter.return_value.first.return_value = None
        mock_orm_policy.objects.get.return_value = mock_parent

        mock_rule = MagicMock()
        mock_orm_rule.objects.create.return_value = mock_rule
        mock_status.return_value = MagicMock()
        mock_get_tag.return_value = MagicMock()

        NautobotPolicyRule.create(
            adapter=mock_adapter,
            ids={"policy_name": "test-policy", "index": 1},
            attrs={
                "name": "rule1",
                "action": "allow",
                "source_addresses": ["any"],
                "destination_addresses": ["any"],
            },
        )

        # With 'any', should set empty list
        mock_rule.source_addresses.set.assert_called_with([])
        mock_rule.destination_addresses.set.assert_called_with([])


class TestAutoCreatedInlineIP(TestCase):
    """Tests for auto-created inline IP tagging."""

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.IPAddress")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.Prefix")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._get_firewall_content_types")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.get_active_status")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmTag")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmAddressObject")
    def test_auto_created_inline_ip_gets_special_tag(
        self,
        mock_orm_addr,
        mock_orm_tag,
        mock_status,
        mock_get_tag,
        mock_get_cts,
        mock_prefix,
        mock_ip_address,
    ):
        """Verify auto-created inline IPs get the special tracking tag."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotAddressObject

        mock_adapter = MockAdapter()
        mock_obj = MagicMock()
        mock_orm_addr.objects.get_or_create.return_value = (mock_obj, True)
        mock_status.return_value = MagicMock()
        mock_get_tag.return_value = MagicMock()
        mock_get_cts.return_value = []
        mock_prefix.objects.get_or_create.return_value = (MagicMock(), True)
        mock_ip_address.objects.get_or_create.return_value = (MagicMock(), True)

        mock_auto_tag = MagicMock()
        mock_auto_tag.content_types.values_list.return_value.flat = True
        mock_auto_tag.content_types.values_list.return_value = []
        mock_orm_tag.objects.get_or_create.return_value = (mock_auto_tag, True)

        NautobotAddressObject.create(
            adapter=mock_adapter,
            ids={"name": "192.168.1.100"},
            attrs={
                "description": "Inline IP reference (auto-created)",
                "ip_address": "192.168.1.100/32",
            },
        )

        # Should have created/retrieved auto-created tag
        mock_orm_tag.objects.get_or_create.assert_called()
        call_args = mock_orm_tag.objects.get_or_create.call_args
        self.assertEqual(call_args.kwargs["name"], "Auto-Created Inline IP")


class TestDeferredTagging(TestCase):
    """Tests for deferred tag assignment optimization."""

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.get_active_status")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmServiceObject")
    def test_deferred_tagging_when_supported(self, mock_orm_svc, mock_status, mock_get_tag):
        """Verify objects are added to pending tags list when supported."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotServiceObject

        mock_adapter = MockAdapter()
        mock_obj = MagicMock()
        mock_orm_svc.objects.get_or_create.return_value = (mock_obj, True)
        mock_status.return_value = MagicMock()
        mock_get_tag.return_value = MagicMock()

        NautobotServiceObject.create(
            adapter=mock_adapter,
            ids={"name": "https"},
            attrs={"description": "HTTPS", "port": "443", "ip_protocol": "TCP"},
        )

        # Should be in pending list
        self.assertIn(mock_obj, mock_adapter.objects_pending_tags["serviceobject"])

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.get_active_status")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmServiceObject")
    def test_immediate_tagging_fallback(self, mock_orm_svc, mock_status, mock_get_tag):
        """Verify immediate tagging when deferred not supported."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotServiceObject

        # Create adapter without serviceobject in pending tags
        mock_adapter = MockAdapter()
        mock_adapter.objects_pending_tags = {}  # Empty - no serviceobject key

        mock_obj = MagicMock()
        mock_orm_svc.objects.get_or_create.return_value = (mock_obj, True)
        mock_status.return_value = MagicMock()
        mock_tag = MagicMock()
        mock_get_tag.return_value = mock_tag

        NautobotServiceObject.create(
            adapter=mock_adapter,
            ids={"name": "https"},
            attrs={"description": "HTTPS", "port": "443", "ip_protocol": "TCP"},
        )

        # Should have tagged immediately
        mock_obj.tags.add.assert_called_once_with(mock_tag)


class TestObjectsToDeleteConsistency(TestCase):
    """Tests for consistent objects_to_delete handling."""

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmApplicationObject")
    def test_setdefault_prevents_keyerror(self, mock_orm_app):
        """Verify setdefault usage prevents KeyError for missing keys."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotApplicationObject

        mock_adapter = MockAdapter()
        # Remove the key to simulate missing initialization
        del mock_adapter.objects_to_delete["applicationobject"]

        mock_obj = MagicMock()
        mock_orm_app.objects.get.return_value = mock_obj

        app = NautobotApplicationObject(name="test-app", description="Test", adapter=mock_adapter)

        # Should not raise KeyError
        app.delete()

        self.assertIn("applicationobject", mock_adapter.objects_to_delete)
        self.assertIn(mock_obj, mock_adapter.objects_to_delete["applicationobject"])


class TestNullDescriptionHandling(TestCase):
    """Tests for NULL description constraint handling."""

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.get_active_status")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmNATPolicy")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmNATPolicyRule")
    def test_existing_rule_with_null_description_fixed(self, mock_orm_rule, mock_orm_nat, mock_status, mock_get_tag):
        """Verify existing rules with NULL description are fixed."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotNATPolicyRule

        mock_adapter = MockAdapter()
        mock_parent = MagicMock()
        existing_rule = MagicMock()
        existing_rule.description = None  # NULL in DB
        mock_parent.nat_policy_rules.filter.return_value.first.return_value = existing_rule
        mock_orm_nat.objects.get.return_value = mock_parent

        mock_status.return_value = MagicMock()
        mock_get_tag.return_value = MagicMock()

        NautobotNATPolicyRule.create(
            adapter=mock_adapter,
            ids={"nat_policy_name": "test-nat", "index": 1},
            attrs={"name": "rule1", "description": None},
        )

        # Should have been coerced to empty string
        self.assertEqual(existing_rule.description, "")
        existing_rule.validated_save.assert_called()


class TestPolicyRuleLookupFallback(TestCase):
    """Tests for PolicyRule lookup with fallback behavior."""

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmPolicy")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmPolicyRule")
    def test_delete_fallback_to_direct_lookup(self, mock_orm_rule, mock_orm_policy):
        """Verify delete falls back to direct lookup when parent policy not found."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotPolicyRule

        mock_adapter = MockAdapter()
        # Parent policy lookup fails
        mock_orm_policy.DoesNotExist = Exception
        mock_orm_policy.objects.get.side_effect = mock_orm_policy.DoesNotExist

        # Direct lookup succeeds
        mock_rule = MagicMock()
        mock_orm_rule.objects.get.return_value = mock_rule

        rule = NautobotPolicyRule(policy_name="deleted-policy", index=1, name="rule1", adapter=mock_adapter)

        rule.delete()

        # Should have tried direct lookup
        mock_orm_rule.objects.get.assert_called_with(index=1, name="rule1")
        self.assertIn(mock_rule, mock_adapter.objects_to_delete["policyrule"])

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmPolicy")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmPolicyRule")
    def test_update_skips_when_rule_not_found(self, mock_orm_rule, mock_orm_policy):
        """Verify update logs and returns when rule not found."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotPolicyRule

        mock_adapter = MockAdapter()
        mock_orm_policy.DoesNotExist = Exception
        mock_orm_policy.objects.get.side_effect = mock_orm_policy.DoesNotExist
        mock_orm_rule.DoesNotExist = Exception
        mock_orm_rule.objects.get.side_effect = mock_orm_rule.DoesNotExist

        rule = NautobotPolicyRule(policy_name="missing", index=999, name="ghost", adapter=mock_adapter)

        # Should not raise
        rule.update({"description": "New"})

        mock_adapter.job.logger.debug.assert_called()


class TestZoneCreationForNATRules(TestCase):
    """Tests for automatic zone creation in NAT rules."""

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.get_active_status")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmZone")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmNATPolicy")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmNATPolicyRule")
    def test_creates_both_source_and_destination_zones(
        self, mock_orm_rule, mock_orm_nat, mock_orm_zone, mock_status, mock_get_tag
    ):
        """Verify both zones are created when missing."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotNATPolicyRule

        mock_adapter = MockAdapter()
        mock_parent = MagicMock()
        mock_parent.nat_policy_rules.filter.return_value.first.return_value = None
        mock_orm_nat.objects.get.return_value = mock_parent

        mock_rule = MagicMock()
        mock_orm_rule.objects.create.return_value = mock_rule

        # Both zone lookups fail
        mock_orm_zone.DoesNotExist = Exception
        mock_orm_zone.objects.get.side_effect = mock_orm_zone.DoesNotExist

        mock_src_zone = MagicMock()
        mock_dst_zone = MagicMock()
        mock_orm_zone.objects.get_or_create.side_effect = [
            (mock_src_zone, True),
            (mock_dst_zone, True),
        ]

        mock_status.return_value = MagicMock()
        mock_get_tag.return_value = MagicMock()

        NautobotNATPolicyRule.create(
            adapter=mock_adapter,
            ids={"nat_policy_name": "test-nat", "index": 1},
            attrs={
                "name": "rule1",
                "source_zone": "new-trust",
                "destination_zone": "new-untrust",
            },
        )

        # Should have created both zones
        self.assertEqual(mock_orm_zone.objects.get_or_create.call_count, 2)


class TestGroupMembershipResolution(TestCase):
    """Tests for group membership resolution in groups."""

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._set_nested_group_members")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmServiceObject")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmServiceObjectGroup")
    def test_empty_member_lists_handled(self, mock_orm_grp, mock_orm_svc, mock_get_tag, mock_set_nested):
        """Verify empty member lists don't cause issues."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotServiceObjectGroup

        mock_adapter = MockAdapter()
        mock_obj = MagicMock()
        mock_orm_grp.objects.get_or_create.return_value = (mock_obj, True)
        mock_get_tag.return_value = MagicMock()
        mock_orm_svc.objects.filter.return_value = []

        NautobotServiceObjectGroup.create(
            adapter=mock_adapter,
            ids={"name": "empty-group"},
            attrs={
                "description": "Empty group",
                "service_objects": [],
                "service_object_groups": [],
            },
        )

        # Should not have set any members (empty list check)
        mock_obj.service_objects.set.assert_not_called()
        # Nested groups function not called with empty list
        mock_set_nested.assert_not_called()
