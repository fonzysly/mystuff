"""Unit tests for DiffSync model CRUD operations.

Tests create, update, and delete operations for Nautobot DiffSync models.
"""

# pylint: disable=import-outside-toplevel,too-many-arguments,unused-argument,duplicate-code

from unittest.mock import MagicMock, patch

from diffsync import Adapter
from django.test import TestCase

from nautobot_ssot_panorama.tests.conftest import get_sample_application_object_attrs


class MockAdapter(Adapter):
    """Mock adapter for testing that satisfies Pydantic validation."""

    top_level = []

    def __init__(self):
        """Initialize the mock adapter."""
        super().__init__()
        self.job = MagicMock()
        self.job.logger = MagicMock()
        self.objects_to_delete = {
            "fqdn": [],
            "iprange": [],
            "addressobject": [],
            "serviceobject": [],
            "applicationobject": [],
            "userobject": [],
            "zone": [],
            "addressobjectgroup": [],
            "serviceobjectgroup": [],
            "applicationobjectgroup": [],
            "policy": [],
            "policyrule": [],
            "natpolicy": [],
            "natpolicyrule": [],
        }
        self.objects_pending_tags = {
            "fqdn": [],
            "iprange": [],
            "addressobject": [],
            "serviceobject": [],
            "applicationobject": [],
            "userobject": [],
            "zone": [],
            "addressobjectgroup": [],
            "serviceobjectgroup": [],
            "applicationobjectgroup": [],
            "policy": [],
            "policyrule": [],
            "natpolicy": [],
            "natpolicyrule": [],
        }


class TestNautobotFQDN(TestCase):
    """Tests for NautobotFQDN model CRUD operations."""

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.get_active_status")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmFQDN")
    def test_create_new_fqdn(self, mock_orm_fqdn, mock_status, mock_get_tag):
        """Verify FQDN is created with correct attributes."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotFQDN

        mock_adapter = MockAdapter()
        mock_obj = MagicMock()
        mock_orm_fqdn.objects.get_or_create.return_value = (mock_obj, True)
        mock_status.return_value = MagicMock(name="Active")
        mock_tag = MagicMock()
        mock_get_tag.return_value = mock_tag

        result = NautobotFQDN.create(
            adapter=mock_adapter,
            ids={"name": "test.example.com"},
            attrs={"description": "Test FQDN"},
        )

        mock_orm_fqdn.objects.get_or_create.assert_called_once()
        # Check tag is added (either immediately or via pending)
        self.assertIsNotNone(result)

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmFQDN")
    def test_update_fqdn_description(self, mock_orm_fqdn):
        """Verify FQDN description is updated."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotFQDN

        mock_adapter = MockAdapter()
        mock_obj = MagicMock()
        mock_orm_fqdn.objects.get.return_value = mock_obj

        fqdn = NautobotFQDN(name="test.example.com", description="Old", adapter=mock_adapter)

        fqdn.update({"description": "New description"})

        self.assertEqual(mock_obj.description, "New description")
        mock_obj.validated_save.assert_called_once()

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmFQDN")
    def test_delete_schedules_for_cleanup(self, mock_orm_fqdn):
        """Verify FQDN delete schedules object for cleanup."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotFQDN

        mock_adapter = MockAdapter()
        mock_obj = MagicMock()
        mock_orm_fqdn.objects.get.return_value = mock_obj

        fqdn = NautobotFQDN(name="test.example.com", description="Test", adapter=mock_adapter)

        fqdn.delete()

        self.assertIn(mock_obj, mock_adapter.objects_to_delete["fqdn"])


class TestNautobotIPRange(TestCase):
    """Tests for NautobotIPRange model CRUD operations."""

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.get_active_status")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmIPRange")
    def test_create_new_iprange(self, mock_orm_iprange, mock_status, mock_get_tag):
        """Verify IPRange is created with start/end addresses."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotIPRange

        mock_adapter = MockAdapter()
        mock_obj = MagicMock()
        mock_orm_iprange.objects.get_or_create.return_value = (mock_obj, True)
        mock_status.return_value = MagicMock()
        mock_tag = MagicMock()
        mock_get_tag.return_value = mock_tag

        NautobotIPRange.create(
            adapter=mock_adapter,
            ids={"start_address": "192.168.1.1", "end_address": "192.168.1.100"},
            attrs={"description": "Test range"},
        )

        mock_orm_iprange.objects.get_or_create.assert_called_once()
        call_args = mock_orm_iprange.objects.get_or_create.call_args
        self.assertEqual(call_args.kwargs["start_address"], "192.168.1.1")
        self.assertEqual(call_args.kwargs["end_address"], "192.168.1.100")

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmIPRange")
    def test_delete_schedules_for_cleanup(self, mock_orm_iprange):
        """Verify IPRange delete schedules object for cleanup."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotIPRange

        mock_adapter = MockAdapter()
        mock_obj = MagicMock()
        mock_orm_iprange.objects.get.return_value = mock_obj

        iprange = NautobotIPRange(
            start_address="192.168.1.1",
            end_address="192.168.1.100",
            description="Test",
            adapter=mock_adapter,
        )

        iprange.delete()

        self.assertIn(mock_obj, mock_adapter.objects_to_delete["iprange"])


class TestNautobotServiceObject(TestCase):
    """Tests for NautobotServiceObject model CRUD operations."""

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.get_active_status")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmServiceObject")
    def test_create_application_default_placeholder(self, mock_orm_svc, mock_status, mock_get_tag):
        """Verify 'application-default' creates placeholder with Reserved protocol."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotServiceObject

        mock_adapter = MockAdapter()
        mock_obj = MagicMock()
        mock_orm_svc.objects.get_or_create.return_value = (mock_obj, True)
        mock_status.return_value = MagicMock()
        mock_get_tag.return_value = MagicMock()

        NautobotServiceObject.create(
            adapter=mock_adapter,
            ids={"name": "application-default"},
            attrs={},
        )

        call_args = mock_orm_svc.objects.get_or_create.call_args
        defaults = call_args.kwargs["defaults"]
        self.assertEqual(defaults["ip_protocol"], "Reserved")
        self.assertIn("application-default", defaults["description"])
        self.assertEqual(defaults["port"], "0")

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.get_active_status")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmServiceObject")
    def test_create_normal_service(self, mock_orm_svc, mock_status, mock_get_tag):
        """Verify normal service is created with provided attributes."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotServiceObject

        mock_adapter = MockAdapter()
        mock_obj = MagicMock()
        mock_orm_svc.objects.get_or_create.return_value = (mock_obj, True)
        mock_status.return_value = MagicMock()
        mock_get_tag.return_value = MagicMock()

        NautobotServiceObject.create(
            adapter=mock_adapter,
            ids={"name": "https"},
            attrs={"description": "HTTPS service", "port": "443", "ip_protocol": "TCP"},
        )

        call_args = mock_orm_svc.objects.get_or_create.call_args
        defaults = call_args.kwargs["defaults"]
        self.assertEqual(defaults["port"], "443")
        self.assertEqual(defaults["ip_protocol"], "TCP")

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmServiceObject")
    def test_update_multiple_fields(self, mock_orm_svc):
        """Verify ServiceObject update handles multiple fields."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotServiceObject

        mock_adapter = MockAdapter()
        mock_obj = MagicMock()
        mock_obj.description = "Old"
        mock_obj.port = "80"
        mock_obj.ip_protocol = "TCP"
        mock_orm_svc.objects.get.return_value = mock_obj

        svc = NautobotServiceObject(name="http", description="Old", port="80", ip_protocol="TCP", adapter=mock_adapter)

        svc.update({"description": "New", "port": "8080"})

        self.assertEqual(mock_obj.description, "New")
        self.assertEqual(mock_obj.port, "8080")
        mock_obj.validated_save.assert_called_once()


class TestNautobotApplicationObject(TestCase):
    """Tests for NautobotApplicationObject model CRUD operations."""

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmApplicationObject")
    def test_create_with_all_fields(self, mock_orm_app, mock_get_tag):
        """Verify ApplicationObject is created with all attributes."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotApplicationObject

        mock_adapter = MockAdapter()
        sample_attrs = get_sample_application_object_attrs()
        mock_obj = MagicMock()
        mock_orm_app.objects.get_or_create.return_value = (mock_obj, True)
        mock_get_tag.return_value = MagicMock()

        NautobotApplicationObject.create(
            adapter=mock_adapter,
            ids={"name": "custom-app"},
            attrs=sample_attrs,
        )


class TestNautobotUserObject(TestCase):
    """Tests for NautobotUserObject model CRUD operations."""

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmUserObject")
    def test_create_uses_username(self, mock_orm_user, mock_get_tag):
        """Verify UserObject create uses username as the key."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotUserObject

        mock_adapter = MockAdapter()
        mock_obj = MagicMock()
        mock_orm_user.objects.filter.return_value.first.return_value = None
        mock_orm_user.objects.get_or_create.return_value = (mock_obj, True)
        mock_get_tag.return_value = MagicMock()

        NautobotUserObject.create(adapter=mock_adapter, ids={"name": "user1"}, attrs={})

        mock_orm_user.objects.get_or_create.assert_called_once_with(username="user1")

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmUserObject")
    def test_delete_schedules_for_cleanup(self, mock_orm_user):
        """Verify UserObject delete schedules object for cleanup."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotUserObject

        mock_adapter = MockAdapter()
        mock_obj = MagicMock()
        mock_orm_user.objects.get.return_value = mock_obj

        user = NautobotUserObject(name="user1", adapter=mock_adapter)
        user.delete()

        self.assertIn(mock_obj, mock_adapter.objects_to_delete["userobject"])

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmApplicationObject")
    def test_create_coerces_none_to_empty_string(self, mock_orm_app, mock_get_tag):
        """Verify None values are coerced to empty strings for NOT NULL fields."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotApplicationObject

        mock_adapter = MockAdapter()
        mock_obj = MagicMock()
        mock_orm_app.objects.get_or_create.return_value = (mock_obj, True)
        mock_get_tag.return_value = MagicMock()

        NautobotApplicationObject.create(
            adapter=mock_adapter,
            ids={"name": "app-with-nulls"},
            attrs={"description": None, "category": None, "subcategory": None, "technology": None},
        )

        call_args = mock_orm_app.objects.get_or_create.call_args
        defaults = call_args.kwargs["defaults"]
        self.assertEqual(defaults["description"], "")
        self.assertEqual(defaults["category"], "")
        self.assertEqual(defaults["subcategory"], "")
        self.assertEqual(defaults["technology"], "")


class TestNautobotZone(TestCase):
    """Tests for NautobotZone model CRUD operations."""

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmZone")
    def test_create_zone(self, mock_orm_zone, mock_get_tag):
        """Verify Zone is created and tagged."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotZone

        mock_adapter = MockAdapter()
        mock_obj = MagicMock()
        mock_orm_zone.objects.get_or_create.return_value = (mock_obj, True)
        mock_tag = MagicMock()
        mock_get_tag.return_value = mock_tag

        NautobotZone.create(
            adapter=mock_adapter,
            ids={"name": "trust"},
            attrs={"description": "Trusted zone"},
        )

        mock_orm_zone.objects.get_or_create.assert_called_once()

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmZone")
    def test_delete_uses_setdefault(self, mock_orm_zone):
        """Verify Zone delete uses setdefault for safety."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotZone

        mock_adapter = MockAdapter()
        # Remove zone key to test setdefault behavior
        mock_adapter.objects_to_delete.pop("zone", None)

        mock_obj = MagicMock()
        mock_orm_zone.objects.get.return_value = mock_obj

        zone = NautobotZone(name="trust", description="Test", adapter=mock_adapter)

        zone.delete()

        self.assertIn("zone", mock_adapter.objects_to_delete)
        self.assertIn(mock_obj, mock_adapter.objects_to_delete["zone"])


class TestNautobotPolicy(TestCase):
    """Tests for NautobotPolicy model CRUD operations."""

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmPolicy")
    def test_create_policy(self, mock_orm_policy, mock_get_tag):
        """Verify Policy is created and tagged."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotPolicy

        mock_adapter = MockAdapter()
        mock_obj = MagicMock()
        mock_orm_policy.objects.get_or_create.return_value = (mock_obj, True)
        mock_tag = MagicMock()
        mock_get_tag.return_value = mock_tag

        NautobotPolicy.create(
            adapter=mock_adapter,
            ids={"name": "SEC-PRE-DFW"},
            attrs={"description": "Security pre-rules"},
        )

        mock_orm_policy.objects.get_or_create.assert_called_once()

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmPolicy")
    def test_delete_schedules_for_cleanup(self, mock_orm_policy):
        """Verify Policy delete schedules for cleanup."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotPolicy

        mock_adapter = MockAdapter()
        mock_obj = MagicMock()
        mock_orm_policy.objects.get.return_value = mock_obj

        policy = NautobotPolicy(name="test-policy", description="Test", adapter=mock_adapter)

        policy.delete()

        self.assertIn(mock_obj, mock_adapter.objects_to_delete["policy"])


class TestNautobotPolicyRule(TestCase):
    """Tests for NautobotPolicyRule model CRUD operations."""

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.get_active_status")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmZone")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmPolicy")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmPolicyRule")
    def test_create_returns_none_when_parent_missing(
        self, mock_orm_rule, mock_orm_policy, mock_orm_zone, mock_status, mock_get_tag
    ):
        """Verify create returns None when parent Policy doesn't exist."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotPolicyRule

        mock_adapter = MockAdapter()
        mock_orm_policy.DoesNotExist = Exception
        mock_orm_policy.objects.get.side_effect = mock_orm_policy.DoesNotExist
        mock_status.return_value = MagicMock()
        mock_get_tag.return_value = MagicMock()

        result = NautobotPolicyRule.create(
            adapter=mock_adapter,
            ids={"policy_name": "nonexistent", "index": 1},
            attrs={"name": "rule1", "action": "allow"},
        )

        self.assertIsNone(result)
        mock_adapter.job.logger.warning.assert_called()

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.get_active_status")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmZone")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmPolicy")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmPolicyRule")
    def test_create_warns_when_action_missing(
        self, mock_orm_rule, mock_orm_policy, mock_orm_zone, mock_status, mock_get_tag
    ):
        """Verify warning is logged when action is not provided."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotPolicyRule

        mock_adapter = MockAdapter()
        mock_parent = MagicMock()
        mock_parent.policy_rules.filter.return_value.first.return_value = None
        mock_orm_policy.objects.get.return_value = mock_parent

        mock_rule = MagicMock()
        mock_orm_rule.objects.create.return_value = mock_rule
        mock_status.return_value = MagicMock()
        mock_get_tag.return_value = MagicMock()

        NautobotPolicyRule.create(
            adapter=mock_adapter,
            ids={"policy_name": "test-policy", "index": 1},
            attrs={"name": "rule1"},  # No action
        )

        # Check that warning was logged
        mock_adapter.job.logger.warning.assert_called()

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmPolicy")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmPolicyRule")
    def test_delete_looks_up_via_parent_policy(self, mock_orm_rule, mock_orm_policy):
        """Verify delete looks up rule via parent policy first."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotPolicyRule

        mock_adapter = MockAdapter()
        mock_parent = MagicMock()
        mock_rule = MagicMock()
        mock_parent.policy_rules.filter.return_value.first.return_value = mock_rule
        mock_orm_policy.objects.get.return_value = mock_parent

        rule = NautobotPolicyRule(policy_name="test-policy", index=1, name="rule1", adapter=mock_adapter)

        rule.delete()

        mock_parent.policy_rules.filter.assert_called_with(index=1)
        self.assertIn(mock_rule, mock_adapter.objects_to_delete["policyrule"])

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmZone")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmPolicy")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmPolicyRule")
    def test_update_handles_any_zone(self, mock_orm_rule, mock_orm_policy, mock_orm_zone):
        """Verify update clears zone when set to 'any'."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotPolicyRule

        mock_adapter = MockAdapter()
        mock_parent = MagicMock()
        mock_rule = MagicMock()
        mock_rule.source_zone = MagicMock()  # Has a zone
        mock_parent.policy_rules.filter.return_value.first.return_value = mock_rule
        mock_orm_policy.objects.get.return_value = mock_parent

        rule = NautobotPolicyRule(policy_name="test-policy", index=1, name="rule1", adapter=mock_adapter)

        rule.update({"source_zone": "any"})

        self.assertIsNone(mock_rule.source_zone)


class TestNautobotNATPolicy(TestCase):
    """Tests for NautobotNATPolicy model CRUD operations."""

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmNATPolicy")
    def test_create_nat_policy(self, mock_orm_nat, mock_get_tag):
        """Verify NATPolicy is created and tagged."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotNATPolicy

        mock_adapter = MockAdapter()
        mock_obj = MagicMock()
        mock_orm_nat.objects.get_or_create.return_value = (mock_obj, True)
        mock_tag = MagicMock()
        mock_get_tag.return_value = mock_tag

        NautobotNATPolicy.create(
            adapter=mock_adapter,
            ids={"name": "NAT-PRE-DFW"},
            attrs={"description": "NAT pre-rules"},
        )

        mock_orm_nat.objects.get_or_create.assert_called_once()


class TestNautobotNATPolicyRule(TestCase):
    """Tests for NautobotNATPolicyRule model CRUD operations."""

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.get_active_status")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmNATPolicy")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmNATPolicyRule")
    def test_create_returns_none_when_parent_missing(self, mock_orm_rule, mock_orm_nat, mock_status, mock_get_tag):
        """Verify create returns None when parent NATPolicy doesn't exist."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotNATPolicyRule

        mock_adapter = MockAdapter()
        mock_orm_nat.DoesNotExist = Exception
        mock_orm_nat.objects.get.side_effect = mock_orm_nat.DoesNotExist
        mock_status.return_value = MagicMock()
        mock_get_tag.return_value = MagicMock()

        result = NautobotNATPolicyRule.create(
            adapter=mock_adapter,
            ids={"nat_policy_name": "nonexistent", "index": 1},
            attrs={"name": "nat-rule1"},
        )

        self.assertIsNone(result)
        mock_adapter.job.logger.warning.assert_called()

    @patch("nautobot_ssot_panorama.diffsync.models.nautobot._get_tag")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.get_active_status")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmZone")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmNATPolicy")
    @patch("nautobot_ssot_panorama.diffsync.models.nautobot.OrmNATPolicyRule")
    def test_create_auto_creates_missing_zone(
        self, mock_orm_rule, mock_orm_nat, mock_orm_zone, mock_status, mock_get_tag
    ):
        """Verify missing zones are auto-created for NAT rules."""
        from nautobot_ssot_panorama.diffsync.models.nautobot import NautobotNATPolicyRule

        mock_adapter = MockAdapter()
        mock_parent = MagicMock()
        mock_parent.nat_policy_rules.filter.return_value.first.return_value = None
        mock_orm_nat.objects.get.return_value = mock_parent

        mock_rule = MagicMock()
        mock_orm_rule.objects.create.return_value = mock_rule

        mock_orm_zone.DoesNotExist = Exception
        mock_orm_zone.objects.get.side_effect = mock_orm_zone.DoesNotExist
        mock_zone = MagicMock()
        mock_orm_zone.objects.get_or_create.return_value = (mock_zone, True)

        mock_status.return_value = MagicMock()
        mock_get_tag.return_value = MagicMock()

        NautobotNATPolicyRule.create(
            adapter=mock_adapter,
            ids={"nat_policy_name": "test-nat", "index": 1},
            attrs={"name": "nat-rule1", "source_zone": "new-zone"},
        )

        mock_orm_zone.objects.get_or_create.assert_called()
        mock_adapter.job.logger.info.assert_called()
