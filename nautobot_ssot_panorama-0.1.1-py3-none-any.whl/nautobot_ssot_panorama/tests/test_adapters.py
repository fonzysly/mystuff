"""Unit tests for local and remote adapters."""

# pylint: disable=import-outside-toplevel,duplicate-code

from unittest.mock import MagicMock, patch

from django.test import TestCase

from nautobot_ssot_panorama.diffsync.adapters.local import (
    PANORAMA_TAG_NAME,
    PanoramaLocalAdapter,
    _normalize_list,
    _normalize_str,
)


class TestNormalizeStr(TestCase):
    """Tests for _normalize_str helper function."""

    def test_none_returns_empty_string(self):
        """Verify None is converted to empty string."""
        self.assertEqual(_normalize_str(None), "")

    def test_string_stripped(self):
        """Verify whitespace is stripped."""
        self.assertEqual(_normalize_str("  test  "), "test")

    def test_normal_string_unchanged(self):
        """Verify normal string passes through."""
        self.assertEqual(_normalize_str("test"), "test")

    def test_non_string_converted(self):
        """Verify non-strings are converted to string."""
        self.assertEqual(_normalize_str(123), "123")


class TestNormalizeList(TestCase):
    """Tests for _normalize_list helper function."""

    def test_none_returns_empty_list(self):
        """Verify None is converted to empty list."""
        self.assertEqual(_normalize_list(None), [])

    def test_single_value_wrapped(self):
        """Verify single value is wrapped in list."""
        self.assertEqual(_normalize_list("test"), ["test"])

    def test_list_sorted(self):
        """Verify list is sorted."""
        self.assertEqual(_normalize_list(["c", "a", "b"]), ["a", "b", "c"])

    def test_list_elements_stringified(self):
        """Verify list elements are converted to strings."""
        self.assertEqual(_normalize_list([1, 2, 3]), ["1", "2", "3"])


class TestPanoramaLocalAdapterInit(TestCase):
    """Tests for PanoramaLocalAdapter initialization."""

    def test_initializes_with_job(self):
        """Verify adapter initializes with job parameter."""
        mock_job = MagicMock()
        adapter = PanoramaLocalAdapter(job=mock_job)
        self.assertEqual(adapter.job, mock_job)

    def test_initializes_without_job(self):
        """Verify adapter initializes without job parameter."""
        adapter = PanoramaLocalAdapter()
        self.assertIsNone(adapter.job)

    def test_initializes_objects_to_delete(self):
        """Verify objects_to_delete is initialized with all keys."""
        adapter = PanoramaLocalAdapter()
        expected_keys = {
            "fqdn",
            "iprange",
            "addressobject",
            "serviceobject",
            "applicationobject",
            "userobject",
            "zone",
            "addressobjectgroup",
            "serviceobjectgroup",
            "applicationobjectgroup",
            "policy",
            "policyrule",
            "natpolicy",
            "natpolicyrule",
        }
        self.assertEqual(set(adapter.objects_to_delete.keys()), expected_keys)

    def test_initializes_objects_pending_tags(self):
        """Verify objects_pending_tags is initialized."""
        adapter = PanoramaLocalAdapter()
        expected_keys = {
            "addressobject",
            "serviceobject",
            "applicationobject",
            "userobject",
            "zone",
            "addressobjectgroup",
            "serviceobjectgroup",
            "applicationobjectgroup",
        }
        self.assertEqual(set(adapter.objects_pending_tags.keys()), expected_keys)

    def test_sync_parameter_stored(self):
        """Verify sync parameter is stored."""
        mock_sync = MagicMock()
        adapter = PanoramaLocalAdapter(sync=mock_sync)
        self.assertEqual(adapter.sync, mock_sync)

    def test_sync_popped_from_kwargs(self):
        """Verify sync is popped from kwargs to avoid passing to base class."""
        # This should not raise - sync is removed before passing to base
        adapter = PanoramaLocalAdapter(sync=MagicMock())
        self.assertIsNotNone(adapter)


class TestPanoramaLocalAdapterTopLevel(TestCase):
    """Tests for PanoramaLocalAdapter top_level configuration."""

    def test_top_level_contains_all_object_types(self):
        """Verify top_level contains all expected object types."""
        expected = [
            "fqdn",
            "iprange",
            "addressobject",
            "serviceobject",
            "applicationobject",
            "userobject",
            "zone",
            "addressobjectgroup",
            "serviceobjectgroup",
            "applicationobjectgroup",
            "policy",
            "natpolicy",
        ]
        self.assertEqual(PanoramaLocalAdapter.top_level, expected)

    def test_base_objects_before_groups(self):
        """Verify base objects come before groups in top_level."""
        top_level = PanoramaLocalAdapter.top_level
        # All object types should come before group types
        object_indices = [
            top_level.index("addressobject"),
            top_level.index("serviceobject"),
            top_level.index("applicationobject"),
            top_level.index("userobject"),
        ]
        group_indices = [
            top_level.index("addressobjectgroup"),
            top_level.index("serviceobjectgroup"),
            top_level.index("applicationobjectgroup"),
        ]
        self.assertTrue(max(object_indices) < min(group_indices))


class TestPanoramaLocalAdapterLoad(TestCase):
    """Tests for PanoramaLocalAdapter load method."""

    @patch.object(PanoramaLocalAdapter, "load_fqdns")
    @patch.object(PanoramaLocalAdapter, "load_ipranges")
    @patch.object(PanoramaLocalAdapter, "load_address_objects")
    @patch.object(PanoramaLocalAdapter, "load_service_objects")
    @patch.object(PanoramaLocalAdapter, "load_application_objects")
    @patch.object(PanoramaLocalAdapter, "load_user_objects")
    @patch.object(PanoramaLocalAdapter, "load_zones")
    @patch.object(PanoramaLocalAdapter, "load_address_object_groups")
    @patch.object(PanoramaLocalAdapter, "load_service_object_groups")
    @patch.object(PanoramaLocalAdapter, "load_application_object_groups")
    @patch.object(PanoramaLocalAdapter, "load_policies")
    @patch.object(PanoramaLocalAdapter, "load_nat_policies")
    @patch("nautobot_ssot_panorama.diffsync.adapters.local.Tag")
    def test_load_calls_all_loaders(self, mock_tag, *mock_loaders):
        """Verify load calls all individual loader methods."""
        mock_tag.objects.filter.return_value.first.return_value = MagicMock()
        adapter = PanoramaLocalAdapter()
        adapter.load()

        # All loaders should have been called
        for mock_loader in mock_loaders:
            mock_loader.assert_called_once()

    @patch.object(PanoramaLocalAdapter, "load_fqdns")
    @patch.object(PanoramaLocalAdapter, "load_ipranges")
    @patch.object(PanoramaLocalAdapter, "load_address_objects")
    @patch.object(PanoramaLocalAdapter, "load_service_objects")
    @patch.object(PanoramaLocalAdapter, "load_application_objects")
    @patch.object(PanoramaLocalAdapter, "load_user_objects")
    @patch.object(PanoramaLocalAdapter, "load_zones")
    @patch.object(PanoramaLocalAdapter, "load_address_object_groups")
    @patch.object(PanoramaLocalAdapter, "load_service_object_groups")
    @patch.object(PanoramaLocalAdapter, "load_application_object_groups")
    @patch.object(PanoramaLocalAdapter, "load_policies")
    @patch.object(PanoramaLocalAdapter, "load_nat_policies")
    @patch("nautobot_ssot_panorama.diffsync.adapters.local.Tag")
    def test_load_uses_panorama_tag(self, mock_tag, *_mock_loaders):
        """Verify load filters by Panorama SSoT tag."""
        mock_tag_instance = MagicMock()
        mock_tag.objects.filter.return_value.first.return_value = mock_tag_instance
        adapter = PanoramaLocalAdapter()
        adapter.load()

        mock_tag.objects.filter.assert_called_with(name=PANORAMA_TAG_NAME)

    @patch.object(PanoramaLocalAdapter, "load_fqdns")
    @patch.object(PanoramaLocalAdapter, "load_ipranges")
    @patch.object(PanoramaLocalAdapter, "load_address_objects")
    @patch.object(PanoramaLocalAdapter, "load_service_objects")
    @patch.object(PanoramaLocalAdapter, "load_application_objects")
    @patch.object(PanoramaLocalAdapter, "load_user_objects")
    @patch.object(PanoramaLocalAdapter, "load_zones")
    @patch.object(PanoramaLocalAdapter, "load_address_object_groups")
    @patch.object(PanoramaLocalAdapter, "load_service_object_groups")
    @patch.object(PanoramaLocalAdapter, "load_application_object_groups")
    @patch.object(PanoramaLocalAdapter, "load_policies")
    @patch.object(PanoramaLocalAdapter, "load_nat_policies")
    @patch("nautobot_ssot_panorama.diffsync.adapters.local.Tag")
    def test_load_logs_success_with_job(self, mock_tag, *_mock_loaders):
        """Verify load logs success when job is present."""
        mock_tag.objects.filter.return_value.first.return_value = MagicMock()
        mock_job = MagicMock()
        adapter = PanoramaLocalAdapter(job=mock_job)
        adapter.load()

        mock_job.logger.success.assert_called()


class TestPanoramaLocalAdapterApplyDeferredTags(TestCase):
    """Tests for apply_deferred_tags method."""

    @patch("nautobot_ssot_panorama.diffsync.adapters.local.Tag")
    def test_applies_tags_to_pending_objects(self, mock_tag):
        """Verify tags are applied to all pending objects."""
        mock_tag_instance = MagicMock()
        mock_tag.objects.get_or_create.return_value = (mock_tag_instance, False)

        adapter = PanoramaLocalAdapter()
        mock_obj = MagicMock()
        adapter.objects_pending_tags["addressobject"].append(mock_obj)

        adapter.apply_deferred_tags()

        mock_obj.tags.add.assert_called_with(mock_tag_instance)

    @patch("nautobot_ssot_panorama.diffsync.adapters.local.Tag")
    def test_clears_pending_tags_after_apply(self, mock_tag):
        """Verify pending tags lists are cleared after applying."""
        mock_tag.objects.get_or_create.return_value = (MagicMock(), False)

        adapter = PanoramaLocalAdapter()
        adapter.objects_pending_tags["addressobject"].append(MagicMock())

        adapter.apply_deferred_tags()

        # List should be empty after applying
        self.assertEqual(len(adapter.objects_pending_tags["addressobject"]), 0)


class TestPanoramaLocalAdapterProcessDeletions(TestCase):
    """Tests for process_deletions method."""

    def test_deletes_objects_in_reverse_dependency_order(self):
        """Verify objects are deleted in correct order."""
        adapter = PanoramaLocalAdapter()

        # Add mock objects to delete
        mock_policy = MagicMock()
        mock_addressobject = MagicMock()
        mock_fqdn = MagicMock()

        adapter.objects_to_delete["policy"].append(mock_policy)
        adapter.objects_to_delete["addressobject"].append(mock_addressobject)
        adapter.objects_to_delete["fqdn"].append(mock_fqdn)

        adapter.process_deletions()

        # All objects should have been deleted
        mock_policy.delete.assert_called_once()
        mock_addressobject.delete.assert_called_once()
        mock_fqdn.delete.assert_called_once()

    def test_clears_deletion_lists_after_processing(self):
        """Verify deletion lists are cleared after processing."""
        adapter = PanoramaLocalAdapter()
        adapter.objects_to_delete["addressobject"].append(MagicMock())

        adapter.process_deletions()

        self.assertEqual(len(adapter.objects_to_delete["addressobject"]), 0)

    def test_logs_deletion_count_with_job(self):
        """Verify deletion count is logged when job present."""
        mock_job = MagicMock()
        adapter = PanoramaLocalAdapter(job=mock_job)
        adapter.objects_to_delete["addressobject"].append(MagicMock())

        adapter.process_deletions()

        mock_job.logger.info.assert_called()

    def test_handles_deletion_errors_gracefully(self):
        """Verify deletion errors don't stop processing."""
        mock_job = MagicMock()
        adapter = PanoramaLocalAdapter(job=mock_job)

        mock_obj_bad = MagicMock()
        mock_obj_bad.delete.side_effect = Exception("Delete error")
        mock_obj_good = MagicMock()

        adapter.objects_to_delete["addressobject"].extend([mock_obj_bad, mock_obj_good])

        # Should not raise
        adapter.process_deletions()

        # Good object should still be deleted
        mock_obj_good.delete.assert_called_once()


class TestRemoteAdapterNormalizeFunctions(TestCase):
    """Tests for remote adapter normalize functions."""

    def test_normalize_str_handles_any(self):
        """Verify 'any' keyword is converted to empty string."""
        from nautobot_ssot_panorama.diffsync.adapters.remote import _normalize_str as remote_normalize_str

        self.assertEqual(remote_normalize_str("any"), "")
        self.assertEqual(remote_normalize_str("ANY"), "")
        self.assertEqual(remote_normalize_str("Any"), "")

    def test_normalize_list_filters_any(self):
        """Verify 'any' keywords are filtered from lists."""
        from nautobot_ssot_panorama.diffsync.adapters.remote import _normalize_list as remote_normalize_list

        result = remote_normalize_list(["test", "any", "value"])
        self.assertEqual(result, ["test", "value"])

    def test_normalize_list_sorts_result(self):
        """Verify result is sorted."""
        from nautobot_ssot_panorama.diffsync.adapters.remote import _normalize_list as remote_normalize_list

        result = remote_normalize_list(["z", "a", "m"])
        self.assertEqual(result, ["a", "m", "z"])
