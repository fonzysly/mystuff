"""Test fixtures and helpers for Panorama SSoT tests."""

# pylint: disable=duplicate-code

from unittest.mock import MagicMock


def create_mock_adapter():
    """Create a mock adapter with job logger and objects_to_delete."""
    adapter = MagicMock()
    adapter.job = MagicMock()
    adapter.job.logger = MagicMock()
    adapter.objects_to_delete = {
        "fqdn": [],
        "iprange": [],
        "addressobject": [],
        "serviceobject": [],
        "applicationobject": [],
        "zone": [],
        "addressobjectgroup": [],
        "serviceobjectgroup": [],
        "applicationobjectgroup": [],
        "policy": [],
        "policyrule": [],
        "natpolicy": [],
        "natpolicyrule": [],
    }
    adapter.objects_pending_tags = {
        "addressobject": [],
        "serviceobject": [],
        "applicationobject": [],
    }
    return adapter


def get_sample_address_object_attrs():
    """Sample attributes for AddressObject creation."""
    return {
        "description": "Test address object",
        "fqdn": None,
        "ip_range": None,
        "ip_address": "192.168.1.100/32",
        "prefix": None,
    }


def get_sample_service_object_attrs():
    """Sample attributes for ServiceObject creation."""
    return {
        "description": "Test service object",
        "port": "443",
        "ip_protocol": "TCP",
    }


def get_sample_application_object_attrs():
    """Sample attributes for ApplicationObject creation."""
    return {
        "description": "Test application",
        "category": "business-systems",
        "subcategory": "database",
        "technology": "client-server",
        "risk": 3,
    }


def get_sample_policy_rule_attrs():
    """Sample attributes for PolicyRule creation."""
    return {
        "name": "Allow-Web-Traffic",
        "action": "allow",
        "description": "Allow web traffic to DMZ",
        "source_addresses": ["web-servers"],
        "source_address_groups": [],
        "source_zone": "trust",
        "source_services": [],
        "source_service_groups": [],
        "destination_addresses": ["dmz-servers"],
        "destination_address_groups": [],
        "destination_zone": "dmz",
        "destination_services": ["http", "https"],
        "destination_service_groups": [],
        "applications": ["web-browsing"],
        "application_groups": [],
    }


def get_sample_nat_policy_rule_attrs():
    """Sample attributes for NATPolicyRule creation."""
    return {
        "name": "NAT-Outbound",
        "description": "Outbound NAT rule",
        "source_zone": "trust",
        "destination_zone": "untrust",
        "original_source_addresses": ["internal-net"],
        "original_source_address_groups": [],
        "original_destination_addresses": ["any"],
        "original_destination_address_groups": [],
        "translated_source_addresses": ["nat-pool"],
        "translated_source_address_groups": [],
        "translated_destination_addresses": [],
        "translated_destination_address_groups": [],
    }
