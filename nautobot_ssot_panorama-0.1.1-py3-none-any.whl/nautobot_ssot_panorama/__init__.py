"""App declaration for nautobot_ssot_panorama."""

# Metadata is inherited from Nautobot. If not including Nautobot in the environment, this should be added
from importlib import metadata

from nautobot.apps import NautobotAppConfig, nautobot_database_ready

__version__ = metadata.version(__name__)


class NautobotSsotPanoramaConfig(NautobotAppConfig):
    """App configuration for the nautobot_ssot_panorama app."""

    name = "nautobot_ssot_panorama"
    verbose_name = "Nautobot Ssot Panorama"
    version = __version__
    author = "Eric Fetty"
    description = "Nautobot Ssot Panorama."
    base_url = "ssot-panorama"
    required_settings = []
    default_settings = {}
    docs_view_name = "plugins:nautobot_ssot_panorama:docs"
    searchable_models = ["panoramapolicy"]

    def ready(self):
        """Callback invoked after the app is loaded.

        Connects signal handlers to create self-referential Relationships
        for Firewall Models group objects (e.g., AddressObjectGroup to AddressObjectGroup)
        to support nested groups from Panorama.
        """
        super().ready()

        # Import here to avoid circular imports
        from nautobot_ssot_panorama.signals import (  # pylint: disable=import-outside-toplevel # isort: skip
            create_group_self_relationships,
        )

        # Connect signal handler with sender=self to ensure it only runs once per app
        nautobot_database_ready.connect(create_group_self_relationships, sender=self)


config = NautobotSsotPanoramaConfig  # pylint:disable=invalid-name
