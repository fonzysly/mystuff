"""Custom Diff object for Panorama SSoT integration."""

from diffsync.diff import Diff
from diffsync.enum import DiffSyncActions


class CustomOrderingDiff(Diff):
    """Customized Diff object enforcing explicit creation ordering.

    Rationale:
        AddressObjects may reference FQDN or IPRange objects. The default DiffSync
        ordering could interleave create operations in a non-deterministic way if
        dictionary key ordering changes or if future model types are added. We
        explicitly order creation operations so that foundational objects are
        created before dependents, while still deferring deletions until the end
        (and reversing their order to mirror creation dependencies).
    """

    # Explicit ordered list of model group names for CREATE / UPDATE actions.
    # NOTE: Groups not listed will be appended after these in natural order.
    ORDERED_CREATE_GROUPS = [
        "fqdn",  # base leaf
        "iprange",  # base leaf
        "addressobject",  # depends on fqdn/iprange potentially
        "serviceobject",
        "applicationobject",
        "zone",
        # groups (can reference earlier objects)
        "addressobjectgroup",
        "serviceobjectgroup",
        "applicationobjectgroup",
        # policies last (contain rule children referencing prior objects)
        "policy",
        "natpolicy",
    ]

    def get_children(self):  # noqa: D401
        """Yield child diff elements in dependency-safe order.

        Algorithm:
            1. Partition children into CREATE/UPDATE vs DELETE lists per group.
            2. Yield CREATE/UPDATE in ORDERED_CREATE_GROUPS sequence first.
            3. Yield any remaining groups' CREATE/UPDATE not explicitly ordered.
            4. Yield DELETE actions in exact reverse of ORDERED_CREATE_GROUPS (so
               dependents are deleted before foundations), followed by remaining
               deletions reversed.
        """
        create_children_by_group = {}
        delete_children_by_group = {}
        for group in self.groups():
            for child in self.children[group].values():
                if child.action == DiffSyncActions.DELETE:
                    delete_children_by_group.setdefault(group, []).append(child)
                else:  # CREATE or UPDATE
                    create_children_by_group.setdefault(group, []).append(child)

        # 1 & 2: ordered creation
        for group in self.ORDERED_CREATE_GROUPS:
            yield from create_children_by_group.pop(group, [])

        # 3: any remaining groups (not predefined) in natural insertion order
        for group, children in create_children_by_group.items():
            yield from children

        # 4: deletions reversed based on explicit ordering then remaining
        ordered_deletions = []
        for group in self.ORDERED_CREATE_GROUPS:
            ordered_deletions.extend(delete_children_by_group.pop(group, []))
        # Remaining deletions (groups not explicitly ordered)
        for children in delete_children_by_group.values():
            ordered_deletions.extend(children)
        # Reverse to delete dependents before foundations
        yield from reversed(ordered_deletions)
