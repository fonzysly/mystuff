"""API views for nautobot_ssot_panorama."""

from nautobot.apps.api import NautobotModelViewSet

from nautobot_ssot_panorama import filters, models
from nautobot_ssot_panorama.api import serializers


class PanoramaPolicyViewSet(NautobotModelViewSet):  # pylint: disable=too-many-ancestors
    """PanoramaPolicy viewset."""

    queryset = models.PanoramaPolicy.objects.all()
    serializer_class = serializers.PanoramaPolicySerializer
    filterset_class = filters.PanoramaPolicyFilterSet

    # Option for modifying the default HTTP methods:
    # http_method_names = ["get", "post", "put", "patch", "delete", "head", "options", "trace"]
