"""Django API urlpatterns declaration for nautobot_ssot_panorama app."""

from nautobot.apps.api import OrderedDefaultRouter

from nautobot_ssot_panorama.api import views

router = OrderedDefaultRouter()
# add the name of your api endpoint, usually hyphenated model name in plural, e.g. "my-model-classes"
router.register("panorama-policys", views.PanoramaPolicyViewSet)

app_name = "nautobot_ssot_panorama-api"
urlpatterns = router.urls
