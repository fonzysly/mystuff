"""Utility functions for working with Nautobot."""

import ipaddress

from nautobot.extras.models import Status
from nautobot.ipam.models import Prefix


def get_active_status() -> Status:
    """Get the 'Active' status object for a given model class.

    Parameters
    ----------
    model_class : Type[Model]
        The Nautobot model class to retrieve the status for.

    Returns
    -------
    Status
        The 'Active' status object for the specified model class.
    """
    return Status.objects.get(name="Active")


def find_best_cidr(address: str) -> int:
    """Find the best matching CIDR prefix length for a given IP address.

    Iterates through CIDR prefix lengths from /32 to /2 to find the most
    specific prefix that exists in Nautobot's IPAM.

    Parameters
    ----------
    address : str
        The IP address to find the best CIDR match for.

    Returns
    -------
    int
        The prefix length of the best matching CIDR, or 32 if no match found.
    """
    for cidr in range(32, 1, -1):
        ipnetwork = ipaddress.ip_interface(f"{address}/{cidr}")
        prefix = Prefix.objects.filter(prefix=str(ipnetwork.network), namespace__name="Global")

        if prefix:
            return prefix[0].prefix_length
    return 32


def get_parent_prefix(address: str) -> Prefix:
    """Get the parent prefix for a given IP address."""
    if "/32" in address:
        address = address.replace("/32", "")
    if "/" not in address:
        address += f"/{find_best_cidr(address=address)}"
    try:
        prefix = Prefix.objects.get(
            prefix=ipaddress.ip_network(address, strict=False).with_prefixlen,
            namespace__name="Global",
        )
        return prefix
    except Prefix.DoesNotExist:
        return None
