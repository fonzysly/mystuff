"""Panorama SDK client abstraction using `pan-os-python`.

Phase 2 skeleton: minimal implementation for addresses/services behind feature flag.
Mirrors public interface of existing REST-based PanoramaClient so remote adapter can swap seamlessly.
"""

# pylint: disable=too-many-lines,too-many-instance-attributes,too-many-branches,too-many-locals,too-many-statements,broad-exception-caught,import-outside-toplevel,invalid-name,using-constant-test,duplicate-code

from __future__ import annotations

import logging
from dataclasses import dataclass
from ipaddress import ip_network
from typing import Any, Dict, List, Optional

from panos.device import Vsys
from panos.network import Zone  # type: ignore
from panos.objects import (  # type: ignore
    AddressGroup,
    AddressObject,
    ApplicationGroup,
    ApplicationObject,
    ServiceGroup,
    ServiceObject,
)
from panos.panorama import (  # type: ignore
    DeviceGroup,
    Panorama,
)
from panos.policies import (  # type: ignore
    NatRule,
    PostRulebase,
    PreRulebase,
    SecurityRule,
)

try:  # Optional Nautobot imports for secrets retrieval; keep optional to avoid hard failure in pure SDK contexts
    from nautobot.extras.choices import (  # type: ignore
        SecretsGroupAccessTypeChoices,
        SecretsGroupSecretTypeChoices,
    )
except Exception:  # pragma: no cover
    SecretsGroupAccessTypeChoices = None  # type: ignore
    SecretsGroupSecretTypeChoices = None  # type: ignore


@dataclass
class PanoramaSdkClientConfig:
    """Configuration dataclass for SDK client.

    Attributes:
        base_url: Base URL or hostname for Panorama (schema optional).
        api_key: Pre-generated API key (if provided, username/password ignored).
        username: Username for login when api_key not provided.
        password: Password for login when api_key not provided.
        verify_ssl: Placeholder for future SSL verification toggling.
        device_groups: Optional list of device groups to scope queries.
        templates: Optional list of templates (future use).
        template_stacks: Optional list of template stacks (future use).
        vsys_list: Optional list of vsys identifiers (future use).
    """

    base_url: str
    api_key: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None
    verify_ssl: bool = True  # retained for parity (SDK may rely on requests internally)
    device_groups: Optional[List[str]] = None
    templates: Optional[List[str]] = None
    template_stacks: Optional[List[str]] = None
    vsys_list: Optional[List[str]] = None


class PanoramaSdkClient:
    """Thin wrapper around pan-os-python Panorama object.

    Public methods intentionally mirror PanoramaClient (REST variant):
        get_addresses(), get_services(), get_address_groups(), get_service_groups(),
        get_applications(), get_application_groups(), get_zones(),
        get_security_policies(device_group, direction), get_nat_policies(device_group, direction),
        get_device_groups().

    Phase 2: only get_addresses() and get_services() implemented. Others return empty lists pending Phase 3.
    """

    def __init__(
        self, config: PanoramaSdkClientConfig, logger: Optional[logging.Logger] = None, job: Optional[Any] = None
    ):
        """Initialize SDK client.

        Args:
            config: `PanoramaSdkClientConfig` instance with connection parameters.
            logger: Optional logger; defaults to module logger if None.
            job: Optional Nautobot Job instance for debug flag introspection.
        """
        self.config = config
        self.logger = logger or logging.getLogger(__name__)
        self.job = job
        self._connected = False
        self._panorama: Any = None  # Panorama instance when connected
        # Caches to avoid repeated refreshes in each getter
        self._device_group_cache: Optional[List[Any]] = None
        self._template_cache: Optional[List[Any]] = None
        self._template_stack_cache: Optional[List[Any]] = None
        # Device group parent hierarchy map (populated by _get_device_groups)
        self._device_group_parent_map: Dict[str, str] = {}  # child_name -> parent_name
        # Object family caches (populated on first retrieval)
        self._addresses_cache: Optional[List[Dict[str, Any]]] = None
        self._services_cache: Optional[List[Dict[str, Any]]] = None
        self._address_groups_cache: Optional[List[Dict[str, Any]]] = None
        self._service_groups_cache: Optional[List[Dict[str, Any]]] = None
        self._applications_cache: Optional[List[Dict[str, Any]]] = None
        self._application_groups_cache: Optional[List[Dict[str, Any]]] = None
        self._zones_cache: Optional[List[Dict[str, Any]]] = None
        self._security_policy_cache: Dict[tuple, List[Dict[str, Any]]] = {}
        self._nat_policy_cache: Dict[tuple, List[Dict[str, Any]]] = {}
        # Predefined refresh guards
        self._predefined_services_loaded = False
        self._predefined_applications_loaded = False

    # Identifier Note: With multi-scope retrieval (shared + device-group + template),
    # object names are not globally unique. Downstream DiffSync/Nautobot models should
    # consider composite identifiers (name + device_group or name + template) to avoid
    # accidental merges. This client preserves original names and adds scope keys so
    # adapter layer can evolve identifiers without further SDK changes.

    # ---- Internal helpers ----
    def _debug(self, msg: str, *args):  # pragma: no cover - thin wrapper
        if self.job and not getattr(self.job, "debug", False):
            return
        self.logger.debug(msg, *args)

    def connect(self):
        """Establish SDK connection (login) without global refresh.

        We intentionally avoid `pano.refreshall()` (expensive) and instead call
        `Class.refreshall(pano)` for each object family as needed.
        """
        if self._connected:
            return True
        if Panorama is None:
            self.logger.warning("pan-os-python library unavailable; SDK client inactive.")
            return False
        host = self.config.base_url.replace("https://", "").replace("http://", "").split("/")[0]
        try:
            if self.config.api_key:
                # API key authentication path; username/password ignored.
                pano = Panorama(host, api_key=self.config.api_key)
            else:
                if not (self.config.username and self.config.password):
                    self.logger.warning("Missing credentials for Panorama SDK login.")
                    return False
                pano = Panorama(host, self.config.username, self.config.password)
            # Cache system info (version) to allow SDK to tailor subsequent calls.
            try:
                pano.refresh_system_info()
            except Exception as exc:  # pragma: no cover - non-critical
                self.logger.debug("System info refresh failed (non-fatal): %s", exc)
            self._panorama = pano
            self._connected = True
            self._debug("SDK login successful to %s", host)
            return True
        except Exception as exc:  # pragma: no cover - broad due to vendor exceptions
            self.logger.warning("SDK login failed: %s", exc)
            return False

    # ---- Public interface (Phase 2/3 expanding) ----
    def get_addresses(self) -> List[Dict[str, Any]]:  # pragma: no cover - thin wrapper
        """Return list of address objects across shared and device-group scopes.

        Shared objects have device_group=None; device-group scoped objects include device_group key.
        For device groups, includes inherited objects from parent device groups.
        """
        if self._addresses_cache is not None:
            return self._addresses_cache
        if not self.connect() or not AddressObject:
            self._addresses_cache = []
            return self._addresses_cache
        results: List[Dict[str, Any]] = []
        shared_count = 0
        dg_counts: Dict[str, int] = {}
        seen_names: Dict[str, str] = {}  # Track to avoid duplicates (child overrides parent)

        # Shared scope
        try:
            for addr in AddressObject.refreshall(self._panorama) or []:  # type: ignore[arg-type]
                addr_name = getattr(addr, "name", None)
                if addr_name and addr_name not in seen_names:
                    results.append(self._normalize_address(addr, None))
                    seen_names[addr_name] = "shared"
                    shared_count += 1
        except Exception as exc:  # pragma: no cover
            self.logger.warning("Shared AddressObject.refreshall failed: %s", exc)

        # Device-group scope with parent inheritance
        for dg in self._get_device_groups():
            dg_name = getattr(dg, "name", "?")
            count_before = len(results)

            # Get hierarchy (child first, then parents)
            dg_hierarchy = self._get_device_group_with_parents(dg)

            for hierarchy_dg in dg_hierarchy:
                hierarchy_dg_name = getattr(hierarchy_dg, "name", "?")
                try:
                    for addr in AddressObject.refreshall(hierarchy_dg) or []:  # type: ignore[arg-type]
                        addr_name = getattr(addr, "name", None)
                        if addr_name and addr_name not in seen_names:
                            results.append(self._normalize_address(addr, dg_name if dg_name != "?" else None))
                            seen_names[addr_name] = dg_name
                except Exception as exc:  # pragma: no cover
                    self.logger.debug(
                        "AddressObject.refreshall failed for device-group %s (in hierarchy of %s): %s",
                        hierarchy_dg_name,
                        dg_name,
                        exc,
                    )

            dg_counts[dg_name] = len(results) - count_before

        self._addresses_cache = results
        self._debug(
            "Addresses loaded: shared=%s device-groups=%s total=%s",
            shared_count,
            sum(dg_counts.values()),
            len(self._addresses_cache),
        )
        return self._addresses_cache

    def _normalize_address(self, addr: Any, device_group: Optional[str]) -> Dict[str, Any]:  # pragma: no cover
        record: Dict[str, Any] = {
            "name": addr.name,
            "description": addr.description or "",
            "device_group": device_group,
        }
        # Determine address representation
        # IMPORTANT: Match Nautobot Firewall Models behavior:
        #   - Host addresses (/32 or bare IPs) -> ip_address field
        #   - Network subnets (non-/32) -> prefix field
        # This ensures diff-sync comparisons match what Nautobot will store.
        addr_type = getattr(addr, "type", None)
        val = getattr(addr, "value", None)
        # PAN-OS may omit 'type' for certain legacy objects; attempt inference.
        if addr_type == "fqdn":
            record["fqdn"] = val
        elif addr_type == "ip-range":
            record["ip_range"] = val
        elif addr_type == "ip-address":  # explicit single host type
            record["ip_address"] = val
        elif addr_type == "ip-netmask":
            # ip-netmask: /32 -> ip_address, otherwise -> prefix (normalized to network address)
            if isinstance(val, str):
                if "/" not in val:
                    # Bare IP without mask -> treat as host -> ip_address
                    record["ip_address"] = f"{val}/32"
                elif val.endswith("/32"):
                    # Explicit /32 -> host address -> ip_address
                    record["ip_address"] = val
                else:
                    # Actual subnet -> prefix (normalize to network address)
                    try:
                        record["prefix"] = ip_network(val, strict=False).with_prefixlen
                    except ValueError:
                        record["prefix"] = val  # Fallback if parsing fails
        elif addr_type == "ip-wildcard":  # Represent wildcard as ip_range for now
            if val:
                record["ip_range"] = val
        else:
            # Fallback inference: if value looks like an IP(/mask) decide representation
            if isinstance(val, str):
                if "/" in val:
                    # CIDR notation: /32 -> ip_address, other -> prefix (normalized)
                    if val.endswith("/32"):
                        record["ip_address"] = val
                    else:
                        try:
                            record["prefix"] = ip_network(val, strict=False).with_prefixlen
                        except ValueError:
                            record["prefix"] = val
                elif val:  # plain IP or FQDN; attempt simple heuristic
                    if any(c.isalpha() for c in val):
                        record["fqdn"] = val
                    else:
                        # Bare IP without mask -> treat as /32 host
                        record["ip_address"] = f"{val}/32"
        # Guarantee exactly one of the allowed keys present; if multiple due to heuristic retain precedence order
        keys = [k for k in ("fqdn", "ip_range", "ip_address", "prefix") if record.get(k)]
        if len(keys) > 1:
            # Retain first precedence fqdn > ip_address > prefix > ip_range (ip_address favored for hosts)
            precedence = {"fqdn": 1, "ip_address": 2, "prefix": 3, "ip_range": 4}
            chosen = sorted(keys, key=lambda k: precedence[k])[0]
            for k in keys:
                if k != chosen:
                    record.pop(k, None)
        return record

    def get_services(self) -> List[Dict[str, Any]]:  # pragma: no cover - thin wrapper
        """Return list of service objects across shared and device-group scopes (with predefined)."""
        if self._services_cache is not None:
            return self._services_cache
        if not self.connect() or not ServiceObject:
            self._services_cache = []
            return self._services_cache
        results: List[Dict[str, Any]] = []
        predefined_count = 0
        # Predefined services: query via XPath since Predefined object doesn't support normal hierarchy
        if not self._predefined_services_loaded:
            try:
                # Query predefined services via XPath API
                xpath = "/config/predefined/service/entry"
                self._debug("Querying predefined services via XPath: %s", xpath)
                response = self._panorama.xapi.get(xpath)
                self._debug("XPath query returned, parsing entries")

                # xapi.get() returns an Element object directly, not a string
                if response is not None:
                    # response is already an ElementTree.Element, find entry elements
                    entries = response.findall(".//entry") if hasattr(response, "findall") else []
                    self._debug("Found %s predefined service entries in XML", len(entries))

                    for entry in entries:
                        name = entry.get("name", "")
                        if not name:
                            continue

                        # Extract protocol and port information
                        protocol_elem = entry.find("protocol")
                        tcp_elem = protocol_elem.find("tcp/port") if protocol_elem is not None else None
                        udp_elem = protocol_elem.find("udp/port") if protocol_elem is not None else None

                        if tcp_elem is not None:
                            protocol = "TCP"
                            port = tcp_elem.text
                        elif udp_elem is not None:
                            protocol = "UDP"
                            port = udp_elem.text
                        else:
                            protocol = "Reserved"
                            port = None

                        description_elem = entry.find("description")
                        description = description_elem.text if description_elem is not None else ""

                        results.append(
                            {
                                "name": name,
                                "description": description or "",
                                "ip_protocol": protocol,
                                "port": port,
                                "device_group": None,
                            }
                        )
                        predefined_count += 1

                self._predefined_services_loaded = True
                self._debug("Loaded %s predefined services via XPath", predefined_count)
            except Exception as exc:
                self._debug("XPath predefined services query failed: %s", exc)
                self._predefined_services_loaded = True  # Mark as attempted to avoid repeated failures

        # Shared scope services
        shared_count = 0
        dg_counts: Dict[str, int] = {}
        seen_names: Dict[str, str] = {}  # Track to avoid duplicates (child overrides parent)
        try:
            for svc in ServiceObject.refreshall(self._panorama) or []:  # type: ignore[arg-type]
                svc_name = getattr(svc, "name", None)
                if svc_name and svc_name not in seen_names:
                    results.append(self._normalize_service(svc, None))
                    seen_names[svc_name] = "shared"
                    shared_count += 1
        except Exception as exc:  # pragma: no cover
            self.logger.warning("Shared ServiceObject.refreshall failed: %s", exc)

        # Device-group scope services with parent inheritance
        for dg in self._get_device_groups():
            dg_name = getattr(dg, "name", "?")
            count_before = len(results)

            # Get hierarchy (child first, then parents)
            dg_hierarchy = self._get_device_group_with_parents(dg)

            for hierarchy_dg in dg_hierarchy:
                hierarchy_dg_name = getattr(hierarchy_dg, "name", "?")
                try:
                    for svc in ServiceObject.refreshall(hierarchy_dg) or []:  # type: ignore[arg-type]
                        svc_name = getattr(svc, "name", None)
                        if svc_name and svc_name not in seen_names:
                            results.append(self._normalize_service(svc, dg_name if dg_name != "?" else None))
                            seen_names[svc_name] = dg_name
                except Exception as exc:  # pragma: no cover
                    self.logger.debug(
                        "ServiceObject.refreshall failed for device-group %s (in hierarchy of %s): %s",
                        hierarchy_dg_name,
                        dg_name,
                        exc,
                    )

            dg_counts[dg_name] = len(results) - count_before
        self._services_cache = results
        self._debug(
            "Services loaded: predefined=%s shared=%s device-groups=%s total=%s",
            predefined_count,
            shared_count,
            sum(dg_counts.values()),
            len(self._services_cache),
        )
        return self._services_cache

    def get_address_groups(self) -> List[Dict[str, Any]]:  # pragma: no cover
        """Return static address groups across shared and device-group scopes.

        For device groups, includes inherited objects from parent device groups.
        Child device group objects override parent objects with same name.
        """
        if self._address_groups_cache is not None:
            return self._address_groups_cache
        if not self.connect() or not AddressGroup:
            self._address_groups_cache = []
            return self._address_groups_cache
        results: List[Dict[str, Any]] = []
        shared_count = 0
        dg_counts: Dict[str, int] = {}
        seen_names: Dict[str, str] = {}  # name -> device_group to track overrides

        # Shared groups
        try:
            for grp in AddressGroup.refreshall(self._panorama) or []:  # type: ignore[arg-type]
                grp_name = getattr(grp, "name", None)
                if grp_name and grp_name not in seen_names:
                    results.append(self._normalize_address_group(grp, None))
                    seen_names[grp_name] = "shared"
                    shared_count += 1
        except Exception as exc:  # pragma: no cover
            self.logger.debug("Shared AddressGroup.refreshall failed: %s", exc)

        # Device-group groups with parent inheritance
        for dg in self._get_device_groups():
            dg_name = getattr(dg, "name", "?")
            count_before = len(results)

            # Get all device groups in hierarchy (child first, then parents)
            dg_hierarchy = self._get_device_group_with_parents(dg)

            # Load from child first (to take precedence), then parents
            for hierarchy_dg in dg_hierarchy:
                hierarchy_dg_name = getattr(hierarchy_dg, "name", "?")
                try:
                    for grp in AddressGroup.refreshall(hierarchy_dg) or []:  # type: ignore[arg-type]
                        grp_name = getattr(grp, "name", None)
                        # Only add if not already seen (child overrides parent)
                        if grp_name and grp_name not in seen_names:
                            # Attribute to the child device group even if inherited from parent
                            results.append(self._normalize_address_group(grp, dg_name if dg_name != "?" else None))
                            seen_names[grp_name] = dg_name
                except Exception as exc:  # pragma: no cover
                    self.logger.debug(
                        "AddressGroup.refreshall failed for device-group %s (in hierarchy of %s): %s",
                        hierarchy_dg_name,
                        dg_name,
                        exc,
                    )

            dg_counts[dg_name] = len(results) - count_before

        self._address_groups_cache = results
        self._debug(
            "Address groups loaded: shared=%s device-groups=%s total=%s",
            shared_count,
            sum(dg_counts.values()),
            len(self._address_groups_cache),
        )
        return self._address_groups_cache

    def get_service_groups(self) -> List[Dict[str, Any]]:  # pragma: no cover
        """Return service groups across shared, device-group, and predefined (if any)."""
        if self._service_groups_cache is not None:
            return self._service_groups_cache
        if not self.connect() or not ServiceGroup:
            self._service_groups_cache = []
            return self._service_groups_cache
        results: List[Dict[str, Any]] = []
        predefined_count = 0
        shared_count = 0
        dg_counts: Dict[str, int] = {}

        # Predefined service groups are not standard objects, but attempt via predefined if available.
        try:
            predefined = getattr(self._panorama, "predefined", None)
            if predefined and hasattr(predefined, "service_groups"):
                for grp in getattr(predefined, "service_groups", []) or []:  # hypothetical attribute
                    members = [str(m) for m in getattr(grp, "value", []) or []]
                    results.append(
                        {
                            "name": getattr(grp, "name", ""),
                            "description": getattr(grp, "description", "") or "",
                            "members": members,
                            "device_group": None,
                            "predefined": True,
                        }
                    )
                    predefined_count += 1
        except Exception as exc:
            self.logger.debug("Predefined service groups retrieval failed: %s", exc)

        # Shared
        seen_names: Dict[str, str] = {}  # Track to avoid duplicates
        try:
            for grp in ServiceGroup.refreshall(self._panorama) or []:  # type: ignore[arg-type]
                grp_name = getattr(grp, "name", None)
                if grp_name and grp_name not in seen_names:
                    results.append(self._normalize_service_group(grp, None))
                    seen_names[grp_name] = "shared"
                    shared_count += 1
        except Exception as exc:  # pragma: no cover
            self.logger.debug("Shared ServiceGroup.refreshall failed: %s", exc)

        # Device-group with parent inheritance
        for dg in self._get_device_groups():
            dg_name = getattr(dg, "name", "?")
            count_before = len(results)

            # Get hierarchy (child first, then parents)
            dg_hierarchy = self._get_device_group_with_parents(dg)

            for hierarchy_dg in dg_hierarchy:
                hierarchy_dg_name = getattr(hierarchy_dg, "name", "?")
                try:
                    for grp in ServiceGroup.refreshall(hierarchy_dg) or []:  # type: ignore[arg-type]
                        grp_name = getattr(grp, "name", None)
                        if grp_name and grp_name not in seen_names:
                            results.append(self._normalize_service_group(grp, dg_name if dg_name != "?" else None))
                            seen_names[grp_name] = dg_name
                except Exception as exc:  # pragma: no cover
                    self.logger.debug(
                        "ServiceGroup.refreshall failed for device-group %s (in hierarchy of %s): %s",
                        hierarchy_dg_name,
                        dg_name,
                        exc,
                    )

            dg_counts[dg_name] = len(results) - count_before

        self._service_groups_cache = results
        self._debug(
            "Service groups loaded: predefined=%s shared=%s device-groups=%s total=%s",
            predefined_count,
            shared_count,
            sum(dg_counts.values()),
            len(self._service_groups_cache),
        )
        return self._service_groups_cache

    def get_applications(self) -> List[Dict[str, Any]]:  # pragma: no cover
        """Return application objects across shared, device-group, and predefined scopes."""
        if self._applications_cache is not None:
            return self._applications_cache
        if not self.connect() or not ApplicationObject:
            self._applications_cache = []
            return self._applications_cache
        results: Dict[tuple, Dict[str, Any]] = {}
        predefined_count = 0
        shared_count = 0
        dg_counts: Dict[str, int] = {}

        # Predefined applications: use pan-os-python's Predefined subsystem
        # This is the proper way to retrieve built-in applications like "concur", "facebook", etc.
        if not self._predefined_applications_loaded:
            try:
                self._debug("Loading predefined applications via Panorama.predefined.refreshall_applications()")
                # The predefined subsystem is attached to the Panorama object
                if hasattr(self._panorama, "predefined"):
                    self._panorama.predefined.refreshall_applications()

                    # Get all predefined applications from the cache
                    # After refreshall_applications(), objects are stored in application_objects
                    # and application_container_objects dictionaries
                    predefined_apps = getattr(self._panorama.predefined, "application_objects", {})
                    predefined_containers = getattr(self._panorama.predefined, "application_container_objects", {})

                    self._debug(
                        "Predefined cache: %d applications, %d containers",
                        len(predefined_apps),
                        len(predefined_containers),
                    )

                    # Process predefined applications
                    for name, app in predefined_apps.items():
                        key = (name, None)
                        if key not in results:
                            results[key] = {
                                "name": name,
                                "description": getattr(app, "description", "") or "",
                                "category": getattr(app, "category", None),
                                "subcategory": getattr(app, "subcategory", None),
                                "technology": getattr(app, "technology", None),
                                "risk": getattr(app, "risk", None),
                                "device_group": None,
                            }
                            predefined_count += 1

                    # Also include application containers (groups of predefined apps)
                    # Note: ApplicationContainer has 'applications' attribute, not the same fields as ApplicationObject
                    for name, container in predefined_containers.items():
                        key = (name, None)
                        if key not in results:
                            results[key] = {
                                "name": name,
                                "description": getattr(container, "description", "") or "",
                                "category": getattr(container, "category", None),
                                "subcategory": getattr(container, "subcategory", None),
                                "technology": getattr(container, "technology", None),
                                "risk": getattr(container, "risk", None),
                                "device_group": None,
                            }
                            predefined_count += 1

                self._predefined_applications_loaded = True
                self._debug("Loaded %s predefined applications via Predefined subsystem", predefined_count)
            except Exception as exc:
                self._debug("Predefined applications loading failed: %s", exc)
                self.logger.warning("Failed to load predefined applications: %s", exc)
                self._predefined_applications_loaded = True

        # Shared
        try:
            for app in ApplicationObject.refreshall(self._panorama) or []:  # type: ignore[arg-type]
                self._cache_application(app, None, results)
                shared_count += 1
        except Exception as exc:  # pragma: no cover
            self.logger.debug("Shared ApplicationObject.refreshall failed: %s", exc)

        # Device groups with parent inheritance
        for dg in self._get_device_groups():
            dg_name = getattr(dg, "name", "?")
            count_before = len(results)

            # Get hierarchy (child first, then parents)
            dg_hierarchy = self._get_device_group_with_parents(dg)

            for hierarchy_dg in dg_hierarchy:
                hierarchy_dg_name = getattr(hierarchy_dg, "name", "?")
                try:
                    for app in ApplicationObject.refreshall(hierarchy_dg) or []:  # type: ignore[arg-type]
                        # _cache_application uses dict keyed by name to avoid duplicates
                        self._cache_application(app, dg_name if dg_name != "?" else None, results)
                except Exception as exc:  # pragma: no cover
                    self.logger.debug(
                        "ApplicationObject.refreshall failed for device-group %s (in hierarchy of %s): %s",
                        hierarchy_dg_name,
                        dg_name,
                        exc,
                    )

            dg_counts[dg_name] = len(results) - count_before

        self._applications_cache = list(results.values())
        self._debug(
            "Applications loaded: predefined=%s shared=%s device-groups=%s total=%s",
            predefined_count,
            shared_count,
            sum(dg_counts.values()),
            len(self._applications_cache),
        )
        return self._applications_cache

    def get_application_groups(self) -> List[Dict[str, Any]]:  # pragma: no cover
        """Return application groups (shared + device-group) plus predefined application containers."""
        if self._application_groups_cache is not None:
            return self._application_groups_cache
        if not self.connect() or not ApplicationGroup:
            self._application_groups_cache = []
            return self._application_groups_cache
        results: Dict[tuple, Dict[str, Any]] = {}
        predefined_count = 0
        shared_count = 0
        dg_counts: Dict[str, int] = {}

        # Predefined containers via refreshall_applications (which populates container objects)
        try:
            predefined = getattr(self._panorama, "predefined", None)
            if predefined and hasattr(predefined, "refreshall_applications"):
                predefined.refreshall_applications()
                for container in getattr(predefined, "application_container_objects", []) or []:
                    members = [str(m) for m in getattr(container, "applications", []) or []]
                    key = (getattr(container, "name", ""), None)
                    if key not in results:
                        results[key] = {
                            "name": getattr(container, "name", ""),
                            "description": getattr(container, "description", "") or "",
                            "members": members,
                            "device_group": None,
                            "predefined_container": True,
                        }
                        predefined_count += 1
        except Exception as exc:  # pragma: no cover
            self.logger.debug("Predefined application containers retrieval failed: %s", exc)

        # Shared groups
        try:
            count_before = len(results)
            for grp in ApplicationGroup.refreshall(self._panorama) or []:  # type: ignore[arg-type]
                self._cache_app_group(grp, None, results)
            shared_count = len(results) - count_before
        except Exception as exc:  # pragma: no cover
            self.logger.debug("Shared ApplicationGroup.refreshall failed: %s", exc)

        # Device-group groups with parent inheritance
        for dg in self._get_device_groups():
            dg_name = getattr(dg, "name", "?")
            count_before = len(results)

            # Get hierarchy (child first, then parents)
            dg_hierarchy = self._get_device_group_with_parents(dg)

            for hierarchy_dg in dg_hierarchy:
                hierarchy_dg_name = getattr(hierarchy_dg, "name", "?")
                try:
                    for grp in ApplicationGroup.refreshall(hierarchy_dg) or []:  # type: ignore[arg-type]
                        # _cache_app_group uses dict keyed by (name, dg) to avoid duplicates
                        self._cache_app_group(grp, dg_name if dg_name != "?" else None, results)
                except Exception as exc:  # pragma: no cover
                    self.logger.debug(
                        "ApplicationGroup.refreshall failed for device-group %s (in hierarchy of %s): %s",
                        hierarchy_dg_name,
                        dg_name,
                        exc,
                    )

            dg_counts[dg_name] = len(results) - count_before

        self._application_groups_cache = list(results.values())
        self._debug(
            "Application groups loaded: predefined=%s shared=%s device-groups=%s total=%s",
            predefined_count,
            shared_count,
            sum(dg_counts.values()),
            len(self._application_groups_cache),
        )
        return self._application_groups_cache

    # ---- Normalization / caching helpers for individual objects ----
    def _normalize_service(self, svc: Any, device_group: Optional[str]) -> Dict[str, Any]:  # pragma: no cover
        # pan-os-python ServiceObject exposes 'protocol' and 'destination_port'.
        # Downstream DiffSync/Nautobot expects 'ip_protocol' with constrained choices.
        raw_proto = getattr(svc, "protocol", None)
        proto_map = {
            None: "Reserved",
            "": "Reserved",
            "any": "Reserved",
            "tcp": "TCP",
            "udp": "UDP",
            "icmp": "ICMP",
            "icmp6": "ICMP",  # collapse IPv6 ICMP to ICMP for model choice set
            "sctp": "SCTP",
        }
        proto = proto_map.get(str(raw_proto).lower() if raw_proto is not None else None, str(raw_proto).upper())
        dest = getattr(svc, "destination_port", None)
        # Normalize destination_port: may be list, string, or None.
        if isinstance(dest, list):
            port_val = ",".join(str(p) for p in dest)
        else:
            port_val = str(dest) if dest is not None else None
        name = getattr(svc, "name", "") or ""
        return {
            "name": name,
            "description": getattr(svc, "description", "") or "",
            "ip_protocol": proto,
            "port": port_val,
            "device_group": device_group,
        }

    def _normalize_address_group(self, grp: Any, device_group: Optional[str]) -> Dict[str, Any]:  # pragma: no cover
        static_vals = getattr(grp, "static_value", None)
        members: List[str] = []
        if isinstance(static_vals, list):
            members = [str(m) for m in static_vals]
        name = getattr(grp, "name", "") or ""
        return {
            "name": name,
            "description": getattr(grp, "description", "") or "",
            "members": members,
            "device_group": device_group,
        }

    def _normalize_service_group(self, grp: Any, device_group: Optional[str]) -> Dict[str, Any]:  # pragma: no cover
        members_attr = getattr(grp, "value", None)
        members: List[str] = []
        if isinstance(members_attr, list):
            members = [str(m) for m in members_attr]
        name = getattr(grp, "name", "") or ""
        return {
            "name": name,
            "description": getattr(grp, "description", "") or "",
            "members": members,
            "device_group": device_group,
        }

    def _cache_application(
        self, app: Any, device_group: Optional[str], bucket: Dict[tuple, Dict[str, Any]]
    ):  # pragma: no cover
        key = (getattr(app, "name", None), device_group)
        if key in bucket:
            return
        bucket[key] = {
            "name": getattr(app, "name", "") or "",
            "description": getattr(app, "description", "") or "",
            "category": getattr(app, "category", None),
            "subcategory": getattr(app, "subcategory", None),
            "technology": getattr(app, "technology", None),
            "risk": getattr(app, "risk", None),
            "device_group": device_group,
        }

    def _cache_app_group(
        self, grp: Any, device_group: Optional[str], bucket: Dict[tuple, Dict[str, Any]]
    ):  # pragma: no cover
        members_attr = getattr(grp, "value", None)
        members: List[str] = []
        if isinstance(members_attr, list):
            members = [str(m) for m in members_attr]
        key = (getattr(grp, "name", None), device_group)
        if key not in bucket:
            bucket[key] = {
                "name": getattr(grp, "name", "") or "",
                "description": getattr(grp, "description", "") or "",
                "members": members,
                "device_group": device_group,
            }

    # ---- Preload facility ----
    def preload(self, families: Optional[List[str]] = None):  # pragma: no cover
        """Warm caches and optionally prefetch selected object families.

        Args:
            families: List of families to preload; valid entries: "addresses", "services", "applications".
                     If None, preload a sensible default subset.

        Note:
            This does not store objects themselves (those are returned by getters) but ensures
            device groups/templates are cached and predefined artifacts are loaded once.
        """
        if families is None:
            families = ["addresses", "services", "applications"]
        # Ensure connection and core scope enumeration
        if not self.connect():
            return
        _ = self._get_device_groups()
        _ = self._get_templates()
        predefined = getattr(self._panorama, "predefined", None)
        if predefined:
            try:
                if "applications" in families and hasattr(predefined, "refreshall_applications"):
                    predefined.refreshall_applications()
            except Exception as exc:  # pragma: no cover
                self.logger.debug("Preload predefined applications failed: %s", exc)
            try:
                if "services" in families and hasattr(predefined, "refreshall_services"):
                    predefined.refreshall_services()
            except Exception as exc:  # pragma: no cover
                self.logger.debug("Preload predefined services failed: %s", exc)

    def get_zones(self) -> List[Dict[str, Any]]:  # pragma: no cover
        """Return zone objects across templates (and shared if any).

        Shared zones rarely exist at Panorama root; templates and template stacks hold zone definitions.
        Enumerate Template and TemplateStack objects and refresh zones per scope.
        """
        if self._zones_cache is not None:
            return self._zones_cache
        if not self.connect() or not Zone:
            self._zones_cache = []
            return self._zones_cache
        zones: List[Dict[str, Any]] = []
        shared_count = 0
        tmpl_count = 0
        stack_count = 0
        # Attempt shared zones
        try:
            for z in Zone.refreshall(self._panorama) or []:  # type: ignore[arg-type]
                name = (getattr(z, "name", "") or "").strip()
                if not name:
                    continue
                zones.append({"name": name, "description": getattr(z, "description", "") or "", "template": None})
                shared_count += 1
        except Exception as exc:
            self.logger.debug("Shared Zone.refreshall failed: %s", exc)
        # Templates
        templates = self._get_templates()
        for tmpl in templates:
            try:
                # Ensure template children are initialized before class-level refreshes
                try:
                    if hasattr(tmpl, "refresh"):
                        tmpl.refresh(self._panorama)  # type: ignore[arg-type]
                except Exception as exc_tmpl_refresh:  # pragma: no cover
                    self.logger.debug(
                        "Template refresh failed for %s (non-fatal): %s", getattr(tmpl, "name", "?"), exc_tmpl_refresh
                    )
                virtual_systems = tmpl.findall(Vsys)
                for vsys in virtual_systems:
                    for z in Zone.refreshall(vsys) or []:  # type: ignore[arg-type]
                        name = (getattr(z, "name", "") or "").strip()
                        if not name:
                            continue
                        zones.append(
                            {
                                "name": name,
                                "description": getattr(z, "description", "") or "",
                                "template": getattr(tmpl, "name", None),
                            }
                        )
                        tmpl_count += 1
            except Exception as exc:  # pragma: no cover
                self.logger.debug("Zone.refreshall failed for template %s: %s", getattr(tmpl, "name", "?"), exc)
        self._zones_cache = zones
        self._debug(
            "Zones loaded: shared=%s templates=%s stacks=%s total=%s",
            shared_count,
            tmpl_count,
            stack_count,
            len(zones),
        )
        return self._zones_cache

    # ---- Cached enumeration helpers ----
    def _get_device_groups(self) -> List[Any]:  # pragma: no cover
        """Return DeviceGroup objects (cached). Honors explicit config.device_groups filter."""
        if self._device_group_cache is not None:
            return self._device_group_cache
        if not self.connect() or not DeviceGroup:
            self._device_group_cache = []
            return self._device_group_cache
        try:
            dgs = DeviceGroup.refreshall(self._panorama) or []  # type: ignore[arg-type]
        except Exception as exc:  # pragma: no cover
            self.logger.debug("DeviceGroup.refreshall failed: %s", exc)
            dgs = []

        # Build parent hierarchy map from XPath since SDK doesn't populate parent attribute reliably
        parent_map: Dict[str, str] = {}  # child_name -> parent_name
        try:
            xpath = "/config/devices/entry[@name='localhost.localdomain']/device-group"
            response = self._panorama.xapi.get(xpath)
            entries = response.findall(".//entry")
            for entry in entries:
                dg_name = entry.get("name")
                parent_elem = entry.find("parent-dg")
                if dg_name and parent_elem is not None and parent_elem.text:
                    parent_map[dg_name] = parent_elem.text
                    self._debug("Found parent relationship: %s -> %s", dg_name, parent_elem.text)
        except Exception as exc:
            self._debug("XPath device group hierarchy query failed: %s", exc)

        # Filter if config specifies subset
        if self.config.device_groups:
            filtered = []
            wanted = set(self.config.device_groups)
            for dg in dgs:
                if getattr(dg, "name", None) in wanted:
                    filtered.append(dg)
            dgs = filtered

        # Store parent map for later use
        self._device_group_parent_map = parent_map

        # Debug device group hierarchy
        for dg in dgs:
            dg_name = getattr(dg, "name", "?")
            parent_from_map = parent_map.get(dg_name)
            self._debug("Device group: %s, parent: %s", dg_name, parent_from_map or "None")

        self._device_group_cache = dgs
        return self._device_group_cache

    def _get_device_group_with_parents(self, dg: Any) -> List[Any]:  # pragma: no cover
        """Return list of device groups starting from given DG and walking up parent chain.

        Uses XPath-derived parent hierarchy map since SDK doesn't reliably populate parent attribute.

        Args:
            dg: DeviceGroup object to start from.

        Returns:
            List of DeviceGroup objects [dg, parent, grandparent, ...] with dg first.
        """
        result = [dg]
        dg_name = getattr(dg, "name", None)
        if not dg_name:
            return result

        visited = {dg_name}  # Prevent circular refs
        current_name = dg_name

        # Walk up parent chain using XPath-derived parent map
        while True:
            parent_name = self._device_group_parent_map.get(current_name)
            if not parent_name or parent_name in visited:
                break

            visited.add(parent_name)

            # Find parent DeviceGroup object in cache
            parent_dg = None
            all_dgs = DeviceGroup.refreshall(self._panorama) if DeviceGroup else []  # Get ALL device groups
            for candidate_dg in all_dgs:
                if getattr(candidate_dg, "name", None) == parent_name:
                    parent_dg = candidate_dg
                    break

            if parent_dg is None:
                self._debug("Parent device group %s not found in Panorama", parent_name)
                break

            result.append(parent_dg)
            current_name = parent_name

        if len(result) > 1:
            self._debug(
                "Device group hierarchy for %s: %s",
                dg_name,
                " -> ".join([getattr(d, "name", "?") for d in result]),
            )

        return result

    def _get_templates(self) -> List[Any]:  # pragma: no cover
        """Return Template objects (cached). Honors explicit config.templates filter."""
        if self._template_cache is not None:
            return self._template_cache
        if not self.connect():
            self._template_cache = []
            return self._template_cache
        try:
            from panos.panorama import Template  # type: ignore

            tmpls = Template.refreshall(self._panorama) or []  # type: ignore[arg-type]
        except Exception as exc:  # pragma: no cover
            self.logger.debug("Template.refreshall failed: %s", exc)
            tmpls = []
        if self.config.templates:
            wanted = set(self.config.templates)
            tmpls = [t for t in tmpls if getattr(t, "name", None) in wanted]
        self._template_cache = tmpls
        return self._template_cache

    def _get_template_stacks(self) -> List[Any]:  # pragma: no cover
        """Return TemplateStack objects (cached). Honors explicit config.template_stacks filter."""
        if self._template_stack_cache is not None:
            return self._template_stack_cache
        if not self.connect():
            self._template_stack_cache = []
            return self._template_stack_cache
        try:
            from panos.panorama import TemplateStack  # type: ignore

            stacks = TemplateStack.refreshall(self._panorama) or []  # type: ignore[arg-type]
        except Exception as exc:  # pragma: no cover
            self.logger.debug("TemplateStack.refreshall failed: %s", exc)
            stacks = []
        if self.config.template_stacks:
            wanted = set(self.config.template_stacks)
            stacks = [s for s in stacks if getattr(s, "name", None) in wanted]
        self._template_stack_cache = stacks
        return self._template_stack_cache

    def get_security_policies(self, device_group: str, direction: str) -> List[Dict[str, Any]]:  # pragma: no cover
        """Return a synthetic security policy (one per direction/device-group) with ordered rules.

        Args:
            device_group: Device group name.
            direction: "pre" or "post".
        """
        if not self.connect():
            return []
        if not (DeviceGroup and SecurityRule):
            return []
        cache_key = (device_group, direction)
        if cache_key in self._security_policy_cache:
            return self._security_policy_cache[cache_key]
        # Locate device group object via cached list
        dg_obj = None
        for dg in self._get_device_groups():
            if getattr(dg, "name", None) == device_group:
                dg_obj = dg
                break
        if dg_obj is None:
            return []
        # Instantiate and attach rulebase object per Panorama direction semantics
        rulebase_obj = dg_obj.add(PreRulebase() if direction == "pre" else PostRulebase())
        try:
            rules_candidates = SecurityRule.refreshall(rulebase_obj)  # type: ignore[arg-type]
        except Exception as exc:  # pragma: no cover
            self.logger.warning("SecurityRule.refreshall failed for %s/%s: %s", device_group, direction, exc)
            rules_candidates = []
        rules_out: List[Dict[str, Any]] = []
        seq = 0
        for rule in rules_candidates:
            if isinstance(rule, SecurityRule):
                seq += 1

                # Normalize list-like attributes; SDK may expose as list or str.
                def _ensure_list(val):
                    if val is None:
                        return []
                    if isinstance(val, list):
                        return [str(v) for v in val]
                    return [str(val)]

                sources = _ensure_list(getattr(rule, "source", []))
                destinations = _ensure_list(getattr(rule, "destination", []))
                applications = _ensure_list(getattr(rule, "application", []))
                services = _ensure_list(getattr(rule, "service", []))
                fromzones = _ensure_list(getattr(rule, "fromzone", []))
                tozones = _ensure_list(getattr(rule, "tozone", []))
                source_users = _ensure_list(
                    getattr(rule, "source_user", None)
                    or getattr(rule, "source_users", None)
                    or getattr(rule, "source_user_list", None)
                )
                destination_users = _ensure_list(
                    getattr(rule, "destination_user", None)
                    or getattr(rule, "destination_users", None)
                    or getattr(rule, "destination_user_list", None)
                )
                rules_out.append(
                    {
                        "sequence": seq,
                        "name": rule.name,
                        "action": getattr(rule, "action", None),
                        "description": getattr(rule, "description", None),
                        "source_addresses": sources,
                        "destination_addresses": destinations,
                        "source_services": services,
                        "destination_services": services,  # mirror for symmetric handling
                        "applications": applications,
                        "source_address_groups": [],
                        "destination_address_groups": [],
                        "source_service_groups": [],
                        "destination_service_groups": [],
                        "application_groups": [],
                        "source_zone": fromzones[0] if fromzones else None,
                        "destination_zone": tozones[0] if tozones else None,
                        "source_users": source_users,
                        "destination_users": destination_users,
                    }
                )
        if not rules_out:
            return []
        policy_name = f"SEC-{direction.upper()}-{device_group}"
        result = [
            {
                "name": policy_name,
                "description": f"Security policy ({direction}) for {device_group}",
                "direction": direction,
                "device_group": device_group,
                "rules": rules_out,
            }
        ]
        self._security_policy_cache[cache_key] = result
        return result

    def get_nat_policies(self, device_group: str, direction: str) -> List[Dict[str, Any]]:  # pragma: no cover
        """Return synthetic NAT policy (one per direction/device-group) with ordered rules."""
        if not self.connect():
            return []
        if not (DeviceGroup and NatRule):
            return []
        cache_key = (device_group, direction)
        if cache_key in self._nat_policy_cache:
            return self._nat_policy_cache[cache_key]
        # Locate device group via cached list
        dg_obj = None
        for dg in self._get_device_groups():
            if getattr(dg, "name", None) == device_group:
                dg_obj = dg
                break
        if dg_obj is None:
            return []
        # Attach appropriate rulebase object (Panorama only supports PreRulebase/PostRulebase).
        rulebase_obj = dg_obj.add(PreRulebase() if direction == "pre" else PostRulebase())
        try:
            all_rules = NatRule.refreshall(rulebase_obj)  # type: ignore[arg-type]
            rules_candidates = [r for r in all_rules or [] if isinstance(r, NatRule)]
        except Exception as exc:  # pragma: no cover
            self.logger.warning("NatRule.refreshall failed for %s/%s: %s", device_group, direction, exc)
            rules_candidates = []
        rules_out: List[Dict[str, Any]] = []
        seq = 0
        for rule in rules_candidates:
            if isinstance(rule, NatRule):
                seq += 1

                def _ensure_list(val):  # local helper
                    if val is None:
                        return []
                    if isinstance(val, list):
                        return [str(v) for v in val]
                    return [str(val)]

                # PAN-OS SDK NAT rule attribute mapping (per pan-os-python docs):
                # - source, destination: original match addresses
                # - source_translation_translated_addresses: translated source address list
                # - destination_translated_address: translated destination (single value, not list)
                # - fromzone, tozone: zone lists (take first entry)
                # - service: single service string (NAT rules don't have service lists like security rules)
                source_users = _ensure_list(
                    getattr(rule, "source_user", None)
                    or getattr(rule, "source_users", None)
                    or getattr(rule, "source_user_list", None)
                )
                destination_users = _ensure_list(
                    getattr(rule, "destination_user", None)
                    or getattr(rule, "destination_users", None)
                    or getattr(rule, "destination_user_list", None)
                )

                rules_out.append(
                    {
                        "sequence": seq,
                        "name": rule.name,
                        "description": getattr(rule, "description", None) or "",
                        "source_translation": getattr(rule, "source_translation_type", None) or "",
                        "destination_translation": (
                            "static" if getattr(rule, "destination_translated_address", None) else ""
                        ),
                        "source_users": source_users,
                        "destination_users": destination_users,
                        # Original addresses use "source" and "destination" attributes
                        "original_source_addresses": _ensure_list(getattr(rule, "source", [])),
                        "original_source_address_groups": [],  # PAN-OS doesn't distinguish groups in NAT rules
                        "original_destination_addresses": _ensure_list(getattr(rule, "destination", [])),
                        "original_destination_address_groups": [],
                        # NAT rules use a single service, not lists
                        "original_source_services": [],  # NAT doesn't have source services
                        "original_source_service_groups": [],
                        "original_destination_services": [],  # NAT doesn't have destination services
                        "original_destination_service_groups": [],
                        # Translated source addresses from source_translation_translated_addresses
                        "translated_source_addresses": _ensure_list(
                            getattr(rule, "source_translation_translated_addresses", [])
                        ),
                        "translated_source_address_groups": [],
                        # Translated destination is a single address in PAN-OS, convert to list
                        "translated_destination_addresses": (
                            [getattr(rule, "destination_translated_address")]
                            if getattr(rule, "destination_translated_address", None)
                            else []
                        ),
                        "translated_destination_address_groups": [],
                        # Zones - fromzone/tozone are lists, take first element
                        "source_zone": (
                            getattr(rule, "fromzone", [None])[0]
                            if isinstance(getattr(rule, "fromzone", None), list)
                            else getattr(rule, "fromzone", None)
                        ),
                        "destination_zone": (
                            getattr(rule, "tozone", [None])[0]
                            if isinstance(getattr(rule, "tozone", None), list)
                            else getattr(rule, "tozone", None)
                        ),
                    }
                )
        if not rules_out:
            return []
        policy_name = f"NAT-{direction.upper()}-{device_group}"
        result = [
            {
                "name": policy_name,
                "description": f"NAT policy ({direction}) for {device_group}",
                "direction": direction,
                "device_group": device_group,
                "rules": rules_out,
            }
        ]
        self._nat_policy_cache[cache_key] = result
        return result

    # ---- Cache management ----
    def reset_caches(self):  # pragma: no cover
        """Invalidate all per-run caches (useful for testing or multi-phase jobs)."""
        self._device_group_cache = None
        self._template_cache = None
        self._addresses_cache = None
        self._services_cache = None
        self._address_groups_cache = None
        self._service_groups_cache = None
        self._applications_cache = None
        self._application_groups_cache = None
        self._zones_cache = None
        self._security_policy_cache.clear()
        self._nat_policy_cache.clear()
        self._predefined_services_loaded = False
        self._predefined_applications_loaded = False

    def get_device_groups(self) -> List[str]:  # pragma: no cover
        """Return device group names.

        If explicit list provided in config, use that; else enumerate Panorama children.
        """
        if self.config.device_groups:
            return self.config.device_groups
        if not self.connect():
            return []
        if not DeviceGroup:
            return []
        names: List[str] = []
        try:
            dgs = DeviceGroup.refreshall(self._panorama)  # type: ignore[arg-type]
            for dg in dgs or []:
                names.append(dg.name)
        except Exception as exc:  # pragma: no cover
            self.logger.warning("DeviceGroup.refreshall failed: %s", exc)
        return names

    def get_regions(self) -> List[str]:  # pragma: no cover
        """Return list of Panorama region names (geographic locations like 'US', 'VN', 'PK', etc.).

        Panorama supports geographic regions as address references in policies.
        These are predefined and accessed via XPath.

        Returns:
            List of region code strings (e.g., ['US', 'VN', 'PK', 'PT', ...])
        """
        if not self.connect():
            return []
        regions: List[str] = []
        try:
            # Query predefined regions via XPath
            xpath = "/config/predefined/region/entry"
            self._debug("Querying predefined regions via XPath: %s", xpath)
            response = self._panorama.xapi.get(xpath)

            if response is not None:
                entries = response.findall(".//entry") if hasattr(response, "findall") else []
                self._debug("Found %s predefined region entries", len(entries))

                for entry in entries:
                    name = entry.get("name", "")
                    if name:
                        regions.append(name)

                self._debug("Loaded %s predefined regions", len(regions))
        except Exception as exc:
            self._debug("XPath predefined regions query failed: %s", exc)

        return regions

    # ---- Factory ----
    @staticmethod
    def from_external_integration(ei, logger: Optional[logging.Logger] = None, job: Optional[Any] = None):  # type: ignore[valid-type]
        """Construct client from Nautobot ExternalIntegration.

        Args:
            ei: ExternalIntegration instance with credentials in `extra_config`.
            logger: Optional logger.
            job: Optional job for debug flag.

        Returns:
            PanoramaSdkClient configured instance.
        """
        cfg_dict = ei.extra_config
        secrets_group = getattr(ei, "secrets_group", None)

        def _get_secret(secret_type):  # helper
            if not secrets_group or not SecretsGroupAccessTypeChoices or not SecretsGroupSecretTypeChoices:
                return None
            try:
                return secrets_group.get_secret_value(
                    access_type=SecretsGroupAccessTypeChoices.TYPE_GENERIC, secret_type=secret_type
                )
            except Exception:  # pragma: no cover
                return None

        username = _get_secret(getattr(SecretsGroupSecretTypeChoices, "TYPE_USERNAME", None)) or cfg_dict.get(
            "username"
        )
        password = _get_secret(getattr(SecretsGroupSecretTypeChoices, "TYPE_PASSWORD", None)) or cfg_dict.get(
            "password"
        )

        config = PanoramaSdkClientConfig(
            base_url=ei.remote_url,
            api_key=cfg_dict.get("api_key"),
            username=username,
            password=password,
            device_groups=cfg_dict.get("device_groups"),
            templates=cfg_dict.get("templates"),
            template_stacks=cfg_dict.get("template_stacks"),
            vsys_list=cfg_dict.get("vsys"),
        )
        return PanoramaSdkClient(config=config, logger=logger, job=job)
