"""Panorama API client abstraction.

Lightweight client used by the DiffSync adapter to retrieve Panorama
configuration objects and normalize them into dictionaries accepted by
SSoT model constructors.

Current State:
    - REST API used for all object and policy retrieval.
    - XML API retained solely for API key generation (keygen).

ExternalIntegration assumptions:
    - Retrieved via slug (e.g. ``panorama``).
    - ``url`` holds base URL (``https://panorama.example/api``).
        - ``config`` keys optionally include: ``username``, ``password``, ``api_key``,
            ``verify_ssl`` (bool), ``device_groups`` (list[str]).

Precedence: if both ``api_key`` and username/password provided, ``api_key`` wins.
Future enhancements: token refresh, pagination, batch calls.
"""

# pylint: disable=duplicate-code

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import requests
import urllib3
from defusedxml import ElementTree as ET  # still used only for keygen XML parsing
from nautobot.extras.choices import SecretsGroupAccessTypeChoices, SecretsGroupSecretTypeChoices
from nautobot.extras.models import ExternalIntegration
from requests import Response

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


@dataclass
class PanoramaClientConfig:  # pylint: disable=too-many-instance-attributes
    """Structured config extracted from ExternalIntegration.

    rest_version: Panorama REST API version segment, e.g. "v11.1".
    """

    base_url: str
    api_key: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None
    verify_ssl: bool = True
    device_groups: Optional[List[str]] = None
    rest_version: str = "v11.1"
    templates: Optional[List[str]] = None
    template_stacks: Optional[List[str]] = None
    vsys_list: Optional[List[str]] = None  # e.g. ["vsys1"]


class PanoramaClient:  # pylint: disable=too-many-instance-attributes
    """Thin client for Panorama API.

    Notes on PAN-OS/Panorama REST response structure (v11.x):
    - Top-level meta fields frequently appear as JSON attributes prefixed with '@' (e.g. ``@status``, ``@code``).
    - Collections are returned under ``result.entry`` (list) or sometimes ``result.data.entry``.
    - Each object within an ``entry`` list typically exposes its name as ``@name`` (NOT ``name``).
    - Attribute names inside objects commonly use hyphens, e.g. ``ip-netmask``, ``ip-range``, ``source-translation``.
    - Group membership is nested, e.g. ``{"static": {"member": ["a","b"]}}`` or ``{"members": {"member": [...]}}``.
      The API may also collapse to a single string for one member. This client normalizes all such cases to lists.
    - Some endpoints may return a single object rather than a list; we normalize to a list for downstream processing.
    """

    def __init__(
        self, config: PanoramaClientConfig, logger: Optional[logging.Logger] = None, job: Optional[Any] = None
    ):
        """Initialize the client.

        Args:
            config: Parsed configuration (credentials, URL, flags).
            logger: Optional logger (defaults to module logger).
            job: Optional Nautobot Job instance used to gate debug logging by the job's debug flag.
        """
        self.config = config
        self.logger = logger or logging.getLogger(__name__)
        # Optional Nautobot Job instance; used to respect job-level debug flag.
        self.job = job

    # ------------------------------ Internal Logging Helpers -----------------------
    def _debug(self, message: str, *args, **kwargs):  # pragma: no cover - thin wrapper
        """Emit a debug log only if job debug flag enabled (if job provided); else use logger directly.

        The Nautobot Job logger currently emits debug messages unconditionally; we need to gate
        PanoramaClient verbosity behind the job.debug checkbox to prevent excessive output when
        debug is not requested.
        """
        if self.job is not None:
            if getattr(self.job, "debug", False):  # job exposes debug BooleanVar state
                # Use job.log_debug if available for consistent grouping; else fall back.
                log_debug = getattr(self.job, "log_debug", None)
                if callable(log_debug):
                    log_debug(message)
                else:
                    # Fallback: still respect debug flag
                    self.logger.debug(message, *args, **kwargs)
            else:
                return  # suppress
        else:
            self.logger.debug(message, *args, **kwargs)

    # ------------------------------ Auth Helpers --------------------------
    def ensure_api_key(self) -> bool:
        """Ensure an API key is present; if username/password provided and no api_key, attempt keygen."""
        if self.config.api_key:
            return True
        if not (self.config.username and self.config.password):
            self.logger.warning("No credentials available for Panorama key generation.")
            return False
        keygen_params = {"type": "keygen", "user": self.config.username, "password": self.config.password}
        url = f"{self.config.base_url.rstrip('/')}/api/"
        try:
            resp = requests.post(url, params=keygen_params, verify=self.config.verify_ssl, timeout=30)
            resp.raise_for_status()
            root = ET.fromstring(resp.text)
            key_el = root.find("result/key")
            if key_el is not None and key_el.text:
                self.config.api_key = key_el.text.strip()
                return True
            self.logger.warning("Failed to parse Panorama API key from response.")
        except Exception as exc:  # pylint: disable=broad-except
            self.logger.warning("Panorama key generation failed: %s", exc)
        return False

    # ------------------------------ Internal Helpers -----------------------
    def _request(self, path: str, params: Optional[Dict[str, Any]] = None) -> Optional[Response]:
        """Perform a GET request to Panorama."""
        url = f"{self.config.base_url.rstrip('/')}/{path.lstrip('/')}"
        headers: Dict[str, str] = {}
        auth = None
        if self.config.api_key:
            headers["X-PAN-KEY"] = self.config.api_key
        elif self.config.username and self.config.password:
            auth = (self.config.username, self.config.password)
        try:
            resp = requests.get(
                url, headers=headers, params=params, auth=auth, verify=self.config.verify_ssl, timeout=30
            )
            resp.raise_for_status()
            return resp
        except Exception as exc:  # pylint: disable=broad-except
            self.logger.warning("Panorama request failed for %s: %s", url, exc)
            return None

    # ------------------------------ REST Helpers -------------------------
    def _rest_get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        """Perform a REST API GET returning parsed JSON body."""
        if not self.ensure_api_key():
            self.logger.warning("Failed to ensure API key for REST call")
            return None
        url = f"{self.config.base_url.rstrip('/')}/restapi/{self.config.rest_version.strip('/')}/{path.lstrip('/')}"
        headers = {"X-PAN-KEY": self.config.api_key} if self.config.api_key else {}
        self._debug(f"Making REST call to {url} with params {params}")
        try:
            resp = requests.get(url, headers=headers, params=params, verify=self.config.verify_ssl, timeout=60)
            resp.raise_for_status()
            data = resp.json()
            status = data.get("status") or data.get("@status") or "success"
            self._debug(f"REST response status: {status}")
            if status != "success":
                self.logger.warning("REST call non-success for %s: status=%s", path, status)
                return None

            # Log result structure for debugging
            if "result" in data:
                result = data["result"]
                if isinstance(result, dict) and "entry" in result:
                    entry_count = len(result["entry"]) if isinstance(result["entry"], list) else 1
                    self._debug(f"REST response contains {entry_count} entries")

            return data
        except Exception as exc:  # pylint: disable=broad-except
            self.logger.warning("REST GET failed for %s: %s", path, exc)
            return None

    # ------------------------------ Extraction & Normalization -----------
    @staticmethod
    def _rest_extract_entries(data: Optional[Dict[str, Any]]) -> List[Dict[str, Any]]:  # pylint: disable=too-many-return-statements
        """Extract list of entries from response supporting multiple shapes."""
        if not data or not isinstance(data, dict):
            return []
        result = data.get("result")
        if not isinstance(result, dict):
            return []
        entry_obj = result.get("entry")
        if entry_obj is not None:  # Handle explicit None vs empty list/dict
            if isinstance(entry_obj, list):
                return [e for e in entry_obj if e]  # Filter out empty dicts
            if isinstance(entry_obj, dict):
                return [entry_obj] if entry_obj else []  # Don't include empty dicts
        data_node = result.get("data")
        if isinstance(data_node, dict):
            entry_obj = data_node.get("entry")
            if entry_obj is not None:
                if isinstance(entry_obj, list):
                    return [e for e in entry_obj if e]  # Filter out empty dicts
                if isinstance(entry_obj, dict):
                    return [entry_obj] if entry_obj else []  # Don't include empty dicts
        return []

    @staticmethod
    def _entry_name(entry: Dict[str, Any]) -> Optional[str]:
        if not isinstance(entry, dict):
            return None
        return entry.get("@name") or entry.get("name")

    @staticmethod
    def _flatten_members(node: Any) -> List[str]:  # pylint: disable=too-many-return-statements
        if node is None:
            return []
        if isinstance(node, dict) and "member" in node:
            member_val = node.get("member")
            if isinstance(member_val, list):
                return [str(m) for m in member_val]
            if isinstance(member_val, (str, int)):
                return [str(member_val)]
            return []
        if isinstance(node, list):
            return [str(m) for m in node]
        if isinstance(node, (str, int)):
            return [str(node)]
        return []

    # ------------------------------ REST Object Parsers ------------------
    def _rest_addresses(self) -> List[Dict[str, Any]]:
        data = self._rest_get("Objects/Addresses", params={"location": "shared"})
        if not data:
            self.logger.warning("No data returned from Addresses API call")
            return []

        entries = self._rest_extract_entries(data)
        self._debug(f"Extracted {len(entries)} address entries from API response")

        out: List[Dict[str, Any]] = []
        for entry in entries:
            name = self._entry_name(entry)
            if not name:
                self.logger.debug("Skipping entry with no name: %s", entry)
                continue
            desc = entry.get("description") or ""
            # Panorama can represent addresses in multiple underlying forms.
            # Choose a single canonical representation to populate the
            # SSoT helper keys so we never set multiple underlying fields
            # simultaneously (the upstream model enforces exactly-one).
            # Precedence order: fqdn -> ip-address -> ip-netmask (prefix)
            # -> ip-range -> ip-wildcard.
            addr_record: Dict[str, Any] = {"name": name, "description": desc}
            if "fqdn" in entry:
                addr_record["fqdn"] = entry.get("fqdn")
            elif "ip-address" in entry:
                addr_record["ip_address"] = entry.get("ip-address")
            elif "ip-netmask" in entry:
                # Treat ip-netmask as a prefix (network) representation
                addr_record["prefix"] = entry.get("ip-netmask")
            elif "ip-range" in entry:
                addr_record["ip_range"] = entry.get("ip-range")
            elif "ip-wildcard" in entry:
                # Preserve wildcard representation in ip_range for now
                addr_record["ip_range"] = entry.get("ip-wildcard")
            out.append(addr_record)

        self._debug(f"Returning {len(out)} processed address objects")
        return out

    def _rest_address_groups(self) -> List[Dict[str, Any]]:
        data = self._rest_get("Objects/AddressGroups", params={"location": "shared"})
        out: List[Dict[str, Any]] = []
        for entry in self._rest_extract_entries(data):
            name = self._entry_name(entry)
            if not name:
                continue
            desc = entry.get("description") or ""
            static_members = self._flatten_members(entry.get("static"))
            out.append({"name": name, "description": desc, "members": static_members})
        return out

    def _rest_services(self) -> List[Dict[str, Any]]:  # pylint: disable=too-many-locals
        # Query services from predefined, shared, and each device-group scope.
        locations: List[Dict[str, str]] = [
            {"location": "predefined"},
            {"location": "shared"},
        ]
        for dg in self.get_device_groups() or []:
            locations.append({"location": "device-group", "device-group": dg})
        collected: List[Dict[str, Any]] = []
        for params in locations:
            data = self._rest_get("Objects/Services", params=params)
            entries = self._rest_extract_entries(data)
            if not entries:
                self._debug(f"No service entries returned for params={params}")
            for entry in entries:
                name = self._entry_name(entry)
                if not name:
                    continue
                desc = entry.get("description") or ""
                protocol = None
                ports = None
                protocol_block = entry.get("protocol") or {}
                for proto_name in ["tcp", "udp", "sctp"]:
                    if proto_name in protocol_block:
                        proto_data = protocol_block.get(proto_name) or {}
                        protocol = proto_name.upper()
                        ports = proto_data.get("port")
                        break
                collected.append({"name": name, "description": desc, "ip_protocol": protocol, "port": ports})
        # Deduplicate by service name preserving first occurrence (predefined overrides retained)
        dedup: Dict[str, Dict[str, Any]] = {}
        for svc in collected:
            if svc["name"] not in dedup:
                dedup[svc["name"]] = svc
        result = list(dedup.values())
        self._debug(f"Returning {len(result)} service objects (merged predefined/shared/device-group)")
        return result

    def _rest_service_groups(self) -> List[Dict[str, Any]]:
        # Query service groups from predefined, shared, and each device-group scope
        locations: List[Dict[str, str]] = [
            {"location": "predefined"},
            {"location": "shared"},
        ]
        for dg in self.get_device_groups() or []:
            locations.append({"location": "device-group", "device-group": dg})
        collected: List[Dict[str, Any]] = []
        for params in locations:
            data = self._rest_get("Objects/ServiceGroups", params=params)
            entries = self._rest_extract_entries(data)
            if not entries:
                self._debug(f"No service group entries returned for params={params}")
            for entry in entries:
                name = self._entry_name(entry)
                if not name:
                    continue
                desc = entry.get("description") or ""
                members = self._flatten_members(entry.get("members"))
                collected.append({"name": name, "description": desc, "members": members})
        # Deduplicate by group name preserving first occurrence
        dedup: Dict[str, Dict[str, Any]] = {}
        for grp in collected:
            if grp["name"] not in dedup:
                dedup[grp["name"]] = grp
        result = list(dedup.values())
        self._debug(f"Returning {len(result)} service group objects (merged predefined/shared/device-group)")
        return result

    def _rest_applications(self) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        # Locations to query: predefined (system), shared (user-defined global), and each device-group
        locations: List[Dict[str, str]] = [{"location": "predefined"}, {"location": "shared"}]
        # Device-group scoped applications (custom to device group context)
        for dg in self.get_device_groups() or []:
            locations.append({"location": "device-group", "device-group": dg})
        for params in locations:
            data = self._rest_get("Objects/Applications", params=params)
            entries = self._rest_extract_entries(data)
            if not entries:
                self._debug(
                    f"No application entries returned for params={params}",
                )
            for entry in entries:
                name = self._entry_name(entry)
                if not name:
                    continue
                out.append(
                    {
                        "name": name,
                        "description": entry.get("description") or "",
                        "category": entry.get("category"),
                        "subcategory": entry.get("subcategory"),
                    }
                )
        # De-duplicate by name preserving first occurrence (predefined definitions may overlap with shared)
        dedup: Dict[str, Dict[str, Any]] = {}
        for app in out:
            if app["name"] not in dedup:
                dedup[app["name"]] = app
        result = list(dedup.values())
        self._debug(f"Returning {len(result)} application objects (merged predefined/shared/device-group)")
        return result

    def _rest_application_groups(self) -> List[Dict[str, Any]]:
        data = self._rest_get("Objects/ApplicationGroups", params={"location": "shared"})
        out: List[Dict[str, Any]] = []
        for entry in self._rest_extract_entries(data):
            name = self._entry_name(entry)
            if not name:
                continue
            members = self._flatten_members(entry.get("members"))
            out.append({"name": name, "description": entry.get("description") or "", "members": members})
        return out

    def _rest_zones(self) -> List[Dict[str, Any]]:  # pylint: disable=too-many-branches
        out: List[Dict[str, Any]] = []

        # Normalize config values: if a single string is provided instead of list, wrap it.
        def _ensure_list(val):  # local helper
            if val is None:
                return []
            if isinstance(val, list):
                return val
            return [val]

        templates = _ensure_list(self.config.templates) or self._discover_templates()
        template_stacks = _ensure_list(self.config.template_stacks) or self._discover_template_stacks()
        vsys_list = _ensure_list(self.config.vsys_list) or self._discover_vsys_list()
        if not vsys_list:
            self.logger.warning(
                "No vsys_list configured or discovered; defaulting to vsys1", extra={"grouping": "panorama-rest"}
            )
            vsys_list = ["vsys1"]
        if not templates and not template_stacks:
            self._debug(
                "No templates or template stacks discovered/configured; attempting shared zone retrieval",
                extra={"grouping": "panorama-rest"},
            )
        # Template-based zones
        for tmpl in templates:
            for vsys in vsys_list:
                params = {"location": "template", "template": tmpl, "vsys": vsys}
                data = self._rest_get("Network/Zones", params=params)
                entries = self._rest_extract_entries(data)
                if not entries:
                    self._debug(
                        "No zones returned for template=%s vsys=%s", tmpl, vsys, extra={"grouping": "panorama-rest"}
                    )
                for entry in entries:
                    name = self._entry_name(entry)
                    if not name:
                        continue
                    out.append({"name": name, "description": entry.get("description") or ""})
        # Template-stack based zones
        for stack in template_stacks:
            for vsys in vsys_list:
                params = {"location": "template-stack", "template-stack": stack, "vsys": vsys}
                data = self._rest_get("Network/Zones", params=params)
                entries = self._rest_extract_entries(data)
                if not entries:
                    self._debug(
                        "No zones returned for template-stack=%s vsys=%s",
                        stack,
                        vsys,
                        extra={"grouping": "panorama-rest"},
                    )
                for entry in entries:
                    name = self._entry_name(entry)
                    if not name:
                        continue
                    out.append({"name": name, "description": entry.get("description") or ""})
        # If still empty, emit a warning (no zones found for provided templates/template-stacks and vsys list)
        if not out:
            self.logger.warning(
                "No zones returned from Panorama for any template/template-stack and vsys combination.",
                extra={"grouping": "panorama-rest"},
            )
        self._debug(f"Returning {len(out)} zones total", extra={"grouping": "panorama-rest"})
        return out

    # ------------------------------ Discovery ---------------------------
    def _discover_templates(self) -> List[str]:
        data = self._rest_get("Panorama/Templates")
        entries = self._rest_extract_entries(data)
        names = [self._entry_name(e) for e in entries if self._entry_name(e)]
        if not names:
            self._debug("No templates discovered via REST", extra={"grouping": "panorama-rest"})
        return names

    def _discover_template_stacks(self) -> List[str]:
        data = self._rest_get("Panorama/TemplateStacks")
        entries = self._rest_extract_entries(data)
        names = [self._entry_name(e) for e in entries if self._entry_name(e)]
        if not names:
            self._debug("No template stacks discovered via REST", extra={"grouping": "panorama-rest"})
        return names

    def _discover_device_groups(self) -> List[str]:
        data = self._rest_get("Panorama/DeviceGroups")
        entries = self._rest_extract_entries(data)
        names = [self._entry_name(e) for e in entries if self._entry_name(e)]
        if not names:
            self._debug("No device groups discovered via REST", extra={"grouping": "panorama-rest"})
        return names

    def _discover_vsys_list(self) -> List[str]:
        """Discover virtual systems using REST Device/VirtualSystems endpoint.

        Returns list of vsys names (e.g. ["vsys1", "vsys2"]). Defaults to ["vsys1"] if none found.
        """
        vsys_names: List[str] = []
        templates = self.config.templates or self._discover_templates()
        if not templates:
            self._debug("_discover_vsys_list: no templates available; defaulting vsys to ['vsys1']")
            return ["vsys1"]
        for tmpl in templates:
            params = {"location": "template", "template": tmpl}
            data = self._rest_get("Device/VirtualSystems", params=params)
            entries = self._rest_extract_entries(data)
            names = [self._entry_name(e) for e in entries if self._entry_name(e)]
            if not names:
                self._debug(f"No vsys entries for template {tmpl}")
            for n in names:
                if n and n not in vsys_names:
                    vsys_names.append(n)
        if not vsys_names:
            self._debug("No vsys discovered across templates; defaulting to ['vsys1']")
            return ["vsys1"]
        self._debug(f"Discovered vsys list (templates={templates}): {vsys_names}")
        return vsys_names

    # ------------------------------ REST Policies ------------------------
    def _rest_security_policies(self, device_group: str, direction: str) -> List[Dict[str, Any]]:  # pylint: disable=too-many-locals
        endpoint = "Policies/SecurityPreRules" if direction == "pre" else "Policies/SecurityPostRules"
        params = {"location": "device-group", "device-group": device_group}
        data = self._rest_get(endpoint, params=params)
        rules: List[Dict[str, Any]] = []
        for idx, entry in enumerate(self._rest_extract_entries(data), start=1):
            name = self._entry_name(entry) or f"rule-{idx}"
            # Extract rule components; Panorama JSON may use member lists for these keys.
            sources = self._flatten_members(entry.get("source"))
            destinations = self._flatten_members(entry.get("destination"))
            services = self._flatten_members(entry.get("service"))
            applications = self._flatten_members(entry.get("application"))
            from_zones = self._flatten_members(entry.get("from"))
            to_zones = self._flatten_members(entry.get("to"))
            rule_record = {
                "sequence": idx,
                "name": name,
                "action": entry.get("action"),
                "description": entry.get("description"),
                # Address/service/application lists
                "source_addresses": sources,
                "destination_addresses": destinations,
                "source_services": services,
                "destination_services": services if services else [],  # symmetric if only one list provided
                "applications": applications,
                # Group placeholders (classification TBD)
                "source_address_groups": [],
                "destination_address_groups": [],
                "source_service_groups": [],
                "destination_service_groups": [],
                "application_groups": [],
                # Zones (select first if multiple provided)
                "source_zone": from_zones[0] if from_zones else None,
                "destination_zone": to_zones[0] if to_zones else None,
            }
            self._debug(
                "Parsed security rule %s (seq=%s) src=%s dst=%s svc=%s apps=%s from=%s to=%s",
                name,
                idx,
                sources,
                destinations,
                services,
                applications,
                from_zones,
                to_zones,
            )
            rules.append(rule_record)
        if not rules:
            return []
        policy_name = f"SEC-{direction.upper()}-{device_group}"
        return [
            {
                "name": policy_name,
                "description": f"Security policy ({direction}) for {device_group}",
                "direction": direction,
                "device_group": device_group,
                "rules": rules,
            }
        ]

    def _rest_nat_policies(self, device_group: str, direction: str) -> List[Dict[str, Any]]:
        endpoint = "Policies/NatPreRules" if direction == "pre" else "Policies/NatPostRules"
        params = {"location": "device-group", "device-group": device_group}
        data = self._rest_get(endpoint, params=params)
        rules: List[Dict[str, Any]] = []
        for idx, entry in enumerate(self._rest_extract_entries(data), start=1):
            name = self._entry_name(entry) or f"nat-rule-{idx}"
            src_trans = (entry.get("source-translation") or {}).get("translated-address")
            dst_trans = (entry.get("destination-translation") or {}).get("translated-address")
            rules.append(
                {
                    "sequence": idx,
                    "name": name,
                    "description": entry.get("description"),
                    "source_translation": src_trans,
                    "destination_translation": dst_trans,
                }
            )
        if not rules:
            return []
        policy_name = f"NAT-{direction.upper()}-{device_group}"
        return [
            {
                "name": policy_name,
                "description": f"NAT policy ({direction}) for {device_group}",
                "direction": direction,
                "device_group": device_group,
                "rules": rules,
            }
        ]

    # ------------------------------ Public Fetch Methods -------------------
    def get_addresses(self) -> List[Dict[str, Any]]:  # pragma: no cover - thin wrapper
        """Return normalized address objects from Panorama."""
        return self._rest_addresses()

    def get_address_groups(self) -> List[Dict[str, Any]]:  # pragma: no cover
        """Return normalized address group objects (with member lists)."""
        return self._rest_address_groups()

    def get_services(self) -> List[Dict[str, Any]]:  # pragma: no cover
        """Return normalized service objects (protocol + ports)."""
        return self._rest_services()

    def get_service_groups(self) -> List[Dict[str, Any]]:  # pragma: no cover
        """Return normalized service group objects (member list)."""
        return self._rest_service_groups()

    def get_applications(self) -> List[Dict[str, Any]]:  # pragma: no cover
        """Return application objects (basic descriptive fields)."""
        return self._rest_applications()

    def get_application_groups(self) -> List[Dict[str, Any]]:  # pragma: no cover
        """Return application group objects (member list)."""
        return self._rest_application_groups()

    def get_zones(self) -> List[Dict[str, Any]]:  # pragma: no cover
        """Return zone objects aggregated across templates/template-stacks."""
        return self._rest_zones()

    def get_security_policies(self, device_group: str, direction: str) -> List[Dict[str, Any]]:  # pragma: no cover
        """Return synthetic security policy (one per direction/device group) with ordered rules."""
        return self._rest_security_policies(device_group, direction)

    def get_nat_policies(self, device_group: str, direction: str) -> List[Dict[str, Any]]:  # pragma: no cover
        """Return synthetic NAT policy (one per direction/device group) with ordered rules."""
        return self._rest_nat_policies(device_group, direction)

    def get_device_groups(self) -> List[str]:  # pragma: no cover
        """Return configured device groups or discover them via REST."""
        if self.config.device_groups:
            return self.config.device_groups
        discovered = self._discover_device_groups()
        if not discovered:
            self.logger.warning("No device groups discovered via REST", extra={"grouping": "panorama-rest"})
        return discovered

    # ------------------------------ Factory -------------------------------
    @staticmethod
    def from_external_integration(
        ei: ExternalIntegration, logger: Optional[logging.Logger] = None, job: Optional[Any] = None
    ) -> "PanoramaClient":  # type: ignore[valid-type]
        """Instantiate a client from an `ExternalIntegration` object.

        Args:
            ei: ExternalIntegration providing remote_url and extra_config.
            logger: Optional Nautobot Job logger so that client debug messages are captured in job output.
            job: Optional Nautobot Job instance; if provided, its debug flag gates client debug output.
        """
        cfg_dict = ei.extra_config
        secrets_group = ei.secrets_group

        def _get_secret(secret_type: SecretsGroupSecretTypeChoices) -> Optional[str]:  # helper
            if not secrets_group:
                return None
            try:
                return secrets_group.get_secret_value(
                    access_type=SecretsGroupAccessTypeChoices.TYPE_GENERIC, secret_type=secret_type
                )
            except Exception:  # pragma: no cover - defensive # pylint: disable=broad-except
                return None

        username = _get_secret(SecretsGroupSecretTypeChoices.TYPE_USERNAME) or cfg_dict.get("username")
        password = _get_secret(SecretsGroupSecretTypeChoices.TYPE_PASSWORD) or cfg_dict.get("password")

        config = PanoramaClientConfig(
            base_url=ei.remote_url,
            api_key=None,
            username=username,
            password=password,
            verify_ssl=ei.verify_ssl,
            device_groups=cfg_dict.get("device_groups"),
            rest_version=cfg_dict.get("rest_version", "v11.1"),
            templates=cfg_dict.get("templates"),
            template_stacks=cfg_dict.get("template_stacks"),
            vsys_list=cfg_dict.get("vsys"),
        )
        client = PanoramaClient(config=config, logger=logger, job=job)
        if not client.config.vsys_list:
            client.config.vsys_list = client._discover_vsys_list()  # pylint: disable=protected-access
        return client
