"""Jobs for Panorama SSoT integration (SDK-only).

Transition complete: the `pan-os-python` SDK client is now the sole retrieval path.
Legacy REST client retained temporarily for potential troubleshooting but is no longer used by Jobs.
"""

import csv
import io
from datetime import datetime

from diffsync.enum import DiffSyncFlags
from nautobot.apps.jobs import BooleanVar, ObjectVar, register_jobs
from nautobot.extras.models import ExternalIntegration
from nautobot_ssot.jobs.base import DataSource, DataTarget

from nautobot_ssot_panorama.diff import CustomOrderingDiff
from nautobot_ssot_panorama.diffsync.adapters.local import PanoramaLocalAdapter
from nautobot_ssot_panorama.diffsync.adapters.remote import PanoramaRemoteAdapter
from nautobot_ssot_panorama.utils.panorama_sdk import PanoramaSdkClient

name = "Panorama SSoT"  # pylint: disable=invalid-name


class PanoramaDataSource(DataSource):  # pylint: disable=too-many-instance-attributes
    """Panorama SSoT Data Source."""

    debug = BooleanVar(description="Enable for more verbose debug logging", default=False)
    enable_deletion = BooleanVar(
        description="Enable deletion of Nautobot objects not present in Panorama. When disabled (default), objects in Nautobot that don't exist in Panorama will be flagged but not deleted.",
        default=False,
    )
    panorama_integration = ObjectVar(
        model=ExternalIntegration,
        required=True,
        description="ExternalIntegration object providing Panorama connection details.",
    )

    class Meta:  # pylint: disable=too-few-public-methods
        """Meta data for Panorama."""

        name = "Panorama to Nautobot"
        data_source = "Panorama"
        data_target = "Nautobot"
        description = "Sync information from Panorama to Nautobot"
        soft_time_limit = 4 * 60 * 60  # 4 hours
        time_limit = 4 * 60 * 60 + 60  # 4 hours + 1 minute

    @classmethod
    def config_information(cls):
        """Dictionary describing the configuration of this DataSource."""
        return {}

    @classmethod
    def data_mappings(cls):
        """List describing the data mappings involved in this DataSource."""
        return ()

    def load_source_adapter(self):
        """Load data from Panorama into DiffSync models using ExternalIntegration config."""
        client = self._build_panorama_client()
        self.source_adapter = PanoramaRemoteAdapter(job=self, sync=self.sync, client=client)
        self.source_adapter.load()

    def log_debug(self, message: str, extra: dict | None = None):
        """Log a debug message only when the job's debug option is enabled."""
        if getattr(self, "debug", False):
            if extra is None:
                extra = {"grouping": "panorama-debug"}
            else:
                extra.setdefault("grouping", "panorama-debug")
            self.logger.debug(message, extra=extra)

    def load_target_adapter(self):
        """Load data from Nautobot into DiffSync models."""
        self.target_adapter = PanoramaLocalAdapter(job=self, sync=self.sync)
        self.target_adapter.load()

    def _build_panorama_client(self):
        """Instantiate Panorama SDK client (REST deprecated)."""
        ei = self.panorama_integration
        if ei is None:
            raise ValueError("ExternalIntegration is required for PanoramaDataSource.")
        sdk_client = PanoramaSdkClient.from_external_integration(ei, logger=self.logger, job=self)
        # Best-effort connect; if it fails we raise to abort sync (no fallback).
        if not sdk_client.connect():  # pragma: no cover - network side-effect
            raise RuntimeError("Panorama SDK client connection failed; cannot proceed with sync.")
        return sdk_client

    def run(  # pylint: disable=arguments-differ,too-many-arguments
        self, debug, dryrun, memory_profiling, panorama_integration, *args, enable_deletion=False, **kwargs
    ):
        """Perform data synchronization."""
        self.debug = debug
        self.dryrun = dryrun
        self.memory_profiling = memory_profiling
        self.panorama_integration = panorama_integration
        self.enable_deletion = enable_deletion

        # Configure diffsync_flags based on enable_deletion setting
        # By default, SKIP_UNMATCHED_DST prevents deletion of objects not in source
        if not enable_deletion:
            self.diffsync_flags = (
                DiffSyncFlags.CONTINUE_ON_FAILURE
                | DiffSyncFlags.LOG_UNCHANGED_RECORDS
                | DiffSyncFlags.SKIP_UNMATCHED_DST
            )
            self.logger.info(
                "Deletion disabled - objects in Nautobot not present in Panorama will be skipped",
                extra={"grouping": "panorama-run"},
            )
        else:
            self.diffsync_flags = DiffSyncFlags.CONTINUE_ON_FAILURE | DiffSyncFlags.LOG_UNCHANGED_RECORDS
            self.logger.warning(
                "Deletion ENABLED - objects in Nautobot not present in Panorama will be DELETED",
                extra={"grouping": "panorama-run"},
            )

        self.logger.info("Starting Panorama -> Nautobot sync", extra={"grouping": "panorama-run"})
        try:
            # Call parent run but intercept to add diagnostic logging
            super().run(dryrun=self.dryrun, memory_profiling=self.memory_profiling, *args, **kwargs)

            # Apply deferred tags after sync completes
            if hasattr(self, "target_adapter") and hasattr(self.target_adapter, "apply_deferred_tags"):
                self.logger.info("Applying deferred tags...", extra={"grouping": "panorama-run"})
                self.target_adapter.apply_deferred_tags()

            # Process scheduled deletions if not a dry run and deletion is enabled
            if not self.dryrun and self.enable_deletion:
                if hasattr(self, "target_adapter") and hasattr(self.target_adapter, "process_deletions"):
                    self.logger.info("Processing deletions...", extra={"grouping": "panorama-run"})
                    self.target_adapter.process_deletions()

            self.logger.success("Panorama -> Nautobot sync completed", extra={"grouping": "panorama-run"})
            # Tagging now handled during create() in CRUD models; legacy method retained no-op.
        except Exception as exc:  # pylint: disable=broad-except
            self.logger.failure("Panorama -> Nautobot sync failed: %s", exc, extra={"grouping": "panorama-run"})
            raise

    def calculate_diff(self):
        """Override to add diagnostic logging and CSV report for spurious updates/creates."""
        diff = super().calculate_diff()  # pylint: disable=assignment-from-no-return

        # Check both the returned diff and self.diff (where SSoT might store it)
        actual_diff = diff if diff is not None else getattr(self, "diff", None)

        if self.debug and actual_diff is not None:
            self._generate_diff_report(actual_diff)

        return diff

    def _generate_diff_report(self, diff_obj):
        """Generate a detailed CSV diff report and attach it to the job.

        Args:
            diff_obj: The DiffSync Diff object containing all diff elements.
        """
        # Collect all diff entries
        diff_entries = []

        # Use DiffSync's built-in summary() for accurate counts
        try:
            official_summary = diff_obj.summary() if hasattr(diff_obj, "summary") else {}
        except Exception:  # pylint: disable=broad-except
            official_summary = {}

        try:
            self._collect_diff_entries(diff_obj, diff_entries)
        except Exception as exc:  # pylint: disable=broad-except
            self.logger.warning("Error collecting diff entries: %s", exc)
            return

        # Log summary using official DiffSync summary
        self.logger.info("Diff Summary (official): %s", official_summary, extra={"grouping": "panorama-diff"})
        self.logger.info(
            "Diff entries collected for CSV: %s create/update items",
            len(diff_entries),
            extra={"grouping": "panorama-diff"},
        )

        # Generate CSV if there are creates or updates
        create_count = official_summary.get("create", 0)
        update_count = official_summary.get("update", 0)
        if create_count > 0 or update_count > 0 or diff_entries:
            try:
                self._write_diff_csv(diff_entries, official_summary)
            except Exception as exc:  # pylint: disable=broad-except
                self.logger.warning("Error writing diff CSV report: %s", exc)

    def _collect_diff_entries(self, diff_obj, entries, parent_path=""):
        """Recursively collect diff entries from a Diff object.

        Args:
            diff_obj: A Diff or DiffElement object.
            entries: List to append diff entry dicts to.
            parent_path: String path for nested children context.
        """
        # Handle top-level Diff object - iterate through groups then children
        if hasattr(diff_obj, "groups"):
            # This is a Diff object - iterate through all groups
            for group_name in diff_obj.groups():
                group_children = diff_obj.children.get(group_name, {})
                for child in group_children.values():
                    self._collect_diff_element(child, entries, parent_path)
        elif hasattr(diff_obj, "get_children"):
            # Fallback for objects with get_children method
            for child in diff_obj.get_children():
                self._collect_diff_element(child, entries, parent_path)

    def _collect_diff_element(self, element, entries, parent_path=""):
        """Process a single DiffElement and its children.

        Args:
            element: A DiffElement object.
            entries: List to append diff entry dicts to.
            parent_path: String path for nested children context.
        """
        # Get action - handle both enum and string
        action = getattr(element, "action", None)
        action_str = None

        if action is not None:
            # Normalize action to string - DiffSyncActions enum has name and value attributes
            if hasattr(action, "name"):
                # It's an enum - use the name (CREATE, UPDATE, DELETE, SKIP)
                action_str = action.name.lower()
            elif hasattr(action, "value"):
                action_str = str(action.value).lower()
            else:
                action_str = str(action).lower()

            # Map DiffSyncActions enum values and other possible representations
            action_map = {
                "create": "create",
                "update": "update",
                "delete": "delete",
                "skip": "no-change",
                "+": "create",
                "-": "delete",
                "~": "update",
                "none": "no-change",
            }
            action_str = action_map.get(action_str, action_str)

        # Get model type and unique identifier
        model_type = getattr(element, "type", getattr(element, "_modelname", "unknown"))
        unique_id = self._get_element_unique_id(element)

        # Build current path for context
        current_path = f"{parent_path}/{model_type}:{unique_id}" if parent_path else f"{model_type}:{unique_id}"

        # Only record creates and updates in detail
        if action_str in ("create", "update"):
            entry = self._build_diff_entry(element, action_str, model_type, unique_id, current_path)
            entries.append(entry)

        # Process children recursively - ALWAYS check for children even if this element has no action
        # DiffElement stores children in a 'child_diff' attribute (nested Diff object)
        child_diff = getattr(element, "child_diff", None)
        if child_diff is not None:
            self._collect_diff_entries(child_diff, entries, current_path)
        # Also check for direct children via get_children method
        if hasattr(element, "get_children"):
            for child in element.get_children():
                self._collect_diff_element(child, entries, current_path)

    def _get_element_unique_id(self, element):
        """Extract a unique identifier from a DiffElement.

        Args:
            element: A DiffElement object.

        Returns:
            String unique identifier.
        """
        # Try common identifier attributes
        for attr in ("name", "unique_id", "key", "keys"):
            val = getattr(element, attr, None)
            if val is not None:
                if isinstance(val, (list, tuple)):
                    return "|".join(str(v) for v in val)
                return str(val)

        # Fallback to source/dest model identifiers
        src = getattr(element, "source", None)
        if src and hasattr(src, "get_unique_id"):
            return src.get_unique_id()
        dst = getattr(element, "dest", None)
        if dst and hasattr(dst, "get_unique_id"):
            return dst.get_unique_id()

        return "unknown"

    def _build_diff_entry(self, element, action, model_type, unique_id, path):  # pylint: disable=too-many-locals,too-many-arguments
        """Build a diff entry dict for CSV output.

        Args:
            element: DiffElement object.
            action: Action string (create/update).
            model_type: Model type name.
            unique_id: Unique identifier string.
            path: Full path context.

        Returns:
            Dict with diff entry details.
        """
        entry = {
            "action": action,
            "model_type": model_type,
            "unique_id": unique_id,
            "path": path,
            "changed_attrs": "",
            "source_values": "",
            "dest_values": "",
            "all_source_attrs": "",
            "all_dest_attrs": "",
        }

        # Get source and dest attributes
        src_attrs = getattr(element, "source_attrs", None) or {}
        dst_attrs = getattr(element, "dest_attrs", None) or {}

        # For creates, source_attrs contains the new values
        # For updates, we need to compare source vs dest
        if action == "create":
            entry["changed_attrs"] = ", ".join(sorted(src_attrs.keys())) if src_attrs else "(all - new object)"
            entry["source_values"] = self._format_attrs(src_attrs)
            entry["dest_values"] = "(does not exist)"
            entry["all_source_attrs"] = self._format_attrs(src_attrs)

            # Also try to get full model data from source object
            src_model = getattr(element, "source", None)
            if src_model:
                entry["all_source_attrs"] = self._format_model_attrs(src_model)

        elif action == "update":
            # Find which attributes differ
            changed = []
            src_diff = {}
            dst_diff = {}

            all_keys = set(src_attrs.keys()) | set(dst_attrs.keys())
            for k in sorted(all_keys):
                src_val = src_attrs.get(k)
                dst_val = dst_attrs.get(k)
                if src_val != dst_val:
                    changed.append(k)
                    src_diff[k] = src_val
                    dst_diff[k] = dst_val

            entry["changed_attrs"] = ", ".join(changed)
            entry["source_values"] = self._format_attrs(src_diff)
            entry["dest_values"] = self._format_attrs(dst_diff)
            entry["all_source_attrs"] = self._format_attrs(src_attrs)
            entry["all_dest_attrs"] = self._format_attrs(dst_attrs)

        return entry

    def _format_attrs(self, attrs):
        """Format attributes dict as a readable string.

        Args:
            attrs: Dict of attribute name to value.

        Returns:
            Formatted string representation.
        """
        if not attrs:
            return ""
        parts = []
        for k, v in sorted(attrs.items()):
            # No truncation - show full values for debugging
            v_str = str(v)
            parts.append(f"{k}={v_str}")
        return "; ".join(parts)

    def _format_model_attrs(self, model):
        """Format all attributes from a DiffSyncModel.

        Args:
            model: A DiffSyncModel instance.

        Returns:
            Formatted string of all model attributes.
        """
        if model is None:
            return ""
        try:
            # Get identifiers and attributes from model class
            identifiers = getattr(model, "_identifiers", ()) or ()
            attributes = getattr(model, "_attributes", ()) or ()

            parts = []
            for attr_name in list(identifiers) + list(attributes):
                val = getattr(model, attr_name, None)
                # No truncation - show full values for debugging
                v_str = str(val) if val is not None else "None"
                parts.append(f"{attr_name}={v_str}")
            return "; ".join(parts)
        except Exception:  # pylint: disable=broad-except
            return str(model)

    def _write_diff_csv(self, entries, summary):
        """Write diff entries to a CSV file and attach to job.

        Args:
            entries: List of diff entry dicts.
            summary: Dict with summary counts.
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"panorama_diff_report_{timestamp}.csv"

        # Create CSV in memory
        output = io.StringIO()
        fieldnames = [
            "action",
            "model_type",
            "unique_id",
            "changed_attrs",
            "source_values",
            "dest_values",
            "all_source_attrs",
            "all_dest_attrs",
            "path",
        ]
        writer = csv.DictWriter(output, fieldnames=fieldnames, extrasaction="ignore")

        # Write header comment with summary
        output.write(f"# Panorama SSoT Diff Report - Generated {timestamp}\n")
        output.write(f"# Summary: create={summary['create']}, update={summary['update']}, ")
        output.write(f"delete={summary['delete']}, no-change={summary['no-change']}\n")
        output.write("#\n")

        writer.writeheader()

        # Sort entries: creates first, then updates, alphabetically within each
        sorted_entries = sorted(
            entries, key=lambda e: (0 if e["action"] == "create" else 1, e["model_type"], e["unique_id"])
        )
        for entry in sorted_entries:
            writer.writerow(entry)

        csv_content = output.getvalue()
        output.close()

        # Attach file to job result
        try:
            self.create_file(filename, csv_content)
            self.logger.info(
                "Created diff report: %s (%s entries)",
                filename,
                len(entries),
                extra={"grouping": "panorama-diff"},
            )
        except Exception as exc:  # pylint: disable=broad-except
            self.logger.warning("Failed to attach diff report file: %s", exc)

    def _ensure_panorama_tags(self):  # pragma: no cover
        """Legacy tagging path retained for backward compatibility (no-op)."""
        return


class PanoramaDataTarget(DataTarget):
    """Panorama SSoT Data Target (SDK-only)."""

    debug = BooleanVar(description="Enable for more verbose debug logging", default=False)
    panorama_integration = None

    class Meta:  # pylint: disable=too-few-public-methods
        """Meta data for Panorama."""

        name = "Nautobot to Panorama"
        data_source = "Nautobot"
        data_target = "Panorama"
        description = "Sync information from Nautobot to Panorama"

    @classmethod
    def config_information(cls):
        """Dictionary describing the configuration of this DataTarget."""
        return {}

    @classmethod
    def data_mappings(cls):
        """List describing the data mappings involved in this DataSource."""
        return ()

    def load_source_adapter(self):
        """Load data from Nautobot into DiffSync models."""
        self.source_adapter = PanoramaLocalAdapter(job=self, sync=self.sync)
        self.source_adapter.load()

    def load_target_adapter(self):
        """Load data from Panorama into DiffSync models (SDK-only)."""
        client = self._build_panorama_client()
        self.target_adapter = PanoramaRemoteAdapter(job=self, sync=self.sync, client=client)
        self.target_adapter.load()

    def _build_panorama_client(self):
        """Instantiate Panorama SDK client (REST deprecated)."""
        ei = self.panorama_integration
        if ei is None:
            raise ValueError("ExternalIntegration is required for PanoramaDataTarget.")
        sdk_client = PanoramaSdkClient.from_external_integration(ei, logger=self.logger, job=self)
        # Best-effort connect; if it fails we raise to abort sync (no fallback).
        if not sdk_client.connect():  # pragma: no cover - network side-effect
            raise RuntimeError("Panorama SDK client connection failed; cannot proceed with sync.")
        return sdk_client

    def run(self, dryrun, memory_profiling, debug, *args, **kwargs):  # pylint: disable=arguments-differ,too-many-arguments
        """Perform data synchronization."""
        self.debug = debug
        self.dryrun = dryrun
        self.memory_profiling = memory_profiling
        self.logger.info("Starting Nautobot -> Panorama sync", extra={"grouping": "panorama-run"})
        try:
            super().run(dryrun=self.dryrun, memory_profiling=self.memory_profiling, *args, **kwargs)
            self.logger.success("Nautobot -> Panorama sync completed", extra={"grouping": "panorama-run"})
        except Exception as exc:  # pylint: disable=broad-except
            self.logger.failure(
                "Nautobot -> Panorama sync failed: %s",
                exc,
                extra={"grouping": "panorama-run"},
            )
            raise

    def execute_sync(self):
        """Method to synchronize the difference from `self.diff`, from SOURCE to TARGET adapter.

        Overridden to use a CustomOrderingDiff diff_class.
        """
        if self.source_adapter is not None and self.target_adapter is not None:
            self.source_adapter.sync_to(self.target_adapter, flags=self.diffsync_flags, diff_class=CustomOrderingDiff)
        else:
            self.logger.failure("Adapters not initialized; aborting sync.", extra={"grouping": "panorama-run"})


jobs = [PanoramaDataSource, PanoramaDataTarget]
register_jobs(*jobs)
