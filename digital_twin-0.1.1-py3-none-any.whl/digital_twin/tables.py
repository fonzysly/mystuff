"""Tables for digital_twin."""

from datetime import timezone as datetime_timezone

import django_tables2 as tables
from django.utils import timezone
from django.utils.formats import date_format
from django.utils.html import format_html
from nautobot.apps.tables import BaseTable, ButtonsColumn, ToggleColumn

from digital_twin import models


class DeviceScopeTable(BaseTable):
    """Table for DeviceScope list."""

    pk = ToggleColumn()
    name = tables.Column(linkify=True)
    actions = ButtonsColumn(models.DeviceScope, pk_field="pk")

    class Meta(BaseTable.Meta):
        model = models.DeviceScope
        fields = ("pk", "name", "scope_type", "description", "actions")
        default_columns = ("pk", "name", "scope_type", "description", "actions")


class TwinSnapshotTable(BaseTable):
    """Table for TwinSnapshot list."""

    pk = ToggleColumn()
    scope = tables.Column(linkify=True)
    status = tables.Column()
    actions = ButtonsColumn(models.TwinSnapshot, pk_field="pk")

    class Meta(BaseTable.Meta):
        model = models.TwinSnapshot
        fields = ("pk", "scope", "status", "created", "notes", "actions")
        default_columns = ("pk", "scope", "status", "created", "actions")

    def render_created(self, value):
        """Render created timestamp in friendly local format."""
        if value is None:
            return ""
        fallback = date_format(timezone.localtime(value), format="N j, Y, P T", use_l10n=True)
        value_utc = timezone.localtime(value, datetime_timezone.utc).isoformat()
        return format_html(
            '<time class="dt-localized-datetime" data-utc="{}">{}</time>'
            "<script>"
            'window.__dtLocalizeDateTime=window.__dtLocalizeDateTime||(()=>document.querySelectorAll("time.dt-localized-datetime[data-utc]").forEach(el=>el.textContent=new Date(el.dataset.utc).toLocaleString()));'
            "window.__dtLocalizeDateTime();"
            "</script>",
            value_utc,
            fallback,
        )
