"""App declaration for digital_twin."""

# Metadata is inherited from Nautobot. If not including Nautobot in the environment, this should be added
from importlib import metadata

from nautobot.apps import NautobotAppConfig

__version__ = metadata.version(__name__)


class DigitalTwinConfig(NautobotAppConfig):
    """App configuration for the digital_twin app."""

    name = "digital_twin"
    verbose_name = "Digital Twin"
    version = __version__
    author = "Eric Fetty"
    description = "Digital Twin."
    base_url = "digital_twin"
    required_settings = []
    default_settings = {}
    docs_view_name = "plugins:digital_twin:docs"
    searchable_models = ["devicescope", "twinsnapshot"]


config = DigitalTwinConfig  # pylint:disable=invalid-name
