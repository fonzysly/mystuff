"""Django urlpatterns declaration for digital_twin app."""

from django.templatetags.static import static
from django.urls import path
from django.views.generic import RedirectView
from nautobot.apps.urls import NautobotUIViewSetRouter

from digital_twin import views

app_name = "digital_twin"
router = NautobotUIViewSetRouter()

router.register("device-scopes", views.DeviceScopeUIViewSet)
router.register("twin-snapshots", views.TwinSnapshotUIViewSet)


urlpatterns = [
    path("docs/", RedirectView.as_view(url=static("digital_twin/docs/index.html")), name="docs"),
    path("reachability/query/", views.ReachabilityQueryView.as_view(), name="reachability_query"),
    path("snapshot-diff/query/", views.SnapshotDiffQueryView.as_view(), name="snapshot_diff_query"),
]

urlpatterns += router.urls
