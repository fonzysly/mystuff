"""Filtering for digital_twin."""

from nautobot.apps.filters import NameSearchFilterSet, NautobotFilterSet

from digital_twin import models


class DeviceScopeFilterSet(NameSearchFilterSet, NautobotFilterSet):
    """Filter for DeviceScope."""

    class Meta:
        model = models.DeviceScope
        fields = ["id", "name", "scope_type", "created", "last_updated"]


class TwinSnapshotFilterSet(NameSearchFilterSet, NautobotFilterSet):
    """Filter for TwinSnapshot."""

    class Meta:
        model = models.TwinSnapshot
        fields = ["id", "scope", "status", "created", "last_updated"]
