"""Unit tests for Netmiko-based collectors."""

import json
from types import SimpleNamespace
from unittest.mock import patch

from django.test import TestCase

from digital_twin import collectors


class _FakeConnection:
    """Minimal fake Netmiko connection context manager."""

    def __init__(self, outputs):
        self.outputs = outputs
        self.commands = []
        self.enabled = False

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def enable(self):
        self.enabled = True

    def send_command(self, command, read_timeout=30):
        self.commands.append((command, read_timeout))
        return self.outputs.get(command, "")


class CollectorTests(TestCase):
    """Collector behavior tests with mocked Netmiko."""

    def _device(self, platform_name="Cisco IOS", address="172.22.8.29/24"):
        normalized = platform_name.lower()
        if "nx" in normalized:
            network_driver = "cisco_nxos"
        elif "ios" in normalized or "xe" in normalized or "catalyst" in normalized:
            network_driver = "cisco_ios"
        elif "palo" in normalized or "pan" in normalized:
            network_driver = "paloalto_panos"
        else:
            network_driver = "cisco_ios"
        return SimpleNamespace(
            name="test-device",
            platform=SimpleNamespace(name=platform_name, network_driver=network_driver),
            primary_ip4=SimpleNamespace(address=address),
        )

    def test_collect_ssh_state_cisco_ios(self):
        outputs = {
            "show ip route": "C    10.0.0.0/8 is directly connected, GigabitEthernet0/0\n"
            "S*   0.0.0.0/0 [1/0] via 192.0.2.1",
            "show vrf": "Name                             Default RD            Protocols   Interfaces\n"
            "LAB                              <not set>             ipv4        Vl20\n",
            "show ip route vrf LAB": "Routing Table: LAB\nO    10.255.0.1/32 [110/41] via 172.16.2.2",
            "show ip interface brief": "Interface              IP-Address      OK? Method Status                Protocol\n"
            "GigabitEthernet0/0     10.0.0.1        YES NVRAM  up                    up",
            "show ip arp": "Internet 10.0.0.2 3 0011.2233.4455 ARPA Vlan10",
            "show mac address-table": "  10  0011.2233.4455 DYNAMIC Gi0/1",
            "show standby brief": "Interface   Grp  Pri P State   Active          Standby         Virtual IP\n"
            "Vlan10      10   110 P Active  local           10.0.0.2        10.0.0.1",
            "show vrrp brief": "",
            "show access-lists": "Extended IP access list ACL-IN\n10 permit ip any any",
            "show running-config": "interface Vlan10\n"
            " ip nat inside\n"
            "interface GigabitEthernet0/0\n"
            " ip nat outside\n"
            "ip access-list standard HIDE-NAT\n"
            " permit 10.0.0.0 0.0.0.255\n"
            "ip nat inside source list HIDE-NAT interface GigabitEthernet0/0 overload\n"
            "ip nat inside source static tcp 10.10.10.10 8443 203.0.113.10 443\n"
            "hostname test-device",
        }
        fake_connection = _FakeConnection(outputs)

        with patch.object(collectors, "ConnectHandler", return_value=fake_connection):
            artifacts = collectors.collect_ssh_state(self._device(platform_name="Cisco IOS-XE"))

        artifact_types = {item["artifact_type"] for item in artifacts}
        self.assertIn("show_route_raw", artifact_types)
        self.assertIn("show_vrf_raw", artifact_types)
        self.assertIn("show_interface_raw", artifact_types)
        self.assertIn("show_arp_raw", artifact_types)
        self.assertIn("show_mac_raw", artifact_types)
        self.assertIn("show_fhrp_raw", artifact_types)
        self.assertIn("show_acl_raw", artifact_types)
        self.assertIn("show_run", artifact_types)
        self.assertIn("cisco_route_table", artifact_types)
        self.assertIn("interface_state", artifact_types)
        self.assertIn("cisco_nat_table", artifact_types)

        sent = [command for command, _timeout in fake_connection.commands]
        self.assertIn("show vrf", sent)
        self.assertIn("show ip route vrf LAB", sent)
        self.assertIn("show ip arp vrf LAB", sent)
        self.assertIn("show standby brief", sent)
        self.assertIn("show access-lists", sent)

        cisco_route_artifact = next(item for item in artifacts if item["artifact_type"] == "cisco_route_table")
        self.assertIn("LAB 10.255.0.1/32 172.16.2.2 ospf 41", cisco_route_artifact["content"])

        interface_state_artifact = next(item for item in artifacts if item["artifact_type"] == "interface_state")
        interface_rows = json.loads(interface_state_artifact["content"])
        self.assertEqual(len(interface_rows), 1)
        self.assertEqual(interface_rows[0]["name"], "GigabitEthernet0/0")
        self.assertTrue(interface_rows[0]["admin_up"])
        self.assertTrue(interface_rows[0]["oper_up"])

        nat_artifact = next(item for item in artifacts if item["artifact_type"] == "cisco_nat_table")
        nat_payload = json.loads(nat_artifact["content"])
        self.assertEqual(nat_payload["tables"][0]["table_scope"], "GLOBAL")
        nat_rules = nat_payload["tables"][0]["rules"]
        self.assertEqual(len(nat_rules), 2)
        self.assertEqual(nat_rules[0]["inside_interface"], "vlan10")
        self.assertEqual(nat_rules[0]["outside_interface"], "gigabitethernet0/0")
        self.assertEqual(nat_rules[0]["conditions_json"], {"src_prefix": "10.0.0.0/24"})
        self.assertEqual(nat_rules[0]["translations_json"], {"src_ip": "10.0.0.1"})
        static_rule = next(rule for rule in nat_rules if (rule.get("attrs_json") or {}).get("kind") == "static")
        self.assertEqual(static_rule["inside_interface"], "vlan10")
        self.assertEqual(static_rule["outside_interface"], "gigabitethernet0/0")
        self.assertEqual(static_rule["conditions_json"]["src_prefix"], "10.10.10.10/32")
        self.assertEqual(static_rule["translations_json"]["src_ip"], "203.0.113.10")

    def test_collect_ssh_state_nxos_commands(self):
        outputs = {
            "show ip route vrf all": "C    10.10.0.0/16 is directly connected",
            "show ip interface brief vrf all": "Eth1/1               10.10.10.1      protocol-up/link-up/admin-up",
            "show ip access-lists": "IP access list ACL-EDGE\n10 permit ip any any",
            "show running-config": "feature ospf",
        }
        fake_connection = _FakeConnection(outputs)

        with patch.object(collectors, "ConnectHandler", return_value=fake_connection):
            collectors.collect_ssh_state(self._device(platform_name="Cisco NX-OS", address="172.22.8.27/24"))

        sent = [command for command, _timeout in fake_connection.commands]
        self.assertIn("show ip route vrf all", sent)
        self.assertIn("show ip interface brief vrf all", sent)
        self.assertIn("show ip access-lists", sent)

    def test_collect_ssh_state_requires_netmiko(self):
        with patch.object(collectors, "ConnectHandler", None):
            with self.assertRaises(RuntimeError):
                collectors.collect_ssh_state(self._device())

    def test_to_cisco_route_artifact_parses_nxos_vrf_routes(self):
        route_output = (
            'IP Route Table for VRF "LAB"\n'
            "10.255.0.1/32, ubest/mbest: 1/0\n"
            "    *via 172.16.2.5, Eth1/2, [110/81], 01:42:36, ospf-10, intra\n"
            "10.10.20.0/24, ubest/mbest: 1/0, attached\n"
            "    *via 10.10.20.3, Vlan20, [0/0], 13:33:50, direct\n"
        )

        parsed = collectors._to_cisco_route_artifact(route_output).splitlines()
        self.assertIn("LAB 10.255.0.1/32 172.16.2.5 ospf-10 81", parsed)
        self.assertIn("LAB 10.10.20.0/24 0.0.0.0 direct 0", parsed)

    def test_to_cisco_route_artifact_adds_default_from_gateway_when_missing(self):
        route_output = (
            "Gateway of last resort is 172.22.8.1 to network 0.0.0.0\n\n"
            "C    10.10.20.0/24 is directly connected, Vlan20\n"
        )

        parsed = collectors._to_cisco_route_artifact(route_output).splitlines()
        self.assertIn("default 0.0.0.0/0 172.22.8.1 static 1", parsed)

    def test_to_interface_state_artifact_parses_nxos_compact_format(self):
        interface_output = "Eth1/1               10.10.10.1      protocol-up/link-up/admin-up\n"
        parsed = json.loads(collectors._to_interface_state_artifact(interface_output))
        self.assertEqual(len(parsed), 1)
        self.assertEqual(parsed[0]["name"], "Eth1/1")
        self.assertTrue(parsed[0]["admin_up"])
        self.assertTrue(parsed[0]["oper_up"])
        self.assertEqual(parsed[0]["ips"], ["10.10.10.1/32"])

    def test_extract_ios_vrf_names(self):
        show_vrf_output = (
            "Name                             Default RD            Protocols   Interfaces\n"
            "LAB                              <not set>             ipv4        Vl20\n"
            "Prod                             65000:1               ipv4        Vl10\n"
            "default                          <not set>             ipv4        Gi0/0\n"
        )
        self.assertEqual(collectors._extract_ios_vrf_names(show_vrf_output), ["LAB", "Prod"])

    def test_to_cisco_nat_table_artifact_separates_global_and_vrf_roles(self):
        interface_output = (
            "GigabitEthernet0/1     172.16.1.2      YES NVRAM  up                    up\n"
            "GigabitEthernet0/2     10.255.2.2      YES NVRAM  up                    up\n"
            "GigabitEthernet0/3     1.2.3.254       YES NVRAM  up                    up\n"
            "GigabitEthernet0/4     4.3.2.254       YES NVRAM  up                    up\n"
        )
        running_config = (
            "interface GigabitEthernet0/1\n"
            " ip nat outside\n"
            "interface GigabitEthernet0/2\n"
            " ip nat inside\n"
            "interface GigabitEthernet0/3\n"
            " ip vrf forwarding NAT-TEST\n"
            " ip nat inside\n"
            "interface GigabitEthernet0/4\n"
            " ip vrf forwarding NAT-TEST\n"
            " ip nat outside\n"
            "ip access-list standard HIDE-NAT\n"
            " permit 10.255.0.0 0.0.255.255\n"
            "ip nat inside source list HIDE-NAT interface GigabitEthernet0/1 overload\n"
            "ip nat inside source static 10.255.2.1 172.16.1.2\n"
            "ip nat inside source static 1.2.3.4 4.3.2.1 vrf NAT-TEST\n"
        )

        payload = json.loads(
            collectors._to_cisco_nat_table_artifact(
                running_config,
                "cisco_ios",
                interface_output,
            )
        )

        tables = {(table["table_scope"], table["vrf_name"]): table for table in payload["tables"]}
        self.assertIn(("GLOBAL", ""), tables)
        self.assertIn(("VRF", "NAT-TEST"), tables)

        global_rules = tables[("GLOBAL", "")]["rules"]
        vrf_rules = tables[("VRF", "NAT-TEST")]["rules"]

        self.assertEqual(len(global_rules), 2)
        self.assertEqual(len(vrf_rules), 1)

        self.assertTrue(
            any(
                rule["inside_interface"] == "gigabitethernet0/2"
                and rule["outside_interface"] == "gigabitethernet0/1"
                and rule["conditions_json"].get("src_prefix") == "10.255.2.1/32"
                and rule["translations_json"].get("src_ip") == "172.16.1.2"
                for rule in global_rules
            )
        )
        self.assertEqual(vrf_rules[0]["inside_interface"], "gigabitethernet0/3")
        self.assertEqual(vrf_rules[0]["outside_interface"], "gigabitethernet0/4")
        self.assertEqual(vrf_rules[0]["conditions_json"].get("src_prefix"), "1.2.3.4/32")
        self.assertEqual(vrf_rules[0]["translations_json"].get("src_ip"), "4.3.2.1")

    def test_resolve_credentials_from_secrets_group(self):
        class _SG:
            def get_secret_value(self, access_type, secret_type, obj=None):
                mapping = {
                    ("SSH", "username"): "sg-user",
                    ("SSH", "password"): "sg-pass",
                    ("SSH", "secret"): "sg-enable",
                }
                return mapping[(access_type, secret_type)]

        device = self._device()
        device.secrets_group = _SG()
        username, password, secret = collectors._resolve_ssh_credentials(device)
        self.assertEqual(username, "sg-user")
        self.assertEqual(password, "sg-pass")
        self.assertEqual(secret, "sg-enable")

    @patch.dict(
        "os.environ", {"DIGITAL_TWIN_SSH_USERNAME": "env-user", "DIGITAL_TWIN_SSH_PASSWORD": "env-pass"}, clear=True
    )
    def test_resolve_credentials_env_fallback(self):
        device = self._device()
        device.secrets_group = None
        username, password, secret = collectors._resolve_ssh_credentials(device)
        self.assertEqual(username, "env-user")
        self.assertEqual(password, "env-pass")
        self.assertEqual(secret, "")
