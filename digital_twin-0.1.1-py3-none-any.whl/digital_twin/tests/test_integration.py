"""Integration test for Collect -> Normalize -> Build -> API reachability."""

import json
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.test import TestCase

try:
    from nautobot.dcim.tests.test_views import create_test_device
except ImportError:  # pragma: no cover
    from nautobot.dcim.tests.test_filters import create_test_device

from digital_twin import models
from digital_twin.jobs import BuildTwinJob, CollectSnapshotJob, NormalizeSnapshotJob


class SnapshotToApiIntegrationTest(TestCase):
    """End-to-end integration against fixture artifacts."""

    endpoint = "/api/plugins/digital_twin/reachability/"

    @classmethod
    def setUpTestData(cls):
        cls.scope = models.DeviceScope.objects.create(
            name="Integration Scope", scope_type=models.ScopeTypeChoices.STATIC
        )
        cls.device = create_test_device(name="integration-device")
        cls.scope.devices.add(cls.device)
        user_model = get_user_model()
        cls.user = user_model.objects.create_superuser(
            username="integrationadmin",
            password="password",
            email="integrationadmin@example.com",
        )

    def setUp(self):
        self.client.force_login(self.user)

    def test_end_to_end_workflow(self):
        artifact_payload = [
            {
                "artifact_type": "cisco_route_table",
                "content": "default 198.51.100.0/24 192.0.2.1 static 1",
            },
            {
                "artifact_type": "cisco_nat_table",
                "content": json.dumps(
                    {
                        "schema_version": 1,
                        "platform_driver": "cisco_ios",
                        "tables": [
                            {
                                "table_scope": "GLOBAL",
                                "vrf_name": "",
                                "rules": [
                                    {
                                        "inside_interface": "vlan10",
                                        "outside_interface": "gigabitethernet0/0",
                                        "conditions_json": {
                                            "dst_prefix": "198.51.100.0/24",
                                            "protocol": "tcp",
                                            "port": 443,
                                        },
                                        "translations_json": {"dst_ip": "198.51.100.10", "dst_port": 8443},
                                        "order": 10,
                                    }
                                ],
                            }
                        ],
                    }
                ),
            },
            {
                "artifact_type": "f5_ltm_dump",
                "content": json.dumps(
                    [
                        {
                            "vip": "203.0.113.100",
                            "pool": "pool-web",
                            "members": ["198.51.100.10"],
                            "snat": "automap",
                            "has_irules": True,
                        }
                    ]
                ),
            },
        ]

        with patch("digital_twin.collectors.collect_device_artifacts", return_value=artifact_payload):
            snapshot_id = CollectSnapshotJob().run(scope=self.scope, notes="integration test")

        snapshot = models.TwinSnapshot.objects.get(pk=snapshot_id)
        device_state = models.DeviceSnapshotState.objects.create(snapshot=snapshot)
        for artifact in artifact_payload:
            models.StateArtifact.objects.create(
                device_state=device_state,
                artifact_type=artifact["artifact_type"],
                content=artifact["content"],
                checksum="integration",
            )
        NormalizeSnapshotJob().run(snapshot=snapshot)
        BuildTwinJob().run(snapshot=snapshot)
        snapshot.refresh_from_db()
        self.assertEqual(snapshot.status, models.SnapshotStatusChoices.READY)

        response = self.client.post(
            self.endpoint,
            data=json.dumps(
                {
                    "snapshot_id": str(snapshot.pk),
                    "src": "10.0.0.10",
                    "dst": ["203.0.113.100"],
                    "protocol": "tcp",
                    "port": 443,
                    "mode": "ENFORCE_SECURITY",
                }
            ),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(len(data["results"]), 1)
        self.assertEqual(data["results"][0]["dst"], "203.0.113.100")
