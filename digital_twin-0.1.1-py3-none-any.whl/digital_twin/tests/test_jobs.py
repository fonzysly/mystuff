"""Unit tests for digital twin jobs."""

import json
from unittest.mock import patch

from django.test import TestCase

try:
    from nautobot.dcim.tests.test_views import create_test_device
except ImportError:  # pragma: no cover
    from nautobot.dcim.tests.test_filters import create_test_device

from nautobot.extras.models import Note

from digital_twin import models
from digital_twin.jobs import CollectSnapshotJob, NormalizeSnapshotJob


class CollectSnapshotJobTests(TestCase):
    """Tests for collection job behavior."""

    @classmethod
    def setUpTestData(cls):
        cls.device_a = create_test_device(name="job-device-a")
        cls.device_b = create_test_device(name="job-device-b")
        cls.scope = models.DeviceScope.objects.create(name="Job Scope", scope_type=models.ScopeTypeChoices.STATIC)
        cls.scope.devices.add(cls.device_a, cls.device_b)

    def test_collect_continues_when_one_device_fails(self):
        def fake_collect(device):
            if device.name == "job-device-a":
                return [{"artifact_type": "show_run", "content": "hostname ok"}]
            raise RuntimeError("simulated device failure")

        with patch("digital_twin.jobs.collectors.collect_device_artifacts", side_effect=fake_collect):
            with self.assertRaises(RuntimeError):
                CollectSnapshotJob().run(scope=self.scope, notes="job-test")

        snapshot = models.TwinSnapshot.objects.filter(scope=self.scope).order_by("-created").first()
        self.assertIsNotNone(snapshot)
        self.assertEqual(snapshot.status, models.SnapshotStatusChoices.FAILED)
        self.assertIn("job-device-b", snapshot.error_summary)

        states = {state.device.name: state for state in snapshot.device_states.select_related("device")}
        self.assertEqual(states["job-device-a"].collection_status, models.StageStatusChoices.SUCCESS)
        self.assertEqual(states["job-device-b"].collection_status, models.StageStatusChoices.FAILED)
        self.assertEqual(states["job-device-a"].artifacts.count(), 1)
        self.assertEqual(states["job-device-b"].artifacts.count(), 0)

    def test_collect_success_runs_full_pipeline_to_ready(self):
        with patch(
            "digital_twin.jobs.collectors.collect_device_artifacts",
            return_value=[{"artifact_type": "show_run", "content": "hostname ok"}],
        ):
            snapshot_id = CollectSnapshotJob().run(scope=self.scope, notes="job-success")

        snapshot = models.TwinSnapshot.objects.get(pk=snapshot_id)
        self.assertEqual(snapshot.status, models.SnapshotStatusChoices.READY)

    def test_collect_fails_when_scope_is_empty(self):
        empty_scope = models.DeviceScope.objects.create(
            name="Empty Scope",
            scope_type=models.ScopeTypeChoices.STATIC,
        )

        with self.assertRaises(RuntimeError):
            CollectSnapshotJob().run(scope=empty_scope, notes="job-empty")

        snapshot = models.TwinSnapshot.objects.filter(scope=empty_scope).order_by("-created").first()
        self.assertIsNotNone(snapshot)
        self.assertEqual(snapshot.status, models.SnapshotStatusChoices.FAILED)
        self.assertEqual(snapshot.error_summary, "Collection scope resolved to zero devices.")
        self.assertEqual(snapshot.device_states.count(), 0)

    def test_collect_fails_when_collector_returns_no_artifacts(self):
        with patch("digital_twin.jobs.collectors.collect_device_artifacts", return_value=[]):
            with self.assertRaises(RuntimeError):
                CollectSnapshotJob().run(scope=self.scope, notes="job-empty-artifacts")

        snapshot = models.TwinSnapshot.objects.filter(scope=self.scope).order_by("-created").first()
        self.assertIsNotNone(snapshot)
        self.assertEqual(snapshot.status, models.SnapshotStatusChoices.FAILED)
        self.assertIn("Collector returned zero artifacts", snapshot.error_summary)

    def test_collect_persists_snapshot_note(self):
        with patch(
            "digital_twin.jobs.collectors.collect_device_artifacts",
            return_value=[{"artifact_type": "show_run", "content": "hostname ok"}],
        ):
            snapshot_id = CollectSnapshotJob().run(scope=self.scope, notes="captured note")

        snapshot = models.TwinSnapshot.objects.get(pk=snapshot_id)
        note = Note.objects.filter(
            assigned_object_type__app_label="digital_twin",
            assigned_object_type__model="twinsnapshot",
            assigned_object_id=snapshot.pk,
        ).first()
        self.assertIsNotNone(note)
        self.assertEqual(note.note, "captured note")


class NormalizeSnapshotJobTests(TestCase):
    """Tests for normalization behavior."""

    def test_normalize_parses_acl_artifacts_into_acl_rule_state(self):
        scope = models.DeviceScope.objects.create(name="Normalize ACL Scope", scope_type=models.ScopeTypeChoices.STATIC)
        device = create_test_device(name="normalize-acl-device")
        scope.devices.add(device)
        snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.NORMALIZING)
        device_state = models.DeviceSnapshotState.objects.create(snapshot=snapshot, device=device)
        models.StateArtifact.objects.create(
            device_state=device_state,
            artifact_type="show_acl_raw",
            content="Extended IP access list ACL-IN\n10 permit tcp any host 172.16.1.10 eq 443\n20 deny ip any any",
            checksum="a" * 64,
        )

        with patch("digital_twin.jobs.BuildTwinJob.run", return_value=snapshot.pk):
            NormalizeSnapshotJob().run(snapshot=snapshot)

        rules = list(models.AclRuleState.objects.filter(snapshot=snapshot, device=device).order_by("order"))
        self.assertEqual(len(rules), 2)
        self.assertEqual(rules[0].action, models.SecurityActionChoices.ALLOW)
        self.assertEqual(rules[0].protocol, "tcp")
        self.assertEqual(rules[0].dst_prefix, "172.16.1.10/32")
        self.assertEqual(rules[0].port, 443)
        self.assertEqual(rules[1].action, models.SecurityActionChoices.DENY)

    def test_normalize_parses_cisco_nat_table_artifact(self):
        scope = models.DeviceScope.objects.create(name="Normalize NAT Scope", scope_type=models.ScopeTypeChoices.STATIC)
        device = create_test_device(name="normalize-nat-device")
        scope.devices.add(device)
        snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.NORMALIZING)
        device_state = models.DeviceSnapshotState.objects.create(snapshot=snapshot, device=device)
        models.StateArtifact.objects.create(
            device_state=device_state,
            artifact_type="cisco_nat_table",
            content=json.dumps(
                {
                    "schema_version": 1,
                    "platform_driver": "cisco_ios",
                    "tables": [
                        {
                            "table_scope": "GLOBAL",
                            "vrf_name": "",
                            "rules": [
                                {
                                    "inside_interface": "vlan10",
                                    "outside_interface": "gigabitethernet0/0",
                                    "conditions_json": {
                                        "dst_prefix": "203.0.113.10/32",
                                        "protocol": "tcp",
                                        "port": 443,
                                    },
                                    "translations_json": {"dst_ip": "10.10.10.10", "dst_port": 8443},
                                    "order": 10,
                                }
                            ],
                        }
                    ],
                }
            ),
            checksum="b" * 64,
        )

        with patch("digital_twin.jobs.BuildTwinJob.run", return_value=snapshot.pk):
            NormalizeSnapshotJob().run(snapshot=snapshot)

        table = models.NatTableState.objects.get(snapshot=snapshot, device=device)
        self.assertEqual(table.table_scope, models.NatTableScopeChoices.GLOBAL)
        rule = models.NatRuleState.objects.get(snapshot=snapshot, device=device)
        self.assertEqual(rule.nat_table_id, table.id)
        self.assertEqual(rule.inside_interface, "vlan10")
        self.assertEqual(rule.outside_interface, "gigabitethernet0/0")
