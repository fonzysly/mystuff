"""Filter tests for digital twin."""

from django.test import TestCase

from digital_twin import filters, models


class DeviceScopeFilterTestCase(TestCase):
    """DeviceScope filter test case."""

    @classmethod
    def setUpTestData(cls):
        models.DeviceScope.objects.create(name="Scope One", scope_type=models.ScopeTypeChoices.STATIC)
        models.DeviceScope.objects.create(name="Scope Two", scope_type=models.ScopeTypeChoices.STATIC)

    def test_q_search_name(self):
        queryset = models.DeviceScope.objects.all()
        params = {"q": "Scope One"}
        self.assertEqual(filters.DeviceScopeFilterSet(params, queryset).qs.count(), 1)
