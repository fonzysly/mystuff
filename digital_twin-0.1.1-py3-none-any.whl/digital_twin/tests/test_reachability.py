"""Unit tests for deterministic reachability core."""

import hashlib

from django.test import TestCase

try:
    from nautobot.dcim.tests.test_views import create_test_device
except ImportError:  # pragma: no cover
    from nautobot.dcim.tests.test_filters import create_test_device

from digital_twin import models
from digital_twin.engine.reachability import check_reachability_many
from digital_twin.tests import fixtures


class ReachabilityCoreTests(TestCase):
    """Reachability engine unit tests."""

    def setUp(self):
        self.snapshot = fixtures.create_ready_snapshot("ReachabilityScope")
        fixtures.seed_basic_reachability_state(self.snapshot)

    def test_nat_lb_always_applied(self):
        edge_device = create_test_device(name="NAT-EDGE")
        self.snapshot.scope.devices.add(edge_device)
        models.RoutingTableEntryState.objects.create(
            snapshot=self.snapshot,
            device=edge_device,
            vrf="default",
            prefix="10.0.0.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=self.snapshot,
            device=edge_device,
            vrf="default",
            prefix="198.51.100.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.InterfaceState.objects.create(
            snapshot=self.snapshot,
            device=edge_device,
            interface_name="Vlan10",
            admin_up=True,
            oper_up=True,
            observed_ips=["10.0.0.1/24"],
        )
        models.InterfaceState.objects.create(
            snapshot=self.snapshot,
            device=edge_device,
            interface_name="GigabitEthernet0/0",
            admin_up=True,
            oper_up=True,
            observed_ips=["198.51.100.1/24"],
        )
        nat_table = models.NatTableState.objects.create(
            snapshot=self.snapshot,
            device=edge_device,
            table_scope=models.NatTableScopeChoices.GLOBAL,
            vrf_name="",
        )
        models.NatRuleState.objects.create(
            snapshot=self.snapshot,
            device=edge_device,
            nat_table=nat_table,
            inside_interface="vlan10",
            outside_interface="gigabitethernet0/0",
            conditions_json={"dst_prefix": "198.51.100.0/24", "protocol": "tcp", "port": 443},
            translations_json={"dst_ip": "198.51.100.10", "dst_port": 8443},
            order=1,
        )

        payload = check_reachability_many(
            snapshot=self.snapshot,
            src="10.0.0.10",
            destinations=["203.0.113.100"],
            protocol="tcp",
            port=443,
            mode=models.ReachabilityModeChoices.IGNORE_SECURITY,
        )
        result = payload["results"][0]
        transforms = result["paths"][0]["transforms"]
        self.assertEqual(transforms[0]["type"], "LOAD_BALANCER")
        self.assertEqual(transforms[1]["type"], "NAT")
        self.assertEqual(result["confidence"], models.ConfidenceChoices.LOW)
        self.assertIn("F5:iRules", result["paths"][0]["opaque_features"])

    def test_mode_toggle_only_changes_policy(self):
        models.FirewallRuleState.objects.create(
            snapshot=self.snapshot,
            order=5,
            src_prefix="10.0.0.0/8",
            dst_prefix="198.51.100.0/24",
            protocol="tcp",
            port=443,
            action=models.SecurityActionChoices.ALLOW,
        )

        enforce = check_reachability_many(
            snapshot=self.snapshot,
            src="10.0.0.10",
            destinations=["203.0.113.100"],
            protocol="tcp",
            port=443,
            mode=models.ReachabilityModeChoices.ENFORCE_SECURITY,
        )
        ignore = check_reachability_many(
            snapshot=self.snapshot,
            src="10.0.0.10",
            destinations=["203.0.113.100"],
            protocol="tcp",
            port=443,
            mode=models.ReachabilityModeChoices.IGNORE_SECURITY,
        )
        enforce_path = enforce["results"][0]["paths"][0]
        ignore_path = ignore["results"][0]["paths"][0]
        self.assertEqual(enforce_path["transforms"], ignore_path["transforms"])
        self.assertGreater(len(enforce_path["policy_decisions"]), 0)
        self.assertEqual(ignore_path["policy_decisions"], [])

    def test_requires_max_16_destinations(self):
        with self.assertRaises(ValueError):
            check_reachability_many(
                snapshot=self.snapshot,
                src="10.0.0.10",
                destinations=[f"198.51.100.{index}" for index in range(1, 18)],
                protocol="tcp",
                port=443,
                mode=models.ReachabilityModeChoices.ENFORCE_SECURITY,
            )

    def test_source_anchored_paths_prevent_false_positive(self):
        scope = models.DeviceScope.objects.create(name="SourceAnchoredScope", scope_type=models.ScopeTypeChoices.STATIC)
        snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)

        src_device = create_test_device(name="SRC-RTR")
        core_device = create_test_device(name="CORE-RTR")

        scope.devices.add(src_device, core_device)

        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="10.10.10.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="10.0.0.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="172.16.2.0/24",
            next_hop="10.0.0.2",
            protocol="ospf",
            metric=10,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="10.4.0.0/24",
            next_hop="10.0.0.2",
            protocol="ospf",
            metric=10,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="0.0.0.0/0",
            next_hop="10.0.0.2",
            protocol="static",
            metric=100,
        )

        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=core_device,
            vrf="default",
            prefix="10.0.0.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=core_device,
            vrf="default",
            prefix="10.10.10.0/24",
            next_hop="10.0.0.1",
            protocol="ospf",
            metric=10,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=core_device,
            vrf="default",
            prefix="172.16.2.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=core_device,
            vrf="default",
            prefix="10.4.0.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=core_device,
            vrf="default",
            prefix="0.0.0.0/0",
            next_hop="203.0.113.1",
            protocol="static",
            metric=100,
        )

        payload = check_reachability_many(
            snapshot=snapshot,
            src="10.10.10.3",
            destinations=["1.1.1.1", "172.16.2.5", "10.4.0.1"],
            protocol="tcp",
            port=443,
            mode=models.ReachabilityModeChoices.IGNORE_SECURITY,
            include_explanation=True,
            max_paths=2,
        )

        results = {result["dst"]: result for result in payload["results"]}
        self.assertEqual(results["1.1.1.1"]["verdict"], models.VerdictChoices.UNREACHABLE)
        self.assertEqual(results["172.16.2.5"]["verdict"], models.VerdictChoices.REACHABLE)
        self.assertEqual(results["10.4.0.1"]["verdict"], models.VerdictChoices.REACHABLE)

        self.assertEqual(results["172.16.2.5"]["forward"]["status"], "PASS")
        self.assertEqual(results["172.16.2.5"]["reverse"]["status"], "PASS")
        self.assertEqual(results["172.16.2.5"]["root_cause"], "END_TO_END_REACHABLE")
        self.assertEqual(results["1.1.1.1"]["forward"]["status"], "FAIL")
        self.assertTrue(results["1.1.1.1"]["root_cause"].startswith("FORWARD_"))
        self.assertIn(results["1.1.1.1"]["reverse"]["status"], {"PASS", "FAIL"})

        reachable_path = results["172.16.2.5"]["paths"][0]
        self.assertTrue(reachable_path["reached"])
        self.assertGreaterEqual(len(reachable_path["hops"]), 2)
        self.assertTrue(any(path["reached"] for path in results["172.16.2.5"]["return_paths"]))

        failed_path = results["1.1.1.1"]["paths"][0]
        self.assertFalse(failed_path["reached"])
        self.assertIn(failed_path["termination_reason"], {"NEXT_HOP_EXTERNAL", "NO_ROUTE"})

    def test_forward_route_without_return_route_is_unreachable(self):
        scope = models.DeviceScope.objects.create(name="AsymmetryScope", scope_type=models.ScopeTypeChoices.STATIC)
        snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)

        src_device = create_test_device(name="ASYM-SRC")
        dst_device = create_test_device(name="ASYM-DST")
        scope.devices.add(src_device, dst_device)

        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="10.10.10.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="172.16.2.0/24",
            next_hop="10.0.0.2",
            protocol="ospf",
            metric=10,
        )

        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst_device,
            vrf="default",
            prefix="10.0.0.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst_device,
            vrf="default",
            prefix="172.16.2.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst_device,
            vrf="default",
            prefix="0.0.0.0/0",
            next_hop="203.0.113.1",
            protocol="static",
            metric=100,
        )

        payload = check_reachability_many(
            snapshot=snapshot,
            src="10.10.10.3",
            destinations=["172.16.2.5"],
            protocol="tcp",
            port=443,
            mode=models.ReachabilityModeChoices.IGNORE_SECURITY,
            include_explanation=True,
            max_paths=2,
        )
        result = payload["results"][0]
        self.assertEqual(result["verdict"], models.VerdictChoices.UNREACHABLE)
        self.assertIn("return route", result["explanation"]["summary"].lower())
        self.assertTrue(any(path["reached"] for path in result["paths"]))
        self.assertFalse(any(path["reached"] for path in result["return_paths"]))
        self.assertEqual(result["forward"]["status"], "PASS")
        self.assertEqual(result["reverse"]["status"], "FAIL")
        self.assertTrue(result["root_cause"].startswith("REVERSE_"))
        self.assertIn("primary_termination", result["forward"])
        self.assertIn("primary_termination", result["reverse"])

    def test_failed_path_includes_terminal_failure_hop(self):
        scope = models.DeviceScope.objects.create(name="FailHopScope", scope_type=models.ScopeTypeChoices.STATIC)
        snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)

        src_device = create_test_device(name="FAIL-SRC")
        transit_device = create_test_device(name="FAIL-TRANSIT")
        scope.devices.add(src_device, transit_device)

        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="10.10.10.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="198.51.100.50/32",
            next_hop="10.10.10.2",
            protocol="static",
            metric=1,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=transit_device,
            vrf="default",
            prefix="10.10.10.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.InterfaceState.objects.create(
            snapshot=snapshot,
            device=src_device,
            interface_name="Vlan10",
            admin_up=True,
            oper_up=True,
            observed_ips=["10.10.10.10/32"],
        )
        models.InterfaceState.objects.create(
            snapshot=snapshot,
            device=transit_device,
            interface_name="Vlan10",
            admin_up=True,
            oper_up=True,
            observed_ips=["10.10.10.2/32"],
        )

        payload = check_reachability_many(
            snapshot=snapshot,
            src="10.10.10.10",
            destinations=["198.51.100.50"],
            protocol="tcp",
            port=443,
            mode=models.ReachabilityModeChoices.IGNORE_SECURITY,
            include_explanation=True,
            max_paths=1,
        )
        result = payload["results"][0]
        self.assertEqual(result["forward"]["primary_termination"], "NO_ROUTE")
        hops = result["paths"][0]["hops"]
        self.assertGreaterEqual(len(hops), 2)
        self.assertEqual(hops[-1]["device"], "FAIL-TRANSIT")
        self.assertEqual(hops[-1]["protocol"], "failure")
        self.assertEqual(hops[-1]["ingress_interface"], "Vlan10")

    def test_failed_hop_ingress_inferred_from_connected_network_with_32_interfaces(self):
        scope = models.DeviceScope.objects.create(name="FailHop32Scope", scope_type=models.ScopeTypeChoices.STATIC)
        snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)

        src_device = create_test_device(name="FAIL32-SRC")
        transit_device = create_test_device(name="FAIL32-TRANSIT")
        scope.devices.add(src_device, transit_device)

        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="10.10.10.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="198.51.100.60/32",
            next_hop="10.10.10.2",
            protocol="static",
            metric=1,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=transit_device,
            vrf="default",
            prefix="10.10.10.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.InterfaceState.objects.create(
            snapshot=snapshot,
            device=src_device,
            interface_name="Vlan10",
            admin_up=True,
            oper_up=True,
            observed_ips=["10.10.10.10/32"],
        )
        models.InterfaceState.objects.create(
            snapshot=snapshot,
            device=transit_device,
            interface_name="Vlan10",
            admin_up=True,
            oper_up=True,
            observed_ips=["10.10.10.3/32"],
        )

        payload = check_reachability_many(
            snapshot=snapshot,
            src="10.10.10.10",
            destinations=["198.51.100.60"],
            protocol="tcp",
            port=443,
            mode=models.ReachabilityModeChoices.IGNORE_SECURITY,
            include_explanation=True,
            max_paths=1,
        )
        result = payload["results"][0]
        self.assertEqual(result["forward"]["primary_termination"], "NO_ROUTE")
        terminal_hop = result["paths"][0]["hops"][-1]
        self.assertEqual(terminal_hop["device"], "FAIL32-TRANSIT")
        self.assertEqual(terminal_hop["ingress_interface"], "Vlan10")

    def test_enforce_security_honors_interface_outbound_acl(self):
        scope = models.DeviceScope.objects.create(name="AclAttachScope", scope_type=models.ScopeTypeChoices.STATIC)
        snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)

        nx1 = create_test_device(name="NX1")
        dst = create_test_device(name="ACL-DST")
        scope.devices.add(nx1, dst)

        nx1_state = models.DeviceSnapshotState.objects.create(snapshot=snapshot, device=nx1)
        models.StateArtifact.objects.create(
            device_state=nx1_state,
            artifact_type="show_run",
            content="interface Eth1/1\n ip access-group EDGE-OUT out",
            checksum=hashlib.sha256(b"acl-attach-run").hexdigest(),
        )

        models.AclRuleState.objects.create(
            snapshot=snapshot,
            device=nx1,
            src_prefix="",
            dst_prefix="",
            protocol="tcp",
            port=80,
            action=models.SecurityActionChoices.DENY,
            order=10,
            attrs_json={"acl_name": "EDGE-OUT"},
        )
        models.AclRuleState.objects.create(
            snapshot=snapshot,
            device=nx1,
            src_prefix="",
            dst_prefix="",
            protocol="ip",
            port=None,
            action=models.SecurityActionChoices.ALLOW,
            order=20,
            attrs_json={"acl_name": "EDGE-OUT"},
        )

        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=nx1,
            vrf="default",
            prefix="10.0.0.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=nx1,
            vrf="default",
            prefix="172.16.1.0/24",
            next_hop="10.0.0.2",
            protocol="ospf",
            metric=10,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst,
            vrf="default",
            prefix="10.0.0.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst,
            vrf="default",
            prefix="172.16.1.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.InterfaceState.objects.create(
            snapshot=snapshot,
            device=nx1,
            interface_name="Eth1/1",
            admin_up=True,
            oper_up=True,
            observed_ips=["10.0.0.1/32"],
        )

        payload = check_reachability_many(
            snapshot=snapshot,
            src="10.0.0.10",
            destinations=["172.16.1.10"],
            protocol="tcp",
            port=80,
            mode=models.ReachabilityModeChoices.ENFORCE_SECURITY,
            include_explanation=True,
            max_paths=1,
        )
        result = payload["results"][0]
        self.assertEqual(result["verdict"], models.VerdictChoices.UNREACHABLE)
        self.assertEqual(result["root_cause"], "SECURITY_POLICY_DENY")

    def test_enforce_security_matches_long_short_interface_names_for_acl_binding(self):
        scope = models.DeviceScope.objects.create(name="AclIfaceNameScope", scope_type=models.ScopeTypeChoices.STATIC)
        snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)

        nx1 = create_test_device(name="NX1-LONGSHORT")
        dst = create_test_device(name="ACL-DST-LS")
        scope.devices.add(nx1, dst)

        nx1_state = models.DeviceSnapshotState.objects.create(snapshot=snapshot, device=nx1)
        models.StateArtifact.objects.create(
            device_state=nx1_state,
            artifact_type="show_run",
            content="interface Ethernet1/1\n ip access-group EDGE-OUT out",
            checksum=hashlib.sha256(b"acl-attach-run-long").hexdigest(),
        )

        models.AclRuleState.objects.create(
            snapshot=snapshot,
            device=nx1,
            src_prefix="",
            dst_prefix="",
            protocol="tcp",
            port=80,
            action=models.SecurityActionChoices.DENY,
            order=10,
            attrs_json={"acl_name": "EDGE-OUT"},
        )
        models.AclRuleState.objects.create(
            snapshot=snapshot,
            device=nx1,
            src_prefix="",
            dst_prefix="",
            protocol="ip",
            port=None,
            action=models.SecurityActionChoices.ALLOW,
            order=20,
            attrs_json={"acl_name": "EDGE-OUT"},
        )

        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=nx1,
            vrf="default",
            prefix="10.0.0.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=nx1,
            vrf="default",
            prefix="172.16.1.0/24",
            next_hop="10.0.0.2",
            protocol="ospf",
            metric=10,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst,
            vrf="default",
            prefix="10.0.0.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst,
            vrf="default",
            prefix="172.16.1.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.InterfaceState.objects.create(
            snapshot=snapshot,
            device=nx1,
            interface_name="Eth1/1",
            admin_up=True,
            oper_up=True,
            observed_ips=["10.0.0.1/32"],
        )

        payload = check_reachability_many(
            snapshot=snapshot,
            src="10.0.0.10",
            destinations=["172.16.1.10"],
            protocol="tcp",
            port=80,
            mode=models.ReachabilityModeChoices.ENFORCE_SECURITY,
            include_explanation=True,
            max_paths=1,
        )
        result = payload["results"][0]
        self.assertEqual(result["verdict"], models.VerdictChoices.UNREACHABLE)
        self.assertEqual(result["root_cause"], "SECURITY_POLICY_DENY")

    def test_connected_route_with_interface_down_is_unreachable(self):
        scope = models.DeviceScope.objects.create(name="InterfaceDownScope", scope_type=models.ScopeTypeChoices.STATIC)
        snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)

        src_device = create_test_device(name="IFDOWN-SRC")
        dst_device = create_test_device(name="IFDOWN-DST")
        scope.devices.add(src_device, dst_device)

        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="10.10.10.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="172.16.1.0/24",
            next_hop="10.0.0.2",
            protocol="ospf",
            metric=10,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst_device,
            vrf="default",
            prefix="10.0.0.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst_device,
            vrf="default",
            prefix="172.16.1.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.InterfaceState.objects.create(
            snapshot=snapshot,
            device=src_device,
            interface_name="Vlan10",
            admin_up=True,
            oper_up=True,
            observed_ips=["10.0.0.10/32"],
        )

        models.InterfaceState.objects.create(
            snapshot=snapshot,
            device=dst_device,
            interface_name="Loopback0",
            admin_up=False,
            oper_up=False,
            observed_ips=["172.16.1.1/32"],
        )

        payload = check_reachability_many(
            snapshot=snapshot,
            src="10.10.10.3",
            destinations=["172.16.1.1"],
            protocol="tcp",
            port=443,
            mode=models.ReachabilityModeChoices.IGNORE_SECURITY,
            include_explanation=True,
            max_paths=2,
        )
        result = payload["results"][0]
        self.assertEqual(result["verdict"], models.VerdictChoices.UNREACHABLE)
        self.assertTrue(result["root_cause"].startswith("FORWARD_INTERFACE_DOWN"))

    def test_route_via_device_marked_failed_is_unreachable(self):
        scope = models.DeviceScope.objects.create(name="DeviceDownScope", scope_type=models.ScopeTypeChoices.STATIC)
        snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)

        src_device = create_test_device(name="DEVDOWN-SRC")
        mid_device = create_test_device(name="DEVDOWN-MID")
        scope.devices.add(src_device, mid_device)

        models.DeviceSnapshotState.objects.create(
            snapshot=snapshot,
            device=mid_device,
            collection_status=models.StageStatusChoices.FAILED,
        )

        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="10.10.10.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="172.16.1.0/24",
            next_hop="10.0.0.2",
            protocol="ospf",
            metric=10,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=mid_device,
            vrf="default",
            prefix="10.0.0.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=mid_device,
            vrf="default",
            prefix="172.16.1.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )

        payload = check_reachability_many(
            snapshot=snapshot,
            src="10.10.10.3",
            destinations=["172.16.1.1"],
            protocol="tcp",
            port=443,
            mode=models.ReachabilityModeChoices.IGNORE_SECURITY,
            include_explanation=True,
            max_paths=2,
        )
        result = payload["results"][0]
        self.assertEqual(result["verdict"], models.VerdictChoices.UNREACHABLE)
        self.assertTrue(result["root_cause"].startswith("FORWARD_DEVICE_DOWN"))

    def test_hops_include_transited_interfaces(self):
        scope = models.DeviceScope.objects.create(name="InterfaceHopScope", scope_type=models.ScopeTypeChoices.STATIC)
        snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)

        src_device = create_test_device(name="IFACE-SRC")
        dst_device = create_test_device(name="IFACE-DST")
        scope.devices.add(src_device, dst_device)

        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="10.10.10.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="172.16.2.0/24",
            next_hop="10.0.0.2",
            protocol="ospf",
            metric=10,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst_device,
            vrf="default",
            prefix="10.0.0.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst_device,
            vrf="default",
            prefix="172.16.2.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )

        models.InterfaceState.objects.create(
            snapshot=snapshot,
            device=src_device,
            interface_name="Eth1",
            admin_up=True,
            oper_up=True,
            observed_ips=["10.0.0.1/24"],
        )
        models.InterfaceState.objects.create(
            snapshot=snapshot,
            device=dst_device,
            interface_name="Loopback0",
            admin_up=True,
            oper_up=True,
            observed_ips=["172.16.2.1/24"],
        )

        payload = check_reachability_many(
            snapshot=snapshot,
            src="10.10.10.3",
            destinations=["172.16.2.5"],
            protocol="tcp",
            port=443,
            mode=models.ReachabilityModeChoices.IGNORE_SECURITY,
            include_explanation=True,
            max_paths=8,
        )
        hop_interfaces = []
        ingress_values = []
        egress_values = []
        for hop in payload["results"][0]["paths"][0]["hops"]:
            hop_interfaces.extend(hop.get("interfaces", []))
            ingress_values.append(hop.get("ingress_interface"))
            egress_values.append(hop.get("egress_interface"))
        self.assertIn("Eth1", hop_interfaces)
        self.assertTrue(any(value == "Eth1" for value in ingress_values + egress_values))

    def test_max_paths_over_one_requires_ecmp(self):
        scope = models.DeviceScope.objects.create(name="NonECMPScope", scope_type=models.ScopeTypeChoices.STATIC)
        snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)

        src_device = create_test_device(name="NONECMP-SRC")
        next_a = create_test_device(name="NONECMP-NEXT-A")
        next_b = create_test_device(name="NONECMP-NEXT-B")
        scope.devices.add(src_device, next_a, next_b)

        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="10.10.10.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="172.16.10.0/24",
            next_hop="10.0.0.2",
            protocol="ospf",
            metric=10,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=next_a,
            vrf="default",
            prefix="10.0.0.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=next_a,
            vrf="default",
            prefix="172.16.10.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=next_b,
            vrf="default",
            prefix="10.0.0.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )

        payload = check_reachability_many(
            snapshot=snapshot,
            src="10.10.10.3",
            destinations=["172.16.10.5"],
            protocol="tcp",
            port=443,
            mode=models.ReachabilityModeChoices.IGNORE_SECURITY,
            include_explanation=True,
            max_paths=8,
        )
        self.assertEqual(len(payload["results"][0]["paths"]), 1)

    def test_policy_based_routing_changes_forward_action_on_match(self):
        scope = models.DeviceScope.objects.create(name="PBRScope", scope_type=models.ScopeTypeChoices.STATIC)
        snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)

        src_device = create_test_device(name="PBR-SRC")
        next_hop_device = create_test_device(name="PBR-NH")
        scope.devices.add(src_device, next_hop_device)

        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="10.10.10.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="172.16.1.0/24",
            next_hop="10.0.0.2",
            protocol="ospf",
            metric=10,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=next_hop_device,
            vrf="default",
            prefix="10.0.0.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=next_hop_device,
            vrf="default",
            prefix="172.16.1.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=next_hop_device,
            vrf="default",
            prefix="10.10.10.0/24",
            next_hop="10.0.0.1",
            protocol="ospf",
            metric=10,
        )

        models.PbrRuleState.objects.create(
            snapshot=snapshot,
            device=src_device,
            src_prefix="10.10.10.0/24",
            dst_prefix="172.16.1.0/24",
            protocol="tcp",
            port=443,
            set_next_hop="203.0.113.1",
            order=1,
        )

        matched = check_reachability_many(
            snapshot=snapshot,
            src="10.10.10.3",
            destinations=["172.16.1.1"],
            protocol="tcp",
            port=443,
            mode=models.ReachabilityModeChoices.IGNORE_SECURITY,
            include_explanation=True,
            max_paths=2,
        )["results"][0]

        non_matched = check_reachability_many(
            snapshot=snapshot,
            src="10.10.10.3",
            destinations=["172.16.1.1"],
            protocol="tcp",
            port=80,
            mode=models.ReachabilityModeChoices.IGNORE_SECURITY,
            include_explanation=True,
            max_paths=2,
        )["results"][0]

        self.assertEqual(matched["verdict"], models.VerdictChoices.UNREACHABLE)
        self.assertTrue(matched["root_cause"].startswith("FORWARD_PBR_"))
        self.assertEqual(non_matched["verdict"], models.VerdictChoices.REACHABLE)

    def test_direct_protocol_route_is_treated_as_connected(self):
        scope = models.DeviceScope.objects.create(name="DirectProtoScope", scope_type=models.ScopeTypeChoices.STATIC)
        snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)

        src_device = create_test_device(name="DIRECT-SRC")
        dst_device = create_test_device(name="DIRECT-DST")
        scope.devices.add(src_device, dst_device)

        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="10.10.20.0/24",
            next_hop="10.0.0.2",
            protocol="ospf",
            metric=10,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst_device,
            vrf="default",
            prefix="10.0.0.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst_device,
            vrf="default",
            prefix="10.10.20.0/24",
            next_hop="0.0.0.0",
            protocol="direct",
            metric=0,
        )

        payload = check_reachability_many(
            snapshot=snapshot,
            src="10.0.0.10",
            destinations=["10.10.20.10"],
            protocol="tcp",
            port=443,
            mode=models.ReachabilityModeChoices.IGNORE_SECURITY,
            include_explanation=True,
            max_paths=2,
        )
        result = payload["results"][0]
        self.assertTrue(any(path["reached"] for path in result["paths"]))
        self.assertNotEqual(result["forward"]["primary_termination"], "UNRESOLVED_NEXT_HOP")

    def test_source_device_can_be_selected_from_interface_network_context(self):
        scope = models.DeviceScope.objects.create(name="SourceIfaceScope", scope_type=models.ScopeTypeChoices.STATIC)
        snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)

        sw1 = create_test_device(name="SRC-SW1")
        nx1 = create_test_device(name="SRC-NX1")
        abr = create_test_device(name="SRC-ABR")
        scope.devices.add(sw1, nx1, abr)

        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=sw1,
            vrf="LAB",
            prefix="0.0.0.0/0",
            next_hop="10.10.20.1",
            protocol="static",
            metric=1,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=sw1,
            vrf="LAB",
            prefix="10.10.20.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=nx1,
            vrf="default",
            prefix="10.10.20.0/24",
            next_hop="0.0.0.0",
            protocol="direct",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=nx1,
            vrf="default",
            prefix="10.255.0.1/32",
            next_hop="172.16.2.1",
            protocol="ospf-10",
            metric=10,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=abr,
            vrf="default",
            prefix="172.16.2.0/30",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=abr,
            vrf="default",
            prefix="10.255.0.1/32",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )

        models.InterfaceState.objects.create(
            snapshot=snapshot,
            device=sw1,
            interface_name="Vlan20",
            admin_up=True,
            oper_up=True,
            observed_ips=["10.10.20.3/32"],
        )

        payload = check_reachability_many(
            snapshot=snapshot,
            src="10.10.20.10",
            destinations=["10.255.0.1"],
            protocol="tcp",
            port=443,
            mode=models.ReachabilityModeChoices.IGNORE_SECURITY,
            include_explanation=True,
            max_paths=2,
        )
        first_hop_device = payload["results"][0]["paths"][0]["hops"][0]["device"]
        self.assertEqual(first_hop_device, "SRC-SW1")

    def test_source_device_route_lookup_is_vrf_scoped(self):
        scope = models.DeviceScope.objects.create(name="SourceVRFScope", scope_type=models.ScopeTypeChoices.STATIC)
        snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)

        sw1 = create_test_device(name="VRF-SW1")
        lab_nh = create_test_device(name="VRF-LAB-NH")
        def_nh = create_test_device(name="VRF-DEF-NH")
        dst = create_test_device(name="VRF-DST")
        scope.devices.add(sw1, lab_nh, def_nh, dst)

        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=sw1,
            vrf="LAB",
            prefix="10.10.20.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=sw1,
            vrf="LAB",
            prefix="0.0.0.0/0",
            next_hop="10.10.20.1",
            protocol="static",
            metric=50,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=sw1,
            vrf="default",
            prefix="0.0.0.0/0",
            next_hop="192.0.2.1",
            protocol="static",
            metric=1,
        )

        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=lab_nh,
            vrf="default",
            prefix="10.10.20.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=lab_nh,
            vrf="default",
            prefix="10.255.0.1/32",
            next_hop="10.10.20.2",
            protocol="ospf-10",
            metric=10,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst,
            vrf="default",
            prefix="10.10.20.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst,
            vrf="default",
            prefix="10.255.0.1/32",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=def_nh,
            vrf="default",
            prefix="192.0.2.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )

        payload = check_reachability_many(
            snapshot=snapshot,
            src="10.10.20.10",
            destinations=["10.255.0.1"],
            protocol="tcp",
            port=443,
            mode=models.ReachabilityModeChoices.IGNORE_SECURITY,
            include_explanation=True,
            max_paths=2,
        )
        first_hop = payload["results"][0]["paths"][0]["hops"][0]
        self.assertEqual(first_hop["device"], "VRF-SW1")
        self.assertEqual(first_hop["vrf"], "LAB")
        self.assertEqual(first_hop["next_hop"], "10.10.20.1")

    def test_arp_miss_fails_next_hop_validation(self):
        scope = models.DeviceScope.objects.create(name="ArpMissScope", scope_type=models.ScopeTypeChoices.STATIC)
        snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)

        src_device = create_test_device(name="ARP-SRC")
        dst_device = create_test_device(name="ARP-DST")
        scope.devices.add(src_device, dst_device)

        src_state = models.DeviceSnapshotState.objects.create(snapshot=snapshot, device=src_device)

        models.StateArtifact.objects.create(
            device_state=src_state,
            artifact_type="show_arp_raw",
            content="Internet 10.0.0.99 3 0011.2233.4455 ARPA Vlan10",
            checksum=hashlib.sha256(b"arp-miss").hexdigest(),
        )

        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="10.0.0.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="172.16.1.0/24",
            next_hop="10.0.0.2",
            protocol="ospf",
            metric=10,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst_device,
            vrf="default",
            prefix="10.0.0.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst_device,
            vrf="default",
            prefix="172.16.1.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.InterfaceState.objects.create(
            snapshot=snapshot,
            device=src_device,
            interface_name="Vlan10",
            admin_up=True,
            oper_up=True,
            observed_ips=["10.0.0.10/32"],
        )

        payload = check_reachability_many(
            snapshot=snapshot,
            src="10.0.0.10",
            destinations=["172.16.1.10"],
            protocol="tcp",
            port=443,
            mode=models.ReachabilityModeChoices.IGNORE_SECURITY,
            include_explanation=True,
            max_paths=2,
        )
        result = payload["results"][0]
        self.assertEqual(result["forward"]["primary_termination"], "ARP_MISS")
        self.assertTrue(result["root_cause"].startswith("FORWARD_ARP_MISS"))

    def test_arp_mac_miss_fails_when_mac_table_exists(self):
        scope = models.DeviceScope.objects.create(name="ArpMacMissScope", scope_type=models.ScopeTypeChoices.STATIC)
        snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)

        src_device = create_test_device(name="ARPMAC-SRC")
        dst_device = create_test_device(name="ARPMAC-DST")
        scope.devices.add(src_device, dst_device)

        src_state = models.DeviceSnapshotState.objects.create(snapshot=snapshot, device=src_device)

        models.StateArtifact.objects.create(
            device_state=src_state,
            artifact_type="show_arp_raw",
            content="Internet 10.0.0.2 3 0011.2233.4455 ARPA Vlan10",
            checksum=hashlib.sha256(b"arp-hit").hexdigest(),
        )
        models.StateArtifact.objects.create(
            device_state=src_state,
            artifact_type="show_mac_raw",
            content="  10   00aa.bbcc.ddee   DYNAMIC   Gi0/1",
            checksum=hashlib.sha256(b"mac-miss").hexdigest(),
        )
        models.StateArtifact.objects.create(
            device_state=src_state,
            artifact_type="show_run",
            content="interface Vlan10\n switchport",
            checksum=hashlib.sha256(b"mac-miss-switchport").hexdigest(),
        )

        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="10.0.0.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="172.16.1.0/24",
            next_hop="10.0.0.2",
            protocol="ospf",
            metric=10,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst_device,
            vrf="default",
            prefix="10.0.0.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst_device,
            vrf="default",
            prefix="172.16.1.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.InterfaceState.objects.create(
            snapshot=snapshot,
            device=src_device,
            interface_name="Vlan10",
            admin_up=True,
            oper_up=True,
            observed_ips=["10.0.0.10/32"],
        )

        payload = check_reachability_many(
            snapshot=snapshot,
            src="10.0.0.10",
            destinations=["172.16.1.10"],
            protocol="tcp",
            port=443,
            mode=models.ReachabilityModeChoices.IGNORE_SECURITY,
            include_explanation=True,
            max_paths=2,
        )
        result = payload["results"][0]
        self.assertEqual(result["forward"]["primary_termination"], "ARP_MAC_MISS")
        self.assertTrue(result["root_cause"].startswith("FORWARD_ARP_MAC_MISS"))

    def test_no_switchport_skips_mac_validation(self):
        scope = models.DeviceScope.objects.create(name="NoSwitchportScope", scope_type=models.ScopeTypeChoices.STATIC)
        snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)

        src_device = create_test_device(name="NOSW-SRC")
        dst_device = create_test_device(name="NOSW-DST")
        scope.devices.add(src_device, dst_device)

        src_state = models.DeviceSnapshotState.objects.create(snapshot=snapshot, device=src_device)

        models.StateArtifact.objects.create(
            device_state=src_state,
            artifact_type="show_arp_raw",
            content="Internet 10.0.0.2 3 0011.2233.4455 ARPA Ethernet1/1",
            checksum=hashlib.sha256(b"nosw-arp-hit").hexdigest(),
        )
        models.StateArtifact.objects.create(
            device_state=src_state,
            artifact_type="show_mac_raw",
            content="  10   00aa.bbcc.ddee   DYNAMIC   Ethernet1/2",
            checksum=hashlib.sha256(b"nosw-mac-miss").hexdigest(),
        )
        models.StateArtifact.objects.create(
            device_state=src_state,
            artifact_type="show_run",
            content="interface Ethernet1/1\n no switchport",
            checksum=hashlib.sha256(b"nosw-routed").hexdigest(),
        )

        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="10.0.0.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="172.16.1.0/24",
            next_hop="10.0.0.2",
            protocol="ospf",
            metric=10,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst_device,
            vrf="default",
            prefix="10.0.0.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst_device,
            vrf="default",
            prefix="172.16.1.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.InterfaceState.objects.create(
            snapshot=snapshot,
            device=src_device,
            interface_name="Ethernet1/1",
            admin_up=True,
            oper_up=True,
            observed_ips=["10.0.0.10/32"],
        )

        payload = check_reachability_many(
            snapshot=snapshot,
            src="10.0.0.10",
            destinations=["172.16.1.10"],
            protocol="tcp",
            port=443,
            mode=models.ReachabilityModeChoices.IGNORE_SECURITY,
            include_explanation=True,
            max_paths=2,
        )
        result = payload["results"][0]
        self.assertEqual(result["forward"]["primary_termination"], "CONNECTED")

    def test_l2_mac_resolution_overrides_egress_interface(self):
        scope = models.DeviceScope.objects.create(name="L2EgressScope", scope_type=models.ScopeTypeChoices.STATIC)
        snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)

        src_device = create_test_device(name="L2EG-SRC")
        dst_device = create_test_device(name="L2EG-DST")
        scope.devices.add(src_device, dst_device)

        src_state = models.DeviceSnapshotState.objects.create(snapshot=snapshot, device=src_device)
        models.StateArtifact.objects.create(
            device_state=src_state,
            artifact_type="show_arp_raw",
            content="Internet 10.0.0.2 3 0011.2233.4455 ARPA Vlan10",
            checksum=hashlib.sha256(b"l2eg-arp").hexdigest(),
        )
        models.StateArtifact.objects.create(
            device_state=src_state,
            artifact_type="show_mac_raw",
            content="  10   0011.2233.4455   DYNAMIC   Gi0/47",
            checksum=hashlib.sha256(b"l2eg-mac").hexdigest(),
        )
        models.StateArtifact.objects.create(
            device_state=src_state,
            artifact_type="show_run",
            content="interface Vlan10\n switchport",
            checksum=hashlib.sha256(b"l2eg-run").hexdigest(),
        )

        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="10.0.0.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=src_device,
            vrf="default",
            prefix="172.16.1.0/24",
            next_hop="10.0.0.2",
            protocol="ospf",
            metric=10,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst_device,
            vrf="default",
            prefix="10.0.0.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst_device,
            vrf="default",
            prefix="172.16.1.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.InterfaceState.objects.create(
            snapshot=snapshot,
            device=src_device,
            interface_name="Vlan10",
            admin_up=True,
            oper_up=True,
            observed_ips=["10.0.0.10/32"],
        )

        payload = check_reachability_many(
            snapshot=snapshot,
            src="10.0.0.10",
            destinations=["172.16.1.10"],
            protocol="tcp",
            port=443,
            mode=models.ReachabilityModeChoices.IGNORE_SECURITY,
            include_explanation=True,
            max_paths=2,
        )
        hop = payload["results"][0]["paths"][0]["hops"][0]
        self.assertEqual(hop["egress_interface"], "Gi0/47")

    def test_arp_lookup_is_scoped_to_route_vrf(self):
        scope = models.DeviceScope.objects.create(name="ArpVrfScope", scope_type=models.ScopeTypeChoices.STATIC)
        snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)

        sw1 = create_test_device(name="ARPVRF-SW1")
        nh = create_test_device(name="ARPVRF-NH")
        dst = create_test_device(name="ARPVRF-DST")
        scope.devices.add(sw1, nh, dst)

        sw1_state = models.DeviceSnapshotState.objects.create(snapshot=snapshot, device=sw1)
        models.StateArtifact.objects.create(
            device_state=sw1_state,
            artifact_type="show_arp_raw",
            content='IP ARP Table for VRF "LAB"\nInternet 10.10.20.1 3 0011.2233.4455 ARPA Vlan20',
            checksum=hashlib.sha256(b"arp-vrf-lab").hexdigest(),
        )
        models.StateArtifact.objects.create(
            device_state=sw1_state,
            artifact_type="show_arp_raw",
            content="Internet 10.10.20.1 3 aaaa.bbbb.cccc ARPA Vlan99",
            checksum=hashlib.sha256(b"arp-vrf-default").hexdigest(),
        )
        models.StateArtifact.objects.create(
            device_state=sw1_state,
            artifact_type="show_mac_raw",
            content="  20  0011.2233.4455 DYNAMIC Gi0/1",
            checksum=hashlib.sha256(b"arp-vrf-mac").hexdigest(),
        )

        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=sw1,
            vrf="LAB",
            prefix="10.10.20.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=sw1,
            vrf="LAB",
            prefix="10.255.0.1/32",
            next_hop="10.10.20.1",
            protocol="static",
            metric=1,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=nh,
            vrf="default",
            prefix="10.10.20.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=nh,
            vrf="default",
            prefix="10.255.0.1/32",
            next_hop="10.10.20.2",
            protocol="ospf-10",
            metric=10,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst,
            vrf="default",
            prefix="10.10.20.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=dst,
            vrf="default",
            prefix="10.255.0.1/32",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )

        payload = check_reachability_many(
            snapshot=snapshot,
            src="10.10.20.10",
            destinations=["10.255.0.1"],
            protocol="tcp",
            port=443,
            mode=models.ReachabilityModeChoices.IGNORE_SECURITY,
            include_explanation=True,
            max_paths=2,
        )
        result = payload["results"][0]
        self.assertEqual(result["forward"]["primary_termination"], "CONNECTED")
        self.assertEqual(result["paths"][0]["hops"][0]["device"], "ARPVRF-SW1")

    def test_fhrp_active_device_resolves_virtual_next_hop(self):
        scope = models.DeviceScope.objects.create(name="FhrpScope", scope_type=models.ScopeTypeChoices.STATIC)
        snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)

        sw1 = create_test_device(name="FHRP-SW1")
        nx1a = create_test_device(name="FHRP-NX1A")
        nx1b = create_test_device(name="FHRP-NX1B")
        abr = create_test_device(name="FHRP-ABR")
        scope.devices.add(sw1, nx1a, nx1b, abr)

        state_nx1a = models.DeviceSnapshotState.objects.create(snapshot=snapshot, device=nx1a)
        models.StateArtifact.objects.create(
            device_state=state_nx1a,
            artifact_type="show_fhrp_raw",
            content="Interface  Grp Pri P State   Active  Standby  Virtual IP\n"
            "Vlan20     20  110 P Active  local   10.10.20.2 10.10.20.1",
            checksum=hashlib.sha256(b"fhrp-active").hexdigest(),
        )

        state_nx1b = models.DeviceSnapshotState.objects.create(snapshot=snapshot, device=nx1b)
        models.StateArtifact.objects.create(
            device_state=state_nx1b,
            artifact_type="show_fhrp_raw",
            content="Interface  Grp Pri P State   Active  Standby  Virtual IP\n"
            "Vlan20     20  90  P Standby 10.10.20.3 local   10.10.20.1",
            checksum=hashlib.sha256(b"fhrp-standby").hexdigest(),
        )

        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=sw1,
            vrf="LAB",
            prefix="10.10.20.0/24",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=sw1,
            vrf="LAB",
            prefix="0.0.0.0/0",
            next_hop="10.10.20.1",
            protocol="static",
            metric=1,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=nx1a,
            vrf="default",
            prefix="10.10.20.0/24",
            next_hop="0.0.0.0",
            protocol="direct",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=nx1a,
            vrf="default",
            prefix="10.255.0.1/32",
            next_hop="172.16.2.1",
            protocol="ospf-10",
            metric=10,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=nx1b,
            vrf="default",
            prefix="10.10.20.0/24",
            next_hop="0.0.0.0",
            protocol="direct",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=nx1b,
            vrf="default",
            prefix="10.255.0.1/32",
            next_hop="172.16.3.1",
            protocol="ospf-10",
            metric=10,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=abr,
            vrf="default",
            prefix="172.16.2.0/30",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )
        models.RoutingTableEntryState.objects.create(
            snapshot=snapshot,
            device=abr,
            vrf="default",
            prefix="10.255.0.1/32",
            next_hop="0.0.0.0",
            protocol="connected",
            metric=0,
        )

        models.InterfaceState.objects.create(
            snapshot=snapshot,
            device=sw1,
            interface_name="Vlan20",
            admin_up=True,
            oper_up=True,
            observed_ips=["10.10.20.3/32"],
        )

        payload = check_reachability_many(
            snapshot=snapshot,
            src="10.10.20.10",
            destinations=["10.255.0.1"],
            protocol="tcp",
            port=443,
            mode=models.ReachabilityModeChoices.IGNORE_SECURITY,
            include_explanation=True,
            max_paths=3,
        )

        hops = payload["results"][0]["paths"][0]["hops"]
        self.assertGreaterEqual(len(hops), 2)
        self.assertEqual(hops[1]["device"], "FHRP-NX1A")
