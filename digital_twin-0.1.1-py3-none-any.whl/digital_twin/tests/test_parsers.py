"""Unit tests for parser functions."""

from django.test import TestCase

from digital_twin.engine.parsers import (
    parse_cisco_acl_text,
    parse_cisco_nat_table_json,
    parse_cisco_route_text,
    parse_f5_ltm_json,
    parse_interface_json,
    parse_pbr_json,
)


class ParserTests(TestCase):
    """Parser unit tests for normalized state extraction."""

    def test_parse_cisco_route_text(self):
        raw = "default 10.0.0.0/8 192.0.2.1 static 1\n# comment\ndefault 198.51.100.0/24 0.0.0.0 connected 0"
        rows = parse_cisco_route_text(raw)
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]["prefix"], "10.0.0.0/8")
        self.assertEqual(rows[1]["protocol"], "connected")

    def test_parse_interface_json(self):
        payload = [{"name": "Ethernet1", "admin_up": True, "oper_up": False, "ips": ["10.0.0.1/24"]}]
        rows = parse_interface_json(payload)
        self.assertEqual(rows[0]["interface_name"], "Ethernet1")
        self.assertFalse(rows[0]["oper_up"])

    def test_parse_f5_ltm_json(self):
        payload = [{"vip": "203.0.113.100", "pool": "web", "members": ["198.51.100.10"], "has_irules": True}]
        rows = parse_f5_ltm_json(payload)
        self.assertEqual(rows[0]["vip"], "203.0.113.100")
        self.assertTrue(rows[0]["has_irules"])

    def test_parse_pbr_json(self):
        payload = [
            {
                "src_prefix": "10.10.10.0/24",
                "dst_prefix": "172.16.1.0/24",
                "protocol": "tcp",
                "port": 443,
                "set_next_hop": "192.0.2.1",
                "order": 5,
                "attrs": {"name": "RM-PBR"},
            }
        ]
        rows = parse_pbr_json(payload)
        self.assertEqual(rows[0]["src_prefix"], "10.10.10.0/24")
        self.assertEqual(rows[0]["set_next_hop"], "192.0.2.1")
        self.assertEqual(rows[0]["order"], 5)

    def test_parse_cisco_acl_text(self):
        raw = (
            "Extended IP access list ACL-IN\n"
            "10 permit tcp 10.10.10.0 0.0.0.255 host 172.16.1.10 eq https\n"
            "20 deny ip any any\n"
        )
        rows = parse_cisco_acl_text(raw)
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]["action"], "ALLOW")
        self.assertEqual(rows[0]["protocol"], "tcp")
        self.assertEqual(rows[0]["src_prefix"], "10.10.10.0/24")
        self.assertEqual(rows[0]["dst_prefix"], "172.16.1.10/32")
        self.assertEqual(rows[0]["port"], 443)
        self.assertEqual(rows[0]["attrs_json"]["acl_name"], "ACL-IN")
        self.assertEqual(rows[1]["action"], "DENY")
        self.assertEqual(rows[1]["src_prefix"], "")
        self.assertEqual(rows[1]["dst_prefix"], "")

    def test_parse_cisco_acl_text_nxos_header(self):
        raw = "IP access list EDGE-OUT\n10 deny tcp any any eq www\n20 permit ip any any"
        rows = parse_cisco_acl_text(raw)
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]["attrs_json"]["acl_name"], "EDGE-OUT")
        self.assertEqual(rows[0]["action"], "DENY")
        self.assertEqual(rows[0]["port"], 80)

    def test_parse_cisco_acl_text_with_source_port_clause(self):
        raw = "IP access list COPP-ACL\n10 permit udp any eq 1645 any\n20 permit udp any eq 1645 any eq domain\n"
        rows = parse_cisco_acl_text(raw)
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]["port"], 1645)
        self.assertEqual(rows[1]["port"], 53)

    def test_parse_cisco_acl_text_named_tacacs_port(self):
        raw = "IP access list COPP-TACACS\n10 permit tcp any any eq tacacs"
        rows = parse_cisco_acl_text(raw)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["port"], 49)

    def test_parse_cisco_nat_table_json(self):
        payload = {
            "tables": [
                {
                    "table_scope": "GLOBAL",
                    "vrf_name": "",
                    "rules": [
                        {
                            "inside_interface": "Vlan10",
                            "outside_interface": "GigabitEthernet0/0",
                            "conditions_json": {"dst_prefix": "203.0.113.10/32", "protocol": "tcp", "port": 443},
                            "translations_json": {"dst_ip": "10.10.10.10", "dst_port": 8443},
                            "order": 10,
                        }
                    ],
                }
            ]
        }
        parsed = parse_cisco_nat_table_json(payload)
        self.assertEqual(len(parsed["tables"]), 1)
        self.assertEqual(parsed["tables"][0]["table_scope"], "GLOBAL")
        self.assertEqual(len(parsed["rules"]), 1)
        self.assertEqual(parsed["rules"][0]["inside_interface"], "vlan10")
        self.assertEqual(parsed["rules"][0]["outside_interface"], "gigabitethernet0/0")
