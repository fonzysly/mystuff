"""Model tests for digital twin models."""

import re
from unittest.mock import MagicMock

from django.core.exceptions import ValidationError
from django.test import TestCase

from digital_twin import models


class DeviceScopeModelTest(TestCase):
    """Test DeviceScope behavior."""

    def test_scope_string(self):
        scope = models.DeviceScope.objects.create(name="Core", scope_type=models.ScopeTypeChoices.STATIC)
        self.assertEqual(str(scope), "Core")

    def test_dynamic_scope_requires_dynamic_group(self):
        scope = models.DeviceScope(name="DG Scope", scope_type=models.ScopeTypeChoices.DYNAMIC_GROUP)
        with self.assertRaises(ValidationError):
            scope.full_clean()

    def test_get_devices_for_dynamic_scope_returns_group_members(self):
        expected_queryset = object()
        dynamic_group = MagicMock()
        dynamic_group.members = expected_queryset

        scope = models.DeviceScope(name="DG Scope", scope_type=models.ScopeTypeChoices.DYNAMIC_GROUP)
        scope.dynamic_group_id = "dynamic-group-id"
        scope._state.fields_cache["dynamic_group"] = dynamic_group

        self.assertIs(scope.get_devices(), expected_queryset)


class TwinSnapshotModelTest(TestCase):
    """Test TwinSnapshot defaults."""

    def test_snapshot_defaults(self):
        scope = models.DeviceScope.objects.create(name="Snapshot Scope", scope_type=models.ScopeTypeChoices.STATIC)
        snapshot = models.TwinSnapshot.objects.create(scope=scope)
        self.assertEqual(snapshot.status, models.SnapshotStatusChoices.CREATED)

    def test_snapshot_string_is_human_friendly(self):
        scope = models.DeviceScope.objects.create(name="Friendly Scope", scope_type=models.ScopeTypeChoices.STATIC)
        snapshot = models.TwinSnapshot.objects.create(scope=scope)
        rendered = str(snapshot)

        self.assertIn("Friendly Scope @", rendered)
        self.assertIsNone(re.search(r"\dT\d", rendered))
