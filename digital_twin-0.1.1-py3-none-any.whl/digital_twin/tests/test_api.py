"""API tests for digital twin reachability endpoint."""

import json
import uuid

from django.contrib.auth import get_user_model
from django.test import SimpleTestCase, TestCase
from rest_framework.generics import GenericAPIView

from digital_twin import models
from digital_twin.api import serializers as api_serializers
from digital_twin.api import views as api_views
from digital_twin.tests import fixtures


class ReachabilityAPIContractTest(SimpleTestCase):
    """Test API schema contract wiring for reachability endpoint."""

    def test_reachability_api_view_is_serializer_backed_generic_view(self):
        self.assertTrue(issubclass(api_views.ReachabilityAPIView, GenericAPIView))
        self.assertIs(api_views.ReachabilityAPIView.serializer_class, api_serializers.ReachabilityQuerySerializer)


class ReachabilityAPITest(TestCase):
    """Test POST reachability endpoint behavior and validations."""

    endpoint = "/api/plugins/digital_twin/reachability/"

    def setUp(self):
        user_model = get_user_model()
        self.user = user_model.objects.create_superuser(
            username="apiadmin", password="password", email="apiadmin@example.com"
        )
        self.client.force_login(self.user)

    def test_returns_404_for_unknown_snapshot(self):
        response = self.client.post(
            self.endpoint,
            data=json.dumps(
                {
                    "snapshot_id": str(uuid.uuid4()),
                    "src": "10.0.0.10",
                    "dst": ["198.51.100.1"],
                    "protocol": "tcp",
                    "port": 443,
                    "mode": "ENFORCE_SECURITY",
                }
            ),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 404)

    def test_rejects_non_ready_snapshot(self):
        scope = models.DeviceScope.objects.create(name="NonReadyScope", scope_type=models.ScopeTypeChoices.STATIC)
        snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.COLLECTING)
        response = self.client.post(
            self.endpoint,
            data=json.dumps(
                {
                    "snapshot_id": str(snapshot.pk),
                    "src": "10.0.0.10",
                    "dst": ["198.51.100.1"],
                    "protocol": "tcp",
                    "port": 443,
                    "mode": "ENFORCE_SECURITY",
                }
            ),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 409)

    def test_destination_limit_enforced(self):
        snapshot = fixtures.create_ready_snapshot("ApiLimitScope")
        destinations = [f"198.51.100.{index}" for index in range(1, 18)]
        response = self.client.post(
            self.endpoint,
            data=json.dumps(
                {
                    "snapshot_id": str(snapshot.pk),
                    "src": "10.0.0.10",
                    "dst": destinations,
                    "protocol": "tcp",
                    "port": 443,
                    "mode": "ENFORCE_SECURITY",
                }
            ),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 400)

    def test_results_returned_in_input_order(self):
        snapshot = fixtures.create_ready_snapshot("ApiReachabilityScope")
        fixtures.seed_basic_reachability_state(snapshot)
        response = self.client.post(
            self.endpoint,
            data=json.dumps(
                {
                    "snapshot_id": str(snapshot.pk),
                    "src": "10.0.0.10",
                    "dst": ["203.0.113.100", "198.51.100.20"],
                    "protocol": "tcp",
                    "port": 443,
                    "mode": "ENFORCE_SECURITY",
                }
            ),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["results"][0]["dst"], "203.0.113.100")
        self.assertEqual(data["results"][1]["dst"], "198.51.100.20")

    def test_response_contains_structured_forward_reverse_status(self):
        snapshot = fixtures.create_ready_snapshot("ApiStructuredScope")
        fixtures.seed_basic_reachability_state(snapshot)
        response = self.client.post(
            self.endpoint,
            data=json.dumps(
                {
                    "snapshot_id": str(snapshot.pk),
                    "src": "10.0.0.10",
                    "dst": ["203.0.113.100"],
                    "protocol": "tcp",
                    "port": 443,
                    "mode": "ENFORCE_SECURITY",
                }
            ),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 200)
        data = response.json()
        result = data["results"][0]
        self.assertIn("forward", result)
        self.assertIn("reverse", result)
        self.assertIn("root_cause", result)
        self.assertIn(result["forward"]["status"], ["PASS", "FAIL"])
        self.assertIn(result["reverse"]["status"], ["PASS", "FAIL"])
        self.assertIn("primary_termination", result["forward"])
        self.assertIn("primary_termination", result["reverse"])
        self.assertIn("forward_pass", data["summary"])
        self.assertIn("reverse_fail", data["summary"])


class TwinSnapshotAPITest(TestCase):
    """Test TwinSnapshot API status mutability constraints."""

    endpoint = "/api/plugins/digital_twin/twin-snapshots/"

    def setUp(self):
        user_model = get_user_model()
        self.user = user_model.objects.create_superuser(
            username="snapshotapiadmin",
            password="password",
            email="snapshotapiadmin@example.com",
        )
        self.client.force_login(self.user)
        self.scope = models.DeviceScope.objects.create(
            name="SnapshotAPIScope",
            scope_type=models.ScopeTypeChoices.STATIC,
        )

    def test_create_ignores_client_supplied_status(self):
        response = self.client.post(
            self.endpoint,
            data=json.dumps(
                {
                    "scope": str(self.scope.pk),
                    "status": models.SnapshotStatusChoices.READY,
                }
            ),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 201)
        snapshot = models.TwinSnapshot.objects.get(pk=response.json()["id"])
        self.assertEqual(snapshot.status, models.SnapshotStatusChoices.CREATED)

    def test_update_cannot_change_status(self):
        snapshot = models.TwinSnapshot.objects.create(scope=self.scope, status=models.SnapshotStatusChoices.CREATED)
        response = self.client.patch(
            f"{self.endpoint}{snapshot.pk}/",
            data={"status": models.SnapshotStatusChoices.FAILED},
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 200)
        snapshot.refresh_from_db()
        self.assertEqual(snapshot.status, models.SnapshotStatusChoices.CREATED)

    def test_update_cannot_change_error_summary(self):
        snapshot = models.TwinSnapshot.objects.create(scope=self.scope)
        response = self.client.patch(
            f"{self.endpoint}{snapshot.pk}/",
            data={"error_summary": "manually set"},
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 200)
        snapshot.refresh_from_db()
        self.assertEqual(snapshot.error_summary, "")
