"""View tests for digital twin UI."""

from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.test import TestCase

try:
    from nautobot.dcim.tests.test_views import create_test_device
except ImportError:  # pragma: no cover
    from nautobot.dcim.tests.test_filters import create_test_device

from nautobot.extras.models import Job as JobModel
from nautobot.extras.models import JobResult

from digital_twin import models
from digital_twin.tests import fixtures


class DigitalTwinUIViewTests(TestCase):
    """Smoke tests for key UI pages."""

    def test_twin_snapshot_list_page_loads(self):
        user_model = get_user_model()
        user = user_model.objects.create_superuser(
            username="snapshotlistadmin",
            password="password",
            email="snapshotlistadmin@example.com",
        )
        self.client.force_login(user)
        response = self.client.get("/plugins/digital_twin/twin-snapshots/")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Collect New Snapshot")

    def test_reachability_query_page_loads(self):
        response = self.client.get("/plugins/digital_twin/reachability/query/")
        self.assertEqual(response.status_code, 200)

    def test_snapshot_diff_query_page_loads(self):
        response = self.client.get("/plugins/digital_twin/snapshot-diff/query/")
        self.assertEqual(response.status_code, 200)

    def test_twin_snapshot_add_post_succeeds(self):
        user_model = get_user_model()
        user = user_model.objects.create_superuser(
            username="viewadmin", password="password", email="viewadmin@example.com"
        )
        self.client.force_login(user)

        scope = models.DeviceScope.objects.create(name="UIViewScope", scope_type=models.ScopeTypeChoices.STATIC)

        response = self.client.post(
            "/plugins/digital_twin/twin-snapshots/add/",
            data={"scope": str(scope.pk), "object_note": "test note"},
        )
        self.assertNotEqual(response.status_code, 500)
        self.assertEqual(response.status_code, 302)

        job_model = JobModel.objects.get_for_class_path("digital_twin.jobs.CollectSnapshotJob")
        self.assertEqual(JobResult.objects.filter(job_model=job_model).count(), 1)

    @patch("digital_twin.views.check_reachability_many")
    def test_reachability_query_renders_hop_device_link(self, mock_check_reachability):
        snapshot = fixtures.create_ready_snapshot("UIViewReachabilityScope")
        sw1 = create_test_device("SW1")

        mock_check_reachability.return_value = {
            "summary": {"total": 1, "reachable": 1, "unreachable": 0},
            "results": [
                {
                    "dst": "172.16.1.1",
                    "verdict": "REACHABLE",
                    "confidence": "HIGH",
                    "root_cause": "END_TO_END_REACHABLE",
                    "explanation": {"summary": "Reachability computed from snapshot state."},
                    "forward": {
                        "status": "PASS",
                        "primary_termination": "CONNECTED",
                        "paths": [
                            {
                                "termination_reason": "CONNECTED",
                                "hops": [
                                    {
                                        "prefix": "10.10.20.0/24",
                                        "protocol": "connected",
                                        "vrf": "default",
                                        "ingress_interface": "Vlan20",
                                        "egress_interface": "GigabitEthernet0/1",
                                        "device": "SW1",
                                    }
                                ],
                            }
                        ],
                    },
                    "reverse": {
                        "status": "PASS",
                        "primary_termination": "CONNECTED",
                        "paths": [
                            {
                                "termination_reason": "CONNECTED",
                                "hops": [
                                    {
                                        "prefix": "10.10.20.0/24",
                                        "protocol": "connected",
                                        "vrf": "default",
                                        "ingress_interface": "GigabitEthernet0/1",
                                        "egress_interface": "Vlan20",
                                        "device": "SW1",
                                    }
                                ],
                            }
                        ],
                    },
                }
            ],
        }

        response = self.client.post(
            "/plugins/digital_twin/reachability/query/",
            data={
                "snapshot": str(snapshot.pk),
                "src": "10.0.0.2",
                "dst": "172.16.1.1",
                "protocol": "tcp",
                "port": 443,
                "max_paths": 2,
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Path Diagram")
        self.assertContains(response, f'href="{sw1.get_absolute_url()}"')
        self.assertContains(response, "Forward 1")

    def test_snapshot_diff_query_renders_changes(self):
        scope = models.DeviceScope.objects.create(name="Diff Scope A", scope_type=models.ScopeTypeChoices.STATIC)
        older_snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)
        newer_snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)

        models.InterfaceState.objects.create(
            snapshot=newer_snapshot,
            interface_name="Vlan10",
            admin_up=True,
            oper_up=True,
            observed_ips=["10.0.10.1/24"],
        )
        models.InterfaceState.objects.create(
            snapshot=older_snapshot,
            interface_name="Vlan10",
            admin_up=False,
            oper_up=False,
            observed_ips=["10.0.10.1/24"],
        )

        response = self.client.post(
            "/plugins/digital_twin/snapshot-diff/query/",
            data={
                "scope": str(scope.pk),
                "left_snapshot": str(newer_snapshot.pk),
                "right_snapshot": str(older_snapshot.pk),
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Summary")
        self.assertContains(response, "Modified")
        self.assertContains(response, "Interface")

    def test_snapshot_diff_query_renders_newer_only_row_on_newer_side(self):
        scope = models.DeviceScope.objects.create(
            name="Diff Scope Newer Only", scope_type=models.ScopeTypeChoices.STATIC
        )
        older_snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)
        newer_snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)

        models.InterfaceState.objects.create(
            snapshot=newer_snapshot,
            interface_name="Vlan200",
            admin_up=True,
            oper_up=True,
            observed_ips=["10.200.0.1/24"],
        )

        response = self.client.post(
            "/plugins/digital_twin/snapshot-diff/query/",
            data={
                "scope": str(scope.pk),
                "left_snapshot": str(newer_snapshot.pk),
                "right_snapshot": str(older_snapshot.pk),
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Added")
        self.assertContains(response, "Vlan200")
        self.assertContains(response, "No matching row in older snapshot.")

    def test_snapshot_diff_query_rejects_same_snapshot(self):
        snapshot = fixtures.create_ready_snapshot("Diff Scope Same")
        response = self.client.post(
            "/plugins/digital_twin/snapshot-diff/query/",
            data={
                "scope": str(snapshot.scope.pk),
                "left_snapshot": str(snapshot.pk),
                "right_snapshot": str(snapshot.pk),
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Newer and older snapshots must be different.")

    def test_snapshot_diff_query_rejects_different_scopes(self):
        left_snapshot = fixtures.create_ready_snapshot("Diff Scope Left")
        right_snapshot = fixtures.create_ready_snapshot("Diff Scope Right")
        response = self.client.post(
            "/plugins/digital_twin/snapshot-diff/query/",
            data={
                "scope": str(left_snapshot.scope.pk),
                "left_snapshot": str(left_snapshot.pk),
                "right_snapshot": str(right_snapshot.pk),
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Snapshots must belong to the same device scope.")

    def test_snapshot_diff_query_rejects_older_left_snapshot(self):
        scope = models.DeviceScope.objects.create(
            name="Diff Scope Chronological",
            scope_type=models.ScopeTypeChoices.STATIC,
        )
        older_snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)
        newer_snapshot = models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)

        response = self.client.post(
            "/plugins/digital_twin/snapshot-diff/query/",
            data={
                "scope": str(scope.pk),
                "left_snapshot": str(older_snapshot.pk),
                "right_snapshot": str(newer_snapshot.pk),
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Newer snapshot must be newer than or equal to older snapshot.")
