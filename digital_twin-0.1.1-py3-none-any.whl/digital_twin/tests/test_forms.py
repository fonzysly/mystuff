"""Form tests for digital twin."""

import re

from django.test import TestCase
from nautobot.apps import forms as nautobot_forms
from nautobot.dcim.models import Device

from digital_twin import forms
from digital_twin.tests import fixtures


class DeviceScopeFormTest(TestCase):
    """Test DeviceScope form behavior."""

    def test_devices_field_uses_object_selector(self):
        form = forms.DeviceScopeForm()

        self.assertIsInstance(form.fields["devices"], nautobot_forms.DynamicModelMultipleChoiceField)
        self.assertIsInstance(form.fields["devices"].widget, nautobot_forms.APISelectMultiple)
        self.assertEqual(form.fields["devices"].queryset.model, Device)


class TwinSnapshotFormTest(TestCase):
    """Test TwinSnapshot form behavior."""

    def test_internal_fields_not_present_for_user_input(self):
        form = forms.TwinSnapshotForm()
        self.assertNotIn("status", form.fields)
        self.assertNotIn("notes", form.fields)
        self.assertIn("object_note", form.fields)
        self.assertNotIn("error_summary", form.fields)


class ReachabilityQueryFormTest(TestCase):
    """Test reachability form validation."""

    def test_form_valid(self):
        snapshot = fixtures.create_ready_snapshot("Form Scope")
        form = forms.ReachabilityQueryForm(
            data={
                "snapshot": str(snapshot.pk),
                "src": "10.0.0.10",
                "dst": "198.51.100.1,198.51.100.2",
                "protocol": "tcp",
                "port": 443,
                "enforce_security": True,
            }
        )
        self.assertTrue(form.is_valid())
        self.assertEqual(len(form.cleaned_data["dst"]), 2)

    def test_form_enforces_destination_limit(self):
        snapshot = fixtures.create_ready_snapshot("Form Scope Limit")
        destinations = ",".join([f"192.0.2.{idx}" for idx in range(1, 18)])
        form = forms.ReachabilityQueryForm(
            data={
                "snapshot": str(snapshot.pk),
                "src": "10.0.0.10",
                "dst": destinations,
                "protocol": "tcp",
                "port": 443,
                "enforce_security": True,
            }
        )
        self.assertFalse(form.is_valid())

    def test_form_defaults_enforce_security_and_max_paths(self):
        form = forms.ReachabilityQueryForm()
        self.assertTrue(form.fields["enforce_security"].initial)
        self.assertEqual(form.fields["max_paths"].initial, 8)

    def test_snapshot_label_is_human_friendly(self):
        snapshot = fixtures.create_ready_snapshot("Friendly Reachability Scope")
        form = forms.ReachabilityQueryForm()
        label = form.fields["snapshot"].label_from_instance(snapshot)

        self.assertIn("Friendly Reachability Scope @", label)
        self.assertIsNone(re.search(r"\dT\d", label))


class SnapshotDiffQueryFormTest(TestCase):
    """Test snapshot diff form validation."""

    def test_form_valid(self):
        scope = fixtures.models.DeviceScope.objects.create(
            name="Diff Scope",
            scope_type=fixtures.models.ScopeTypeChoices.STATIC,
        )
        older_snapshot = fixtures.models.TwinSnapshot.objects.create(
            scope=scope,
            status=fixtures.models.SnapshotStatusChoices.READY,
        )
        newer_snapshot = fixtures.models.TwinSnapshot.objects.create(
            scope=scope,
            status=fixtures.models.SnapshotStatusChoices.READY,
        )
        form = forms.SnapshotDiffQueryForm(
            data={
                "scope": str(scope.pk),
                "left_snapshot": str(newer_snapshot.pk),
                "right_snapshot": str(older_snapshot.pk),
            }
        )
        self.assertTrue(form.is_valid())

    def test_form_rejects_same_snapshot(self):
        snapshot = fixtures.create_ready_snapshot("Diff Scope Same")
        form = forms.SnapshotDiffQueryForm(
            data={
                "scope": str(snapshot.scope.pk),
                "left_snapshot": str(snapshot.pk),
                "right_snapshot": str(snapshot.pk),
            }
        )
        self.assertFalse(form.is_valid())
        self.assertIn("Newer and older snapshots must be different.", str(form.errors))

    def test_form_rejects_snapshots_from_different_scopes(self):
        left_snapshot = fixtures.create_ready_snapshot("Diff Scope Left")
        right_snapshot = fixtures.create_ready_snapshot("Diff Scope Right")
        form = forms.SnapshotDiffQueryForm(
            data={
                "scope": str(left_snapshot.scope.pk),
                "left_snapshot": str(left_snapshot.pk),
                "right_snapshot": str(right_snapshot.pk),
            }
        )

        self.assertFalse(form.is_valid())
        self.assertIn("Snapshots must belong to the same device scope.", str(form.errors))

    def test_form_rejects_older_left_snapshot(self):
        scope = fixtures.models.DeviceScope.objects.create(
            name="Diff Scope Chronological",
            scope_type=fixtures.models.ScopeTypeChoices.STATIC,
        )
        older_snapshot = fixtures.models.TwinSnapshot.objects.create(
            scope=scope,
            status=fixtures.models.SnapshotStatusChoices.READY,
        )
        newer_snapshot = fixtures.models.TwinSnapshot.objects.create(
            scope=scope,
            status=fixtures.models.SnapshotStatusChoices.READY,
        )

        form = forms.SnapshotDiffQueryForm(
            data={
                "scope": str(scope.pk),
                "left_snapshot": str(older_snapshot.pk),
                "right_snapshot": str(newer_snapshot.pk),
            }
        )

        self.assertFalse(form.is_valid())
        self.assertIn("Newer snapshot must be newer than or equal to older snapshot.", str(form.errors))

    def test_form_exposes_ready_only_snapshots(self):
        ready_snapshot = fixtures.create_ready_snapshot("Diff Scope Ready")
        pending_scope = fixtures.models.DeviceScope.objects.create(
            name="Diff Scope Pending",
            scope_type=fixtures.models.ScopeTypeChoices.STATIC,
        )
        fixtures.models.TwinSnapshot.objects.create(
            scope=pending_scope,
            status=fixtures.models.SnapshotStatusChoices.COLLECTING,
        )

        form = forms.SnapshotDiffQueryForm()
        left_ids = list(form.fields["left_snapshot"].queryset.values_list("pk", flat=True))
        right_ids = list(form.fields["right_snapshot"].queryset.values_list("pk", flat=True))

        self.assertIn(ready_snapshot.pk, left_ids)
        self.assertIn(ready_snapshot.pk, right_ids)
        self.assertEqual(len(left_ids), len(right_ids))
        self.assertEqual(left_ids, right_ids)

    def test_snapshot_labels_are_human_friendly(self):
        left_snapshot = fixtures.create_ready_snapshot("Friendly Diff Scope Left")
        right_snapshot = fixtures.create_ready_snapshot("Friendly Diff Scope Right")
        form = forms.SnapshotDiffQueryForm()

        left_label = form.fields["left_snapshot"].label_from_instance(left_snapshot)
        right_label = form.fields["right_snapshot"].label_from_instance(right_snapshot)

        self.assertIn("Friendly Diff Scope Left @", left_label)
        self.assertIn("Friendly Diff Scope Right @", right_label)
        self.assertIsNone(re.search(r"\dT\d", left_label))
        self.assertIsNone(re.search(r"\dT\d", right_label))
