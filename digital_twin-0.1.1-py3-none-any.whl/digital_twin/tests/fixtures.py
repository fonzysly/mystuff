"""Fixture builders for digital twin tests."""

from digital_twin import models


def create_ready_snapshot(name="Scope A"):
    """Create a READY snapshot with no device dependencies."""
    scope = models.DeviceScope.objects.create(name=name, scope_type=models.ScopeTypeChoices.STATIC)
    return models.TwinSnapshot.objects.create(scope=scope, status=models.SnapshotStatusChoices.READY)


def seed_basic_reachability_state(snapshot):
    """Seed deterministic route/NAT/LB/security rows for reachability tests."""
    models.RoutingTableEntryState.objects.create(
        snapshot=snapshot,
        vrf="default",
        prefix="198.51.100.0/24",
        next_hop="192.0.2.1",
        protocol="static",
        metric=1,
    )
    nat_table = models.NatTableState.objects.create(
        snapshot=snapshot,
        table_scope=models.NatTableScopeChoices.GLOBAL,
        vrf_name="",
    )
    models.NatRuleState.objects.create(
        snapshot=snapshot,
        nat_table=nat_table,
        inside_interface="vlan10",
        outside_interface="gigabitethernet0/0",
        order=10,
        conditions_json={"dst_prefix": "198.51.100.0/24", "protocol": "tcp", "port": 443},
        translations_json={"dst_ip": "198.51.100.10", "dst_port": 8443},
    )
    models.LoadBalancerState.objects.create(
        snapshot=snapshot,
        vip="203.0.113.100",
        pool="pool-web",
        members=["198.51.100.10", "198.51.100.11"],
        snat="automap",
        has_irules=True,
    )
    models.FirewallRuleState.objects.create(
        snapshot=snapshot,
        order=10,
        src_prefix="10.0.0.0/8",
        dst_prefix="198.51.100.0/24",
        protocol="tcp",
        port=8443,
        action=models.SecurityActionChoices.ALLOW,
    )
