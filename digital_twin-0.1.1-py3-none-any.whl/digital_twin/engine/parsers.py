"""Parsers for normalized state extraction."""

import ipaddress

from netutils.protocol_mapper import PROTOCOLS as _SERVICE_PORTS

_ACL_PORT_OPERAND_COUNT = {
    "eq": 1,
    "neq": 1,
    "lt": 1,
    "gt": 1,
    "range": 2,
}


def _normalize_interface_name(interface_name):
    """Normalize interface labels for deterministic matching."""
    return str(interface_name or "").strip().lower().replace(" ", "")


def _service_to_port(value):
    """Normalize netutils service mapping values into an integer port."""
    if isinstance(value, int):
        return value
    if isinstance(value, dict):
        port_number = value.get("port_number")
        if isinstance(port_number, int):
            return port_number
    return None


def parse_cisco_route_text(raw_text):
    """Parse line-oriented route artifacts.

    Expected format per line:
        <vrf> <prefix> <next_hop> <protocol> <metric>
    """
    rows = []
    for line in raw_text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        parts = stripped.split()
        if len(parts) < 5:
            continue
        vrf, prefix, next_hop, protocol, metric = parts[:5]
        ipaddress.ip_network(prefix, strict=False)
        rows.append(
            {
                "vrf": vrf,
                "prefix": prefix,
                "next_hop": next_hop,
                "protocol": protocol,
                "metric": int(metric),
            }
        )
    return rows


def parse_interface_json(payload):
    """Parse interface state payload into normalized rows."""
    rows = []
    for item in payload:
        rows.append(
            {
                "interface_name": item.get("name", ""),
                "admin_up": bool(item.get("admin_up", True)),
                "oper_up": bool(item.get("oper_up", True)),
                "observed_ips": item.get("ips", []),
                "attrs_json": item.get("attrs", {}),
            }
        )
    return rows


def parse_f5_ltm_json(payload):
    """Parse F5 virtual server payload into load balancer rows."""
    rows = []
    for item in payload:
        rows.append(
            {
                "vip": item["vip"],
                "pool": item.get("pool", ""),
                "members": item.get("members", []),
                "snat": item.get("snat", ""),
                "has_irules": bool(item.get("has_irules", False)),
                "attrs_json": item.get("attrs", {}),
            }
        )
    return rows


def parse_pbr_json(payload):
    """Parse PBR payload into normalized rows."""
    rows = []
    for item in payload:
        next_hop = item.get("set_next_hop", "")
        if next_hop:
            ipaddress.ip_address(next_hop)
        row = {
            "src_prefix": item.get("src_prefix", ""),
            "dst_prefix": item.get("dst_prefix", ""),
            "protocol": item.get("protocol", ""),
            "port": item.get("port"),
            "set_next_hop": next_hop,
            "order": int(item.get("order", 0)),
            "attrs_json": item.get("attrs", {}),
        }
        rows.append(row)
    return rows


def parse_cisco_nat_table_json(payload):
    """Parse canonical NAT table payload into table/rule rows."""
    if isinstance(payload, list):
        payload = {"tables": payload}

    table_rows = []
    rule_rows = []
    tables = payload.get("tables") or []
    for table in tables:
        table_scope = str(table.get("table_scope") or "GLOBAL").strip().upper()
        if table_scope not in {"GLOBAL", "VRF"}:
            table_scope = "GLOBAL"
        vrf_name = str(table.get("vrf_name") or "").strip()
        if table_scope == "GLOBAL":
            vrf_name = ""

        table_rows.append(
            {
                "table_scope": table_scope,
                "vrf_name": vrf_name,
                "attrs_json": table.get("attrs_json") or {},
            }
        )

        for item in table.get("rules") or []:
            inside_interface = _normalize_interface_name(item.get("inside_interface"))
            outside_interface = _normalize_interface_name(item.get("outside_interface"))
            if not inside_interface or not outside_interface:
                continue

            conditions = item.get("conditions_json") or {}
            translations = item.get("translations_json") or {}

            src_prefix = conditions.get("src_prefix") or ""
            dst_prefix = conditions.get("dst_prefix") or ""
            if src_prefix:
                ipaddress.ip_network(src_prefix, strict=False)
            if dst_prefix:
                ipaddress.ip_network(dst_prefix, strict=False)

            src_ip = translations.get("src_ip")
            dst_ip = translations.get("dst_ip")
            if src_ip:
                ipaddress.ip_address(src_ip)
            if dst_ip:
                ipaddress.ip_address(dst_ip)

            row = {
                "table_scope": table_scope,
                "vrf_name": vrf_name,
                "inside_interface": inside_interface,
                "outside_interface": outside_interface,
                "conditions_json": conditions,
                "translations_json": translations,
                "order": int(item.get("order", 0)),
                "attrs_json": item.get("attrs_json") or {},
            }
            rule_rows.append(row)

    return {"tables": table_rows, "rules": rule_rows}


def _wildcard_to_prefix(ip_token, wildcard_token):
    """Convert Cisco wildcard notation into CIDR prefix."""
    wildcard_int = int(ipaddress.IPv4Address(wildcard_token))
    netmask_int = (~wildcard_int) & 0xFFFFFFFF
    netmask = str(ipaddress.IPv4Address(netmask_int))
    network = ipaddress.IPv4Network((ip_token, netmask), strict=False)
    return str(network)


def _parse_acl_address(tokens, index):
    """Parse ACL address operand returning (prefix, next_index)."""
    if index >= len(tokens):
        return "", index

    token = tokens[index].lower()
    if token == "any":  # noqa: S105
        return "", index + 1
    if token == "host" and index + 1 < len(tokens):  # noqa: S105
        ipaddress.ip_address(tokens[index + 1])
        return f"{tokens[index + 1]}/32", index + 2

    if index + 1 < len(tokens):
        try:
            ipaddress.ip_address(tokens[index])
            ipaddress.ip_address(tokens[index + 1])
            return _wildcard_to_prefix(tokens[index], tokens[index + 1]), index + 2
        except ValueError:
            return "", index + 1

    return "", index + 1


def _parse_acl_port(tokens, index):
    """Parse ACL destination port returning (port, next_index)."""
    if index >= len(tokens):
        return None, index

    operator = tokens[index].lower()
    operand_count = _ACL_PORT_OPERAND_COUNT.get(operator)
    if operand_count is None or index + operand_count >= len(tokens):
        return None, index

    raw = tokens[index + 1].lower()
    if raw.isdigit():
        return int(raw), index + 1 + operand_count
    return _service_to_port(_SERVICE_PORTS.get(raw)), index + 1 + operand_count


def _consume_acl_port_clause(tokens, index):
    """Consume one ACL port clause and return the next token index."""
    if index >= len(tokens):
        return index

    operator = tokens[index].lower()
    operand_count = _ACL_PORT_OPERAND_COUNT.get(operator)
    if operand_count is None:
        return index

    next_index = index + 1 + operand_count
    return min(next_index, len(tokens))


def parse_cisco_acl_text(raw_text):
    """Parse Cisco ACL show output into normalized ACL rule rows."""
    rows = []
    current_acl = ""
    inferred_order = 0

    for line in raw_text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue

        lowered = stripped.lower()
        if lowered.startswith("extended ip access list "):
            current_acl = stripped.split("Extended IP access list ", 1)[1].strip()
            continue
        if lowered.startswith("ip access list ") and len(stripped.split()) >= 4:
            current_acl = stripped.split(None, 3)[3].strip()
            continue
        if lowered.startswith("ip access list extended "):
            current_acl = stripped.split("ip access list extended ", 1)[1].strip()
            continue
        if lowered.startswith("ip access list standard "):
            current_acl = stripped.split("ip access list standard ", 1)[1].strip()
            continue
        if lowered.startswith("standard ip access list "):
            current_acl = stripped.split("Standard IP access list ", 1)[1].strip()
            continue

        tokens = stripped.split()
        if not tokens:
            continue

        seq = None
        if tokens[0].isdigit():
            seq = int(tokens[0])
            tokens = tokens[1:]
        if not tokens:
            continue

        acl_action = tokens[0].lower()
        if acl_action not in {"permit", "deny"}:
            continue
        if len(tokens) < 2:
            continue

        protocol = tokens[1].lower()
        index = 2
        src_prefix, index = _parse_acl_address(tokens, index)
        src_port = None
        if protocol in {"tcp", "udp"}:
            src_port, _ = _parse_acl_port(tokens, index)
            index = _consume_acl_port_clause(tokens, index)
        dst_prefix, index = _parse_acl_address(tokens, index)

        port = None
        if protocol in {"tcp", "udp"}:
            dst_port, index = _parse_acl_port(tokens, index)
            port = dst_port if dst_port is not None else src_port

        inferred_order += 1
        rows.append(
            {
                "src_prefix": src_prefix,
                "dst_prefix": dst_prefix,
                "protocol": protocol,
                "port": port,
                "action": "ALLOW" if acl_action == "permit" else "DENY",
                "order": seq if seq is not None else inferred_order,
                "attrs_json": {
                    "acl_name": current_acl,
                    "raw": stripped,
                },
            }
        )

    return rows
