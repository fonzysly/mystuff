"""Deterministic snapshot-scoped reachability engine."""

import ipaddress
import re

from django.db.utils import OperationalError, ProgrammingError

try:
    from netutils.interface import canonical_interface_name
except ImportError:  # pragma: no cover
    canonical_interface_name = None

from digital_twin import models


class ReachabilityError(ValueError):
    """Raised when reachability input is invalid."""


CONNECTED_PROTOCOLS = {"connected", "local", "direct"}
DEFAULT_NEXT_HOP = "0.0.0.0"  # noqa: S104


def _normalize_nexthop(next_hop):
    """Normalize next hop values from collected route text."""
    value = str(next_hop or "").strip()
    if not value or value.lower() in {"direct", "connected", "-"}:
        return DEFAULT_NEXT_HOP
    return value


def _build_route_index(snapshot):
    """Index snapshot routes by device and by network ownership."""
    routes_by_device = {}
    connected_networks_by_device = {}
    for route in models.RoutingTableEntryState.objects.filter(snapshot=snapshot).select_related("device"):
        if route.device is None:
            continue
        routes_by_device.setdefault(route.device_id, []).append(route)

        protocol = (route.protocol or "").lower()
        if protocol in CONNECTED_PROTOCOLS:
            try:
                network = ipaddress.ip_network(route.prefix, strict=False)
            except ValueError:
                continue
            connected_networks_by_device.setdefault(route.device_id, []).append(network)
    return routes_by_device, connected_networks_by_device


def _build_interface_index(snapshot):
    """Index normalized interface rows per device for operational checks."""
    interfaces_by_device = {}
    for interface_state in models.InterfaceState.objects.filter(snapshot=snapshot):
        if interface_state.device_id is None:
            continue
        interfaces_by_device.setdefault(interface_state.device_id, []).append(interface_state)
    return interfaces_by_device


def _build_down_device_index(snapshot):
    """Index devices with failed collection/parse/build states in this snapshot."""
    down_device_ids = set()
    for device_state in snapshot.device_states.select_related("device"):
        if device_state.device_id is None:
            continue
        if (
            device_state.collection_status == models.StageStatusChoices.FAILED
            or device_state.parse_status == models.StageStatusChoices.FAILED
            or device_state.build_status == models.StageStatusChoices.FAILED
        ):
            down_device_ids.add(device_state.device_id)
    return down_device_ids


def _build_pbr_index(snapshot):
    """Index PBR rules by device, sorted by order."""
    rules_by_device = {}
    try:
        queryset = models.PbrRuleState.objects.filter(snapshot=snapshot).order_by("order", "pk")
        for rule in queryset:
            if rule.device_id is None:
                continue
            rules_by_device.setdefault(rule.device_id, []).append(rule)
    except (ProgrammingError, OperationalError):
        return {}
    return rules_by_device


def _normalize_mac(value):
    """Normalize MAC into 12-hex lowercase string."""
    normalized = re.sub(r"[^0-9A-Fa-f]", "", str(value or ""))
    if len(normalized) != 12:
        return ""
    return normalized.lower()


def _build_arp_index(snapshot):
    """Index ARP next-hop resolution per device from raw artifacts."""
    arp_by_device = {}
    devices_with_arp = set()
    ip_pattern = re.compile(r"\b(?P<ip>(?:\d{1,3}\.){3}\d{1,3})\b")
    mac_pattern = re.compile(
        r"\b(?P<mac>(?:[0-9A-Fa-f]{4}\.){2}[0-9A-Fa-f]{4}|(?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}|(?:[0-9A-Fa-f]{2}-){5}[0-9A-Fa-f]{2})\b"
    )
    vrf_patterns = [
        re.compile(r'^IP ARP Table for VRF\s+"(?P<vrf>[^"]+)"$', re.IGNORECASE),
        re.compile(r"^Address Resolution Protocol Table\s*-\s*VRF\s*(?P<vrf>\S+)$", re.IGNORECASE),
        re.compile(r"^VRF:\s*(?P<vrf>\S+)$", re.IGNORECASE),
    ]

    artifacts = models.StateArtifact.objects.filter(
        device_state__snapshot=snapshot,
        artifact_type="show_arp_raw",
    ).select_related("device_state__device")

    for artifact in artifacts:
        device = artifact.device_state.device
        if device is None:
            continue
        devices_with_arp.add(device.id)
        device_table = arp_by_device.setdefault(device.id, {})
        current_vrf = "default"
        for line in artifact.content.splitlines():
            stripped = line.strip()
            if not stripped:
                continue
            for vrf_pattern in vrf_patterns:
                vrf_match = vrf_pattern.match(stripped)
                if vrf_match:
                    current_vrf = (vrf_match.group("vrf") or "default").strip() or "default"
                    break
            else:
                vrf_match = None
            if vrf_match:
                continue
            ip_match = ip_pattern.search(line)
            mac_match = mac_pattern.search(line)
            if not ip_match or not mac_match:
                continue
            mac = _normalize_mac(mac_match.group("mac"))
            if not mac:
                continue
            vrf_table = device_table.setdefault(current_vrf, {})
            vrf_table[ip_match.group("ip")] = mac

    return arp_by_device, devices_with_arp


def _build_mac_index(snapshot):
    """Index MAC addresses observed in MAC table artifacts per device."""
    macs_by_device = {}
    mac_interfaces_by_device = {}
    devices_with_mac = set()
    mac_pattern = re.compile(
        r"\b(?P<mac>(?:[0-9A-Fa-f]{4}\.){2}[0-9A-Fa-f]{4}|(?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}|(?:[0-9A-Fa-f]{2}-){5}[0-9A-Fa-f]{2})\b"
    )
    interface_pattern = re.compile(r"^(?:[A-Za-z]+[A-Za-z0-9/\.\-]*\d+[A-Za-z0-9/\.\-]*|Vlan\d+)$")

    artifacts = models.StateArtifact.objects.filter(
        device_state__snapshot=snapshot,
        artifact_type="show_mac_raw",
    ).select_related("device_state__device")

    for artifact in artifacts:
        device = artifact.device_state.device
        if device is None:
            continue
        devices_with_mac.add(device.id)
        table = macs_by_device.setdefault(device.id, set())
        interface_map = mac_interfaces_by_device.setdefault(device.id, {})
        for line in artifact.content.splitlines():
            stripped = line.strip()
            learned_interface = None
            tokens = stripped.split()
            for token in reversed(tokens):
                if interface_pattern.match(token):
                    learned_interface = token
                    break
            for match in mac_pattern.finditer(stripped):
                mac = _normalize_mac(match.group("mac"))
                if mac:
                    table.add(mac)
                    if learned_interface:
                        interface_map.setdefault(mac, set()).add(learned_interface)

    return macs_by_device, mac_interfaces_by_device, devices_with_mac


def _build_interface_mode_index(snapshot):
    """Index explicit interface L2/L3 mode from running configuration artifacts."""
    mode_by_device = {}
    artifacts = models.StateArtifact.objects.filter(
        device_state__snapshot=snapshot,
        artifact_type="show_run",
    ).select_related("device_state__device")

    for artifact in artifacts:
        device = artifact.device_state.device
        if device is None:
            continue
        device_modes = mode_by_device.setdefault(device.id, {})
        current_interface = None
        for line in (artifact.content or "").splitlines():
            stripped = line.strip()
            lowered = stripped.lower()
            if lowered.startswith("interface "):
                current_interface = stripped.split(None, 1)[1].strip().lower()
                continue
            if not current_interface:
                continue
            if lowered.startswith("no switchport"):
                device_modes[current_interface] = "routed"
                continue
            if lowered.startswith("switchport"):
                device_modes[current_interface] = "switched"

    return mode_by_device


def _extract_active_fhrp_vips(raw_output):
    """Extract active/master FHRP virtual IPs from raw command output."""
    vips = set()
    ip_pattern = re.compile(r"\b(?P<ip>(?:\d{1,3}\.){3}\d{1,3})\b")
    for line in raw_output.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        lowered = stripped.lower()
        if lowered.startswith("interface") or lowered.startswith("vlan") and "group" in lowered:
            continue
        if "active" not in lowered and "master" not in lowered:
            continue
        ips = [match.group("ip") for match in ip_pattern.finditer(stripped)]
        if not ips:
            continue
        vips.add(ips[-1])
    return vips


def _build_fhrp_active_index(snapshot):
    """Map FHRP virtual IPs to active device IDs from collected artifacts."""
    active_device_by_vip = {}
    artifacts = models.StateArtifact.objects.filter(
        device_state__snapshot=snapshot,
        artifact_type="show_fhrp_raw",
    ).select_related("device_state__device")

    for artifact in artifacts:
        device = artifact.device_state.device
        if device is None:
            continue
        for vip in _extract_active_fhrp_vips(artifact.content or ""):
            active_device_by_vip[vip] = device.id

    return active_device_by_vip


def _validate_next_hop_neighbor(
    current_device_id,
    current_vrf,
    egress_interface,
    next_hop_ip,
    arp_by_device,
    devices_with_arp,
    macs_by_device,
    mac_interfaces_by_device,
    devices_with_mac,
    interface_mode_by_device,
    limitations,
):
    """Validate next-hop neighbor using ARP and optional MAC table evidence."""
    next_hop_key = str(next_hop_ip)
    if current_device_id not in devices_with_arp:
        limitation = "ARP table unavailable for some devices; neighbor validation is partial."
        if limitation not in limitations:
            limitations.append(limitation)
        return None, None

    device_arp = arp_by_device.get(current_device_id, {})
    lookup_vrf = (current_vrf or "default").strip() or "default"
    mac = device_arp.get(lookup_vrf, {}).get(next_hop_key)
    if not mac and lookup_vrf != "default":
        mac = device_arp.get("default", {}).get(next_hop_key)
    if not mac:
        return "ARP_MISS", None

    interface_mode = None
    if egress_interface:
        interface_mode = interface_mode_by_device.get(current_device_id, {}).get(egress_interface.strip().lower())

    if current_device_id in devices_with_mac:
        if interface_mode == "routed":
            return None, None
        if interface_mode is None:
            limitation = (
                "Interface switchport mode unknown for some egress interfaces; L2 adjacency validation is partial."
            )
            if limitation not in limitations:
                limitations.append(limitation)
            return None, None
        if mac not in macs_by_device.get(current_device_id, set()):
            return "ARP_MAC_MISS", None
        learned_interfaces = sorted(mac_interfaces_by_device.get(current_device_id, {}).get(mac, set()))
        if learned_interfaces:
            return None, learned_interfaces[0]
    else:
        limitation = "MAC table unavailable for some devices; L2 adjacency validation is partial."
        if limitation not in limitations:
            limitations.append(limitation)

    return None, None


def _select_pbr_rule(device_rules, src_ip, dst_ip, protocol, port):
    """Return first matching PBR rule for this flow."""
    for rule in device_rules:
        conditions = {
            "src_prefix": rule.src_prefix,
            "dst_prefix": rule.dst_prefix,
            "protocol": rule.protocol,
            "port": rule.port,
        }
        if _match_rule(conditions, src_ip, dst_ip, protocol, port):
            return rule
    return None


def _route_is_usable(route, interfaces_by_device, down_device_ids):
    """Check whether route is usable given device/interface operational state."""
    if route.device_id in down_device_ids:
        return False, "DEVICE_DOWN"

    protocol = (route.protocol or "").lower()
    if protocol not in CONNECTED_PROTOCOLS:
        return True, None

    interface_rows = interfaces_by_device.get(route.device_id, [])
    if not interface_rows:
        return True, None

    try:
        route_network = ipaddress.ip_network(route.prefix, strict=False)
    except ValueError:
        return True, None

    candidates = []
    for interface_state in interface_rows:
        for observed in interface_state.observed_ips:
            try:
                observed_ip = ipaddress.ip_interface(observed).ip
            except ValueError:
                continue
            if observed_ip in route_network:
                candidates.append(interface_state)
                break

    if not candidates:
        return True, None

    if any(interface_state.admin_up and interface_state.oper_up for interface_state in candidates):
        return True, None
    return False, "INTERFACE_DOWN"


def _infer_transit_interfaces(route, interfaces_by_device):
    """Infer likely transit interfaces for a route hop."""
    interface_rows = interfaces_by_device.get(route.device_id, [])
    if not interface_rows:
        return []

    protocol = (route.protocol or "").lower()
    expected_network = None
    next_hop_ip = None
    if protocol in CONNECTED_PROTOCOLS:
        try:
            expected_network = ipaddress.ip_network(route.prefix, strict=False)
        except ValueError:
            return []
    else:
        normalized_next_hop = _normalize_nexthop(route.next_hop)
        if normalized_next_hop == DEFAULT_NEXT_HOP:
            return []
        try:
            next_hop_ip = ipaddress.ip_address(normalized_next_hop)
        except ValueError:
            return []

    interfaces = []
    for interface_state in interface_rows:
        for observed in interface_state.observed_ips:
            try:
                observed_interface = ipaddress.ip_interface(observed)
            except ValueError:
                continue
            if expected_network is not None and observed_interface.ip in expected_network:
                interfaces.append(interface_state.interface_name)
                break
            if expected_network is None and next_hop_ip in observed_interface.network:
                interfaces.append(interface_state.interface_name)
                break

    return sorted(set(interfaces))


def _infer_hop_interface_details(route, interfaces_by_device, routes_by_device, path_hops, src_ip):
    """Infer ingress/egress interface names for a hop."""
    interface_rows = interfaces_by_device.get(route.device_id, [])
    if not interface_rows:
        return None, None, []

    connected_networks = []
    for candidate_route in routes_by_device.get(route.device_id, []):
        if (candidate_route.protocol or "").lower() not in CONNECTED_PROTOCOLS:
            continue
        try:
            connected_networks.append(ipaddress.ip_network(candidate_route.prefix, strict=False))
        except ValueError:
            continue

    ingress_ip = None
    if path_hops:
        previous_next_hop = _normalize_nexthop(path_hops[-1].get("next_hop"))
        if previous_next_hop != DEFAULT_NEXT_HOP:
            try:
                ingress_ip = ipaddress.ip_address(previous_next_hop)
            except ValueError:
                ingress_ip = None
    if ingress_ip is None:
        try:
            ingress_ip = ipaddress.ip_address(src_ip)
        except ValueError:
            ingress_ip = None

    ingress_interface = None
    egress_interface = None

    protocol = (route.protocol or "").lower()
    destination_network = None
    if protocol in CONNECTED_PROTOCOLS:
        try:
            destination_network = ipaddress.ip_network(route.prefix, strict=False)
        except ValueError:
            destination_network = None

    next_hop_ip = None
    if protocol not in CONNECTED_PROTOCOLS:
        normalized_next_hop = _normalize_nexthop(route.next_hop)
        if normalized_next_hop != DEFAULT_NEXT_HOP:
            try:
                next_hop_ip = ipaddress.ip_address(normalized_next_hop)
            except ValueError:
                next_hop_ip = None

    for interface_state in interface_rows:
        for observed in interface_state.observed_ips:
            try:
                observed_interface = ipaddress.ip_interface(observed)
            except ValueError:
                continue
            observed_ip = observed_interface.ip
            if ingress_interface is None and ingress_ip:
                if ingress_ip in observed_interface.network:
                    ingress_interface = interface_state.interface_name
                elif any(observed_ip in net and ingress_ip in net for net in connected_networks):
                    ingress_interface = interface_state.interface_name
            if egress_interface is None:
                if destination_network is not None and observed_interface.ip in destination_network:
                    egress_interface = interface_state.interface_name
                elif next_hop_ip:
                    if next_hop_ip in observed_interface.network:
                        egress_interface = interface_state.interface_name
                    elif any(observed_ip in net and next_hop_ip in net for net in connected_networks):
                        egress_interface = interface_state.interface_name
            if ingress_interface and egress_interface:
                break
        if ingress_interface and egress_interface:
            break

    interfaces = [value for value in [ingress_interface, egress_interface] if value]
    return ingress_interface, egress_interface, sorted(set(interfaces))


def _candidate_source_devices(routes_by_device, interfaces_by_device, src_ip):
    """Find possible source devices that own the source IP."""
    candidates = {}

    def _bump(device_id, score):
        candidates[device_id] = candidates.get(device_id, 0) + score

    for device_id, routes in routes_by_device.items():
        for route in routes:
            protocol = (route.protocol or "").lower()
            if protocol not in CONNECTED_PROTOCOLS:
                continue
            try:
                network = ipaddress.ip_network(route.prefix, strict=False)
            except ValueError:
                continue
            if src_ip in network:
                _bump(device_id, 20)
                route_vrf = (route.vrf or "default").strip() or "default"
                if route_vrf.lower() != "default":
                    _bump(device_id, 20)
                for candidate_route in routes:
                    candidate_protocol = (candidate_route.protocol or "").lower()
                    candidate_vrf = (candidate_route.vrf or "default").strip() or "default"
                    if candidate_protocol in CONNECTED_PROTOCOLS:
                        continue
                    if candidate_vrf == route_vrf:
                        _bump(device_id, 10)
                        break
                break

    for device_id, interface_rows in interfaces_by_device.items():
        device_networks = []
        for route in routes_by_device.get(device_id, []):
            if (route.protocol or "").lower() not in CONNECTED_PROTOCOLS:
                continue
            try:
                device_networks.append(ipaddress.ip_network(route.prefix, strict=False))
            except ValueError:
                continue
        for interface_state in interface_rows:
            for observed in interface_state.observed_ips:
                try:
                    observed_ip = ipaddress.ip_interface(observed).ip
                except ValueError:
                    continue
                if observed_ip == src_ip:
                    _bump(device_id, 100)
                elif any(observed_ip in network and src_ip in network for network in device_networks):
                    _bump(device_id, 40)

    return [device_id for device_id, _score in sorted(candidates.items(), key=lambda item: (-item[1], item[0]))]


def _best_routes_for_device(device_routes, destination_ip, vrf=None):
    """Return best route set (longest prefix, then lowest metric) for one device."""
    matches = []
    for route in device_routes:
        if vrf and (route.vrf or "") != vrf:
            continue
        try:
            network = ipaddress.ip_network(route.prefix, strict=False)
        except ValueError:
            continue
        if destination_ip in network:
            metric = route.metric if route.metric is not None else 0
            matches.append((route, network.prefixlen, metric))

    if not matches:
        return []

    best_prefix = max(prefix_len for _route, prefix_len, _metric in matches)
    prefix_matches = [entry for entry in matches if entry[1] == best_prefix]
    best_metric = min(metric for _route, _prefix_len, metric in prefix_matches)
    return [route for route, _prefix_len, metric in prefix_matches if metric == best_metric]


def _infer_source_vrf(source_device_id, routes_by_device, interfaces_by_device, src_ip):
    """Infer the source VRF for first-hop route lookup on source device."""
    candidates = []
    device_routes = routes_by_device.get(source_device_id, [])
    for route in device_routes:
        if (route.protocol or "").lower() not in CONNECTED_PROTOCOLS:
            continue
        try:
            network = ipaddress.ip_network(route.prefix, strict=False)
        except ValueError:
            continue
        if src_ip in network:
            candidates.append((network.prefixlen, route.vrf or "default"))
    if candidates:
        candidates.sort(reverse=True)
        return candidates[0][1]

    interface_rows = interfaces_by_device.get(source_device_id, [])
    connected_routes = [route for route in device_routes if (route.protocol or "").lower() in CONNECTED_PROTOCOLS]
    for interface_state in interface_rows:
        for observed in interface_state.observed_ips:
            try:
                observed_ip = ipaddress.ip_interface(observed).ip
            except ValueError:
                continue
            for route in connected_routes:
                try:
                    network = ipaddress.ip_network(route.prefix, strict=False)
                except ValueError:
                    continue
                if observed_ip in network and src_ip in network:
                    return route.vrf or "default"
    return None


def _candidate_next_devices(connected_networks_by_device, next_hop_ip):
    """Map route next-hop IP to candidate downstream devices."""
    candidates = []
    for device_id, networks in connected_networks_by_device.items():
        for network in networks:
            if next_hop_ip in network:
                candidates.append(device_id)
                break
    return candidates


def _device_name_for_id(device_id, routes_by_device):
    """Resolve device name from indexed route rows."""
    for route in routes_by_device.get(device_id, []):
        if route.device is not None:
            return route.device.name
    return None


def _infer_terminal_ingress_interface(current_device_id, routes_by_device, interfaces_by_device, path_hops, src_ip):
    """Infer ingress interface for terminal failure hop."""
    ingress_ip = None
    if path_hops:
        previous_next_hop = _normalize_nexthop(path_hops[-1].get("next_hop"))
        if previous_next_hop != DEFAULT_NEXT_HOP:
            try:
                ingress_ip = ipaddress.ip_address(previous_next_hop)
            except ValueError:
                ingress_ip = None
    if ingress_ip is None:
        try:
            ingress_ip = ipaddress.ip_address(src_ip)
        except ValueError:
            return None

    connected_networks = []
    for route in routes_by_device.get(current_device_id, []):
        if (route.protocol or "").lower() not in CONNECTED_PROTOCOLS:
            continue
        try:
            connected_networks.append(ipaddress.ip_network(route.prefix, strict=False))
        except ValueError:
            continue

    for interface_state in interfaces_by_device.get(current_device_id, []):
        for observed in interface_state.observed_ips:
            try:
                observed_interface = ipaddress.ip_interface(observed)
            except ValueError:
                continue
            if ingress_ip in observed_interface.network:
                return interface_state.interface_name
            observed_ip = observed_interface.ip
            if any(observed_ip in network and ingress_ip in network for network in connected_networks):
                return interface_state.interface_name
    return None


def _terminal_failure_hop(
    current_device_id, destination_ip, routes_by_device, interfaces_by_device, path_hops, src_ip, vrf=""
):
    """Build synthetic terminal hop for failures that occur before route selection."""
    ingress_interface = _infer_terminal_ingress_interface(
        current_device_id,
        routes_by_device,
        interfaces_by_device,
        path_hops,
        src_ip,
    )
    return {
        "device": _device_name_for_id(current_device_id, routes_by_device),
        "vrf": vrf,
        "prefix": str(destination_ip),
        "next_hop": DEFAULT_NEXT_HOP,
        "protocol": "failure",
        "ingress_interface": ingress_interface,
        "egress_interface": None,
        "interfaces": [ingress_interface] if ingress_interface else [],
        "l2_decision": False,
    }


def _trace_paths(
    *,
    routes_by_device,
    connected_networks_by_device,
    current_device_id,
    destination_ip,
    path_hops,
    visited,
    max_paths,
    limitations,
    interfaces_by_device,
    down_device_ids,
    pbr_rules_by_device,
    arp_by_device,
    devices_with_arp,
    macs_by_device,
    mac_interfaces_by_device,
    devices_with_mac,
    interface_mode_by_device,
    fhrp_active_device_by_vip,
    source_device_id,
    source_vrf,
    src_ip,
    protocol,
    port,
):
    """Depth-first path tracing from source device to destination endpoint."""
    if len(path_hops) >= 16:
        failure_hop = _terminal_failure_hop(
            current_device_id,
            destination_ip,
            routes_by_device,
            interfaces_by_device,
            path_hops,
            src_ip,
        )
        return [{"hops": list(path_hops) + [failure_hop], "reached": False, "termination_reason": "MAX_HOPS_EXCEEDED"}]

    device_routes = routes_by_device.get(current_device_id, [])

    pbr_rule = _select_pbr_rule(
        pbr_rules_by_device.get(current_device_id, []),
        src_ip=src_ip,
        dst_ip=str(destination_ip),
        protocol=protocol,
        port=port,
    )
    if pbr_rule and pbr_rule.set_next_hop:
        pbr_ingress_interface = None
        pbr_egress_interface = None
        pbr_interfaces = []
        device_interfaces = interfaces_by_device.get(current_device_id, [])
        if device_interfaces:
            candidate_ingress_ip = None
            if path_hops:
                previous_next_hop = _normalize_nexthop(path_hops[-1].get("next_hop"))
                if previous_next_hop != DEFAULT_NEXT_HOP:
                    try:
                        candidate_ingress_ip = ipaddress.ip_address(previous_next_hop)
                    except ValueError:
                        candidate_ingress_ip = None
            if candidate_ingress_ip is None:
                try:
                    candidate_ingress_ip = ipaddress.ip_address(src_ip)
                except ValueError:
                    candidate_ingress_ip = None

            normalized_pbr_next_hop = _normalize_nexthop(pbr_rule.set_next_hop)
            pbr_next_hop_ip = None
            if normalized_pbr_next_hop != DEFAULT_NEXT_HOP:
                try:
                    pbr_next_hop_ip = ipaddress.ip_address(normalized_pbr_next_hop)
                except ValueError:
                    pbr_next_hop_ip = None

            for interface_state in device_interfaces:
                for observed in interface_state.observed_ips:
                    try:
                        observed_interface = ipaddress.ip_interface(observed)
                    except ValueError:
                        continue
                    if (
                        pbr_ingress_interface is None
                        and candidate_ingress_ip
                        and candidate_ingress_ip in observed_interface.network
                    ):
                        pbr_ingress_interface = interface_state.interface_name
                    if (
                        pbr_egress_interface is None
                        and pbr_next_hop_ip
                        and pbr_next_hop_ip in observed_interface.network
                    ):
                        pbr_egress_interface = interface_state.interface_name
                    if pbr_ingress_interface and pbr_egress_interface:
                        break
                if pbr_ingress_interface and pbr_egress_interface:
                    break
            pbr_interfaces = sorted(set(value for value in [pbr_ingress_interface, pbr_egress_interface] if value))

        pbr_hop = {
            "device": pbr_rule.device.name if pbr_rule.device else None,
            "vrf": "",
            "prefix": str(destination_ip),
            "next_hop": _normalize_nexthop(pbr_rule.set_next_hop),
            "protocol": "pbr",
            "ingress_interface": pbr_ingress_interface,
            "egress_interface": pbr_egress_interface,
            "interfaces": pbr_interfaces,
            "l2_decision": False,
        }
        pbr_path = list(path_hops) + [pbr_hop]

        if pbr_hop["next_hop"] == DEFAULT_NEXT_HOP:
            return [{"hops": pbr_path, "reached": False, "termination_reason": "PBR_UNRESOLVED_NEXT_HOP"}]

        try:
            pbr_next_hop_ip = ipaddress.ip_address(pbr_hop["next_hop"])
        except ValueError:
            return [{"hops": pbr_path, "reached": False, "termination_reason": "PBR_INVALID_NEXT_HOP"}]

        next_devices = [
            device_id
            for device_id in _candidate_next_devices(connected_networks_by_device, pbr_next_hop_ip)
            if device_id != current_device_id
        ]
        if not next_devices:
            current_connected = connected_networks_by_device.get(current_device_id, [])
            if any(pbr_next_hop_ip in network for network in current_connected):
                onlink_limitation = "On-link PBR next hop neighbor not modeled in snapshot; path inferred at L3 egress."
                if onlink_limitation not in limitations:
                    limitations.append(onlink_limitation)
                return [{"hops": pbr_path, "reached": True, "termination_reason": "PBR_ONLINK_NEXT_HOP_UNMAPPED"}]
            return [{"hops": pbr_path, "reached": False, "termination_reason": "PBR_NEXT_HOP_EXTERNAL"}]

        all_paths = []
        for next_device_id in next_devices:
            child_paths = _trace_paths(
                routes_by_device=routes_by_device,
                connected_networks_by_device=connected_networks_by_device,
                current_device_id=next_device_id,
                destination_ip=destination_ip,
                path_hops=pbr_path,
                visited=set(visited),
                max_paths=max_paths,
                limitations=limitations,
                interfaces_by_device=interfaces_by_device,
                down_device_ids=down_device_ids,
                pbr_rules_by_device=pbr_rules_by_device,
                arp_by_device=arp_by_device,
                devices_with_arp=devices_with_arp,
                macs_by_device=macs_by_device,
                mac_interfaces_by_device=mac_interfaces_by_device,
                devices_with_mac=devices_with_mac,
                interface_mode_by_device=interface_mode_by_device,
                fhrp_active_device_by_vip=fhrp_active_device_by_vip,
                source_device_id=source_device_id,
                source_vrf=source_vrf,
                src_ip=src_ip,
                protocol=protocol,
                port=port,
            )
            all_paths.extend(child_paths)
            if len(all_paths) >= max_paths:
                break
        return all_paths[:max_paths]

    route_vrf = source_vrf if source_vrf and current_device_id == source_device_id else None
    selected_routes = _best_routes_for_device(device_routes, destination_ip, vrf=route_vrf)
    if not selected_routes:
        failure_hop = _terminal_failure_hop(
            current_device_id,
            destination_ip,
            routes_by_device,
            interfaces_by_device,
            path_hops,
            src_ip,
            vrf=route_vrf or "",
        )
        return [{"hops": list(path_hops) + [failure_hop], "reached": False, "termination_reason": "NO_ROUTE"}]

    all_paths = []
    for route in selected_routes:
        route_key = (current_device_id, route.prefix, _normalize_nexthop(route.next_hop))
        if route_key in visited:
            failure_hop = _terminal_failure_hop(
                current_device_id,
                destination_ip,
                routes_by_device,
                interfaces_by_device,
                path_hops,
                src_ip,
                vrf=route.vrf or "",
            )
            all_paths.append(
                {"hops": list(path_hops) + [failure_hop], "reached": False, "termination_reason": "ROUTING_LOOP"}
            )
            continue

        ingress_interface, egress_interface, interfaces = _infer_hop_interface_details(
            route,
            interfaces_by_device,
            routes_by_device,
            path_hops,
            src_ip,
        )

        hop = {
            "device": route.device.name if route.device else None,
            "vrf": route.vrf,
            "prefix": route.prefix,
            "next_hop": _normalize_nexthop(route.next_hop),
            "protocol": route.protocol,
            "ingress_interface": ingress_interface,
            "egress_interface": egress_interface,
            "interfaces": interfaces,
            "l2_decision": False,
        }
        current_path = list(path_hops) + [hop]

        usable, unusable_reason = _route_is_usable(route, interfaces_by_device, down_device_ids)
        if not usable:
            all_paths.append({"hops": current_path, "reached": False, "termination_reason": unusable_reason})
            if len(all_paths) >= max_paths:
                break
            continue

        protocol = (route.protocol or "").lower()
        if protocol in CONNECTED_PROTOCOLS:
            all_paths.append({"hops": current_path, "reached": True, "termination_reason": "CONNECTED"})
            if len(all_paths) >= max_paths:
                break
            continue

        if hop["next_hop"] == DEFAULT_NEXT_HOP:
            all_paths.append({"hops": current_path, "reached": False, "termination_reason": "UNRESOLVED_NEXT_HOP"})
            if len(all_paths) >= max_paths:
                break
            continue

        try:
            next_hop_ip = ipaddress.ip_address(hop["next_hop"])
        except ValueError:
            all_paths.append({"hops": current_path, "reached": False, "termination_reason": "INVALID_NEXT_HOP"})
            if len(all_paths) >= max_paths:
                break
            continue

        next_devices = [
            device_id
            for device_id in _candidate_next_devices(connected_networks_by_device, next_hop_ip)
            if device_id != current_device_id
        ]

        active_fhrp_device = fhrp_active_device_by_vip.get(str(next_hop_ip))
        if active_fhrp_device and active_fhrp_device != current_device_id:
            next_devices = [active_fhrp_device]

        neighbor_validation, learned_egress_interface = _validate_next_hop_neighbor(
            current_device_id,
            route.vrf,
            egress_interface,
            next_hop_ip,
            arp_by_device,
            devices_with_arp,
            macs_by_device,
            mac_interfaces_by_device,
            devices_with_mac,
            interface_mode_by_device,
            limitations,
        )
        if neighbor_validation:
            all_paths.append({"hops": current_path, "reached": False, "termination_reason": neighbor_validation})
            if len(all_paths) >= max_paths:
                break
            continue

        if learned_egress_interface:
            hop["egress_interface"] = learned_egress_interface
            hop["interfaces"] = sorted(set(value for value in [ingress_interface, learned_egress_interface] if value))
            hop["l2_decision"] = True

        if len(selected_routes) == 1 and next_devices:
            next_devices = next_devices[:1]
        if not next_devices:
            current_connected = connected_networks_by_device.get(current_device_id, [])
            if any(next_hop_ip in network for network in current_connected):
                onlink_limitation = "On-link next hop neighbor not modeled in snapshot; path inferred at L3 egress."
                if onlink_limitation not in limitations:
                    limitations.append(onlink_limitation)
                all_paths.append(
                    {"hops": current_path, "reached": True, "termination_reason": "ONLINK_NEXT_HOP_UNMAPPED"}
                )
            else:
                all_paths.append({"hops": current_path, "reached": False, "termination_reason": "NEXT_HOP_EXTERNAL"})
            if len(all_paths) >= max_paths:
                break
            continue

        updated_visited = set(visited)
        updated_visited.add(route_key)
        for next_device_id in next_devices:
            child_paths = _trace_paths(
                routes_by_device=routes_by_device,
                connected_networks_by_device=connected_networks_by_device,
                current_device_id=next_device_id,
                destination_ip=destination_ip,
                path_hops=current_path,
                visited=updated_visited,
                max_paths=max_paths,
                limitations=limitations,
                interfaces_by_device=interfaces_by_device,
                down_device_ids=down_device_ids,
                pbr_rules_by_device=pbr_rules_by_device,
                arp_by_device=arp_by_device,
                devices_with_arp=devices_with_arp,
                macs_by_device=macs_by_device,
                mac_interfaces_by_device=mac_interfaces_by_device,
                devices_with_mac=devices_with_mac,
                interface_mode_by_device=interface_mode_by_device,
                fhrp_active_device_by_vip=fhrp_active_device_by_vip,
                source_device_id=source_device_id,
                source_vrf=source_vrf,
                src_ip=src_ip,
                protocol=protocol,
                port=port,
            )
            all_paths.extend(child_paths)
            if len(all_paths) >= max_paths:
                break
        if len(all_paths) >= max_paths:
            break

    return all_paths[:max_paths]


def _compute_directional_paths(
    routes_by_device,
    connected_networks_by_device,
    src_ip,
    dst_ip,
    max_paths,
    confidence,
    limitations,
    interfaces_by_device,
    down_device_ids,
    pbr_rules_by_device,
    arp_by_device,
    devices_with_arp,
    macs_by_device,
    mac_interfaces_by_device,
    devices_with_mac,
    interface_mode_by_device,
    fhrp_active_device_by_vip,
    protocol,
    port,
):
    """Compute directional source->destination paths and associated metadata."""
    source_devices = _candidate_source_devices(
        routes_by_device,
        interfaces_by_device,
        ipaddress.ip_address(src_ip),
    )
    source_inferred = False
    summary = "Reachability computed from snapshot state."

    if not source_devices:
        source_inferred = True
        source_devices = sorted(routes_by_device.keys())
        if confidence == models.ConfidenceChoices.HIGH:
            confidence = models.ConfidenceChoices.MEDIUM
        limitations.append("Source IP not directly observed in snapshot; ingress device inferred from routing domain.")

    source_devices = source_devices[:1]

    traced_paths = []
    if source_devices:
        for source_device_id in source_devices:
            source_vrf = _infer_source_vrf(
                source_device_id, routes_by_device, interfaces_by_device, ipaddress.ip_address(src_ip)
            )
            traced_paths.extend(
                _trace_paths(
                    routes_by_device=routes_by_device,
                    connected_networks_by_device=connected_networks_by_device,
                    current_device_id=source_device_id,
                    destination_ip=ipaddress.ip_address(dst_ip),
                    path_hops=[],
                    visited=set(),
                    max_paths=max_paths,
                    limitations=limitations,
                    interfaces_by_device=interfaces_by_device,
                    down_device_ids=down_device_ids,
                    pbr_rules_by_device=pbr_rules_by_device,
                    arp_by_device=arp_by_device,
                    devices_with_arp=devices_with_arp,
                    macs_by_device=macs_by_device,
                    mac_interfaces_by_device=mac_interfaces_by_device,
                    devices_with_mac=devices_with_mac,
                    interface_mode_by_device=interface_mode_by_device,
                    fhrp_active_device_by_vip=fhrp_active_device_by_vip,
                    source_device_id=source_device_id,
                    source_vrf=source_vrf,
                    src_ip=src_ip,
                    protocol=protocol,
                    port=port,
                )
            )
            if len(traced_paths) >= max_paths:
                break
        traced_paths = traced_paths[:max_paths] or [{"hops": [], "reached": False, "termination_reason": "NO_ROUTE"}]
    else:
        traced_paths = [{"hops": [], "reached": False, "termination_reason": "SOURCE_NOT_IN_SNAPSHOT"}]
        summary = "Source IP is not present in connected/local snapshot state."

    return {
        "paths": traced_paths,
        "source_inferred": source_inferred,
        "summary": summary,
        "confidence": confidence,
        "limitations": limitations,
    }


def _primary_termination(paths):
    """Return first termination reason in a path list."""
    if not paths:
        return "NO_PATH"
    return paths[0].get("termination_reason") or "UNKNOWN"


def _classify_root_cause(forward_reachable, reverse_reachable, policy_allowed, forward_paths, reverse_paths):
    """Classify likely troubleshooting root cause for a flow verdict."""
    if not forward_reachable:
        reason = _primary_termination(forward_paths)
        return f"FORWARD_{reason}"

    if not reverse_reachable:
        reason = _primary_termination(reverse_paths)
        return f"REVERSE_{reason}"

    if not policy_allowed:
        return "SECURITY_POLICY_DENY"

    return "END_TO_END_REACHABLE"


def _match_prefix(prefix, ip_value):
    """Check whether ip matches optional prefix selector."""
    if not prefix:
        return True
    return ipaddress.ip_address(ip_value) in ipaddress.ip_network(prefix, strict=False)


def _match_rule(conditions, src_ip, dst_ip, protocol, port):
    """Evaluate a NAT/security condition map."""
    src_prefix = conditions.get("src_prefix")
    dst_prefix = conditions.get("dst_prefix")
    required_protocol = conditions.get("protocol")
    required_port = conditions.get("port")

    if src_prefix and not _match_prefix(src_prefix, src_ip):
        return False
    if dst_prefix and not _match_prefix(dst_prefix, dst_ip):
        return False
    if required_protocol and required_protocol.lower() != protocol.lower():
        return False
    if required_port and int(required_port) != int(port):
        return False
    return True


def _nat_path_for_matching(paths):
    """Select deterministic path for NAT interface-role matching."""
    if not paths:
        return []
    reached = [path for path in paths if path.get("reached")]
    if reached:
        return reached[0].get("hops", [])
    return paths[0].get("hops", [])


def _nat_rule_matches_path(nat_rule, path_hops):
    """Check NAT rule against hop device/interface roles and table scope."""
    if nat_rule.device is None:
        return False
    if nat_rule.nat_table is None:
        return False

    inside_interface = _normalize_interface_label(nat_rule.inside_interface)
    outside_interface = _normalize_interface_label(nat_rule.outside_interface)
    if not inside_interface or not outside_interface:
        return False

    for hop in path_hops:
        if hop.get("device") != nat_rule.device.name:
            continue

        ingress_interface = _normalize_interface_label(hop.get("ingress_interface"))
        egress_interface = _normalize_interface_label(hop.get("egress_interface"))
        if ingress_interface != inside_interface or egress_interface != outside_interface:
            continue

        if nat_rule.nat_table.table_scope == models.NatTableScopeChoices.VRF:
            hop_vrf = str(hop.get("vrf") or "").strip().lower()
            rule_vrf = str(nat_rule.nat_table.vrf_name or "").strip().lower()
            if hop_vrf != rule_vrf:
                continue

        return True

    return False


def _apply_nat(snapshot, src_ip, dst_ip, protocol, port, paths):
    """Apply first matching NAT rule deterministically with path/interface context."""
    transforms = []
    translated_src = src_ip
    translated_dst = dst_ip
    translated_port = port
    nat_events = []
    path_hops = _nat_path_for_matching(paths)

    rules = list(
        models.NatRuleState.objects.filter(snapshot=snapshot)
        .select_related("device", "nat_table")
        .order_by("order", "pk")
    )
    rules.sort(
        key=lambda rule: (
            0 if rule.nat_table is not None and rule.nat_table.table_scope == models.NatTableScopeChoices.VRF else 1,
            rule.order,
            rule.pk,
        )
    )

    for nat_rule in rules:
        if not _nat_rule_matches_path(nat_rule, path_hops):
            continue
        if _match_rule(nat_rule.conditions_json, translated_src, translated_dst, protocol, translated_port):
            translations = nat_rule.translations_json
            before = {
                "src_ip": translated_src,
                "dst_ip": translated_dst,
                "dst_port": int(translated_port),
            }
            translated_src = translations.get("src_ip", translated_src)
            translated_dst = translations.get("dst_ip", translated_dst)
            translated_port = int(translations.get("dst_port", translated_port))

            after = {
                "src_ip": translated_src,
                "dst_ip": translated_dst,
                "dst_port": int(translated_port),
            }
            nat_events.append({"before": before, "after": after})
            transforms.append(
                {
                    "type": "NAT",
                    "device": nat_rule.device.name if nat_rule.device else None,
                    "table_scope": nat_rule.nat_table.table_scope,
                    "vrf": nat_rule.nat_table.vrf_name,
                    "inside_interface": nat_rule.inside_interface,
                    "outside_interface": nat_rule.outside_interface,
                    "translated_src": translated_src,
                    "translated_dst": translated_dst,
                    "translated_port": translated_port,
                }
            )
            break

    return translated_src, translated_dst, translated_port, transforms, nat_events


def _reverse_detranslate_flow(src_ip, dst_ip, port, nat_events):
    """Derive reverse flow tuple with de-translation from applied NAT events."""
    reverse_src = src_ip
    reverse_dst = dst_ip
    reverse_port = int(port)
    reverse_valid = True

    for event in reversed(nat_events):
        before = event.get("before") or {}
        after = event.get("after") or {}

        if after.get("dst_ip") != before.get("dst_ip"):
            if reverse_src == after.get("dst_ip"):
                reverse_src = before.get("dst_ip")
            else:
                reverse_valid = False
        if after.get("src_ip") != before.get("src_ip"):
            if reverse_dst == after.get("src_ip"):
                reverse_dst = before.get("src_ip")
            else:
                reverse_valid = False
        if int(after.get("dst_port", reverse_port)) != int(before.get("dst_port", reverse_port)):
            if int(reverse_port) == int(after.get("dst_port")):
                reverse_port = int(before.get("dst_port"))
            else:
                reverse_valid = False

    return reverse_src, reverse_dst, reverse_port, reverse_valid


def _apply_load_balancing(snapshot, destination):
    """Apply deterministic VIP->member mapping."""
    transforms = []
    opaque_features = []
    limitations = []
    confidence = models.ConfidenceChoices.HIGH
    effective_destination = destination

    lb_state = models.LoadBalancerState.objects.filter(snapshot=snapshot, vip=destination).order_by("pk").first()
    if not lb_state:
        return effective_destination, transforms, opaque_features, limitations, confidence

    members = list(lb_state.members)
    selected_member = sorted(members)[0] if members else destination
    effective_destination = selected_member
    transforms.append(
        {
            "type": "LOAD_BALANCER",
            "vip": lb_state.vip,
            "pool": lb_state.pool,
            "selected_member": selected_member,
            "snat": lb_state.snat,
        }
    )

    if lb_state.has_irules:
        confidence = models.ConfidenceChoices.LOW
        opaque_features.append("F5:iRules")
        limitations.append("F5 iRules are opaque and are not simulated; verdict confidence reduced.")

    return effective_destination, transforms, opaque_features, limitations, confidence


def _evaluate_security(snapshot, src_ip, dst_ip, protocol, port, mode):
    """Evaluate security controls when mode enforces policy."""
    if mode == models.ReachabilityModeChoices.IGNORE_SECURITY:
        return True, []

    return _evaluate_security_with_paths(
        snapshot=snapshot,
        src_ip=src_ip,
        dst_ip=dst_ip,
        protocol=protocol,
        port=port,
        forward_paths=[],
        reverse_paths=[],
    )


def _build_acl_attachment_index(snapshot):
    """Map ACL attachments from running config artifacts: (device, interface, direction) -> acl name."""
    attachment_by_device = {}
    pattern = re.compile(r"^ip access-group\s+(?P<acl>\S+)\s+(?P<direction>in|out)$", re.IGNORECASE)

    artifacts = models.StateArtifact.objects.filter(
        device_state__snapshot=snapshot,
        artifact_type="show_run",
    ).select_related("device_state__device")

    for artifact in artifacts:
        device = artifact.device_state.device
        if device is None:
            continue
        device_map = attachment_by_device.setdefault(device.id, {})
        current_interface = None
        for line in (artifact.content or "").splitlines():
            stripped = line.strip()
            lowered = stripped.lower()
            if lowered.startswith("interface "):
                current_interface = _normalize_interface_label(stripped.split(None, 1)[1].strip())
                continue
            if not current_interface:
                continue
            match = pattern.match(stripped)
            if not match:
                continue
            direction = match.group("direction").lower()
            acl_name = match.group("acl")
            device_map[(current_interface, direction)] = acl_name

    return attachment_by_device


def _normalize_interface_label(interface_name):
    """Normalize interface names across long/short Cisco variants for matching."""
    name = (interface_name or "").strip()
    if not name:
        return ""

    if canonical_interface_name is not None:
        try:
            canonical = canonical_interface_name(name)
            return canonical.strip().lower().replace(" ", "")
        except Exception:  # pylint: disable=broad-exception-caught
            return name.lower().replace(" ", "")

    name = name.lower().replace(" ", "")
    if not name:
        return ""

    replacements = [
        ("tengigabitethernet", "te"),
        ("fortygigabitethernet", "fo"),
        ("hundredgigabitethernet", "hu"),
        ("gigabitethernet", "gi"),
        ("fastethernet", "fa"),
        ("ethernet", "eth"),
        ("port-channel", "po"),
        ("loopback", "lo"),
    ]
    for prefix, replacement in replacements:
        if name.startswith(prefix):
            return replacement + name[len(prefix) :]
    return name


def _build_acl_rule_index(snapshot):
    """Index ACL rules by device and ACL name ordered by sequence."""
    rules_by_device_acl = {}
    for rule in models.AclRuleState.objects.filter(snapshot=snapshot).order_by("order", "pk"):
        if rule.device_id is None:
            continue
        acl_name = (rule.attrs_json or {}).get("acl_name")
        if not acl_name:
            continue
        rules_by_device_acl.setdefault((rule.device_id, acl_name), []).append(rule)
    return rules_by_device_acl


def _evaluate_single_acl(rules, src_ip, dst_ip, protocol, port):
    """Evaluate one ACL list by first-match semantics with implicit deny."""
    for rule in rules:
        conditions = {
            "src_prefix": rule.src_prefix,
            "dst_prefix": rule.dst_prefix,
            "protocol": rule.protocol,
            "port": rule.port,
        }
        if _match_rule(conditions, src_ip, dst_ip, protocol, port):
            return rule.action == models.SecurityActionChoices.ALLOW, rule
    return False, None


def _evaluate_acl_for_paths(
    *,
    snapshot,
    src_ip,
    dst_ip,
    protocol,
    port,
    forward_paths,
    reverse_paths,
):
    """Evaluate ACLs attached to traversed interfaces on forward/reverse paths."""
    if not forward_paths and not reverse_paths:
        return True, []

    device_by_name = {device.name: device.id for device in snapshot.scope.get_devices()}
    attachments = _build_acl_attachment_index(snapshot)
    acl_rules = _build_acl_rule_index(snapshot)

    def _path_allows(path_hops, flow_src, flow_dst):
        decisions = []
        for hop in path_hops:
            device_name = hop.get("device")
            if not device_name:
                continue
            device_id = device_by_name.get(device_name)
            if not device_id:
                continue

            ingress = _normalize_interface_label(hop.get("ingress_interface"))
            egress = _normalize_interface_label(hop.get("egress_interface"))
            checks = []
            if ingress:
                checks.append((ingress, "in"))
            if egress:
                checks.append((egress, "out"))

            for interface_name, direction in checks:
                acl_name = attachments.get(device_id, {}).get((interface_name, direction))
                if not acl_name:
                    continue
                rules = acl_rules.get((device_id, acl_name), [])
                allowed, matched_rule = _evaluate_single_acl(rules, flow_src, flow_dst, protocol, port)
                decisions.append(
                    {
                        "table": "ACL",
                        "device": device_name,
                        "action": (
                            matched_rule.action if matched_rule is not None else models.SecurityActionChoices.DENY
                        ),
                        "allowed": allowed,
                        "attrs": {
                            "acl_name": acl_name,
                            "interface": interface_name,
                            "direction": direction,
                        },
                    }
                )
                if not allowed:
                    return False, decisions
        return True, decisions

    all_decisions = []
    reached_forward_paths = [path for path in forward_paths if path.get("reached")]
    reached_reverse_paths = [path for path in reverse_paths if path.get("reached")]

    forward_pass = False
    for path in reached_forward_paths:
        allowed, decisions = _path_allows(path.get("hops", []), src_ip, dst_ip)
        all_decisions.extend(decisions)
        if allowed:
            forward_pass = True
            break

    reverse_pass = False
    for path in reached_reverse_paths:
        allowed, decisions = _path_allows(path.get("hops", []), dst_ip, src_ip)
        all_decisions.extend(decisions)
        if allowed:
            reverse_pass = True
            break

    if reached_forward_paths and not forward_pass:
        return False, all_decisions
    if reached_reverse_paths and not reverse_pass:
        return False, all_decisions
    return True, all_decisions


def _evaluate_security_with_paths(snapshot, src_ip, dst_ip, protocol, port, forward_paths, reverse_paths):
    """Evaluate security controls with ACL attachment context and existing policy tables."""
    decisions = []

    acl_allowed, acl_decisions = _evaluate_acl_for_paths(
        snapshot=snapshot,
        src_ip=src_ip,
        dst_ip=dst_ip,
        protocol=protocol,
        port=port,
        forward_paths=forward_paths,
        reverse_paths=reverse_paths,
    )
    decisions.extend(acl_decisions)
    if not acl_allowed:
        return False, decisions

    allowed = True
    rule_sets = [
        ("FIREWALL", models.FirewallRuleState.objects.filter(snapshot=snapshot).order_by("order", "pk")),
        ("ACI", models.AciContractState.objects.filter(snapshot=snapshot).order_by("order", "pk")),
        ("AZURE_NSG", models.AzureNsgRuleState.objects.filter(snapshot=snapshot).order_by("order", "pk")),
    ]

    for table_name, queryset in rule_sets:
        for rule in queryset:
            conditions = {
                "src_prefix": rule.src_prefix,
                "dst_prefix": rule.dst_prefix,
                "protocol": rule.protocol,
                "port": rule.port,
            }
            if _match_rule(conditions, src_ip, dst_ip, protocol, port):
                permitted = rule.action == models.SecurityActionChoices.ALLOW
                decisions.append(
                    {
                        "table": table_name,
                        "device": rule.device.name if rule.device else None,
                        "action": rule.action,
                        "allowed": permitted,
                    }
                )
                if not permitted:
                    allowed = False
                break

    return allowed, decisions


def check_reachability_one(snapshot, src, destination, protocol, port, mode, include_explanation=True, max_paths=1):
    """Compute deterministic reachability for one destination against one snapshot."""
    try:
        src_ip = str(ipaddress.ip_address(src))
        dst_ip = str(ipaddress.ip_address(destination))
    except ValueError as exc:
        raise ReachabilityError("src and destination must be explicit endpoint IP addresses") from exc

    if max_paths < 1:
        raise ReachabilityError("max_paths must be >= 1")

    transformed_dst, lb_transforms, opaque_features, limitations, confidence = _apply_load_balancing(snapshot, dst_ip)

    routes_by_device, connected_networks_by_device = _build_route_index(snapshot)
    interfaces_by_device = _build_interface_index(snapshot)
    down_device_ids = _build_down_device_index(snapshot)
    pbr_rules_by_device = _build_pbr_index(snapshot)
    arp_by_device, devices_with_arp = _build_arp_index(snapshot)
    macs_by_device, mac_interfaces_by_device, devices_with_mac = _build_mac_index(snapshot)
    interface_mode_by_device = _build_interface_mode_index(snapshot)
    fhrp_active_device_by_vip = _build_fhrp_active_index(snapshot)
    nat_seed = _compute_directional_paths(
        routes_by_device=routes_by_device,
        connected_networks_by_device=connected_networks_by_device,
        src_ip=src_ip,
        dst_ip=transformed_dst,
        max_paths=max_paths,
        confidence=confidence,
        limitations=limitations,
        interfaces_by_device=interfaces_by_device,
        down_device_ids=down_device_ids,
        pbr_rules_by_device=pbr_rules_by_device,
        arp_by_device=arp_by_device,
        devices_with_arp=devices_with_arp,
        macs_by_device=macs_by_device,
        mac_interfaces_by_device=mac_interfaces_by_device,
        devices_with_mac=devices_with_mac,
        interface_mode_by_device=interface_mode_by_device,
        fhrp_active_device_by_vip=fhrp_active_device_by_vip,
        protocol=protocol,
        port=port,
    )
    translated_src, translated_dst, translated_port, nat_transforms, nat_events = _apply_nat(
        snapshot=snapshot,
        src_ip=src_ip,
        dst_ip=transformed_dst,
        protocol=protocol,
        port=port,
        paths=nat_seed["paths"],
    )

    forward = _compute_directional_paths(
        routes_by_device=routes_by_device,
        connected_networks_by_device=connected_networks_by_device,
        src_ip=translated_src,
        dst_ip=translated_dst,
        max_paths=max_paths,
        confidence=confidence,
        limitations=limitations,
        interfaces_by_device=interfaces_by_device,
        down_device_ids=down_device_ids,
        pbr_rules_by_device=pbr_rules_by_device,
        arp_by_device=arp_by_device,
        devices_with_arp=devices_with_arp,
        macs_by_device=macs_by_device,
        mac_interfaces_by_device=mac_interfaces_by_device,
        devices_with_mac=devices_with_mac,
        interface_mode_by_device=interface_mode_by_device,
        fhrp_active_device_by_vip=fhrp_active_device_by_vip,
        protocol=protocol,
        port=translated_port,
    )
    traced_paths = forward["paths"]
    summary = forward["summary"]
    confidence = forward["confidence"]
    limitations = forward["limitations"]
    source_inferred = forward["source_inferred"]

    forward_reachable = any(path["reached"] for path in traced_paths)
    reverse_src_ip = translated_dst
    reverse_dst_ip = translated_src
    reverse_port = translated_port
    reverse_valid = True
    if nat_events:
        reverse_src_ip, reverse_dst_ip, reverse_port, reverse_valid = _reverse_detranslate_flow(
            reverse_src_ip,
            reverse_dst_ip,
            reverse_port,
            nat_events,
        )

    if reverse_valid:
        reverse = _compute_directional_paths(
            routes_by_device=routes_by_device,
            connected_networks_by_device=connected_networks_by_device,
            src_ip=reverse_src_ip,
            dst_ip=reverse_dst_ip,
            max_paths=max_paths,
            confidence=confidence,
            limitations=limitations,
            interfaces_by_device=interfaces_by_device,
            down_device_ids=down_device_ids,
            pbr_rules_by_device=pbr_rules_by_device,
            arp_by_device=arp_by_device,
            devices_with_arp=devices_with_arp,
            macs_by_device=macs_by_device,
            mac_interfaces_by_device=mac_interfaces_by_device,
            devices_with_mac=devices_with_mac,
            interface_mode_by_device=interface_mode_by_device,
            fhrp_active_device_by_vip=fhrp_active_device_by_vip,
            protocol=protocol,
            port=reverse_port,
        )
        return_paths = reverse["paths"]
        confidence = reverse["confidence"]
        limitations = reverse["limitations"]
    else:
        nat_reverse_limitation = "Reverse-path NAT de-translation failed to map return flow deterministically."
        if nat_reverse_limitation not in limitations:
            limitations.append(nat_reverse_limitation)
        return_paths = [{"hops": [], "reached": False, "termination_reason": "NAT_REVERSE_MISS"}]

    return_reachable = any(path["reached"] for path in return_paths)

    verdict = (
        models.VerdictChoices.REACHABLE if forward_reachable and return_reachable else models.VerdictChoices.UNREACHABLE
    )
    if verdict == models.VerdictChoices.UNREACHABLE and summary == "Reachability computed from snapshot state.":
        if not forward_reachable:
            if source_inferred:
                summary = "No end-to-end route from inferred ingress to destination in snapshot routing state."
            else:
                summary = "No end-to-end route from source to destination in snapshot routing state."
        else:
            summary = "Forward route exists but return route is not reachable in snapshot routing state."

    transforms = lb_transforms + nat_transforms
    return_path_payload = []
    for traced in return_paths[:max_paths]:
        return_path_payload.append(
            {
                "hops": traced["hops"],
                "termination_reason": traced["termination_reason"],
                "reached": traced["reached"],
            }
        )

    if mode == models.ReachabilityModeChoices.IGNORE_SECURITY:
        policy_allowed, policy_decisions = True, []
    else:
        policy_allowed, policy_decisions = _evaluate_security_with_paths(
            snapshot=snapshot,
            src_ip=translated_src,
            dst_ip=translated_dst,
            protocol=protocol,
            port=translated_port,
            forward_paths=traced_paths[:max_paths],
            reverse_paths=return_paths[:max_paths],
        )

    if verdict == models.VerdictChoices.REACHABLE and not policy_allowed:
        verdict = models.VerdictChoices.UNREACHABLE
        summary = "Security policy denied the flow."

    paths = []
    for traced in traced_paths[:max_paths]:
        paths.append(
            {
                "hops": traced["hops"],
                "transforms": transforms,
                "policy_decisions": policy_decisions,
                "opaque_features": opaque_features,
                "termination_reason": traced["termination_reason"],
                "reached": traced["reached"],
            }
        )

    forward_status = "PASS" if any(path["reached"] for path in paths) else "FAIL"
    reverse_status = "PASS" if any(path["reached"] for path in return_path_payload) else "FAIL"
    root_cause = _classify_root_cause(
        forward_reachable=forward_status == "PASS",
        reverse_reachable=reverse_status == "PASS",
        policy_allowed=policy_allowed,
        forward_paths=paths,
        reverse_paths=return_path_payload,
    )

    explanation = {
        "summary": summary,
        "limitations": limitations,
    }

    result = {
        "dst": destination,
        "verdict": verdict,
        "confidence": confidence,
        "root_cause": root_cause,
        "forward": {
            "status": forward_status,
            "paths": paths,
            "primary_termination": _primary_termination(paths),
        },
        "reverse": {
            "status": reverse_status,
            "paths": return_path_payload,
            "primary_termination": _primary_termination(return_path_payload),
        },
        "paths": paths,
        "return_paths": return_path_payload,
    }
    if include_explanation:
        result["explanation"] = explanation
    else:
        result["explanation"] = {"summary": "", "limitations": []}
    return result


def check_reachability_many(snapshot, src, destinations, protocol, port, mode, include_explanation=True, max_paths=1):
    """Compute deterministic reachability for up to 16 explicit destinations in order."""
    if snapshot.status != models.SnapshotStatusChoices.READY:
        raise ReachabilityError("Snapshot must be READY")

    if not destinations:
        raise ReachabilityError("At least one destination is required")

    if len(destinations) > 16:
        raise ReachabilityError("At most 16 destinations are allowed")

    results = []
    for index, destination in enumerate(destinations):
        try:
            ipaddress.ip_address(destination)
        except ValueError as exc:
            raise ReachabilityError(f"dst[{index}] must be an explicit single endpoint IP") from exc
        results.append(
            check_reachability_one(
                snapshot=snapshot,
                src=src,
                destination=destination,
                protocol=protocol,
                port=port,
                mode=mode,
                include_explanation=include_explanation,
                max_paths=max_paths,
            )
        )

    summary = {
        "total": len(results),
        "reachable": sum(1 for result in results if result["verdict"] == models.VerdictChoices.REACHABLE),
        "unreachable": sum(1 for result in results if result["verdict"] == models.VerdictChoices.UNREACHABLE),
        "forward_pass": sum(1 for result in results if result.get("forward", {}).get("status") == "PASS"),
        "forward_fail": sum(1 for result in results if result.get("forward", {}).get("status") == "FAIL"),
        "reverse_pass": sum(1 for result in results if result.get("reverse", {}).get("status") == "PASS"),
        "reverse_fail": sum(1 for result in results if result.get("reverse", {}).get("status") == "FAIL"),
    }
    return {"results": results, "summary": summary}
