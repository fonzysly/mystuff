"""Collectors for observed state artifacts."""

import ipaddress
import json
import os
import re

try:
    from netmiko import ConnectHandler  # type: ignore[import-not-found]
except ImportError:  # pragma: no cover - covered by runtime guard
    ConnectHandler = None


def _platform_network_driver(device):
    """Return normalized network driver."""
    if getattr(device, "platform", None) and getattr(device.platform, "network_driver", None):
        return device.platform.network_driver.lower()
    if getattr(device, "platform", None) and getattr(device.platform, "name", None):
        platform_name = device.platform.name.lower()
        if "nx" in platform_name:
            return "cisco_nxos"
        if "ios" in platform_name or "xe" in platform_name or "catalyst" in platform_name or "c8k" in platform_name:
            return "cisco_ios"
        if "palo" in platform_name or "pan" in platform_name:
            return "paloalto_panos"
    return ""


def _netmiko_device_type(platform_driver):
    """Map platform driver to supported Netmiko device_type values."""
    mapping = {
        "cisco_ios": "cisco_ios",
        "cisco_xe": "cisco_ios",
        "cisco_nxos": "cisco_nxos",
        "paloalto_panos": "paloalto_panos",
    }
    return mapping.get(platform_driver, "cisco_ios")


def _management_host(device):
    """Extract host IP from Nautobot device primary IP fields."""
    address = None
    if getattr(device, "primary_ip4", None):
        address = str(device.primary_ip4.address)
    elif getattr(device, "primary_ip", None):
        address = str(device.primary_ip.address)
    elif getattr(device, "primary_ip6", None):
        address = str(device.primary_ip6.address)

    if not address:
        raise ValueError(f"Device {device} has no primary management IP configured")

    if "/" in address:
        return str(ipaddress.ip_interface(address).ip)
    return address


def _resolve_ssh_credentials(device):
    """Resolve SSH credentials from Nautobot Secrets Group or environment fallback."""
    username = None
    password = None
    enable_secret = None

    secrets_group = getattr(device, "secrets_group", None)
    if secrets_group:
        try:
            username = secrets_group.get_secret_value("SSH", "username", obj=device)
        except Exception:  # pylint: disable=broad-exception-caught
            username = None
        try:
            password = secrets_group.get_secret_value("SSH", "password", obj=device)
        except Exception:  # pylint: disable=broad-exception-caught
            password = None
        try:
            enable_secret = secrets_group.get_secret_value("SSH", "secret", obj=device)
        except Exception:  # pylint: disable=broad-exception-caught
            enable_secret = None

    username = username or os.getenv("DIGITAL_TWIN_SSH_USERNAME") or os.getenv("DT_COLLECT_USERNAME") or "admin"
    password = password or os.getenv("DIGITAL_TWIN_SSH_PASSWORD") or os.getenv("DT_COLLECT_PASSWORD") or "admin"
    enable_secret = enable_secret or os.getenv("DIGITAL_TWIN_SSH_ENABLE") or os.getenv("DT_COLLECT_SECRET") or ""

    return username, password, enable_secret


def _command_catalog(platform_driver):
    """Return artifact command catalog for a platform."""
    if "cisco_nxos" == platform_driver:
        return [
            ("show_route_raw", "show ip route vrf all"),
            ("show_interface_raw", "show ip interface brief vrf all"),
            ("show_arp_raw", "show ip arp vrf all"),
            ("show_mac_raw", "show mac address-table"),
            ("show_fhrp_raw", "show hsrp brief"),
            ("show_fhrp_raw", "show vrrp brief"),
            ("show_acl_raw", "show ip access-lists"),
            ("show_run", "show running-config"),
        ]
    if "paloalto_panos" == platform_driver:
        return [
            ("show_route_raw", "show routing route"),
            ("show_interface_raw", "show interface all"),
            ("show_run", "show config running"),
        ]
    if platform_driver in ["cisco_ios", "cisco_xe"]:
        return [
            ("show_route_raw", "show ip route"),
            ("show_vrf_raw", "show vrf"),
            ("show_interface_raw", "show ip interface brief"),
            ("show_arp_raw", "show ip arp"),
            ("show_mac_raw", "show mac address-table"),
            ("show_fhrp_raw", "show standby brief"),
            ("show_fhrp_raw", "show vrrp brief"),
            ("show_acl_raw", "show access-lists"),
            ("show_run", "show running-config"),
        ]
    raise ValueError(f"Unsupported network driver for collection: {platform_driver or 'unknown'}")


def _extract_ios_vrf_names(show_vrf_output):
    """Parse IOS/IOS-XE `show vrf` output and return non-default VRF names."""
    vrf_names = []
    seen = set()
    for line in show_vrf_output.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        lowered = stripped.lower()
        if lowered.startswith("name") or lowered.startswith("vrf-name") or lowered.startswith("---"):
            continue
        token = stripped.split()[0]
        if token.lower() in {"default", "name", "vrf-name"}:
            continue
        if token not in seen:
            seen.add(token)
            vrf_names.append(token)
    return vrf_names


def _route_protocol(route_code):
    """Normalize route code to protocol string."""
    mapping = {
        "C": "connected",
        "L": "local",
        "S": "static",
        "O": "ospf",
        "D": "eigrp",
        "R": "rip",
        "B": "bgp",
    }
    key = route_code.strip("*+")[:1].upper()
    return mapping.get(key, "unknown")


def _wildcard_to_prefix(ip_token, wildcard_token):
    """Convert Cisco wildcard notation into CIDR prefix."""
    wildcard_int = int(ipaddress.IPv4Address(wildcard_token))
    netmask_int = (~wildcard_int) & 0xFFFFFFFF
    netmask = str(ipaddress.IPv4Address(netmask_int))
    network = ipaddress.IPv4Network((ip_token, netmask), strict=False)
    return str(network)


def _to_cisco_route_artifact(route_output):
    """Convert raw route output to parser-friendly canonical text rows."""
    rows = []
    current_vrf = "default"
    current_prefix = None
    default_from_gateway = None
    saw_explicit_default = False

    vrf_patterns = [
        re.compile(r'^IP Route Table for VRF\s+"(?P<vrf>[^"]+)"$', re.IGNORECASE),
        re.compile(r"^Routing Table:\s*(?P<vrf>\S+)$", re.IGNORECASE),
        re.compile(r"^VRF:\s*(?P<vrf>\S+)$", re.IGNORECASE),
    ]
    gateway_default_pattern = re.compile(
        r"^Gateway of last resort is\s+(?P<nh>\d+\.\d+\.\d+\.\d+)\s+to network\s+0\.0\.0\.0$",
        re.IGNORECASE,
    )
    ios_via_pattern = re.compile(
        r"^(?P<code>[A-Za-z\*\+]+(?:\s+[A-Za-z0-9\*\+]+)*)\s+"
        r"(?P<prefix>\d+\.\d+\.\d+\.\d+/\d+).+via\s+(?P<nh>\d+\.\d+\.\d+\.\d+)",
        re.IGNORECASE,
    )
    ios_connected_pattern = re.compile(
        r"^(?P<code>[A-Za-z\*\+]+(?:\s+[A-Za-z0-9\*\+]+)*)\s+"
        r"(?P<prefix>\d+\.\d+\.\d+\.\d+/\d+).+directly connected",
        re.IGNORECASE,
    )
    nxos_prefix_pattern = re.compile(
        r"^(?P<prefix>\d+\.\d+\.\d+\.\d+/\d+),\s+ubest/mbest:\s+\d+/\d+(?:,\s+attached)?$",
        re.IGNORECASE,
    )
    nxos_via_pattern = re.compile(
        r"^\*?via\s+(?P<nh>\d+\.\d+\.\d+\.\d+),\s*"
        r"(?P<intf>[A-Za-z][A-Za-z0-9/\.\-]+),\s*"
        r"\[(?P<admin>\d+)/(?P<metric>\d+)\],\s*[^,]+,\s*(?P<proto>[A-Za-z0-9\-]+)",
        re.IGNORECASE,
    )
    metric_pattern = re.compile(r"\[(\d+)/(\d+)\]")

    for line in route_output.splitlines():
        stripped = line.strip()
        if not stripped:
            continue

        vrf_match = None
        for vrf_pattern in vrf_patterns:
            vrf_match = vrf_pattern.match(stripped)
            if vrf_match:
                break
        if vrf_match:
            current_vrf = vrf_match.group("vrf")
            continue

        gateway_match = gateway_default_pattern.match(stripped)
        if gateway_match:
            default_from_gateway = gateway_match.group("nh")
            continue

        nxos_prefix_match = nxos_prefix_pattern.match(stripped)
        if nxos_prefix_match:
            current_prefix = nxos_prefix_match.group("prefix")
            continue

        nxos_via_match = nxos_via_pattern.match(stripped)
        if nxos_via_match and current_prefix:
            protocol = nxos_via_match.group("proto").lower()
            next_hop = nxos_via_match.group("nh")
            metric = int(nxos_via_match.group("metric"))
            if protocol in {"direct", "local"}:
                next_hop = "0.0.0.0"  # noqa: S104
                metric = 0
            rows.append(f"{current_vrf} {current_prefix} {next_hop} {protocol} {metric}")
            if current_prefix == "0.0.0.0/0":
                saw_explicit_default = True
            continue

        via_match = ios_via_pattern.match(stripped)
        if via_match:
            metric_match = metric_pattern.search(stripped)
            metric = int(metric_match.group(2)) if metric_match else 1
            code = via_match.group("code")
            prefix = via_match.group("prefix")
            rows.append(f"{current_vrf} {prefix} {via_match.group('nh')} {_route_protocol(code)} {metric}")
            if prefix == "0.0.0.0/0":
                saw_explicit_default = True
            continue

        connected_match = ios_connected_pattern.match(stripped)
        if connected_match:
            code = connected_match.group("code")
            prefix = connected_match.group("prefix")
            rows.append(f"{current_vrf} {prefix} 0.0.0.0 {_route_protocol(code)} 0")

    if default_from_gateway and not saw_explicit_default:
        rows.insert(0, f"{current_vrf} 0.0.0.0/0 {default_from_gateway} static 1")

    return "\n".join(rows)


def _to_interface_state_artifact(interface_output):
    """Convert raw interface brief output into canonical interface JSON."""
    records = []
    ios_pattern = re.compile(
        r"^(?P<name>[A-Za-z][A-Za-z0-9/\.\-]+)\s+"
        r"(?P<ip>\d+\.\d+\.\d+\.\d+|unassigned)\s+\S+\s+\S+\s+"
        r"(?P<status>administratively down|admin down|up|down)\s+(?P<protocol>up|down)\s*$",
        re.IGNORECASE,
    )
    nxos_compact_pattern = re.compile(
        r"^(?P<name>[A-Za-z][A-Za-z0-9/\.\-]+)\s+"
        r"(?P<ip>\d+\.\d+\.\d+\.\d+|unassigned)\s+"
        r"(?P<state>[A-Za-z\-]+/[A-Za-z\-]+/[A-Za-z\-]+)(?:\s+\S+)?\s*$",
        re.IGNORECASE,
    )

    for line in interface_output.splitlines():
        stripped = line.strip()
        ios_match = ios_pattern.match(stripped)
        if ios_match:
            ip_value = ios_match.group("ip")
            records.append(
                {
                    "name": ios_match.group("name"),
                    "admin_up": ios_match.group("status").lower() not in {"administratively down", "admin down"},
                    "oper_up": ios_match.group("protocol").lower() == "up",
                    "ips": [] if ip_value == "unassigned" else [f"{ip_value}/32"],
                    "attrs": {},
                }
            )
            continue

        nxos_match = nxos_compact_pattern.match(stripped)
        if nxos_match:
            ip_value = nxos_match.group("ip")
            state_tokens = nxos_match.group("state").lower().split("/")
            protocol_state = state_tokens[0] if len(state_tokens) > 0 else ""
            admin_state = state_tokens[2] if len(state_tokens) > 2 else ""
            records.append(
                {
                    "name": nxos_match.group("name"),
                    "admin_up": admin_state.endswith("up"),
                    "oper_up": protocol_state.endswith("up"),
                    "ips": [] if ip_value == "unassigned" else [f"{ip_value}/32"],
                    "attrs": {},
                }
            )

    return json.dumps(records)


def _interface_ip_map_from_brief(interface_output):
    """Build normalized interface->IP map from interface brief output."""
    interface_map = {}
    for row in json.loads(_to_interface_state_artifact(interface_output) or "[]"):
        interface_name = _normalize_interface_name(row.get("name"))
        ips = row.get("ips") or []
        if not interface_name or not ips:
            continue
        first = str(ips[0])
        interface_map[interface_name] = first.split("/", 1)[0]
    return interface_map


def _normalize_interface_name(interface_name):
    """Normalize interface labels for deterministic matching."""
    return str(interface_name or "").strip().lower().replace(" ", "")


def _parse_nat_interface_roles(show_run_output):
    """Extract NAT inside/outside interface roles keyed by table scope."""
    roles_by_table = {}
    current_interface = ""
    interface_context = {}

    def _ensure_interface_context(interface_name):
        context = interface_context.setdefault(
            interface_name,
            {
                "vrf_name": "",
                "inside": False,
                "outside": False,
                "inside_vrf": "",
                "outside_vrf": "",
            },
        )
        return context

    for line in (show_run_output or "").splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        lowered = stripped.lower()
        if lowered.startswith("interface "):
            current_interface = _normalize_interface_name(stripped.split(None, 1)[1].strip())
            _ensure_interface_context(current_interface)
            continue
        if not current_interface:
            continue
        if line.lstrip() == line:
            current_interface = ""
            continue

        context = _ensure_interface_context(current_interface)

        if lowered.startswith("ip vrf forwarding ") or lowered.startswith("vrf forwarding "):
            tokens = stripped.split()
            context["vrf_name"] = tokens[-1] if tokens else ""
            continue

        if not lowered.startswith("ip nat "):
            continue
        if " inside" not in lowered and " outside" not in lowered:
            continue

        tokens = stripped.split()
        token_map = [token.lower() for token in tokens]
        if "inside" in token_map:
            context["inside"] = True
        if "outside" in token_map:
            context["outside"] = True

        if "vrf" in token_map:
            index = token_map.index("vrf")
            if index + 1 < len(tokens):
                vrf_name = tokens[index + 1]

                if "inside" in token_map:
                    context["inside_vrf"] = vrf_name
                if "outside" in token_map:
                    context["outside_vrf"] = vrf_name

    for interface_name, context in interface_context.items():
        inside_vrf_name = context["inside_vrf"] or context["vrf_name"]
        outside_vrf_name = context["outside_vrf"] or context["vrf_name"]

        if context["inside"]:
            inside_key = ("VRF", inside_vrf_name) if inside_vrf_name else ("GLOBAL", "")
            roles_by_table.setdefault(inside_key, {"inside": set(), "outside": set()})["inside"].add(interface_name)

        if context["outside"]:
            outside_key = ("VRF", outside_vrf_name) if outside_vrf_name else ("GLOBAL", "")
            roles_by_table.setdefault(outside_key, {"inside": set(), "outside": set()})["outside"].add(interface_name)

    return roles_by_table


def _parse_nat_static_rule(line, rule_order):
    """Parse a static NAT rule line into normalized condition/translation data."""
    pattern = re.compile(
        r"^ip\s+nat\s+(?:inside\s+)?source\s+static\s+"
        r"(?:(?P<protocol>tcp|udp)\s+)?"
        r"(?P<local_ip>\d+\.\d+\.\d+\.\d+)"
        r"(?:\s+(?P<local_port>\d+))?\s+"
        r"(?P<global_ip>\d+\.\d+\.\d+\.\d+)"
        r"(?:\s+(?P<global_port>\d+))?"
        r"(?:\s+vrf\s+(?P<vrf>\S+))?",
        re.IGNORECASE,
    )

    match = pattern.match(line.strip())
    if not match:
        return None

    protocol = (match.group("protocol") or "").lower()
    local_ip = match.group("local_ip")
    global_ip = match.group("global_ip")
    local_port = match.group("local_port")
    global_port = match.group("global_port")
    vrf_name = (match.group("vrf") or "").strip()
    table_scope = "VRF" if vrf_name else "GLOBAL"

    conditions = {"src_prefix": f"{local_ip}/32"}
    if protocol:
        conditions["protocol"] = protocol
    if local_port:
        conditions["src_port"] = int(local_port)

    translations = {"src_ip": global_ip}
    if global_port:
        translations["src_port"] = int(global_port)

    return {
        "table_scope": table_scope,
        "vrf_name": vrf_name,
        "order": int(rule_order),
        "conditions_json": conditions,
        "translations_json": translations,
        "attrs_json": {"raw_line": line.strip(), "kind": "static"},
    }


def _parse_acl_prefixes_from_running_config(show_run_output):
    """Extract permit source prefixes from running-config ACL definitions."""
    acl_prefixes = {}
    current_standard_acl = ""

    for line in (show_run_output or "").splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        lowered = stripped.lower()

        if lowered.startswith("ip access-list standard "):
            current_standard_acl = stripped.split(None, 3)[3].strip()
            acl_prefixes.setdefault(current_standard_acl, [])
            continue

        if line.lstrip() == line:
            current_standard_acl = ""

        standard_acl_match = re.match(
            r"^access-list\s+(?P<acl>\S+)\s+permit\s+(?P<source>\S+)(?:\s+(?P<wildcard>\S+))?$",
            stripped,
            re.IGNORECASE,
        )
        if standard_acl_match:
            acl_name = standard_acl_match.group("acl")
            source = standard_acl_match.group("source")
            wildcard = standard_acl_match.group("wildcard") or ""
            if source.lower() == "any":
                prefix = "0.0.0.0/0"
            elif wildcard:
                try:
                    prefix = _wildcard_to_prefix(source, wildcard)
                except ValueError:
                    continue
            else:
                prefix = f"{source}/32"
            acl_prefixes.setdefault(acl_name, []).append(prefix)
            continue

        if current_standard_acl and lowered.startswith("permit "):
            parts = stripped.split()
            if len(parts) < 2:
                continue
            source = parts[1]
            wildcard = parts[2] if len(parts) > 2 else ""
            if source.lower() == "any":
                prefix = "0.0.0.0/0"
            elif wildcard:
                try:
                    prefix = _wildcard_to_prefix(source, wildcard)
                except ValueError:
                    continue
            else:
                prefix = f"{source}/32"
            acl_prefixes.setdefault(current_standard_acl, []).append(prefix)

    return acl_prefixes


def _parse_nat_overload_rules(line, rule_order, acl_prefixes, interface_ip_map):
    """Parse ACL-list overload NAT line into one or more normalized rules."""
    pattern = re.compile(
        r"^ip\s+nat\s+inside\s+source\s+list\s+(?P<acl>\S+)\s+"
        r"interface\s+(?P<interface>\S+)"
        r"(?:\s+overload)?"
        r"(?:\s+vrf\s+(?P<vrf>\S+))?$",
        re.IGNORECASE,
    )
    match = pattern.match(line.strip())
    if not match:
        return []

    acl_name = match.group("acl")
    outside_interface = _normalize_interface_name(match.group("interface"))
    outside_ip = interface_ip_map.get(outside_interface)
    vrf_name = (match.group("vrf") or "").strip()
    table_scope = "VRF" if vrf_name else "GLOBAL"

    prefixes = acl_prefixes.get(acl_name) or [""]
    rows = []
    for index, src_prefix in enumerate(prefixes, start=1):
        conditions = {}
        if src_prefix:
            conditions["src_prefix"] = src_prefix
        translations = {}
        if outside_ip:
            translations["src_ip"] = outside_ip
        rows.append(
            {
                "table_scope": table_scope,
                "vrf_name": vrf_name,
                "order": int(rule_order) + index,
                "conditions_json": conditions,
                "translations_json": translations,
                "attrs_json": {"raw_line": line.strip(), "acl_name": acl_name, "kind": "overload"},
            }
        )
    return rows


def _to_cisco_nat_table_artifact(show_run_output, platform_driver, interface_output=""):
    """Convert running config NAT lines into canonical NAT table artifact JSON."""
    roles_by_table = _parse_nat_interface_roles(show_run_output)
    acl_prefixes = _parse_acl_prefixes_from_running_config(show_run_output)
    interface_ip_map = _interface_ip_map_from_brief(interface_output) if interface_output else {}
    tables = {}
    rule_order = 0

    for raw_line in (show_run_output or "").splitlines():
        stripped = raw_line.strip()
        if not stripped.lower().startswith("ip nat "):
            continue
        parsed_rules = []
        static_rule = _parse_nat_static_rule(stripped, rule_order + 1)
        if static_rule is not None:
            parsed_rules.append(static_rule)
        else:
            parsed_rules.extend(
                _parse_nat_overload_rules(
                    stripped,
                    rule_order,
                    acl_prefixes,
                    interface_ip_map,
                )
            )
        if not parsed_rules:
            continue

        for parsed_rule in parsed_rules:
            table_key = (parsed_rule["table_scope"], parsed_rule["vrf_name"])
            table_roles = roles_by_table.get(table_key, {"inside": set(), "outside": set()})
            inside_interfaces = sorted(table_roles.get("inside") or [])
            outside_interfaces = sorted(table_roles.get("outside") or [])
            if not inside_interfaces or not outside_interfaces:
                continue

            table = tables.setdefault(
                table_key,
                {
                    "table_scope": parsed_rule["table_scope"],
                    "vrf_name": parsed_rule["vrf_name"],
                    "attrs_json": {"platform_driver": platform_driver},
                    "rules": [],
                },
            )
            for inside_interface in inside_interfaces:
                for outside_interface in outside_interfaces:
                    rule_order += 1
                    table["rules"].append(
                        {
                            "order": rule_order,
                            "inside_interface": inside_interface,
                            "outside_interface": outside_interface,
                            "conditions_json": parsed_rule["conditions_json"],
                            "translations_json": parsed_rule["translations_json"],
                            "attrs_json": parsed_rule["attrs_json"],
                        }
                    )

    payload = {
        "schema_version": 1,
        "platform_driver": platform_driver,
        "tables": [
            {
                "table_scope": table["table_scope"],
                "vrf_name": table["vrf_name"],
                "attrs_json": table["attrs_json"],
                "rules": table["rules"],
            }
            for table in tables.values()
        ],
    }
    return json.dumps(payload)


def collect_azure_state(_device):
    """Collect observed state from Azure API (MVP stub)."""
    return [
        {
            "artifact_type": "azure_route_table",
            "content": json.dumps(
                {
                    "routes": [
                        {
                            "vrf": "default",
                            "prefix": "0.0.0.0/0",
                            "next_hop": "10.0.0.1",
                            "protocol": "static",
                            "metric": 1,
                        }
                    ]
                }
            ),
        }
    ]


def collect_ssh_state(device):
    """Collect observed state over SSH using Netmiko for on-prem devices."""
    if ConnectHandler is None:
        raise RuntimeError("Netmiko is not installed; cannot run SSH collectors.")

    platform_driver = _platform_network_driver(device)
    host = _management_host(device)
    username, password, secret = _resolve_ssh_credentials(device)

    params = {
        "device_type": _netmiko_device_type(platform_driver),
        "host": host,
        "username": username,
        "password": password,
    }
    if secret:
        params["secret"] = secret

    artifacts = []
    route_outputs = []
    show_vrf_output = ""
    interface_output = ""
    running_config_output = ""
    with ConnectHandler(**params) as connection:
        if secret:
            connection.enable()
        for artifact_type, command in _command_catalog(platform_driver):
            content = connection.send_command(command, read_timeout=30)
            artifacts.append({"artifact_type": artifact_type, "content": content})
            if artifact_type == "show_route_raw":
                route_outputs.append(content)
            elif artifact_type == "show_vrf_raw":
                show_vrf_output = content
            elif artifact_type == "show_interface_raw":
                interface_output = content
            elif artifact_type == "show_run":
                running_config_output = content

        if platform_driver in ["cisco_ios", "cisco_xe"]:
            for vrf_name in _extract_ios_vrf_names(show_vrf_output):
                vrf_route_output = connection.send_command(f"show ip route vrf {vrf_name}", read_timeout=30)
                artifacts.append({"artifact_type": "show_route_raw", "content": vrf_route_output})
                route_outputs.append(vrf_route_output)
                vrf_arp_output = connection.send_command(f"show ip arp vrf {vrf_name}", read_timeout=30)
                artifacts.append(
                    {
                        "artifact_type": "show_arp_raw",
                        "content": f'IP ARP Table for VRF "{vrf_name}"\n{vrf_arp_output}',
                    }
                )

    if route_outputs:
        merged_lines = []
        seen_lines = set()
        for route_output in route_outputs:
            candidate = _to_cisco_route_artifact(route_output)
            for line in candidate.splitlines():
                if line not in seen_lines:
                    seen_lines.add(line)
                    merged_lines.append(line)
        parsed_routes = "\n".join(merged_lines)
        if parsed_routes:
            artifacts.append({"artifact_type": "cisco_route_table", "content": parsed_routes})

    if interface_output:
        artifacts.append(
            {"artifact_type": "interface_state", "content": _to_interface_state_artifact(interface_output)}
        )

    if running_config_output:
        nat_payload = _to_cisco_nat_table_artifact(running_config_output, platform_driver, interface_output)
        if json.loads(nat_payload).get("tables") or []:
            artifacts.append({"artifact_type": "cisco_nat_table", "content": nat_payload})

    return artifacts


def collect_device_artifacts(device):
    """Select collector by platform and return normalized artifact payload entries."""
    platform_name = ""
    if getattr(device, "platform", None):
        platform_name = (device.platform.name or "").lower()

    if "azure" in platform_name:
        return collect_azure_state(device)
    return collect_ssh_state(device)
