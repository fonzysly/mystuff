"""API serializers for digital_twin."""

import ipaddress

from nautobot.apps.api import NautobotModelSerializer, TaggedModelSerializerMixin
from rest_framework import serializers

from digital_twin import models


class DeviceScopeSerializer(NautobotModelSerializer, TaggedModelSerializerMixin):
    """DeviceScope serializer."""

    class Meta:
        model = models.DeviceScope
        fields = "__all__"


class TwinSnapshotSerializer(NautobotModelSerializer, TaggedModelSerializerMixin):
    """TwinSnapshot serializer."""

    class Meta:
        model = models.TwinSnapshot
        fields = "__all__"
        read_only_fields = ["status", "error_summary"]


class ReachabilityOptionsSerializer(serializers.Serializer):
    """Optional reachability query options."""

    max_paths = serializers.IntegerField(required=False, min_value=1, default=1)
    include_explanation = serializers.BooleanField(required=False, default=True)


class ReachabilityQuerySerializer(serializers.Serializer):
    """Validate reachability API request payload."""

    snapshot_id = serializers.UUIDField(required=True)
    src = serializers.IPAddressField(required=True)
    dst = serializers.ListField(child=serializers.CharField(), min_length=1, max_length=16)
    protocol = serializers.ChoiceField(choices=["tcp", "udp"])
    port = serializers.IntegerField(min_value=1, max_value=65535)
    mode = serializers.ChoiceField(choices=models.ReachabilityModeChoices.values)
    options = ReachabilityOptionsSerializer(required=False)

    def validate_dst(self, value):
        """Ensure each destination is explicit single endpoint."""
        for index, destination in enumerate(value):
            try:
                ipaddress.ip_address(destination)
            except ValueError as exc:
                raise serializers.ValidationError(f"dst[{index}] must be an explicit single endpoint IP") from exc
        return value
