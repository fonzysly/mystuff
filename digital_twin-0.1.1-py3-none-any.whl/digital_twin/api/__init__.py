"""REST API module for digital_twin app."""
