"""API views for digital_twin."""

from nautobot.apps.api import NautobotModelViewSet
from rest_framework import status
from rest_framework.generics import GenericAPIView
from rest_framework.response import Response

from digital_twin import filters, models
from digital_twin.api import serializers
from digital_twin.engine.reachability import check_reachability_many


class DeviceScopeViewSet(NautobotModelViewSet):
    """DeviceScope API viewset."""

    queryset = models.DeviceScope.objects.all()
    serializer_class = serializers.DeviceScopeSerializer
    filterset_class = filters.DeviceScopeFilterSet


class TwinSnapshotViewSet(NautobotModelViewSet):
    """TwinSnapshot API viewset."""

    queryset = models.TwinSnapshot.objects.all()
    serializer_class = serializers.TwinSnapshotSerializer
    filterset_class = filters.TwinSnapshotFilterSet


class ReachabilityAPIView(GenericAPIView):
    """POST endpoint for deterministic reachability queries."""

    queryset = models.TwinSnapshot.objects.all()
    serializer_class = serializers.ReachabilityQuerySerializer

    def post(self, request):
        """Run reachability for explicit destinations against a required snapshot."""
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        validated = serializer.validated_data

        snapshot_id = validated["snapshot_id"]
        snapshot = models.TwinSnapshot.objects.filter(pk=snapshot_id).first()
        if snapshot is None:
            return Response({"detail": "Snapshot not found."}, status=status.HTTP_404_NOT_FOUND)

        if snapshot.status != models.SnapshotStatusChoices.READY:
            return Response({"detail": "Snapshot is not READY."}, status=status.HTTP_409_CONFLICT)

        options = validated.get("options", {})
        payload = check_reachability_many(
            snapshot=snapshot,
            src=validated["src"],
            destinations=validated["dst"],
            protocol=validated["protocol"],
            port=validated["port"],
            mode=validated["mode"],
            include_explanation=options.get("include_explanation", True),
            max_paths=options.get("max_paths", 1),
        )
        return Response(payload, status=status.HTTP_200_OK)
