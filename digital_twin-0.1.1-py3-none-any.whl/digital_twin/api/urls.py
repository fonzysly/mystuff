"""Django API urlpatterns declaration for digital_twin app."""

from django.urls import path
from nautobot.apps.api import OrderedDefaultRouter

from digital_twin.api import views

router = OrderedDefaultRouter()
router.register("device-scopes", views.DeviceScopeViewSet)
router.register("twin-snapshots", views.TwinSnapshotViewSet)

app_name = "digital_twin-api"
urlpatterns = [
    path("reachability/", views.ReachabilityAPIView.as_view(), name="reachability"),
]
urlpatterns += router.urls
