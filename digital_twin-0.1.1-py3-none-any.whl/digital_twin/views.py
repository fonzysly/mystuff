"""Views for digital_twin."""

import json
from datetime import date, datetime, time
from decimal import Decimal
from uuid import UUID

try:
    from netutils.interface import canonical_interface_name
except ImportError:  # pragma: no cover
    canonical_interface_name = None

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

from django.contrib import messages
from django.db.models import Model as DjangoModel
from django.shortcuts import redirect, render
from django.utils.html import format_html
from django.views.generic import View
from nautobot.apps.ui import ObjectDetailContent, ObjectFieldsPanel, SectionChoices
from nautobot.apps.views import NautobotUIViewSet
from nautobot.core.forms import restrict_form_fields
from nautobot.core.utils.requests import normalize_querydict
from nautobot.dcim.models import Device
from nautobot.extras.jobs import get_job
from nautobot.extras.models import Job as JobModel
from nautobot.extras.models import JobResult

from digital_twin import filters, forms, models, tables
from digital_twin.api import serializers
from digital_twin.engine.reachability import check_reachability_many


class DeviceScopeUIViewSet(NautobotUIViewSet):
    """UI ViewSet for DeviceScope."""

    filterset_class = filters.DeviceScopeFilterSet
    filterset_form_class = forms.DeviceScopeFilterForm
    form_class = forms.DeviceScopeForm
    lookup_field = "pk"
    queryset = models.DeviceScope.objects.all()
    serializer_class = serializers.DeviceScopeSerializer
    table_class = tables.DeviceScopeTable
    object_detail_content = ObjectDetailContent(
        panels=[
            ObjectFieldsPanel(
                weight=100,
                section=SectionChoices.LEFT_HALF,
                fields=["name", "scope_type", "description", "dynamic_group"],
            ),
        ]
    )


class TwinSnapshotUIViewSet(NautobotUIViewSet):
    """UI ViewSet for TwinSnapshot."""

    filterset_class = filters.TwinSnapshotFilterSet
    filterset_form_class = forms.TwinSnapshotFilterForm
    form_class = forms.TwinSnapshotForm
    lookup_field = "pk"
    queryset = models.TwinSnapshot.objects.select_related("scope", "created_by")
    serializer_class = serializers.TwinSnapshotSerializer
    table_class = tables.TwinSnapshotTable
    object_detail_content = ObjectDetailContent(
        panels=[
            ObjectFieldsPanel(
                weight=100, section=SectionChoices.LEFT_HALF, fields=["scope", "status", "error_summary"]
            ),
        ]
    )

    def perform_create(self, request, *args, **kwargs):
        """Enqueue collect snapshot job from UI create action."""
        form_class = self.get_form_class()
        form = form_class(
            data=request.POST,
            files=request.FILES,
            initial=normalize_querydict(request.GET, form_class=form_class),
        )
        restrict_form_fields(form, request.user)
        if not form.is_valid():
            return self.form_invalid(form)

        job_model = JobModel.objects.get_for_class_path("digital_twin.jobs.CollectSnapshotJob")
        job_class = get_job(job_model.class_path, reload=True)
        job_kwargs = job_class.prepare_job_kwargs(
            {
                "scope": form.cleaned_data["scope"],
                "notes": form.cleaned_data.get("object_note", ""),
            }
        )
        job_result = JobResult.enqueue_job(
            job_model,
            request.user,
            **job_class.serialize_data(job_kwargs),
        )

        messages.info(
            request,
            format_html(
                'Collect Snapshot job enqueued. <a href="{}">Click here for the results.</a>',
                job_result.get_absolute_url(),
            ),
        )
        return redirect("extras:jobresult", pk=job_result.pk)


class ReachabilityQueryView(View):
    """Minimal UI to run reachability query against a snapshot."""

    template_name = "digital_twin/reachability_query.html"

    @staticmethod
    def _normalize_interface_name(interface_name):
        """Normalize interface names for ACL decision matching."""
        value = str(interface_name or "").strip()
        if not value:
            return ""
        if canonical_interface_name is not None:
            try:
                value = canonical_interface_name(value)
            except Exception:  # pylint: disable=broad-exception-caught  # noqa: S110
                pass
        return value.lower().replace(" ", "")

    @classmethod
    def _security_fail_start_index(cls, result, path):
        """Return hop index where ACL/security denial occurs for this path, else None."""
        if result.get("root_cause") != "SECURITY_POLICY_DENY":
            return None

        deny_decision = None
        for decision in path.get("policy_decisions") or []:
            if decision.get("table") == "ACL" and not bool(decision.get("allowed", True)):
                deny_decision = decision
                break
        if not deny_decision:
            return None

        deny_device = str(deny_decision.get("device") or "").strip()
        attrs = deny_decision.get("attrs") or {}
        deny_direction = str(attrs.get("direction") or "").strip().lower()
        deny_interface = cls._normalize_interface_name(attrs.get("interface"))

        device_only_match = None
        for idx, hop in enumerate(path.get("hops") or []):
            hop_device = str(hop.get("device") or "").strip()
            if hop_device != deny_device:
                continue
            if device_only_match is None:
                device_only_match = idx

            if deny_direction == "out":
                hop_interface = cls._normalize_interface_name(hop.get("egress_interface"))
            elif deny_direction == "in":
                hop_interface = cls._normalize_interface_name(hop.get("ingress_interface"))
            else:
                hop_interface = ""

            if deny_interface and hop_interface and hop_interface == deny_interface:
                return idx

        return device_only_match

    @classmethod
    def _annotate_hops_with_device_urls(cls, results):
        """Attach optional Nautobot device URLs to hop dictionaries by hop device name."""
        if not results:
            return

        device_names = set()
        for result in results:
            for direction in ["forward", "reverse"]:
                for path in result.get(direction, {}).get("paths") or []:
                    for hop in path.get("hops") or []:
                        device_name = str(hop.get("device") or "").strip()
                        if device_name:
                            device_names.add(device_name)

        if not device_names:
            return

        device_url_by_name = {
            device.name: device.get_absolute_url()
            for device in Device.objects.filter(name__in=device_names).only("name")
        }

        for result in results:
            limitations = [
                str(item) for item in (result.get("explanation", {}).get("limitations") or []) if str(item).strip()
            ]
            limitations_text = " ".join(limitations).lower()
            result["diagram_mode"] = "L3" if "mac table unavailable" in limitations_text else "L2"

            for direction in ["forward", "reverse"]:
                for path in result.get(direction, {}).get("paths") or []:
                    path_hops = path.get("hops") or []
                    path_reached = bool(path.get("reached"))
                    security_fail_start = None
                    if direction == "forward":
                        security_fail_start = cls._security_fail_start_index(result, path)
                    path["diagram_security_fail_start"] = security_fail_start

                    for hop in path.get("hops") or []:
                        device_name = str(hop.get("device") or "").strip()
                        hop["device_url"] = device_url_by_name.get(device_name)
                        hop["diagram_icon"] = "switch" if bool(hop.get("l2_decision")) else "router"
                        hop["diagram_status"] = "ok"
                        hop["diagram_tooltip"] = (
                            "L2 decision from MAC-table adjacency evidence."
                            if bool(hop.get("l2_decision"))
                            else "L3 routing decision (no MAC-table-driven hop selection)."
                        )

                    if security_fail_start is not None:
                        for idx, hop in enumerate(path_hops):
                            if idx >= security_fail_start:
                                hop["diagram_status"] = "fail"
                                if idx == security_fail_start:
                                    hop["diagram_tooltip"] = f"{hop['diagram_tooltip']} Blocked by security policy."
                                else:
                                    hop["diagram_tooltip"] = f"{hop['diagram_tooltip']} Downstream from security block."

                    if path_hops and not path_reached:
                        path_hops[-1]["diagram_status"] = "fail"
                        path_hops[-1]["diagram_tooltip"] = f"{path_hops[-1]['diagram_tooltip']} Terminal failed hop."

    def get(self, request):
        """Render empty query form."""
        return render(
            request, self.template_name, {"form": forms.ReachabilityQueryForm(), "results": None, "summary": None}
        )

    def post(self, request):
        """Execute reachability and render results."""
        form = forms.ReachabilityQueryForm(request.POST)
        results = None
        summary = None
        if form.is_valid():
            cleaned = form.cleaned_data
            mode = (
                models.ReachabilityModeChoices.ENFORCE_SECURITY
                if cleaned["enforce_security"]
                else models.ReachabilityModeChoices.IGNORE_SECURITY
            )
            payload = check_reachability_many(
                snapshot=cleaned["snapshot"],
                src=cleaned["src"],
                destinations=cleaned["dst"],
                protocol=cleaned["protocol"],
                port=cleaned["port"],
                mode=mode,
                include_explanation=True,
                max_paths=cleaned.get("max_paths") or 8,
            )
            results = payload["results"]
            self._annotate_hops_with_device_urls(results)
            summary = payload["summary"]
        return render(request, self.template_name, {"form": form, "results": results, "summary": summary})


class SnapshotDiffQueryView(View):
    """UI for side-by-side snapshot diff."""

    template_name = "digital_twin/snapshot_diff_query.html"
    state_model_specs = (
        (models.InterfaceState, "Interface", ("device", "interface_name")),
        (models.RoutingTableEntryState, "Routing Table", ("device", "vrf", "prefix", "next_hop", "protocol")),
        (models.NatRuleState, "NAT Rule", ("device", "order")),
        (
            models.PbrRuleState,
            "PBR Rule",
            ("device", "order", "src_prefix", "dst_prefix", "protocol", "port", "set_next_hop"),
        ),
        (models.LoadBalancerState, "Load Balancer", ("device", "vip", "pool")),
        (models.AclRuleState, "ACL Rule", ("device", "attrs_json__acl_name", "order")),
        (models.FirewallRuleState, "Firewall Rule", ("device", "order")),
        (models.AciContractState, "ACI Contract", ("device", "order")),
        (models.AzureNsgRuleState, "Azure NSG Rule", ("device", "order")),
    )

    @staticmethod
    def _device_name(obj):
        device = getattr(obj, "device", None)
        if not device:
            return "Unbound"
        return device.name

    @staticmethod
    def _normalize_value(value):
        """Normalize values to YAML/JSON-safe primitives for display."""
        if value is None or isinstance(value, (str, int, float, bool)):
            return value
        if isinstance(value, (datetime, date, time)):
            return value.isoformat()
        if isinstance(value, Decimal):
            return float(value)
        if isinstance(value, UUID):
            return str(value)
        if isinstance(value, DjangoModel):
            return str(value)
        if isinstance(value, dict):
            return {
                SnapshotDiffQueryView._normalize_value(key): SnapshotDiffQueryView._normalize_value(item)
                for key, item in value.items()
            }
        if isinstance(value, (list, tuple, set)):
            return [SnapshotDiffQueryView._normalize_value(item) for item in value]
        return str(value)

    @staticmethod
    def _serialize_row(row):
        values = {}
        if isinstance(row, models.AclRuleState):
            acl_name = (row.attrs_json or {}).get("acl_name")
            if acl_name:
                values["acl_name"] = acl_name
        for field in row._meta.fields:  # pylint: disable=protected-access
            if field.name in {
                "id",
                "pk",
                "device",
                "snapshot",
                "created",
                "last_updated",
                "attrs_json",
                "custom_field_data",
                "_custom_field_data",
                "nat_table",
                "nat_table_id",
            }:
                continue
            values[field.name] = SnapshotDiffQueryView._normalize_value(getattr(row, field.name))
        return values

    @staticmethod
    def _key_field_value(row, field_name):
        if field_name == "device":
            device = getattr(row, "device", None)
            return device.name if device else None
        if field_name.startswith("attrs_json__"):
            attrs_key = field_name.split("__", 1)[1]
            return (getattr(row, "attrs_json", {}) or {}).get(attrs_key)
        return getattr(row, field_name)

    @classmethod
    def _build_key(cls, row, key_fields):
        key_values = []
        for field_name in key_fields:
            key_values.append(cls._key_field_value(row, field_name))
        return tuple(key_values)

    @classmethod
    def _append_change(cls, bucket, model_label, left_row=None, right_row=None):
        """Append a raw change entry for later formatting."""
        row = right_row or left_row
        device_name = cls._device_name(row)
        bucket.setdefault(device_name, {})
        bucket[device_name].setdefault(model_label, [])
        bucket[device_name][model_label].append(
            {
                "left": cls._serialize_row(left_row) if left_row else None,
                "right": cls._serialize_row(right_row) if right_row else None,
            }
        )

    @staticmethod
    def _to_yaml(data):
        """Render dictionaries/lists in a human-readable YAML-like format."""
        if data is None:
            return ""
        if yaml is not None:
            return yaml.safe_dump(data, sort_keys=True, default_flow_style=False, allow_unicode=True).strip()
        return json.dumps(data, indent=2, sort_keys=True)

    @classmethod
    def _field_deltas(cls, left_data, right_data):
        """Return per-field left/right deltas for modified rows."""
        deltas = {}
        for field_name in sorted(set(left_data.keys()) | set(right_data.keys())):
            left_value = left_data.get(field_name)
            right_value = right_data.get(field_name)
            if left_value != right_value:
                deltas[field_name] = {"newer": left_value, "older": right_value}
        return deltas

    @classmethod
    def _format_changes_for_display(cls, grouped):
        """Convert raw diff output into display-friendly structure."""
        formatted = {"added": {}, "removed": {}, "modified": {}}
        for change_type, devices in grouped.items():
            for device_name, model_groups in devices.items():
                formatted[change_type].setdefault(device_name, {})
                for model_name, entries in model_groups.items():
                    formatted_entries = []
                    for entry in entries:
                        left_data = entry.get("left")
                        right_data = entry.get("right")
                        formatted_entry = {
                            "left_yaml": cls._to_yaml(left_data),
                            "right_yaml": cls._to_yaml(right_data),
                            "delta_yaml": "",
                        }
                        if change_type == "modified":
                            formatted_entry["delta_yaml"] = cls._to_yaml(
                                cls._field_deltas(left_data or {}, right_data or {})
                            )
                        formatted_entries.append(formatted_entry)
                    formatted[change_type][device_name][model_name] = formatted_entries
        return formatted

    @classmethod
    def _compute_diff(cls, left_snapshot, right_snapshot):
        grouped = {"added": {}, "removed": {}, "modified": {}}

        for model_class, model_label, key_fields in cls.state_model_specs:
            left_rows = list(model_class.objects.filter(snapshot=left_snapshot).select_related("device"))
            right_rows = list(model_class.objects.filter(snapshot=right_snapshot).select_related("device"))
            left_by_key = {cls._build_key(row, key_fields): row for row in left_rows}
            right_by_key = {cls._build_key(row, key_fields): row for row in right_rows}

            all_keys = set(left_by_key.keys()) | set(right_by_key.keys())
            for key in all_keys:
                left_row = left_by_key.get(key)
                right_row = right_by_key.get(key)
                if left_row is None and right_row is not None:
                    cls._append_change(grouped["removed"], model_label, right_row=right_row)
                    continue
                if left_row is not None and right_row is None:
                    cls._append_change(grouped["added"], model_label, left_row=left_row)
                    continue
                left_serialized = cls._serialize_row(left_row)
                right_serialized = cls._serialize_row(right_row)
                if left_serialized != right_serialized:
                    cls._append_change(grouped["modified"], model_label, left_row=left_row, right_row=right_row)

        summary = {
            "added": sum(
                len(entries) for device_models in grouped["added"].values() for entries in device_models.values()
            ),
            "removed": sum(
                len(entries) for device_models in grouped["removed"].values() for entries in device_models.values()
            ),
            "modified": sum(
                len(entries) for device_models in grouped["modified"].values() for entries in device_models.values()
            ),
        }
        summary["total"] = summary["added"] + summary["removed"] + summary["modified"]
        summary["left"] = {
            "left_only": summary["added"],
            "right_only": summary["removed"],
            "modified": summary["modified"],
            "total": summary["added"] + summary["modified"],
        }
        summary["right"] = {
            "left_only": summary["added"],
            "right_only": summary["removed"],
            "modified": summary["modified"],
            "total": summary["removed"] + summary["modified"],
        }

        ordered = {
            "added": dict(sorted(grouped["added"].items(), key=lambda item: item[0])),
            "removed": dict(sorted(grouped["removed"].items(), key=lambda item: item[0])),
            "modified": dict(sorted(grouped["modified"].items(), key=lambda item: item[0])),
        }
        return cls._format_changes_for_display(ordered), summary

    def get(self, request):
        """Render empty snapshot diff form."""
        return render(
            request,
            self.template_name,
            {
                "form": forms.SnapshotDiffQueryForm(),
                "diff": None,
                "summary": None,
                "left_snapshot": None,
                "right_snapshot": None,
            },
        )

    def post(self, request):
        """Execute snapshot diff and render grouped changes."""
        form = forms.SnapshotDiffQueryForm(request.POST)
        diff = None
        summary = None
        left_snapshot = None
        right_snapshot = None

        if form.is_valid():
            left_snapshot = form.cleaned_data["left_snapshot"]
            right_snapshot = form.cleaned_data["right_snapshot"]
            diff, summary = self._compute_diff(left_snapshot, right_snapshot)

        return render(
            request,
            self.template_name,
            {
                "form": form,
                "diff": diff,
                "summary": summary,
                "left_snapshot": left_snapshot,
                "right_snapshot": right_snapshot,
            },
        )
