"""Models for Digital Twin."""

from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone
from django.utils.formats import date_format
from nautobot.apps.constants import CHARFIELD_MAX_LENGTH
from nautobot.apps.models import PrimaryModel, extras_features
from nautobot.dcim.models import Device
from nautobot.extras.models import DynamicGroup

User = get_user_model()


class ScopeTypeChoices(models.TextChoices):
    """Device scope modes."""

    STATIC = "STATIC", "Static"
    DYNAMIC_GROUP = "DYNAMIC_GROUP", "Dynamic Group"


class SnapshotStatusChoices(models.TextChoices):
    """Twin snapshot lifecycle status."""

    CREATED = "CREATED", "Created"
    COLLECTING = "COLLECTING", "Collecting"
    NORMALIZING = "NORMALIZING", "Normalizing"
    BUILDING = "BUILDING", "Building"
    READY = "READY", "Ready"
    FAILED = "FAILED", "Failed"


class StageStatusChoices(models.TextChoices):
    """Per-device stage status."""

    PENDING = "PENDING", "Pending"
    SUCCESS = "SUCCESS", "Success"
    FAILED = "FAILED", "Failed"


class ReachabilityModeChoices(models.TextChoices):
    """Reachability modes."""

    ENFORCE_SECURITY = "ENFORCE_SECURITY", "Enforce Security"
    IGNORE_SECURITY = "IGNORE_SECURITY", "Ignore Security"


class VerdictChoices(models.TextChoices):
    """Reachability verdict choices."""

    REACHABLE = "REACHABLE", "Reachable"
    UNREACHABLE = "UNREACHABLE", "Unreachable"


class ConfidenceChoices(models.TextChoices):
    """Result confidence choices."""

    HIGH = "HIGH", "High"
    MEDIUM = "MEDIUM", "Medium"
    LOW = "LOW", "Low"


class SecurityActionChoices(models.TextChoices):
    """Security action values."""

    ALLOW = "ALLOW", "Allow"
    DENY = "DENY", "Deny"


class NatTableScopeChoices(models.TextChoices):
    """NAT table scope values."""

    GLOBAL = "GLOBAL", "Global"
    VRF = "VRF", "VRF"


@extras_features("custom_links", "custom_validators", "export_templates", "graphql", "webhooks")
class DeviceScope(PrimaryModel):
    """Named scope resolving Nautobot devices."""

    name = models.CharField(max_length=CHARFIELD_MAX_LENGTH, unique=True)
    description = models.TextField(blank=True)
    scope_type = models.CharField(max_length=32, choices=ScopeTypeChoices.choices, default=ScopeTypeChoices.STATIC)
    devices = models.ManyToManyField(Device, blank=True, related_name="digital_twin_device_scopes")
    dynamic_group = models.ForeignKey(
        DynamicGroup,
        null=True,
        blank=True,
        on_delete=models.PROTECT,
        related_name="digital_twin_device_scopes",
    )

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name

    def clean(self):
        super().clean()
        if self.scope_type == ScopeTypeChoices.STATIC and self.dynamic_group_id:
            raise ValidationError({"dynamic_group": "Dynamic group must be empty for STATIC scopes."})
        if self.scope_type == ScopeTypeChoices.DYNAMIC_GROUP:
            if not self.dynamic_group_id:
                raise ValidationError({"dynamic_group": "Dynamic group is required for DYNAMIC_GROUP scopes."})
            content_type = self.dynamic_group.content_type
            if content_type.app_label != "dcim" or content_type.model != "device":
                raise ValidationError({"dynamic_group": "Dynamic group content type must be dcim.device."})

    def get_devices(self):
        """Return queryset of scoped devices."""
        if self.scope_type == ScopeTypeChoices.DYNAMIC_GROUP and self.dynamic_group_id:
            return self.dynamic_group.members
        return self.devices.all()


@extras_features("custom_links", "custom_validators", "export_templates", "graphql", "webhooks")
class TwinSnapshot(PrimaryModel):
    """Snapshot root for observed/derived state."""

    scope = models.ForeignKey(DeviceScope, on_delete=models.PROTECT, related_name="snapshots")
    created_by = models.ForeignKey(
        User, null=True, blank=True, on_delete=models.SET_NULL, related_name="digital_twin_snapshots"
    )
    status = models.CharField(
        max_length=16, choices=SnapshotStatusChoices.choices, default=SnapshotStatusChoices.CREATED
    )
    error_summary = models.TextField(blank=True)

    class Meta:
        ordering = ["-created"]

    def display_name(self):
        """Return a user-friendly label with local timestamp."""
        created_local = timezone.localtime(self.created)
        return f"{self.scope.name} @ {date_format(created_local, format='N j, Y, P T', use_l10n=True)}"

    def __str__(self):
        return self.display_name()


@extras_features("custom_links", "custom_validators", "export_templates", "graphql", "webhooks")
class DeviceSnapshotState(PrimaryModel):
    """Per-device progress for a snapshot."""

    snapshot = models.ForeignKey(TwinSnapshot, on_delete=models.CASCADE, related_name="device_states")
    device = models.ForeignKey(
        Device, on_delete=models.PROTECT, related_name="digital_twin_snapshot_states", null=True, blank=True
    )
    collection_status = models.CharField(
        max_length=16, choices=StageStatusChoices.choices, default=StageStatusChoices.PENDING
    )
    parse_status = models.CharField(
        max_length=16, choices=StageStatusChoices.choices, default=StageStatusChoices.PENDING
    )
    build_status = models.CharField(
        max_length=16, choices=StageStatusChoices.choices, default=StageStatusChoices.PENDING
    )
    collected_at = models.DateTimeField(null=True, blank=True)
    parsed_at = models.DateTimeField(null=True, blank=True)
    built_at = models.DateTimeField(null=True, blank=True)
    error_detail = models.TextField(blank=True)

    class Meta:
        ordering = ["snapshot", "device__name"]
        constraints = [models.UniqueConstraint(fields=["snapshot", "device"], name="digital_twin_unique_device_state")]

    def __str__(self):
        return f"{self.snapshot_id}:{self.device.name if self.device else 'unbound'}"


@extras_features("custom_links", "custom_validators", "export_templates", "graphql", "webhooks")
class StateArtifact(PrimaryModel):
    """Raw collected artifact."""

    device_state = models.ForeignKey(DeviceSnapshotState, on_delete=models.CASCADE, related_name="artifacts")
    artifact_type = models.CharField(max_length=64)
    content = models.TextField()
    checksum = models.CharField(max_length=64)
    collected_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["device_state", "artifact_type", "-collected_at"]

    def __str__(self):
        return f"{self.device_state_id}:{self.artifact_type}"


class SnapshotStateBase(PrimaryModel):
    """Abstract base for snapshot keyed state rows."""

    snapshot = models.ForeignKey(TwinSnapshot, on_delete=models.CASCADE)
    device = models.ForeignKey(Device, on_delete=models.PROTECT, null=True, blank=True)
    attrs_json = models.JSONField(default=dict, blank=True)

    class Meta:
        abstract = True


@extras_features("custom_links", "custom_validators", "export_templates", "graphql", "webhooks")
class RoutingTableEntryState(SnapshotStateBase):
    """Normalized route table state."""

    vrf = models.CharField(max_length=64, blank=True)
    prefix = models.CharField(max_length=64)
    next_hop = models.CharField(max_length=64, blank=True)
    protocol = models.CharField(max_length=32, blank=True)
    metric = models.IntegerField(null=True, blank=True)

    class Meta:
        ordering = ["snapshot", "device", "prefix", "metric"]


@extras_features("custom_links", "custom_validators", "export_templates", "graphql", "webhooks")
class InterfaceState(SnapshotStateBase):
    """Normalized interface state."""

    interface_name = models.CharField(max_length=64)
    admin_up = models.BooleanField(default=True)
    oper_up = models.BooleanField(default=True)
    observed_ips = models.JSONField(default=list, blank=True)

    class Meta:
        ordering = ["snapshot", "device", "interface_name"]


@extras_features("custom_links", "custom_validators", "export_templates", "graphql", "webhooks")
class NatTableState(SnapshotStateBase):
    """Normalized NAT table state."""

    table_scope = models.CharField(max_length=16, choices=NatTableScopeChoices.choices)
    vrf_name = models.CharField(max_length=64, blank=True)

    class Meta:
        ordering = ["snapshot", "device", "table_scope", "vrf_name"]
        constraints = [
            models.UniqueConstraint(
                fields=["snapshot", "device", "table_scope", "vrf_name"], name="digital_twin_unique_nat_table"
            )
        ]


@extras_features("custom_links", "custom_validators", "export_templates", "graphql", "webhooks")
class NatRuleState(SnapshotStateBase):
    """Normalized NAT policy state."""

    nat_table = models.ForeignKey(NatTableState, on_delete=models.CASCADE, related_name="rules", null=True, blank=True)
    inside_interface = models.CharField(max_length=64, default="", blank=True)
    outside_interface = models.CharField(max_length=64, default="", blank=True)
    conditions_json = models.JSONField(default=dict, blank=True)
    translations_json = models.JSONField(default=dict, blank=True)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["snapshot", "device", "nat_table", "order"]


@extras_features("custom_links", "custom_validators", "export_templates", "graphql", "webhooks")
class PbrRuleState(SnapshotStateBase):
    """Normalized policy-based routing rule state."""

    src_prefix = models.CharField(max_length=64, blank=True)
    dst_prefix = models.CharField(max_length=64, blank=True)
    protocol = models.CharField(max_length=16, blank=True)
    port = models.PositiveIntegerField(null=True, blank=True)
    set_next_hop = models.CharField(max_length=64)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["snapshot", "device", "order"]


@extras_features("custom_links", "custom_validators", "export_templates", "graphql", "webhooks")
class LoadBalancerState(SnapshotStateBase):
    """Normalized load balancer state."""

    vip = models.GenericIPAddressField()
    pool = models.CharField(max_length=128, blank=True)
    members = models.JSONField(default=list, blank=True)
    snat = models.CharField(max_length=64, blank=True)
    has_irules = models.BooleanField(default=False)

    class Meta:
        ordering = ["snapshot", "vip", "pool"]


class SecurityRuleBase(SnapshotStateBase):
    """Abstract base for security policy tables."""

    src_prefix = models.CharField(max_length=64, blank=True)
    dst_prefix = models.CharField(max_length=64, blank=True)
    protocol = models.CharField(max_length=16, blank=True)
    port = models.PositiveIntegerField(null=True, blank=True)
    action = models.CharField(max_length=8, choices=SecurityActionChoices.choices, default=SecurityActionChoices.ALLOW)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        abstract = True


@extras_features("custom_links", "custom_validators", "export_templates", "graphql", "webhooks")
class AclRuleState(SecurityRuleBase):
    """ACL rule state."""

    class Meta:
        ordering = ["snapshot", "device", "order"]


@extras_features("custom_links", "custom_validators", "export_templates", "graphql", "webhooks")
class FirewallRuleState(SecurityRuleBase):
    """Firewall rule state."""

    class Meta:
        ordering = ["snapshot", "device", "order"]


@extras_features("custom_links", "custom_validators", "export_templates", "graphql", "webhooks")
class AciContractState(SecurityRuleBase):
    """ACI contract state."""

    class Meta:
        ordering = ["snapshot", "device", "order"]


@extras_features("custom_links", "custom_validators", "export_templates", "graphql", "webhooks")
class AzureNsgRuleState(SecurityRuleBase):
    """Azure NSG rule state."""

    class Meta:
        ordering = ["snapshot", "device", "order"]


@extras_features("custom_links", "custom_validators", "export_templates", "graphql", "webhooks")
class TwinGraphNode(PrimaryModel):
    """Derived twin graph node."""

    snapshot = models.ForeignKey(TwinSnapshot, on_delete=models.CASCADE, related_name="graph_nodes")
    ip = models.GenericIPAddressField()
    node_type = models.CharField(max_length=32, default="ENDPOINT")
    ref = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ["snapshot", "ip", "node_type"]
        constraints = [
            models.UniqueConstraint(fields=["snapshot", "ip", "node_type"], name="digital_twin_unique_graph_node")
        ]


@extras_features("custom_links", "custom_validators", "export_templates", "graphql", "webhooks")
class TwinGraphEdge(PrimaryModel):
    """Derived twin graph edge."""

    snapshot = models.ForeignKey(TwinSnapshot, on_delete=models.CASCADE, related_name="graph_edges")
    src_node = models.ForeignKey(TwinGraphNode, on_delete=models.CASCADE, related_name="outgoing_edges")
    dst_node = models.ForeignKey(TwinGraphNode, on_delete=models.CASCADE, related_name="incoming_edges")
    relation = models.CharField(max_length=32)
    attrs_json = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ["snapshot", "src_node", "dst_node", "relation"]


@extras_features("custom_links", "custom_validators", "export_templates", "graphql", "webhooks")
class FlowResult(PrimaryModel):
    """Optional snapshot-scoped cached flow result."""

    snapshot = models.ForeignKey(TwinSnapshot, on_delete=models.CASCADE, related_name="flow_results")
    query_key = models.CharField(max_length=255)
    src_ip = models.GenericIPAddressField()
    dst_ip = models.GenericIPAddressField()
    protocol = models.CharField(max_length=16)
    port = models.PositiveIntegerField()
    mode = models.CharField(max_length=32, choices=ReachabilityModeChoices.choices)
    verdict = models.CharField(max_length=16, choices=VerdictChoices.choices)
    confidence = models.CharField(max_length=16, choices=ConfidenceChoices.choices)
    response_json = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ["snapshot", "src_ip", "dst_ip", "protocol", "port"]
        constraints = [
            models.UniqueConstraint(fields=["snapshot", "query_key"], name="digital_twin_unique_flow_result")
        ]


@extras_features("custom_links", "custom_validators", "export_templates", "graphql", "webhooks")
class FlowExplanationStep(PrimaryModel):
    """Structured explanation step."""

    flow_result = models.ForeignKey(FlowResult, on_delete=models.CASCADE, related_name="explanation_steps")
    step_order = models.PositiveIntegerField(default=0)
    message = models.TextField()
    attrs_json = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ["flow_result", "step_order"]
