"""Menu items."""

from nautobot.apps.ui import NavMenuAddButton, NavMenuGroup, NavMenuItem, NavMenuTab

snapshot_items = (
    NavMenuItem(
        link="plugins:digital_twin:devicescope_list",
        name="Device Scopes",
        permissions=["digital_twin.view_devicescope"],
        buttons=(
            NavMenuAddButton(
                link="plugins:digital_twin:devicescope_add",
                permissions=["digital_twin.add_devicescope"],
            ),
        ),
    ),
    NavMenuItem(
        link="plugins:digital_twin:twinsnapshot_list",
        name="Snapshots",
        permissions=["digital_twin.view_twinsnapshot"],
        buttons=(
            NavMenuAddButton(
                link="plugins:digital_twin:twinsnapshot_add",
                permissions=["digital_twin.add_twinsnapshot"],
            ),
        ),
    ),
)

analyze_items = (
    NavMenuItem(
        link="plugins:digital_twin:reachability_query",
        name="Reachability Query",
        permissions=["digital_twin.view_twinsnapshot"],
    ),
    NavMenuItem(
        link="plugins:digital_twin:snapshot_diff_query",
        name="Snapshot Diff",
        permissions=["digital_twin.view_twinsnapshot"],
    ),
)

menu_items = (
    NavMenuTab(
        name="Digital Twin",
        icon="sitemap-outline",
        groups=(
            NavMenuGroup(name="Snapshot", items=tuple(snapshot_items)),
            NavMenuGroup(name="Analyze", items=tuple(analyze_items)),
        ),
    ),
)
