"""Forms for digital_twin."""

from django import forms
from nautobot.apps import forms as nautobot_forms
from nautobot.apps.forms import NautobotFilterForm, NautobotModelForm
from nautobot.dcim.models import Device

from digital_twin import models


class SnapshotSelect(forms.Select):
    """Select widget exposing snapshot metadata on options."""

    def create_option(self, name, value, label, selected, index, subindex=None, attrs=None):
        """Attach snapshot metadata used by client-side local-time rendering."""
        option = super().create_option(name, value, label, selected, index, subindex=subindex, attrs=attrs)
        instance = getattr(value, "instance", None)
        if instance is not None:
            option["attrs"]["data-snapshot-created"] = instance.created.isoformat()
            option["attrs"]["data-snapshot-scope"] = instance.scope.name
            option["attrs"]["data-snapshot-scope-id"] = str(instance.scope_id)
        return option


class SnapshotChoiceField(forms.ModelChoiceField):
    """ModelChoiceField using a friendly snapshot display label."""

    def __init__(self, *args, **kwargs):
        """Use snapshot-aware select widget for client-side timezone localization."""
        kwargs.setdefault("widget", SnapshotSelect())
        super().__init__(*args, **kwargs)

    def label_from_instance(self, obj):
        return obj.display_name()


class DeviceScopeForm(NautobotModelForm):
    """Create/edit form for DeviceScope."""

    devices = nautobot_forms.DynamicModelMultipleChoiceField(
        queryset=Device.objects.all(),
        required=False,
    )

    class Meta:
        model = models.DeviceScope
        fields = ["name", "description", "scope_type", "dynamic_group", "devices", "tags"]


class DeviceScopeFilterForm(NautobotFilterForm):
    """Filter form for DeviceScope list."""

    model = models.DeviceScope
    field_order = ["q", "name", "scope_type"]
    q = forms.CharField(required=False, label="Search")
    name = forms.CharField(required=False, label="Name")


class TwinSnapshotForm(NautobotModelForm):
    """Create/edit form for TwinSnapshot."""

    class Meta:
        model = models.TwinSnapshot
        fields = ["scope", "tags"]


class TwinSnapshotFilterForm(NautobotFilterForm):
    """Filter form for TwinSnapshot list."""

    model = models.TwinSnapshot
    field_order = ["q", "scope", "status"]
    q = forms.CharField(required=False, label="Search")


class ReachabilityQueryForm(forms.Form):
    """Form used for reachability query UI."""

    snapshot = SnapshotChoiceField(
        queryset=models.TwinSnapshot.objects.filter(status=models.SnapshotStatusChoices.READY)
    )
    src = forms.GenericIPAddressField(protocol="both")
    dst = forms.CharField(
        help_text="Comma-separated explicit destination IPs (max 16).",
        widget=forms.Textarea(attrs={"rows": 3}),
    )
    protocol = forms.ChoiceField(choices=[("tcp", "TCP"), ("udp", "UDP")], initial="tcp")
    port = forms.IntegerField(min_value=1, max_value=65535)
    enforce_security = forms.BooleanField(required=False, initial=True, label="Enforce security")
    max_paths = forms.IntegerField(
        min_value=1,
        max_value=8,
        initial=8,
        required=False,
        help_text="Maximum number of equal-cost paths to return.",
    )

    def __init__(self, *args, **kwargs):
        """Apply consistent UI classes to query controls."""
        super().__init__(*args, **kwargs)
        self.fields["snapshot"].widget.attrs.update({"class": "form-select"})
        self.fields["src"].widget.attrs.update({"class": "form-control"})
        self.fields["dst"].widget.attrs.update({"class": "form-control", "rows": 3})
        self.fields["protocol"].widget.attrs.update({"class": "form-select"})
        self.fields["port"].widget.attrs.update({"class": "form-control"})
        self.fields["enforce_security"].widget.attrs.update({"class": "form-check-input"})
        self.fields["max_paths"].widget.attrs.update({"class": "form-control"})

    def clean_dst(self):
        """Split and validate destination list size."""
        raw = self.cleaned_data["dst"]
        values = [value.strip() for value in raw.replace("\n", ",").split(",") if value.strip()]
        if not values:
            raise forms.ValidationError("At least one destination is required.")
        if len(values) > 16:
            raise forms.ValidationError("At most 16 destinations are allowed.")
        return values


class SnapshotDiffQueryForm(forms.Form):
    """Form used for snapshot diff UI."""

    scope = forms.ModelChoiceField(
        queryset=models.DeviceScope.objects.all(),
        label="Device scope",
    )

    left_snapshot = SnapshotChoiceField(
        queryset=models.TwinSnapshot.objects.filter(status=models.SnapshotStatusChoices.READY),
        label="Newer snapshot",
    )
    right_snapshot = SnapshotChoiceField(
        queryset=models.TwinSnapshot.objects.filter(status=models.SnapshotStatusChoices.READY),
        label="Older snapshot",
    )

    def __init__(self, *args, **kwargs):
        """Apply consistent UI classes to query controls."""
        super().__init__(*args, **kwargs)
        self.fields["scope"].widget.attrs.update({"class": "form-select"})
        self.fields["left_snapshot"].widget.attrs.update({"class": "form-select"})
        self.fields["right_snapshot"].widget.attrs.update({"class": "form-select"})

    def clean(self):
        """Ensure snapshots are distinct and belong to the selected scope."""
        cleaned_data = super().clean()
        scope = cleaned_data.get("scope")
        left_snapshot = cleaned_data.get("left_snapshot")
        right_snapshot = cleaned_data.get("right_snapshot")
        if left_snapshot and right_snapshot and left_snapshot.pk == right_snapshot.pk:
            raise forms.ValidationError("Newer and older snapshots must be different.")
        if left_snapshot and right_snapshot and left_snapshot.scope_id != right_snapshot.scope_id:
            raise forms.ValidationError("Snapshots must belong to the same device scope.")
        if left_snapshot and right_snapshot and left_snapshot.created < right_snapshot.created:
            raise forms.ValidationError(
                "Newer snapshot must be newer than or equal to older snapshot. "
                "Select the newest snapshot in Newer snapshot and the oldest snapshot in Older snapshot."
            )
        if scope and left_snapshot and left_snapshot.scope_id != scope.pk:
            self.add_error("left_snapshot", "Newer snapshot must belong to the selected device scope.")
        if scope and right_snapshot and right_snapshot.scope_id != scope.pk:
            self.add_error("right_snapshot", "Older snapshot must belong to the selected device scope.")
        return cleaned_data
