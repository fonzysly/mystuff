"""Nautobot Jobs for digital twin workflows."""

import hashlib
import json

from django.db import transaction
from django.utils import timezone
from nautobot.apps.jobs import ChoiceVar, IntegerVar, Job, ObjectVar, StringVar, register_jobs
from nautobot.extras.models import Note

from digital_twin import collectors, models
from digital_twin.engine.parsers import (
    parse_cisco_acl_text,
    parse_cisco_nat_table_json,
    parse_cisco_route_text,
    parse_f5_ltm_json,
    parse_interface_json,
    parse_pbr_json,
)
from digital_twin.engine.reachability import check_reachability_many


class CollectSnapshotJob(Job):
    """Collect observed device state for a device scope."""

    scope = ObjectVar(model=models.DeviceScope)
    notes = StringVar(required=False)

    class Meta:
        name = "Collect Snapshot"
        description = "Collect SSH/API artifacts into TwinSnapshot and StateArtifact rows."

    def run(self, scope, notes=""):
        snapshot = models.TwinSnapshot.objects.create(
            scope=scope,
            status=models.SnapshotStatusChoices.COLLECTING,
        )
        note_text = (notes or "").strip()
        if note_text:
            Note.objects.create(
                assigned_object=snapshot,
                user=getattr(self, "user", None),
                note=note_text,
            )

        scoped_devices = list(scope.get_devices())
        if not scoped_devices:
            snapshot.status = models.SnapshotStatusChoices.FAILED
            snapshot.error_summary = "Collection scope resolved to zero devices."
            snapshot.save(update_fields=["status", "error_summary"])
            self.logger.warning("Snapshot %s collection failed: scope %s has no devices", snapshot.pk, scope.pk)
            raise RuntimeError(snapshot.error_summary)

        failures = []
        for device in scoped_devices:
            state = models.DeviceSnapshotState.objects.create(snapshot=snapshot, device=device)
            try:
                artifacts = collectors.collect_device_artifacts(device)
                if not artifacts:
                    raise RuntimeError("Collector returned zero artifacts")
                for artifact in artifacts:
                    content = artifact["content"]
                    checksum = hashlib.sha256(content.encode("utf-8")).hexdigest()
                    models.StateArtifact.objects.create(
                        device_state=state,
                        artifact_type=artifact["artifact_type"],
                        content=content,
                        checksum=checksum,
                        collected_at=timezone.now(),
                    )
                state.collection_status = models.StageStatusChoices.SUCCESS
                state.collected_at = timezone.now()
                state.save(update_fields=["collection_status", "collected_at"])
            except Exception as exc:  # pylint: disable=broad-exception-caught
                state.collection_status = models.StageStatusChoices.FAILED
                state.error_detail = str(exc)
                state.save(update_fields=["collection_status", "error_detail"])
                failures.append(f"{device.name if device else 'unbound'}: {exc}")

        if failures:
            snapshot.status = models.SnapshotStatusChoices.FAILED
            snapshot.error_summary = "Collection failures: " + " | ".join(failures)
            snapshot.save(update_fields=["status", "error_summary"])
            raise RuntimeError(snapshot.error_summary)
        else:
            snapshot.status = models.SnapshotStatusChoices.NORMALIZING
            snapshot.save(update_fields=["status"])
            NormalizeSnapshotJob().run(snapshot=snapshot)
        self.logger.info("Collected snapshot %s", snapshot.pk)
        return snapshot.pk


class NormalizeSnapshotJob(Job):
    """Normalize artifacts into canonical state tables."""

    snapshot = ObjectVar(model=models.TwinSnapshot)

    class Meta:
        name = "Normalize Snapshot"
        description = "Parse artifacts into routing/interface/NAT/LB/security state tables."

    def run(self, snapshot):
        snapshot.status = models.SnapshotStatusChoices.NORMALIZING
        snapshot.save(update_fields=["status"])

        for device_state in snapshot.device_states.select_related("device"):
            try:
                for artifact in device_state.artifacts.all():
                    if artifact.artifact_type == "cisco_route_table":
                        for row in parse_cisco_route_text(artifact.content):
                            models.RoutingTableEntryState.objects.create(
                                snapshot=snapshot, device=device_state.device, **row
                            )
                    elif artifact.artifact_type == "interface_state":
                        for row in parse_interface_json(json.loads(artifact.content)):
                            models.InterfaceState.objects.create(snapshot=snapshot, device=device_state.device, **row)
                    elif artifact.artifact_type == "cisco_nat_table":
                        parsed = parse_cisco_nat_table_json(json.loads(artifact.content))
                        table_index = {}
                        for row in parsed["tables"]:
                            table, _ = models.NatTableState.objects.get_or_create(
                                snapshot=snapshot,
                                device=device_state.device,
                                table_scope=row["table_scope"],
                                vrf_name=row["vrf_name"],
                                defaults={"attrs_json": row.get("attrs_json", {})},
                            )
                            table_index[(table.table_scope, table.vrf_name)] = table
                        for row in parsed["rules"]:
                            table_key = (row["table_scope"], row["vrf_name"])
                            table = table_index.get(table_key)
                            if table is None:
                                table = models.NatTableState.objects.create(
                                    snapshot=snapshot,
                                    device=device_state.device,
                                    table_scope=row["table_scope"],
                                    vrf_name=row["vrf_name"],
                                )
                                table_index[table_key] = table
                            models.NatRuleState.objects.create(
                                snapshot=snapshot,
                                device=device_state.device,
                                nat_table=table,
                                inside_interface=row["inside_interface"],
                                outside_interface=row["outside_interface"],
                                conditions_json=row["conditions_json"],
                                translations_json=row["translations_json"],
                                order=row["order"],
                                attrs_json=row.get("attrs_json", {}),
                            )
                    elif artifact.artifact_type == "nat_rules":
                        legacy_table, _ = models.NatTableState.objects.get_or_create(
                            snapshot=snapshot,
                            device=device_state.device,
                            table_scope=models.NatTableScopeChoices.GLOBAL,
                            vrf_name="",
                        )
                        for row in json.loads(artifact.content):
                            inside_interface = (
                                str(
                                    row.get("inside_interface")
                                    or row.get("attrs_json", {}).get("inside_interface")
                                    or ""
                                )
                                .strip()
                                .lower()
                                .replace(" ", "")
                            )
                            outside_interface = (
                                str(
                                    row.get("outside_interface")
                                    or row.get("attrs_json", {}).get("outside_interface")
                                    or ""
                                )
                                .strip()
                                .lower()
                                .replace(" ", "")
                            )
                            if not inside_interface or not outside_interface:
                                continue
                            models.NatRuleState.objects.create(
                                snapshot=snapshot,
                                device=device_state.device,
                                nat_table=legacy_table,
                                inside_interface=inside_interface,
                                outside_interface=outside_interface,
                                conditions_json=row.get("conditions_json") or {},
                                translations_json=row.get("translations_json") or {},
                                order=int(row.get("order", 0)),
                                attrs_json=row.get("attrs_json") or {},
                            )
                    elif artifact.artifact_type == "f5_ltm_dump":
                        for row in parse_f5_ltm_json(json.loads(artifact.content)):
                            models.LoadBalancerState.objects.create(
                                snapshot=snapshot, device=device_state.device, **row
                            )
                    elif artifact.artifact_type == "pbr_rules":
                        for row in parse_pbr_json(json.loads(artifact.content)):
                            models.PbrRuleState.objects.create(snapshot=snapshot, device=device_state.device, **row)
                    elif artifact.artifact_type == "show_acl_raw":
                        for row in parse_cisco_acl_text(artifact.content):
                            models.AclRuleState.objects.create(snapshot=snapshot, device=device_state.device, **row)

                device_state.parse_status = models.StageStatusChoices.SUCCESS
                device_state.parsed_at = timezone.now()
                device_state.save(update_fields=["parse_status", "parsed_at"])
            except Exception as exc:  # pylint: disable=broad-exception-caught
                device_state.parse_status = models.StageStatusChoices.FAILED
                device_state.error_detail = str(exc)
                device_state.save(update_fields=["parse_status", "error_detail"])
                snapshot.status = models.SnapshotStatusChoices.FAILED
                snapshot.error_summary = (
                    f"Normalization failed on {device_state.device.name if device_state.device else 'unbound'}: {exc}"
                )
                snapshot.save(update_fields=["status", "error_summary"])
                raise

        snapshot.status = models.SnapshotStatusChoices.BUILDING
        snapshot.save(update_fields=["status"])
        BuildTwinJob().run(snapshot=snapshot)
        return snapshot.pk


class BuildTwinJob(Job):
    """Build graph/index tables used by reachability."""

    snapshot = ObjectVar(model=models.TwinSnapshot)

    class Meta:
        name = "Build Twin"
        description = "Build derived graph nodes/edges and mark snapshot READY."

    @transaction.atomic
    def run(self, snapshot):
        snapshot.status = models.SnapshotStatusChoices.BUILDING
        snapshot.save(update_fields=["status"])

        models.TwinGraphNode.objects.filter(snapshot=snapshot).delete()
        models.TwinGraphEdge.objects.filter(snapshot=snapshot).delete()

        node_cache = {}

        def ensure_node(ip_value, node_type="ENDPOINT"):
            key = (str(ip_value), node_type)
            if key not in node_cache:
                node_cache[key], _ = models.TwinGraphNode.objects.get_or_create(
                    snapshot=snapshot,
                    ip=str(ip_value),
                    node_type=node_type,
                    defaults={"ref": {}},
                )
            return node_cache[key]

        for route in models.RoutingTableEntryState.objects.filter(snapshot=snapshot):
            try:
                route_node = ensure_node(route.next_hop or "0.0.0.0", "NEXT_HOP")  # noqa: S104
                prefix_node = ensure_node(route.prefix.split("/")[0], "PREFIX")
                models.TwinGraphEdge.objects.get_or_create(
                    snapshot=snapshot,
                    src_node=route_node,
                    dst_node=prefix_node,
                    relation="ROUTES_TO",
                    defaults={"attrs_json": {"prefix": route.prefix, "protocol": route.protocol}},
                )
            except ValueError:
                continue

        for lb in models.LoadBalancerState.objects.filter(snapshot=snapshot):
            vip_node = ensure_node(lb.vip, "VIP")
            for member in sorted(lb.members):
                try:
                    member_node = ensure_node(member, "POOL_MEMBER")
                except ValueError:
                    continue
                models.TwinGraphEdge.objects.get_or_create(
                    snapshot=snapshot,
                    src_node=vip_node,
                    dst_node=member_node,
                    relation="LB_TO_MEMBER",
                    defaults={"attrs_json": {"pool": lb.pool, "snat": lb.snat, "has_irules": lb.has_irules}},
                )

        for device_state in snapshot.device_states.all():
            device_state.build_status = models.StageStatusChoices.SUCCESS
            device_state.built_at = timezone.now()
            device_state.save(update_fields=["build_status", "built_at"])

        snapshot.status = models.SnapshotStatusChoices.READY
        snapshot.save(update_fields=["status"])
        return snapshot.pk


class ReachabilityQueryJob(Job):
    """Optional convenience job to execute reachability queries."""

    snapshot = ObjectVar(model=models.TwinSnapshot)
    src = StringVar(description="Source IP")
    dst_csv = StringVar(description="Comma-separated destination IPs")
    protocol = ChoiceVar(choices=(("tcp", "tcp"), ("udp", "udp")), default="tcp")
    port = IntegerVar(default=443, min_value=1, max_value=65535)
    mode = ChoiceVar(
        choices=models.ReachabilityModeChoices.choices, default=models.ReachabilityModeChoices.ENFORCE_SECURITY
    )

    class Meta:
        name = "Reachability Query"
        description = "Execute snapshot-scoped reachability for multiple explicit destinations."

    def run(
        self, snapshot, src, dst_csv, protocol="tcp", port=443, mode=models.ReachabilityModeChoices.ENFORCE_SECURITY
    ):
        destinations = [value.strip() for value in dst_csv.split(",") if value.strip()]
        payload = check_reachability_many(
            snapshot=snapshot,
            src=src,
            destinations=destinations,
            protocol=protocol,
            port=port,
            mode=mode,
            include_explanation=True,
            max_paths=1,
        )
        self.logger.info("Reachability summary: %s", payload["summary"])
        return payload


register_jobs(CollectSnapshotJob, NormalizeSnapshotJob, BuildTwinJob, ReachabilityQueryJob)
