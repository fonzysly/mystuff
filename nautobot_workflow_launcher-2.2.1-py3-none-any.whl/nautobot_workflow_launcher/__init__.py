"""App declaration for nautobot_workflow_launcher."""

# Metadata is inherited from Nautobot. If not including Nautobot in the environment, this should be added
import os
from importlib import metadata

from nautobot.apps import NautobotAppConfig

__version__ = metadata.version(__name__)


class WorkflowLauncherConfig(NautobotAppConfig):
    """App configuration for the nautobot_workflow_launcher app."""

    name = "nautobot_workflow_launcher"
    verbose_name = "Workflow Launcher"
    version = __version__
    author = "Eric Fetty"
    description = "General-purpose workflow launcher for Nautobot"
    base_url = "workflow-launcher"
    required_settings = []
    default_settings = {
        "awx_external_integration_name": "AWX",
        "workflow_dir": "workflows",
        "awx_poll_seconds": 5,
        "show_disabled": False,
        "show_add_new_item": os.getenv("SHOW_ADD_NEW_ITEM", "").split(","),
    }
    caching_config = {}
    docs_view_name = "plugins:nautobot_workflow_launcher:docs"
    searchable_models = ["workflow"]


config = WorkflowLauncherConfig  # pylint:disable=invalid-name
