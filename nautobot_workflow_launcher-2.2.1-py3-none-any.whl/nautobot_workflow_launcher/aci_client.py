"""All interactions with ACI."""  # pylint: disable=too-many-lines, too-many-instance-attributes, too-many-arguments

# pylint: disable=invalid-name
import base64
import json
import logging
import re
import sys
from copy import deepcopy
from datetime import datetime, timedelta
from ipaddress import ip_network

import requests
import urllib3
import yaml
from cryptography.hazmat.backends import default_backend

# For using private_key to authenticate
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger(__name__)


class VLANObject:
    vlan: int
    tenant: str
    ap: str
    epg: str
    bd: str
    mode: str

    def __init__(self):
        self.vlan = 0
        self.tenant = ""
        self.ap = ""
        self.epg = ""
        self.bd = ""
        self.mode = ""

    def __str__(self):
        return f'{{"vlan": {self.vlan}, "tenant": "{self.tenant}", "ap": "{self.ap}", "epg": "{self.epg}", "bd": "{self.bd}", "mode": "{self.mode}"}}'


class MemberObject:
    hostname: str
    interfaces: list

    def __init__(self):
        self.interfaces = []
        self.hostname = ""

    def __str__(self):
        return f'{{"hostname": "{self.hostname}", "interfaces": {self.interfaces}}}'


class InterfaceObject:
    name: str

    vlans: list
    type: str
    members: list
    node_id: int
    # mode: str

    def __init__(self):
        self.name = ""
        self.vlans = []
        self.type = ""
        self.members = []
        self.node_id = 0
        # self.mode = ""

    def __str__(self):
        return f'{{"name": "{self.name}", "node_id": {self.node_id}, "vlans": {[str(x) for x in self.vlans]}, "type": "{self.type}", "members": {[str(x) for x in self.members]}}})'


class AciApi:
    """Representation and methods for interacting with aci."""

    def __init__(
        self,
        username,
        password,
        base_uri,
        verify,
        debug=False,
        private_key=None,
        #        stage,
    ):
        """Initialization of aci class."""
        self.username = username
        self.password = password
        self.base_uri = base_uri
        self.verify = verify

        self.cookies = ""
        self.last_login = None
        self.refresh_timeout = None
        self.debug = debug

        self.ig_map = None
        self.phys_map = None
        self.bd_map = None
        self.cdp_map = None
        self.lldp_map = None

        if private_key:
            private_key_bytes = private_key.encode("utf-8")
            self.private_key = serialization.load_pem_private_key(private_key_bytes, None, default_backend())
        else:
            self.private_key = None

    def _login(self):
        """Method to log into the ACI fabric and retrieve the token."""
        payload = {"aaaUser": {"attributes": {"name": self.username, "pwd": self.password}}}

        url = self.base_uri + "/api/aaaLogin.json"
        resp = self._handle_request(url, request_type="post", data=payload)
        if resp.ok:
            self.cookies = resp.cookies
            self.last_login = datetime.now()
            self.refresh_timeout = int(resp.json()["imdata"][0]["aaaLogin"]["attributes"]["refreshTimeoutSeconds"])
        return resp

    def _sign_request(self, method: str, url: str, payload: dict):
        """Generate signature for APIC request"""
        if not payload:
            payload_str = ""
        else:
            payload_str = json.dumps(payload)

        # Clean up URL by removing double slashes and trailing question mark
        uri = url.replace(self.base_uri, "")
        if uri.endswith("?"):
            uri = uri[:-1]
        uri = uri.replace("//", "/")

        # Create signature request string
        sig_request = f"{method.upper()}{uri}{payload_str}"

        # Sign the request
        sig_signature = self.private_key.sign(sig_request.encode(), padding.PKCS1v15(), hashes.SHA256())

        # Create cookie with signature
        sig_dn = f"uni/userext/user-{self.username}/usercert-{self.username}"
        self.cookies = {
            "APIC-Request-Signature": base64.b64encode(sig_signature).decode(),
            "APIC-Certificate-Algorithm": "v1.0",
            "APIC-Certificate-DN": sig_dn,
            "APIC-Certificate-Fingerprint": "fingerprint",
        }

    def _handle_request(
        self,
        url: str,
        params: dict = None,
        request_type: str = "get",
        data: dict = None,
    ) -> object:
        """Send a REST API call to the APIC."""
        try:
            if self.private_key:
                self._sign_request(method=request_type, url=url, payload=data)

            resp = requests.request(
                method=request_type,
                url=url,
                cookies=self.cookies,
                params=params,
                verify=self.verify,
                json=data,
                timeout=30,
            )

        except requests.exceptions.RequestException as error:
            raise Exception(f"Error occurred communicating with {self.base_uri}:\n{error}") from error
        return resp

    def _refresh_token(self):
        """Private method to check if the login token needs refreshed. Returns True if login needs refresh."""
        if self.private_key:
            return False
        if not self.last_login:
            return True
        # if time diff b/w now and last login greater than refresh_timeout then refresh login
        if datetime.now() - self.last_login > timedelta(seconds=self.refresh_timeout):
            return True
        return False

    def _handle_error(self, response: object):
        """Private method to handle HTTP errors."""
        calling_func = sys._getframe().f_back.f_code.co_name  # pylint: disable=protected-access
        raise Exception(
            f"There was an HTTP error while performing the {calling_func} operation on {self.base_uri}:\n"
            f"Error: {response.status_code}, Reason: {response.reason}"
        )

    def _get(self, uri: str, params: dict = None) -> object:
        """Method to retrieve data from the ACI fabric."""
        url = self.base_uri + uri
        if self._refresh_token():
            login_resp = self._login()
            if login_resp.ok:
                resp = self._handle_request(url, params)
                if resp.ok:
                    return resp
                return self._handle_error(resp)
            return self._handle_error(login_resp)
        resp = self._handle_request(url, params)
        if resp.ok:
            return resp
        return self._handle_error(resp)

    def _post(self, uri: str, params: dict = None, data=None) -> object:
        """Method to post data to the ACI fabric."""
        url = self.base_uri + uri
        if self._refresh_token():
            login_resp = self._login()
            if login_resp.ok:
                resp = self._handle_request(url, params, request_type="post", data=data)
                if resp.ok:
                    return resp
                return self._handle_error(resp)
            return self._handle_error(login_resp)
        resp = self._handle_request(url, params, request_type="post", data=data)
        if resp.ok:
            return resp
        return self._handle_error(resp)

    def get_tenants(self) -> list:
        """Retrieve the list of tenants from the ACI fabric."""
        resp = self._get("/api/node/class/fvTenant.json")
        tenant_list = [
            {
                "name": data["fvTenant"]["attributes"]["name"],
                "description": data["fvTenant"]["attributes"]["descr"],
                "annotation": data["fvTenant"]["attributes"].get("annotation", ""),
            }
            for data in resp.json()["imdata"]
        ]
        return tenant_list

    def get_l3outs(self, tenant: str) -> list:
        """Return L3Outs from the Cisco APIC."""
        if tenant == "all":
            resp = self._get("/api/node/class/l3extOut.json")
        else:
            resp = self._get(f"/api/node/mo/uni/tn-{tenant}.json?query-target=children&target-subtree-class=l3extOut")

        l3out_list = [data["l3extOut"]["attributes"]["name"] for data in resp.json()["imdata"]]
        return l3out_list

    def get_physical_domains(self) -> list:
        """Return Physical Domains from the Cisco APIC."""
        resp = self._get("/api/node/class/physDomP.json")
        pd_list = [data["physDomP"]["attributes"]["name"] for data in resp.json()["imdata"]]
        return pd_list

    def get_aps(self, tenant: str) -> list:
        """Return Application Profiles from the Cisco APIC."""
        if tenant == "all":
            resp = self._get("/api/node/class/fvAp.json")
        else:
            resp = self._get(f"/api/node/mo/uni/tn-{tenant}.json?query-target=children&target-subtree-class=fvAp")

        ap_list = [
            {
                "tenant": tenant_from_dn(data["fvAp"]["attributes"]["dn"]),
                "ap": data["fvAp"]["attributes"]["name"],
            }
            for data in resp.json()["imdata"]
        ]
        return ap_list

    def get_epgs(self, tenant: str, ap: str) -> list:
        """Return EPGs configured in the Cisco APIC."""
        if ap == "all":
            resp = self._get("/api/node/class/fvAEPg.json")
        else:
            resp = self._get(
                f"/api/node/mo/uni/tn-{tenant}/ap-{ap}.json?query-target=children&target-subtree-class=fvAEPg"
            )

        if tenant == "all":
            epg_list = [
                {
                    "tenant": tenant_from_dn(data["fvAEPg"]["attributes"]["dn"]),
                    "ap": ap_from_dn(data["fvAEPg"]["attributes"]["dn"]),
                    "epg": data["fvAEPg"]["attributes"]["name"],
                }
                for data in resp.json()["imdata"]
            ]
        else:
            epg_list = [
                {
                    "tenant": tenant_from_dn(data["fvAEPg"]["attributes"]["dn"]),
                    "ap": ap_from_dn(data["fvAEPg"]["attributes"]["dn"]),
                    "epg": data["fvAEPg"]["attributes"]["name"],
                }
                for data in resp.json()["imdata"]
                if tenant_from_dn(data["fvAEPg"]["attributes"]["dn"]) == tenant
            ]

        return epg_list

    def get_bd_subnet(self, tenant: str, bd: str) -> list:
        """Returns the subnet(s) of a BD, or None."""
        resp = self._get(
            f"/api/node/mo/uni/tn-{tenant}/BD-{bd}.json?query-target=children&target-subtree-class=fvSubnet"
        )
        if int(resp.json()["totalCount"]) > 0:
            subnet_list = [data["fvSubnet"]["attributes"]["ip"] for data in resp.json()["imdata"]]
            return subnet_list
        return None

    def _hostname(self, fqdn):
        return fqdn.split(".")[0]

    def get_cdp_neighbors(self, pod: int, node_id: int, interface: str) -> dict:
        """Return CDP neighbors for a specified interface."""
        interface = interface.replace("Ethernet", "eth")
        if not self.cdp_map:
            self.cdp_map = self._get("/api/class/cdpAdjEp.json").json()
        neighbors = [
            {
                "remote_device": x["cdpAdjEp"]["attributes"]["devId"].split(".")[0],
                "remote_interface": x["cdpAdjEp"]["attributes"]["portId"],
            }
            for x in self.cdp_map["imdata"]
            if f"topology/pod-{pod}/node-{node_id}/sys/cdp/inst/if-[{interface}]/" in x["cdpAdjEp"]["attributes"]["dn"]
        ]
        return neighbors

    def get_lldp_neighbors(self, pod: int, node_id: int, interface: str) -> dict:
        """Return LLDP neighbors for a specified interface."""
        interface = interface.replace("Ethernet", "eth")
        if not self.lldp_map:
            self.lldp_map = self._get("/api/class/lldpAdjEp.json").json()
        neighbors = [
            {
                "remote_device": x["lldpAdjEp"]["attributes"]["sysName"].split(".")[0],
                "remote_interface": x["lldpAdjEp"]["attributes"]["portIdV"],
            }
            for x in self.lldp_map["imdata"]
            if f"topology/pod-{pod}/node-{node_id}/sys/lldp/inst/if-[{interface}]/"
            in x["lldpAdjEp"]["attributes"]["dn"]
        ]
        return neighbors

    def get_contract_filters(self, tenant, contract_name: str) -> list:
        """Returns filters for a specified contract."""
        resp = self._get(
            f"/api/node/mo/uni/tn-{tenant}/brc-{contract_name}.json?query-target=subtree&target-subtree-class=vzSubj"
        )
        subj_list = [subj_dn["vzSubj"]["attributes"]["dn"] for subj_dn in resp.json()["imdata"]]
        filter_list = []
        for dn in subj_list:
            subj_resp = self._get(f"/api/node/mo/{dn}.json?query-target=subtree&target-subtree-class=vzRsSubjFiltAtt")
            for fltr in subj_resp.json()["imdata"]:
                fltr_dn = fltr["vzRsSubjFiltAtt"]["attributes"]["tDn"]
                entry_resp = self._get(f"/api/node/mo/{fltr_dn}.json?query-target=subtree&target-subtree-class=vzEntry")
                for entry in entry_resp.json()["imdata"]:
                    fltr_dict = {}
                    fltr_dict["name"] = entry["vzEntry"]["attributes"]["name"]
                    fltr_dict["dstport"] = entry["vzEntry"]["attributes"]["dToPort"]
                    fltr_dict["etype"] = entry["vzEntry"]["attributes"]["etherT"]
                    fltr_dict["prot"] = entry["vzEntry"]["attributes"]["prot"]
                    fltr_dict["action"] = fltr["vzRsSubjFiltAtt"]["attributes"]["action"]
                    filter_list.append(fltr_dict)
        return filter_list

    def get_bgp_asn(self):
        resp = self._get(
            "/api/node/mo/uni/fabric/bgpInstP-default.json?query-target=children&target-subtree-class=bgpAsP"
        ).json()
        asn = resp["imdata"][0]["bgpAsP"]["attributes"]["asn"]
        return int(asn)

    def get_bgp_peers(self):
        resp = self._get("/api/class/bgpAsP.json").json()
        peers = []
        for peer in resp["imdata"]:
            address = re.search(
                r"\/peerP-\[([\d\.]+)\]",
                peer["bgpAsP"]["attributes"]["dn"],
            ).group(1)
            data = {
                "asn": peer["bgpAsP"]["attributes"]["asn"],
                "address": address,
            }
            peers.append(data)
        return peers

    def get_epg_bd_mapping(self, tenant: str, ap: str, epg: str) -> str:
        """Return the BD associated with an EPG."""
        if not self.bd_map:
            self.bd_map = self._get("/api/class/fvRsBd.json").json()

        matches = [
            x["fvRsBd"]["attributes"]["tnFvBDName"]
            for x in self.bd_map["imdata"]
            if f"uni/tn-{tenant}/ap-{ap}/epg-{epg}/rsbd" == x["fvRsBd"]["attributes"]["dn"]
        ]

        bd = matches[0]
        return bd

    def get_phys_ports(self, ig_name):
        """Return the physical ports associated with an Interface Group."""
        ports = []
        if not self.ig_map:
            self.ig_map = self._get("/api/class/infraRtAccBaseGrp.json").json()
        if not self.phys_map:
            self.phys_map = self._get("/api/class/infraPortBlk.json").json()
        ig_matches = [
            x["infraRtAccBaseGrp"]["attributes"]["tDn"]
            for x in self.ig_map["imdata"]
            if f"accbundle-{ig_name}" in x["infraRtAccBaseGrp"]["attributes"]["dn"]
        ]
        if ig_matches:
            for match in ig_matches:
                hostname = re.search(
                    r"\/accportprof-(\w+)/",
                    match,
                ).group(1)
                for port in ports:
                    if port.hostname == hostname:
                        member = port
                        break
                else:
                    member = MemberObject()
                    member.hostname = hostname
                    ports.append(member)

                phys_matches = [x for x in self.phys_map["imdata"] if match in x["infraPortBlk"]["attributes"]["dn"]]
                for phys_match in phys_matches:
                    phys_port = f"Ethernet{phys_match['infraPortBlk']['attributes']['fromCard']}/{phys_match['infraPortBlk']['attributes']['fromPort']}"

                    member.interfaces.append(phys_port)

        return ports

    def get_static_path(self) -> list:
        """Return static path mapping."""
        resp = self._get("/api/class/fvRsPathAtt.json")

        sp_list = []
        for obj in resp.json()["imdata"]:
            tDn = obj["fvRsPathAtt"]["attributes"]["tDn"]
            dn = obj["fvRsPathAtt"]["attributes"]["dn"]

            vid = obj["fvRsPathAtt"]["attributes"]["encap"].replace("vlan-", "")
            vlan = VLANObject()
            vlan.vlan = int(vid)
            vlan.tenant = tenant_from_dn(dn)
            vlan.ap = ap_from_dn(dn)
            vlan.epg = epg_from_dn(dn)
            vlan.bd = self.get_epg_bd_mapping(vlan.tenant, vlan.ap, vlan.epg)

            if "paths" in tDn and "protpaths" not in tDn:
                node_id = int(node_from_path_dn(tDn))
                iface = iface_from_dn(tDn).replace("eth", "Ethernet")
                if "Ethernet" not in iface:
                    iface = "Ethernet" + iface
                matches = [x for x in sp_list if x.name == iface and x.node_id == node_id]
                if matches:
                    if vlan not in matches[0].vlans:
                        vlan.mode = obj["fvRsPathAtt"]["attributes"]["mode"].replace("native", "untagged")
                        matches[0].vlans.append(vlan)
                    continue
                # port on a single node
                iface_obj = InterfaceObject()
                iface_obj.name = iface
                iface_obj.type = "non-PC"
                iface_obj.node_id = int(node_from_path_dn(dn))
                vlan.mode = obj["fvRsPathAtt"]["attributes"]["mode"].replace("native", "untagged")
                iface_obj.vlans.append(vlan)
                iface_obj.vlans = list(set(iface_obj.vlans))
                # iface_obj.mode = obj["fvRsPathAtt"]["attributes"]["mode"]
                sp_list.append(iface_obj)
                continue

            if "protpaths" in tDn:
                lag_name = iface_from_dn(dn)

                if sp_list:
                    matches = [x for x in sp_list if x.name == lag_name]
                    if matches:
                        vlan.mode = obj["fvRsPathAtt"]["attributes"]["mode"].replace("native", "untagged")
                        matches[0].vlans.append(vlan)
                        continue
                iface_obj = InterfaceObject()
                iface_obj.name = lag_name
                vlan.mode = obj["fvRsPathAtt"]["attributes"]["mode"].replace("native", "untagged")
                iface_obj.vlans.append(vlan)
                iface_obj.vlans = list(set(iface_obj.vlans))
                members = self.get_phys_ports(lag_name)

                if len(members) == 1:
                    iface_obj.type = "PC"
                else:
                    iface_obj.type = "vPC"

                iface_obj.members.extend(members)
                sp_list.append(iface_obj)

        return sp_list

    def get_vrfs(self, tenant: str) -> list:
        """Retrieve a list of VRFs in the Cisco APIC."""
        if tenant == "all":
            resp = self._get("/api/node/class/fvCtx.json")
        else:
            resp = self._get(f"/api/node/mo/uni/tn-{tenant}.json?query-target=children&target-subtree-class=fvCtx")
        vrf_list = [
            {
                "name": data["fvCtx"]["attributes"]["name"],
                "tenant": tenant_from_dn(data["fvCtx"]["attributes"]["dn"]),
            }
            for data in resp.json()["imdata"]
        ]
        return vrf_list

    def get_bds(self, tenant: str = "all") -> dict:
        """Return Bridge Domains and Subnets from the Cisco APIC."""
        # TODO: rewrite using one API call -> https://<ip>/api/node/class/fvBD.json?query-target=subtree&target-subtree-class=fvBD,fvRsCtx,fvSubnet
        if tenant == "all":
            resp = self._get(
                "/api/node/class/fvBD.json?query-target=subtree&target-subtree-class=fvBD,fvRsCtx,fvSubnet"
            )
        else:
            resp = self._get(
                f"/api/node/mo/uni/tn-{tenant}.json?query-target=children&target-subtree-class=fvBD"
            )  # test this
        bd_dict = {}
        bd_dict_schema = {
            "name": "",
            "tenant": "",
            "description": "",
            "vrf": None,
            "vrf_tenant": None,
            "subnets": [],
        }
        for data in resp.json()["imdata"]:
            if "fvBD" in data.keys():
                bd_tenant = tenant_from_dn(data["fvBD"]["attributes"]["dn"])
                bd_name = data["fvBD"]["attributes"]["name"]
                unique_name = f"{bd_name}:{bd_tenant}"
                try:
                    bd_dict[unique_name]
                except KeyError:
                    bd_dict.setdefault(unique_name, deepcopy(bd_dict_schema))
                bd_dict[unique_name]["tenant"] = tenant_from_dn(data["fvBD"]["attributes"]["dn"])
                bd_dict[unique_name]["name"] = data["fvBD"]["attributes"]["name"]
                bd_dict[unique_name]["description"] = data["fvBD"]["attributes"]["descr"]

            elif "fvRsCtx" in data.keys():
                bd_tenant = tenant_from_dn(data["fvRsCtx"]["attributes"]["dn"])
                bd_name = bd_from_dn(data["fvRsCtx"]["attributes"]["dn"])
                unique_name = f"{bd_name}:{bd_tenant}"
                try:
                    bd_dict[unique_name]
                except KeyError:
                    bd_dict.setdefault(unique_name, deepcopy(bd_dict_schema))
                bd_dict[unique_name]["vrf"] = data["fvRsCtx"]["attributes"].get("tnFvCtxName") or "default"
                vrf_tenant = data["fvRsCtx"]["attributes"].get("tDn")
                if vrf_tenant:
                    bd_dict[unique_name]["vrf_tenant"] = tenant_from_dn(vrf_tenant)

            elif "fvSubnet" in data.keys():
                bd_tenant = tenant_from_dn(data["fvSubnet"]["attributes"]["dn"])
                bd_name = bd_from_dn(data["fvSubnet"]["attributes"]["dn"])
                unique_name = f"{bd_name}:{bd_tenant}"
                try:
                    bd_dict[unique_name]
                except KeyError:
                    bd_dict.setdefault(unique_name, deepcopy(bd_dict_schema))
                subnet = (
                    data["fvSubnet"]["attributes"]["ip"],
                    data["fvSubnet"]["attributes"]["scope"],
                )
                (bd_dict[unique_name]["subnets"]).append(subnet)
            else:
                logger.error(
                    msg=f"Failed to load Bridge Domains data, unexpected response in {data}. Skipping Record..."
                )
                continue
        return bd_dict

    def get_nodes(self) -> dict:
        """Return list of Leaf/Spine/FEXes nodes in the ACI fabric."""
        resp = self._get('/api/class/fabricNode.json?query-target-filter=ne(fabricNode.role,"controller")')
        node_dict = {}
        for node in resp.json()["imdata"]:
            if node["fabricNode"]["attributes"]["fabricSt"] == "active":
                node_id = node["fabricNode"]["attributes"]["id"]
                node_dict[node_id] = {}
                node_dict[node_id]["name"] = node["fabricNode"]["attributes"]["name"]
                node_dict[node_id]["model"] = node["fabricNode"]["attributes"]["model"]
                node_dict[node_id]["role"] = node["fabricNode"]["attributes"]["role"]
                node_dict[node_id]["serial"] = node["fabricNode"]["attributes"]["serial"]
                node_dict[node_id]["fabric_ip"] = node["fabricNode"]["attributes"]["address"]
                node_dict[node_id]["pod_id"] = pod_from_dn(node["fabricNode"]["attributes"]["dn"])
        resp = self._get('/api/class/topSystem.json?query-target-filter=ne(topSystem.role,"controller")')

        for node in resp.json()["imdata"]:
            if node["topSystem"]["attributes"]["oobMgmtAddr"] != "0.0.0.0":  # noqa: S104
                mgmt_addr = f"{node['topSystem']['attributes']['oobMgmtAddr']}/{node['topSystem']['attributes']['oobMgmtAddrMask']}"
            elif (
                node["topSystem"]["attributes"]["address"] != "0.0.0.0"  # noqa: S104
                and node["topSystem"]["attributes"]["tepPool"]
            ):
                mgmt_addr = f"{node['topSystem']['attributes']['address']}/{ip_network(node['topSystem']['attributes']['tepPool'], strict=False).prefixlen}"
            else:
                mgmt_addr = ""
            if mgmt_addr:
                subnet = ip_network(mgmt_addr, strict=False).with_prefixlen
            elif node["topSystem"]["attributes"]["tepPool"] != "0.0.0.0":  # noqa: S104
                subnet = node["topSystem"]["attributes"]["tepPool"]
            else:
                subnet = ""
            node_id = node["topSystem"]["attributes"]["id"]
            node_dict[node_id]["oob_ip"] = mgmt_addr
            node_dict[node_id]["subnet"] = subnet
            node_dict[node_id]["uptime"] = node["topSystem"]["attributes"]["systemUpTime"]

        resp = self._get("/api/node/class/eqptExtCh.json")

        for fex in resp.json()["imdata"]:
            parent_node_id = node_from_dn(fex["eqptExtCh"]["attributes"]["dn"])
            fex_id = fex["eqptExtCh"]["attributes"]["id"]
            node_id = f"{parent_node_id}{fex_id}"
            node_dict[node_id] = {}
            node_dict[node_id]["name"] = node_dict[parent_node_id]["name"] + "-" + fex["eqptExtCh"]["attributes"]["id"]
            node_dict[node_id]["model"] = fex["eqptExtCh"]["attributes"]["model"]
            node_dict[node_id]["role"] = "fex"
            node_dict[node_id]["serial"] = fex["eqptExtCh"]["attributes"]["ser"]
            node_dict[node_id]["descr"] = fex["eqptExtCh"]["attributes"]["descr"]
            node_dict[node_id]["parent_id"] = parent_node_id
            node_dict[node_id]["fex_id"] = fex["eqptExtCh"]["attributes"]["id"]
            node_dict[node_id]["pod_id"] = pod_from_dn(fex["eqptExtCh"]["attributes"]["dn"])
            # node_dict[node_id]["site"] = self.site
        return node_dict

    def get_controllers(self) -> dict:
        """Return list of Controller nodes in the ACI fabric."""
        resp = self._get('/api/class/fabricNode.json?query-target-filter=eq(fabricNode.role,"controller")')
        node_dict = {}
        for node in resp.json()["imdata"]:
            node_id = node["fabricNode"]["attributes"]["id"]
            node_dict[node_id] = {}
            node_dict[node_id]["name"] = node["fabricNode"]["attributes"]["name"]
            node_dict[node_id]["model"] = node["fabricNode"]["attributes"]["model"] or "APIC-SIM"
            node_dict[node_id]["role"] = node["fabricNode"]["attributes"]["role"]
            node_dict[node_id]["serial"] = node["fabricNode"]["attributes"]["serial"]
            node_dict[node_id]["fabric_ip"] = node["fabricNode"]["attributes"]["address"]
            # node_dict[node_id]["site"] = self.site
        resp = self._get('/api/class/topSystem.json?query-target-filter=eq(topSystem.role,"controller")')
        for node in resp.json()["imdata"]:
            if node["topSystem"]["attributes"]["oobMgmtAddr"] != "0.0.0.0":  # noqa: S104
                mgmt_addr = f"{node['topSystem']['attributes']['oobMgmtAddr']}/{node['topSystem']['attributes']['oobMgmtAddrMask']}"
            elif (
                node["topSystem"]["attributes"]["address"] != "0.0.0.0"  # noqa: S104
                and node["topSystem"]["attributes"]["tepPool"]
            ):
                mgmt_addr = f"{node['topSystem']['attributes']['address']}/{ip_network(node['topSystem']['attributes']['tepPool'], strict=False).prefixlen}"
            else:
                mgmt_addr = ""
            if mgmt_addr:
                subnet = ip_network(mgmt_addr, strict=False).with_prefixlen
            elif node["topSystem"]["attributes"]["tepPool"] != "0.0.0.0":  # noqa: S104
                subnet = node["topSystem"]["attributes"]["tepPool"]
            else:
                subnet = ""
            node_id = node["topSystem"]["attributes"]["id"]
            node_dict[node_id]["pod_id"] = node["topSystem"]["attributes"]["podId"]
            node_dict[node_id]["oob_ip"] = mgmt_addr
            node_dict[node_id]["subnet"] = subnet
            node_dict[node_id]["uptime"] = node["topSystem"]["attributes"]["systemUpTime"]
        return node_dict

    def get_pending_nodes(self) -> dict:
        """Return list of Leaf/Spine nodes which are pending registration."""
        resp = self._get(
            "/api/node/class/dhcpClient.json?query-target-filter"
            '=and(not(wcard(dhcpClient.dn,"__ui_")),and(or(eq(dhcpClient.ip,"0.0.0.0")),'
            'or(eq(dhcpClient.nodeRole,"spine"),eq(dhcpClient.nodeRole,"leaf"),eq(dhcpClient.nodeRole,"unsupported"))))'
        )

        node_dict = {}
        for node in resp.json()["imdata"]:
            sn = node["dhcpClient"]["attributes"]["id"]
            node_dict[sn] = {}
            node_dict[sn]["fabric_id"] = node["dhcpClient"]["attributes"]["fabricId"]
            node_dict[sn]["node_id"] = node["dhcpClient"]["attributes"]["nodeId"]
            node_dict[sn]["model"] = node["dhcpClient"]["attributes"]["model"]
            node_dict[sn]["role"] = node["dhcpClient"]["attributes"]["nodeRole"]
            node_dict[sn]["supported"] = node["dhcpClient"]["attributes"]["supported"]
        return node_dict

    def get_interfaces(self, nodes):
        """Get interfaces on a specified leaf with filtering by up/down state."""
        resp = self._get(
            "/api/node/class/l1PhysIf.json?rsp-subtree=full&rsp-subtree-class=ethpmPhysIf,ethpmFcot&order-by=l1PhysIf.id"
        )
        intf_dict = {}
        for item in nodes:
            intf_dict[item] = {}

        for intf in resp.json()["imdata"]:
            if int(fex_id_from_dn(intf["l1PhysIf"]["attributes"]["dn"])) < 100:
                switch_id = node_from_dn(intf["l1PhysIf"]["attributes"]["dn"])
            else:
                switch_id = node_from_dn(intf["l1PhysIf"]["attributes"]["dn"]) + fex_id_from_dn(
                    intf["l1PhysIf"]["attributes"]["dn"]
                )
            port_name = interface_from_dn(intf["l1PhysIf"]["attributes"]["dn"])
            if "children" in intf["l1PhysIf"]:
                intf_dict[switch_id][port_name] = {}
                intf_dict[switch_id][port_name]["admin"] = intf["l1PhysIf"]["attributes"]["adminSt"]
                intf_dict[switch_id][port_name]["mtu"] = intf["l1PhysIf"]["attributes"]["mtu"]
                intf_dict[switch_id][port_name]["descr"] = intf["l1PhysIf"]["attributes"]["descr"]
                intf_dict[switch_id][port_name]["speed"] = intf["l1PhysIf"]["attributes"]["speed"]
                intf_dict[switch_id][port_name]["bw"] = intf["l1PhysIf"]["attributes"]["bw"]
                intf_dict[switch_id][port_name]["usage"] = intf["l1PhysIf"]["attributes"]["usage"]
                intf_dict[switch_id][port_name]["layer"] = intf["l1PhysIf"]["attributes"]["layer"]
                intf_dict[switch_id][port_name]["mode"] = intf["l1PhysIf"]["attributes"]["mode"]
                intf_dict[switch_id][port_name]["switchingSt"] = intf["l1PhysIf"]["attributes"]["switchingSt"]
                intf_dict[switch_id][port_name]["state"] = intf["l1PhysIf"]["children"][0]["ethpmPhysIf"]["attributes"][
                    "operSt"
                ]
                intf_dict[switch_id][port_name]["state_reason"] = intf["l1PhysIf"]["children"][0]["ethpmPhysIf"][
                    "attributes"
                ]["operStQual"]
                intf_dict[switch_id][port_name]["gbic_sn"] = intf["l1PhysIf"]["children"][0]["ethpmPhysIf"]["children"][
                    0
                ]["ethpmFcot"]["attributes"]["guiSN"]
                intf_dict[switch_id][port_name]["gbic_vendor"] = intf["l1PhysIf"]["children"][0]["ethpmPhysIf"][
                    "children"
                ][0]["ethpmFcot"]["attributes"]["guiName"]
                intf_dict[switch_id][port_name]["gbic_type"] = intf["l1PhysIf"]["children"][0]["ethpmPhysIf"][
                    "children"
                ][0]["ethpmFcot"]["attributes"]["guiPN"]
                if (
                    intf["l1PhysIf"]["children"][0]["ethpmPhysIf"]["children"][0]["ethpmFcot"]["attributes"][
                        "guiCiscoPID"
                    ]
                    != ""
                ):
                    intf_dict[switch_id][port_name]["gbic_model"] = intf["l1PhysIf"]["children"][0]["ethpmPhysIf"][
                        "children"
                    ][0]["ethpmFcot"]["attributes"]["typeName"]
                else:
                    intf_dict[switch_id][port_name]["gbic_model"] = intf["l1PhysIf"]["children"][0]["ethpmPhysIf"][
                        "children"
                    ][0]["ethpmFcot"]["attributes"]["guiCiscoPID"]

        return intf_dict

    def register_node(self, serial_nbr, node_id, name) -> bool:
        """Register a new node to the Cisco APIC."""
        payload = {
            "fabricNodeIdentP": {
                "attributes": {
                    "dn": f"uni/controller/nodeidentpol/nodep-{serial_nbr}",
                    "serial": serial_nbr,
                    "nodeId": node_id,
                    "name": name,
                }
            }
        }
        resp = self._post("/api/node/mo/uni/controller/nodeidentpol.json", data=payload)
        if resp.ok:
            return True
        return self._handle_error(resp)


def pod_from_dn(dn):
    """Match an ACI pod_id in the Distiguished Name (DN)."""
    pattern = r"/pod-(?P<pod>\d+)"
    return (re.search(pattern, dn)).group("pod")


def node_from_path_dn(dn):
    """Match an ACI node_id in the Distiguished Name (DN)."""
    pattern = r"/paths-(?P<node>\d+)"
    return (re.search(pattern, dn)).group("node")


def nodes_from_protpath_dn(dn):
    """Match an ACI node_id in the Distiguished Name (DN)."""
    pattern = r"/protpaths-(?P<node1>\d+)-(?P<node2>\d+)"
    result = re.search(pattern, dn)
    if result:
        ret = (
            result.group("node1"),
            result.group("node2"),
        )
        return ret
    raise Exception(f"Failed to match nodes in {dn}")


def iface_from_dn(dn):
    """Match an ACI interface in the Distiguished Name (DN)."""
    pattern = r"\/pathep-\[(?P<iface>[\w\-\/]+)\]"
    return (re.search(pattern, dn)).group("iface")


def node_from_dn(dn):
    """Match an ACI node_id in the Distiguished Name (DN)."""
    pattern = r"/node-(?P<node>\d+)"
    return (re.search(pattern, dn)).group("node")


def interface_from_dn(dn):
    """Match an ACI port in the Distiguished Name (DN)."""
    pattern = r"phys-.(?P<int>.*)."
    return (re.search(pattern, dn)).group("int")


def fex_id_from_dn(dn):
    """Match an ACI fex_id from port in the Distiguished Name (DN)."""
    pattern = r"phys-.eth(?P<fex>\d*)/.+"
    return (re.search(pattern, dn)).group("fex")


def tenant_from_dn(dn):
    """Match an ACI tenant in the Distiguished Name (DN)."""
    pattern = "tn-(.+?)\/"  # noqa: W605  # pylint: disable=anomalous-backslash-in-string
    return re.search(pattern, dn).group().replace("tn-", "", 1).rstrip("/")


def ap_from_dn(dn):
    """Match an ACI Application Profile in the Distinguished Name (DN)."""
    pattern = "ap-[A-Za-z0-9\-\_]+"  # noqa: W605 # pylint: disable=anomalous-backslash-in-string
    return re.search(pattern, dn).group().replace("ap-", "", 1).rstrip("/")


def bd_from_dn(dn):
    """Match an ACI Bridge Domain in the Distinguished Name (DN)."""
    pattern = "BD-[A-Za-z0-9\-\_]+"  # noqa: W605 # pylint: disable=anomalous-backslash-in-string
    return re.search(pattern, dn).group().replace("BD-", "", 1).rstrip("/")


def epg_from_dn(dn):
    """Match an ACI Endpoint Group in the Distinguished Name (DN)."""
    pattern = "epg-[A-Za-z0-9\-\_]+"  # noqa: W605 # pylint: disable=anomalous-backslash-in-string
    return re.search(pattern, dn).group().replace("epg-", "", 1).rstrip("/")


def load_yamlfile(filename):
    """Load a YAML file to a Dict."""
    with open(filename, "r", encoding="utf-8") as fn:
        yaml_file = yaml.safe_load(fn)
    return yaml_file
