"""Workflow execution engine with IP address filtering capabilities."""

import contextlib
import importlib.util
import io
import ipaddress
import json
import os
import pathlib
import sys
import tempfile
import time
import traceback

import requests
from django.conf import settings
from django.utils import timezone
from jinja2 import Environment
from nautobot.extras.choices import SecretsGroupAccessTypeChoices, SecretsGroupSecretTypeChoices
from nautobot.extras.models import ExternalIntegration, SecretsGroupAssociation
from nautobot.dcim.models import Controller
from .models import AwxRun, WorkflowRun

PLUGIN_CFG = settings.PLUGINS_CONFIG.get("nautobot_workflow_launcher", {})


def _should_show_workflow(workflow):
    """Check if a workflow should be shown based on enabled status and settings."""
    show_disabled = PLUGIN_CFG.get("show_disabled", False)
    return workflow.enabled or show_disabled


def _get_workflow_queryset():
    """Get workflow queryset respecting the show_disabled setting."""
    from .models import Workflow

    show_disabled = PLUGIN_CFG.get("show_disabled", False)
    if show_disabled:
        return Workflow.objects.all()
    else:
        return Workflow.objects.filter(enabled=True)


def _ip_address(value):
    """Convert string to IPv4 or IPv6 address object."""
    try:
        return ipaddress.ip_address(value)
    except ValueError as e:
        raise ValueError(f"Invalid IP address '{value}': {e}")


def _ip_network(value, strict=True):
    """Convert string to IPv4 or IPv6 network object."""
    try:
        return ipaddress.ip_network(value, strict=strict)
    except ValueError as e:
        raise ValueError(f"Invalid IP network '{value}': {e}")


def _ip_interface(value):
    """Convert string to IPv4 or IPv6 interface object."""
    try:
        return ipaddress.ip_interface(value)
    except ValueError as e:
        raise ValueError(f"Invalid IP interface '{value}': {e}")


def _network_address(value):
    """Get network address from IP network or interface."""
    if isinstance(value, str):
        value = _ip_network(value, strict=False)
    elif hasattr(value, "network"):  # interface object
        return value.network.network_address
    return value.network_address


def _broadcast_address(value):
    """Get broadcast address from IP network."""
    if isinstance(value, str):
        value = _ip_network(value, strict=False)
    elif hasattr(value, "network"):  # interface object
        return value.network.broadcast_address
    return value.broadcast_address


def _netmask(value):
    """Get netmask from IP network or interface."""
    if isinstance(value, str):
        value = _ip_network(value, strict=False)
    elif hasattr(value, "network"):  # interface object
        return value.network.netmask
    return value.netmask


def _hostmask(value):
    """Get hostmask from IP network or interface."""
    if isinstance(value, str):
        value = _ip_network(value, strict=False)
    elif hasattr(value, "network"):  # interface object
        return value.network.hostmask
    return value.hostmask


def _prefixlen(value):
    """Get prefix length from IP network or interface."""
    if isinstance(value, str):
        value = _ip_network(value, strict=False)
    elif hasattr(value, "network"):  # interface object
        return value.network.prefixlen
    return value.prefixlen


def _num_addresses(value):
    """Get number of addresses in IP network."""
    if isinstance(value, str):
        value = _ip_network(value, strict=False)
    elif hasattr(value, "network"):  # interface object
        return value.network.num_addresses
    return value.num_addresses


def _subnets(value, prefixlen_diff=1, new_prefix=None):
    """Get subnets from IP network."""
    if isinstance(value, str):
        value = _ip_network(value, strict=False)
    elif hasattr(value, "network"):  # interface object
        value = value.network

    if new_prefix is not None:
        return list(value.subnets(new_prefix=new_prefix))
    else:
        return list(value.subnets(prefixlen_diff=prefixlen_diff))


def _supernet(value, prefixlen_diff=1, new_prefix=None):
    """Get supernet from IP network."""
    if isinstance(value, str):
        value = _ip_network(value, strict=False)
    elif hasattr(value, "network"):  # interface object
        value = value.network

    if new_prefix is not None:
        return value.supernet(new_prefix=new_prefix)
    else:
        return value.supernet(prefixlen_diff=prefixlen_diff)


def _subnet_of(value, other):
    """Check if network is subnet of another network."""
    if isinstance(value, str):
        value = _ip_network(value, strict=False)
    if isinstance(other, str):
        other = _ip_network(other, strict=False)

    if hasattr(value, "network"):  # interface object
        value = value.network
    if hasattr(other, "network"):  # interface object
        other = other.network

    return value.subnet_of(other)


def _supernet_of(value, other):
    """Check if network is supernet of another network."""
    if isinstance(value, str):
        value = _ip_network(value, strict=False)
    if isinstance(other, str):
        other = _ip_network(other, strict=False)

    if hasattr(value, "network"):  # interface object
        value = value.network
    if hasattr(other, "network"):  # interface object
        other = other.network

    return value.supernet_of(other)


def _overlaps(value, other):
    """Check if two networks overlap."""
    if isinstance(value, str):
        value = _ip_network(value, strict=False)
    if isinstance(other, str):
        other = _ip_network(other, strict=False)

    if hasattr(value, "network"):  # interface object
        value = value.network
    if hasattr(other, "network"):  # interface object
        other = other.network

    return value.overlaps(other)


def _address_exclude(value, other):
    """Return networks that are in value but not in other."""
    if isinstance(value, str):
        value = _ip_network(value, strict=False)
    if isinstance(other, str):
        other = _ip_network(other, strict=False)

    if hasattr(value, "network"):  # interface object
        value = value.network
    if hasattr(other, "network"):  # interface object
        other = other.network

    return list(value.address_exclude(other))


def _hosts(value):
    """Get host addresses from IP network."""
    if isinstance(value, str):
        value = _ip_network(value, strict=False)
    elif hasattr(value, "network"):  # interface object
        value = value.network

    return list(value.hosts())


def _ip_in_network(ip_addr, network):
    """Check if IP address is in network."""
    if isinstance(ip_addr, str):
        ip_addr = _ip_address(ip_addr)
    if isinstance(network, str):
        network = _ip_network(network, strict=False)
    elif hasattr(network, "network"):  # interface object
        network = network.network

    return ip_addr in network


def _is_private(value):
    """Check if IP address or network is private."""
    if isinstance(value, str):
        try:
            value = _ip_address(value)
        except ValueError:
            value = _ip_network(value, strict=False)

    if hasattr(value, "network"):  # interface object
        return value.network.is_private

    return value.is_private


def _is_global(value):
    """Check if IP address or network is global."""
    if isinstance(value, str):
        try:
            value = _ip_address(value)
        except ValueError:
            value = _ip_network(value, strict=False)

    if hasattr(value, "network"):  # interface object
        return value.network.is_global

    return value.is_global


def _is_multicast(value):
    """Check if IP address or network is multicast."""
    if isinstance(value, str):
        try:
            value = _ip_address(value)
        except ValueError:
            value = _ip_network(value, strict=False)

    if hasattr(value, "network"):  # interface object
        return value.network.is_multicast

    return value.is_multicast


def _is_reserved(value):
    """Check if IP address or network is reserved."""
    if isinstance(value, str):
        try:
            value = _ip_address(value)
        except ValueError:
            value = _ip_network(value, strict=False)

    if hasattr(value, "network"):  # interface object
        return value.network.is_reserved

    return value.is_reserved


def _ip_version(value):
    """Get IP version (4 or 6) of address or network."""
    if isinstance(value, str):
        try:
            value = _ip_address(value)
        except ValueError:
            value = _ip_network(value, strict=False)

    if hasattr(value, "network"):  # interface object
        return value.network.version

    return value.version


def _available_rack_units(rack, device_type=None):
    """Get available rack units, optionally filtered by device type height."""
    try:
        # Try to import Nautobot models
        try:
            from nautobot.dcim.models import DeviceType, Rack
        except ImportError:
            return []

        # Handle different input types for rack
        rack_obj = None
        if isinstance(rack, str):
            try:
                rack_obj = Rack.objects.get(pk=rack)
            except (Rack.DoesNotExist, ValueError):
                return []
        elif isinstance(rack, dict) and "id" in rack:
            # Handle dictionary format from Jinja context
            try:
                rack_obj = Rack.objects.get(pk=rack["id"])
            except (Rack.DoesNotExist, ValueError):
                return []
        elif hasattr(rack, "get_available_units"):
            rack_obj = rack
        else:
            return []

        # Get available units
        available_units = rack_obj.get_available_units()
        reserved_units = list(rack_obj.get_reserved_units().keys())
        available_units = [x for x in available_units if x not in reserved_units]
        # If device type is specified, filter by height requirements
        if device_type:
            try:
                device_type_obj = None
                # Handle different input types for device_type
                if isinstance(device_type, str):
                    device_type_obj = DeviceType.objects.get(pk=device_type)
                elif isinstance(device_type, dict) and "id" in device_type:
                    # Handle dictionary format from Jinja context
                    device_type_obj = DeviceType.objects.get(pk=device_type["id"])
                elif hasattr(device_type, "u_height"):
                    device_type_obj = device_type
                else:
                    # No valid device type, return all available units
                    return sorted(available_units, reverse=True)

                u_height = device_type_obj.u_height or 1

                # Filter available units to only include positions where the device will fit
                filtered_units = []
                for unit in available_units:
                    # Check if there's enough consecutive space starting from this unit
                    can_fit = True
                    for i in range(u_height):
                        if (unit + i) not in available_units:
                            can_fit = False
                            break
                    if can_fit:
                        filtered_units.append(unit)

                available_units = filtered_units

            except Exception as e:
                # Fall back to showing all available units if device type processing fails
                import logging

                logger = logging.getLogger(__name__)
                logger.warning(f"Error processing device type for rack units: {e}")

        # Return sorted units (top to bottom)
        return sorted(available_units, reverse=True)

    except Exception as e:
        # Return empty list on any error
        import logging

        logger = logging.getLogger(__name__)
        logger.error(f"Error getting available rack units: {e}")
        return []


def _get_aci_api(apic_name):
    """Get AciApi instance for the given APIC controller name."""
    from .aci_client import AciApi

    apic = Controller.objects.get(name=apic_name)
    username = apic.external_integration.secrets_group.get_secret_value(
        access_type=SecretsGroupAccessTypeChoices.TYPE_GENERIC,
        secret_type=SecretsGroupSecretTypeChoices.TYPE_USERNAME,
    )
    try:
        password = apic.external_integration.secrets_group.get_secret_value(
            access_type=SecretsGroupAccessTypeChoices.TYPE_GENERIC,
            secret_type=SecretsGroupSecretTypeChoices.TYPE_PASSWORD,
        )

    except Exception as e:
        password = None
    try:
        private_key = apic.external_integration.secrets_group.get_secret_value(
            access_type=SecretsGroupAccessTypeChoices.TYPE_GENERIC,
            secret_type=SecretsGroupSecretTypeChoices.TYPE_KEY,
        )
    except Exception as e:
        private_key = None

    aci_integration = AciApi(
        username=username,
        password=password,
        private_key=private_key,
        base_uri=apic.external_integration.remote_url,
        verify=apic.external_integration.verify_ssl,
        debug=False,
    )
    return aci_integration


def _aci_domains(apic_name):
    """Get list of ACI Physical Domain names using Nautobot ACI integration."""

    aci_integration = _get_aci_api(apic_name)
    domains = aci_integration.get_physical_domains()
    return domains


def _aci_l3outs(apic_name, tenant_name):
    """Get list of ACI L3Out names for the given tenant using Nautobot ACI integration."""

    aci_integration = _get_aci_api(apic_name)
    l3outs = aci_integration.get_l3outs(tenant_name)
    return l3outs


def _aci_app_profiles(apic_name, tenant_name):
    """Get list of ACI Application Profile names for the given tenant using Nautobot ACI integration."""

    aci_integration = _get_aci_api(apic_name)
    app_profiles = aci_integration.get_aps(tenant_name)
    return [x["ap"] for x in app_profiles]


def _from_json(value):
    """
    Convert a JSON string to a Python data structure.

    Args:
        value: JSON string to parse

    Returns:
        Parsed Python object (dict, list, etc.) or None if parsing fails
    """
    if value is None:
        return None

    if not isinstance(value, str):
        # If already a data structure, return as-is
        return value

    try:
        return json.loads(value)
    except (json.JSONDecodeError, TypeError, ValueError):
        # Return None on parse error to avoid breaking template rendering
        return None


# Create Jinja2 environment with custom IP address filters
_env = Environment(autoescape=False)  # noqa: S701
_env.filters.update(
    {
        "ip_address": _ip_address,
        "ip_network": _ip_network,
        "ip_interface": _ip_interface,
        "network_address": _network_address,
        "broadcast_address": _broadcast_address,
        "netmask": _netmask,
        "hostmask": _hostmask,
        "prefixlen": _prefixlen,
        "num_addresses": _num_addresses,
        "subnets": _subnets,
        "supernet": _supernet,
        "subnet_of": _subnet_of,
        "supernet_of": _supernet_of,
        "overlaps": _overlaps,
        "address_exclude": _address_exclude,
        "hosts": _hosts,
        "ip_in_network": _ip_in_network,
        "is_private": _is_private,
        "is_global": _is_global,
        "is_multicast": _is_multicast,
        "is_reserved": _is_reserved,
        "ip_version": _ip_version,
        "available_rack_units": _available_rack_units,
        "fromjson": _from_json,
        "aci_l3outs": _aci_l3outs,
        "aci_domains": _aci_domains,
        "aci_aps": _aci_app_profiles,
    }
)

_repo_pkg_cache = {}


def _repo_revision_key(repo):
    """Get a revision key for the repository to use in caching."""
    for attr in ("current_head", "head", "commit", "tracked_commit", "last_updated"):
        val = getattr(repo, attr, None)
        if val:
            return str(val)
    return "db"


def clear_repo_script_cache(repo):
    """Clear cached repository packages and Python modules for the given repository."""
    # Clear our package cache
    to_drop = [key for key in _repo_pkg_cache.keys() if key[0] == repo.id]
    cached_dirs = []

    for key in to_drop:
        cached_dir = _repo_pkg_cache.pop(key, None)
        if cached_dir:
            cached_dirs.append(cached_dir)
            # Remove from sys.path if it exists
            if cached_dir in sys.path:
                sys.path.remove(cached_dir)

    # Only clear Python modules that were loaded from our temporary directories
    modules_to_remove = []
    for module_name, module in list(sys.modules.items()):
        if hasattr(module, "__file__") and module.__file__:
            module_path = str(module.__file__)
            # Check if this module was loaded from any of our temp directories
            for cached_dir in cached_dirs:
                if module_path.startswith(cached_dir):
                    modules_to_remove.append(module_name)
                    break

    # Remove only the modules from our temp directories
    for module_name in modules_to_remove:
        sys.modules.pop(module_name, None)


def _materialize_repo_package(repo):
    """Create a temporary Python package from repository files."""
    revision = _repo_revision_key(repo)
    key = (repo.id, revision)

    cached_dir = _repo_pkg_cache.get(key)
    if cached_dir and os.path.isdir(cached_dir):
        if cached_dir not in sys.path:
            sys.path.insert(0, cached_dir)
        return cached_dir

    # Clear any existing modules from previous versions of this repo before creating new package
    clear_repo_script_cache(repo)

    temp_root = pathlib.Path(tempfile.mkdtemp(prefix=f"wfrepo_{repo.id}_{revision}_"))
    (temp_root / "__init__.py").write_text("# workflow temp package\n")

    # Import here to avoid circular import
    from .models import WorkflowHelper

    # Single source: all files from WorkflowHelper
    for helper in WorkflowHelper.objects.filter(source_repo=repo):
        rel_path = pathlib.Path(helper.file_path)
        dst_file = temp_root / rel_path
        dst_file.parent.mkdir(parents=True, exist_ok=True)

        # Make each directory a package
        cur = dst_file.parent
        while cur != temp_root and not (cur / "__init__.py").exists():
            (cur / "__init__.py").write_text("")
            cur = cur.parent

        dst_file.write_text(helper.content)

    sys.path.insert(0, str(temp_root))
    _repo_pkg_cache[key] = str(temp_root)
    return str(temp_root)


def _render(value, ctx):
    """Recursively render Jinja2 templates in strings, dicts, and lists."""
    if isinstance(value, str):
        return _env.from_string(value).render(ctx)
    if isinstance(value, dict):
        return {k: _render(v, ctx) for k, v in value.items()}
    if isinstance(value, list):
        return [_render(v, ctx) for v in value]
    return value


def _build_enhanced_inputs_context(workflow, inputs):
    """Build enhanced inputs context with object properties."""
    enhanced_inputs = {}

    for key, value in inputs.items():
        if not value:
            enhanced_inputs[key] = value
            continue

        # Try to resolve object and add its properties
        try:
            from .models import WorkflowInput

            wi = WorkflowInput.objects.get(workflow=workflow, key=key)
            if wi.content_type:
                model = wi.content_type.model_class()
                obj = model.objects.get(pk=value)

                # Create a custom dict-like object that behaves like an object but also like a string
                class ObjectProxy(dict):
                    def __init__(self, obj_data, pk, original_obj):
                        super().__init__(obj_data)
                        self._pk = pk
                        self._original_obj = original_obj

                    def __str__(self):
                        return str(self._pk)  # Default to ID for backward compatibility

                    def __getattr__(self, name):
                        # First try the dict lookup
                        if name in self:
                            return self[name]
                        # Then try the original object
                        if hasattr(self._original_obj, name):
                            return getattr(self._original_obj, name)
                        # Fallback to None to avoid AttributeError
                        return None

                    def __getitem__(self, key):
                        # Override to handle dot notation in templates
                        try:
                            return super().__getitem__(key)
                        except KeyError:
                            return self.__getattr__(key)

                # Add object with all useful properties
                obj_data = {
                    "id": obj.pk,
                    "name": getattr(obj, "name", str(obj)),
                    "slug": getattr(obj, "slug", None),
                    "description": getattr(obj, "description", None),
                    "__str__": str(obj),  # Default string representation
                }

                enhanced_inputs[key] = ObjectProxy(obj_data, obj.pk, obj)
            else:
                # Non-object field, just use the value
                enhanced_inputs[key] = value
        except Exception:
            # Fall back to just the value if resolution fails
            enhanced_inputs[key] = value

    return enhanced_inputs


def _wait_for_awx_completion(awx_run, workflow_run, max_wait_seconds=3600):
    """Wait for AWX job to complete and return final status with artifacts."""
    poll_seconds = int(PLUGIN_CFG.get("awx_poll_seconds", 10))
    waited = 0

    while waited < max_wait_seconds:
        # Refresh from database to get latest status
        awx_run.refresh_from_db()

        if awx_run.status in {"successful", "failed", "error", "canceled"}:
            workflow_run.log += f"\nAWX job {awx_run.job_id} completed with status: {awx_run.status}"

            # Extract artifacts from raw payload
            artifacts = None
            if awx_run.raw and isinstance(awx_run.raw, dict):
                artifacts = awx_run.raw.get("artifacts")

            workflow_run.save()
            return awx_run.status, artifacts

        time.sleep(poll_seconds)
        waited += poll_seconds

        if waited % 60 == 0:  # Log every minute
            workflow_run.log += f"\nStill waiting for AWX job {awx_run.job_id} (waited {waited}s)..."
            workflow_run.save()

    workflow_run.log += f"\nTimeout waiting for AWX job {awx_run.job_id} after {max_wait_seconds}s"
    workflow_run.save()
    return "timeout", None


def run_workflow(workflow, user, inputs: dict, workflow_run=None) -> WorkflowRun:
    """Start workflow execution asynchronously and return WorkflowRun immediately."""
    from .tasks import execute_workflow_task

    # Safety check: ensure workflow is enabled (unless show_disabled is True)
    if not _should_show_workflow(workflow):
        raise ValueError(f"Cannot execute disabled workflow '{workflow.name}' (key: {workflow.key})")

    if not user.has_perm("nautobot_workflow_launcher.add_workflowrun"):
        raise ValueError(f"User '{user}' does not have permission to execute workflows")

    if not user.has_perm("nautobot_workflow_launcher.view_workflow", workflow):
        raise ValueError(f"User '{user}' does not have permission to this workflow.")

    # Use provided workflow_run or create a new one
    if workflow_run is None:
        workflow_run = WorkflowRun.objects.create(workflow=workflow, requested_by=user, inputs=inputs, status="pending")
    else:
        # Update the workflow_run status if it was scheduled
        workflow_run.status = "pending"
        workflow_run.save()

    # Queue the entire workflow for background execution
    execute_workflow_task.delay(workflow_run.pk)

    return workflow_run


def _run_workflow_synchronous(workflow_run) -> WorkflowRun:
    """Execute a workflow synchronously with the inputs from the WorkflowRun."""
    # Safety check: ensure workflow is still enabled before execution (unless show_disabled is True)
    if not _should_show_workflow(workflow_run.workflow):
        workflow_run.status = "failed"
        workflow_run.log += f"\nERROR: Cannot execute disabled workflow '{workflow_run.workflow.name}' (key: {workflow_run.workflow.key})"
        workflow_run.finished = timezone.now()
        workflow_run.save()
        return workflow_run

    # Build enhanced inputs context with object properties
    enhanced_inputs = _build_enhanced_inputs_context(workflow_run.workflow, workflow_run.inputs)

    # Debug logging to see what's in the enhanced context
    workflow_run.log += "\nEnhanced inputs context:"
    for key, value in enhanced_inputs.items():
        if hasattr(value, "_original_obj"):
            workflow_run.log += f"\n  {key}: ObjectProxy with id={value.get('id')}, name={value.get('name')}"
        else:
            workflow_run.log += f"\n  {key}: {type(value).__name__} = {value}"

    # Context available inside Jinja: {{ inputs }}, {{ results }}, {{ last }}, {{ user }}
    ctx = {
        "inputs": enhanced_inputs,
        "results": {},  # action_name -> {status: "success"/"failed", return_value: ...}
        "last": None,  # convenience alias to most recent result
        "user": workflow_run.requested_by,  # user running the workflow
    }

    any_failed = False
    try:
        for action in workflow_run.workflow.actions.all():
            cond = (action.when or "").strip() or "true"
            should = _env.from_string(cond).render(ctx).lower() in ("true", "1", "yes", "on", "y")
            if not should:
                workflow_run.log += f"\nSkipped action '{action.name}' (when={cond!r} → False)"
                continue

            try:
                if action.action_type == "nautobot":
                    params = _render(action.with_vars or {}, ctx)
                    ret = _run_nautobot_script(action, params, workflow_run, workflow_run.workflow.source_repo)
                    ctx["results"][action.name] = {"status": "success", "return_value": ret}
                    ctx["last"] = {"name": action.name, **ctx["results"][action.name]}
                    workflow_run.log += f"\nResults: {ctx['results'][action.name]!r}"

                elif action.action_type == "awx":
                    params = _render(action.awx_extra_vars or {}, ctx)
                    awx_run = _run_awx_action(action, params, workflow_run)
                    workflow_run.log += (
                        f"\nAction '{action.name}' launched AWX job {awx_run.job_id}, waiting for completion..."
                    )
                    workflow_run.save()  # Save current state before waiting

                    # Wait for AWX job completion and get artifacts
                    final_status, artifacts = _wait_for_awx_completion(awx_run, workflow_run)

                    if final_status == "successful":
                        ctx["results"][action.name] = {
                            "status": "success",
                            "return_value": artifacts,  # Use artifacts as return_value
                        }
                    else:
                        any_failed = True
                        ctx["results"][action.name] = {
                            "status": "failed",
                            "return_value": None,  # No artifacts on failure
                            "error": f"AWX job {final_status}",
                        }
                    workflow_run.log += f"\nResults: {ctx['results'][action.name]!r}"

                    ctx["last"] = {"name": action.name, **ctx["results"][action.name]}
                else:
                    raise RuntimeError(f"Unsupported action type: {action.action_type}")

            except Exception as exc:
                any_failed = True
                workflow_run.log += f"\nAction '{action.name}' failed: {exc}\n" + traceback.format_exc()
                ctx["results"][action.name] = {"status": "failed", "return_value": None, "error": str(exc)}
                ctx["last"] = {"name": action.name, **ctx["results"][action.name]}
                # continue to next action so you can branch on failures

        # overall status
        workflow_run.status = "success" if not any_failed else "failed"
        workflow_run.finished = timezone.now()
        workflow_run.save()
        return workflow_run

    except Exception as exc:
        workflow_run.status = "failed"
        workflow_run.log += "\nERROR: " + str(exc) + "\n" + traceback.format_exc()
        workflow_run.finished = timezone.now()
        workflow_run.save()
        return workflow_run


def _run_nautobot_script(action, params, run, repo):
    """Load and execute an action script from the temp package."""
    if not repo or not getattr(repo, "id", None):
        raise RuntimeError("Workflow has no source_repo; cannot run script action")

    # Get script from WorkflowHelper via the action's script_path
    script_path = action.script_path.lstrip("/")
    try:
        from .models import WorkflowHelper

        WorkflowHelper.objects.get(source_repo=repo, file_path=script_path)
    except WorkflowHelper.DoesNotExist:
        raise RuntimeError(f"Script not found in repository: {script_path}")

    # --- helpers (local to keep this function self-contained) ---
    def _ensure_pkg_chain(path: pathlib.Path, pkg_root: pathlib.Path) -> None:
        """Make every parent dir under pkg_root a Python package."""
        cur = path.parent
        while True:
            init = cur / "__init__.py"
            if not init.exists():
                try:
                    cur.mkdir(parents=True, exist_ok=True)
                    init.write_text("# auto-generated package\n")
                except Exception:
                    break
            if cur == pkg_root:
                break
            cur = cur.parent

    def _debug_tree(root: pathlib.Path) -> str:
        try:
            return "\n".join(p.relative_to(root).as_posix() for p in sorted(root.rglob("*.py")))
        except Exception:
            return "<unavailable>"

    def _preload_all_modules(pkg_root: pathlib.Path) -> None:
        """Pre-load all Python modules in the package to make them importable."""
        # First, log what files we found for debugging
        all_py_files = list(pkg_root.rglob("*.py"))
        for py_file in all_py_files:
            rel_path = py_file.relative_to(pkg_root)

        # Load modules in dependency order (leaf modules first)
        modules_to_load = []
        for py_file in all_py_files:
            if py_file.name == "__init__.py":
                continue

            rel_path = py_file.relative_to(pkg_root)
            module_name = rel_path.with_suffix("").as_posix().replace("/", ".")
            modules_to_load.append((module_name, py_file))

        # Sort by depth (deeper modules first to resolve dependencies)
        modules_to_load.sort(key=lambda x: x[0].count("."), reverse=True)

        for module_name, py_file in modules_to_load:
            try:
                # Skip if already loaded
                if module_name in sys.modules:
                    continue

                # Load the module
                spec = importlib.util.spec_from_file_location(module_name, str(py_file))
                if spec and spec.loader:
                    mod = importlib.util.module_from_spec(spec)
                    sys.modules[module_name] = mod
                    spec.loader.exec_module(mod)

            except Exception as e:
                # Log but don't fail - some modules might have dependencies
                run.log += f"\n[preload] Warning: Could not preload {module_name}: {e}"

    # --- materialize helpers + compute module/file paths ---
    pkg_root = pathlib.Path(_materialize_repo_package(repo))  # ensures helpers like scripts/lib/utils.py are copied
    rel_path = pathlib.Path(action.script_path.lstrip("/"))  # e.g. scripts/actions/do_thing.py
    file_path = pkg_root / rel_path
    module_name = rel_path.with_suffix("").as_posix().replace("/", ".")

    # Ensure package dirs exist (scripts/, scripts/lib/, …)
    _ensure_pkg_chain(file_path, pkg_root)

    # Pre-load all modules in the package to make them importable
    _preload_all_modules(pkg_root)

    # Fresh import from this exact file path to avoid stale sys.modules entries
    # (We purposely do not rely on a prior import of the same module name.)
    sys.modules.pop(module_name, None)
    spec = importlib.util.spec_from_file_location(module_name, str(file_path))
    if spec is None or spec.loader is None:
        run.log += (
            f"\n[loader] Unable to create spec for {module_name} at {file_path}"
            f"\n[loader] package root: {pkg_root}"
            f"\n[loader] tree:\n{_debug_tree(pkg_root)}"
        )
        raise RuntimeError(f"Unable to load spec for {module_name} at {file_path}")

    try:
        mod = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = mod
        spec.loader.exec_module(mod)  # type: ignore[attr-defined]
    except Exception as exc:
        run.log += (
            f"\n[loader] exec_module failed for {module_name} at {file_path}: {exc}"
            f"\n[loader] package root: {pkg_root}"
            f"\n[loader] tree:\n{_debug_tree(pkg_root)}"
            f"\n{traceback.format_exc()}"
        )
        raise

    # Sanity check: require run(params)
    if not hasattr(mod, "run"):
        raise RuntimeError(f"{action.script_path} must define run(params)")

    # Execute and return the script's return value, capturing print() output
    buf = io.StringIO()

    try:
        with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
            ret = mod.run(params)
    except Exception:
        # Capture printed output even on exception, then re-raise
        printed = buf.getvalue()
        if printed:
            run.user_log = (run.user_log or "") + printed
            try:
                run.save(update_fields=["user_log"])
            except Exception as exc:
                run.log += f"\nFailed to save WorkflowRun.user_log after exception: {exc}"
        raise

    # Append any printed output to the WorkflowRun.user_log and persist
    printed = buf.getvalue()
    if printed:
        run.user_log = (run.user_log or "") + printed
        try:
            run.save(update_fields=["user_log"])
        except Exception as exc:
            run.log += f"\nFailed to save WorkflowRun.user_log: {exc}"

    run.log += f"\nExecuted {module_name}.run({params!r})"
    return ret


def _awx_integration():
    """Get the AWX external integration from Nautobot configuration."""
    name = PLUGIN_CFG["awx_external_integration_name"]
    return ExternalIntegration.objects.get(name=name)


def parse_awx_auth(integ: ExternalIntegration):
    """Parse AWX integration credentials."""
    if integ.secrets_group:
        try:
            result = (
                integ.secrets_group.get_secret_value(
                    access_type=SecretsGroupAccessTypeChoices.TYPE_GENERIC,
                    secret_type=SecretsGroupSecretTypeChoices.TYPE_USERNAME,
                ),
                integ.secrets_group.get_secret_value(
                    access_type=SecretsGroupAccessTypeChoices.TYPE_GENERIC,
                    secret_type=SecretsGroupSecretTypeChoices.TYPE_PASSWORD,
                ),
            )
            return result
        except SecretsGroupAssociation.DoesNotExist:
            return None


def _run_awx_action(action, extra_vars, run):
    """Execute an AWX job template and create an AwxRun record."""
    integ = _awx_integration()
    url = integ.remote_url.rstrip("/")
    verify = integ.verify_ssl
    username, password = parse_awx_auth(integ)

    resp = requests.post(
        f"{url}/api/v2/job_templates/{action.awx_template_id}/launch/",
        json={"extra_vars": extra_vars},
        auth=(username, password) if username and password else None,
        verify=verify,
        timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()
    job_id = data.get("job") or data.get("id")
    job_url = f"{url}/#/jobs/playbook/{job_id}"
    awx_run = AwxRun.objects.create(
        workflow_run=run,
        template_id=action.awx_template_id,
        job_id=job_id,
        url=job_url,
        status="pending",
        raw=data,
    )

    # Start the polling task to monitor job status
    from .tasks import poll_awx_job

    poll_awx_job.delay(awx_run.pk)

    run.log += f"\nLaunched AWX template {action.awx_template_id} as job {job_id}"
    run.user_log += f"\nAnsible playbook '{action.name}' has been launched (Job ID: {job_id})"
    run.save(update_fields=["log", "user_log"])
    return awx_run  # Return the AwxRun object for monitoring
