"""Views for the workflow launcher plugin."""

import logging
from math import ceil, floor

from django.conf import settings
from django.contrib import messages
from django.db.models import Count
from django.http import Http404, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views import View
from django.views.generic import TemplateView
from nautobot.apps.views import NautobotUIViewSet, ObjectPermissionRequiredMixin, ObjectView

from .executors import _get_workflow_queryset, run_workflow
from .filters import WorkflowFilterSet
from .forms import DynamicWorkflowForm
from .models import WorkflowInput, WorkflowRun
from .tables import WorkflowTable

logger = logging.getLogger(__name__)
PLUGIN_CFG = settings.PLUGINS_CONFIG.get("nautobot_workflow_launcher", {})


class WorkflowUIViewSet(NautobotUIViewSet):
    """UIViewSet for Workflow model to enable search functionality."""

    queryset = _get_workflow_queryset()

    filterset_class = WorkflowFilterSet
    table_class = WorkflowTable


class WorkflowListView(TemplateView, ObjectPermissionRequiredMixin):
    """List all workflows with category filtering and grouping."""

    template_name = "nautobot_workflow_launcher/workflow_list.html"
    permission_required = "nautobot_workflow_launcher.view_workflow"
    queryset = _get_workflow_queryset().order_by("category", "name")  # Only show enabled workflows

    def get_queryset(self):
        """Get workflows queryset with optional category filtering."""
        qs = _get_workflow_queryset().order_by("category", "name")
        permitted_ids = [
            wf.id for wf in qs if self.request.user.has_perm("nautobot_workflow_launcher.view_workflow", wf)
        ]
        qs = qs.filter(id__in=permitted_ids)
        # Filter by category if specified
        category = self.request.GET.get("category")
        if category:
            qs = qs.filter(category=category)

        return qs

    def get_context_data(self, **kwargs):
        """Add context data including category grouping."""
        context = super().get_context_data(**kwargs)

        workflows = self.get_queryset()

        # Check if user can execute workflows
        can_execute = self.request.user.has_perm("nautobot_workflow_launcher.add_workflowrun")
        context["can_execute_workflows"] = can_execute

        context["object_list"] = workflows
        context["workflow_list"] = workflows
        context["workflows"] = workflows

        # Group workflows by category
        workflows_by_category = {}
        for workflow in workflows:
            category = workflow.category or "Uncategorized"
            if category not in workflows_by_category:
                workflows_by_category[category] = []
            workflows_by_category[category].append(workflow)

        context["workflows_by_category"] = workflows_by_category

        # Get all available categories for filter dropdown
        all_categories = (
            _get_workflow_queryset()
            .exclude(category="")
            .exclude(category__isnull=True)
            .values_list("category", flat=True)
            .distinct()
            .order_by("category")
        )
        context["categories"] = list(all_categories)
        context["selected_category"] = self.request.GET.get("category", "")

        return context


class WorkflowRunCreateView(TemplateView, ObjectPermissionRequiredMixin):
    """View for launching workflows with dynamic forms."""

    template_name = "nautobot_workflow_launcher/workflow_launch.html"
    permission_required = "nautobot_workflow_launcher.add_workflowrun"

    def get_context_data(self, **kwargs):
        """Add workflow and form to context.

        Optionally prefill form fields from a previous WorkflowRun when the
        request includes ?from_run=<pk>. Only prefill when the previous run
        belongs to the same workflow. Scheduling fields are intentionally
        not prefilled.
        """
        context = super().get_context_data(**kwargs)
        qs = _get_workflow_queryset()
        wf = get_object_or_404(qs, key=kwargs["key"])

        initial = {}
        from_run = self.request.GET.get("from_run")
        if from_run:
            try:
                prev_run = WorkflowRun.objects.get(pk=from_run)
                if prev_run.workflow_id == wf.id and prev_run.inputs:
                    # Build initial mapping from workflow inputs to the values
                    # stored in the previous run. Convert shapes where the
                    # form expects specific types (JSON string for list,
                    # object id string for object fields, list of strings for multichoice,
                    # and string for single-choice fields).
                    import json

                    for wi in wf.inputs.all():
                        if wi.key not in prev_run.inputs:
                            continue
                        val = prev_run.inputs.get(wi.key)
                        if val is None:
                            continue

                        if wi.input_type == "list":
                            # List widget stores JSON string
                            initial[wi.key] = val if isinstance(val, str) else json.dumps(val)
                        elif wi.input_type == "listdict":
                            # List-of-dicts widget stores JSON string
                            initial[wi.key] = val if isinstance(val, str) else json.dumps(val)
                        elif wi.input_type == "boolean":
                            initial[wi.key] = bool(val)
                        elif wi.input_type == "object":
                            # Store the object's PK as a string for the field
                            if isinstance(val, dict):
                                initial[wi.key] = str(val.get("id") or val.get("pk") or "")
                            else:
                                initial[wi.key] = str(val)
                        elif wi.input_type == "multichoice":
                            # Ensure multichoice initial is a list of strings
                            if isinstance(val, (list, tuple)):
                                initial[wi.key] = [str(x) for x in val]
                            else:
                                initial[wi.key] = [str(val)]
                        elif wi.input_type == "choice":
                            # Ensure choice initial is a string matching option values
                            initial[wi.key] = "" if val in (None, "") else str(val)
                        else:
                            # Default: cast to string for safety where appropriate
                            initial[wi.key] = val if isinstance(val, (dict, list)) else val
            except WorkflowRun.DoesNotExist:
                # If the run can't be found, just render an empty form
                pass

        form = DynamicWorkflowForm(wf, initial=initial)
        context["workflow"] = wf
        context["form"] = form
        return context

    def post(self, request, key):
        """Handle workflow launch form submission."""
        qs = _get_workflow_queryset()
        wf = get_object_or_404(qs, key=key)
        form = DynamicWorkflowForm(wf, data=request.POST)
        if form.is_valid():
            # Extract scheduling data
            execution_type = form.cleaned_data.pop("execution_type", "immediate")
            scheduled_datetime = form.cleaned_data.pop("scheduled_datetime", None)

            # Capture actual form-fill duration from client (in seconds)
            try:
                form_duration_seconds = int(request.POST.get("form_duration_seconds", "0") or "0")
                if form_duration_seconds < 0:
                    form_duration_seconds = 0
            except ValueError:
                form_duration_seconds = 0

            # Create WorkflowRun with appropriate status
            status = "scheduled" if execution_type == "scheduled" else "pending"

            run = WorkflowRun.objects.create(
                workflow=wf,
                requested_by=request.user,
                inputs=form.cleaned_data,
                status=status,
                scheduled_for=scheduled_datetime,
                form_duration_seconds=form_duration_seconds,
            )

            if execution_type == "immediate":
                # Execute immediately using existing execution path
                run_workflow(wf, request.user, form.cleaned_data, run)
                return redirect("plugins:nautobot_workflow_launcher:workflow_run", pk=run.pk)

            elif execution_type == "scheduled":
                # Create scheduled job
                from nautobot.extras.choices import JobExecutionType
                from nautobot.extras.models import Job, ScheduledJob

                # Get the Job model instance for our ScheduledWorkflowExecutorJob
                try:
                    job_model = Job.objects.get(
                        module_name="nautobot_workflow_launcher.jobs", job_class_name="ScheduledWorkflowExecutorJob"
                    )
                except Job.DoesNotExist:
                    logger.error("ScheduledWorkflowExecutorJob not found in Job registry")
                    messages.error(
                        request, "Job scheduling is not properly configured. Please contact an administrator."
                    )
                    return render(
                        request, "nautobot_workflow_launcher/workflow_launch.html", {"workflow": wf, "form": form}
                    )

                scheduled_job = ScheduledJob.objects.create(
                    name=f"Workflow: {wf.name} (Run #{run.pk})",
                    task=job_model.class_path,  # Use the job's class_path instead of generic handler
                    job_model=job_model,
                    job_queue=job_model.default_job_queue,
                    kwargs={"workflow_run_id": run.pk},
                    start_time=scheduled_datetime,
                    one_off=True,
                    user=request.user,
                    approved_by_user=request.user,
                    interval=JobExecutionType.TYPE_FUTURE,
                    args=[],
                    crontab="",
                    celery_kwargs={
                        "nautobot_job_ignore_singleton_lock": False,
                        "nautobot_job_profile": False,
                        "queue": "default",
                    },
                    time_zone="UTC",
                    description=f"Scheduled execution of workflow '{wf.name}'",
                    enabled=True,
                    approval_required=False,
                    total_run_count=0,
                )

                # Link the scheduled job to the workflow run
                run.scheduled_job = scheduled_job
                run.save()

                # Redirect with success message
                messages.success(
                    request, f"Workflow '{wf.name}' scheduled for {scheduled_datetime.strftime('%Y-%m-%d %H:%M')}"
                )
                return redirect("plugins:nautobot_workflow_launcher:workflow_run", pk=run.pk)

        return render(request, "nautobot_workflow_launcher/workflow_launch.html", {"workflow": wf, "form": form})


class InputOptionsView(View):
    """Return filtered options for a dependent object field."""

    def _build_enhanced_context(self, workflow, form_data):
        """Build context with both IDs and resolved object properties."""
        context = {"inputs": {}}

        for key, value in form_data.items():
            if not value:
                continue

            # Try to resolve object and add its properties
            try:
                wi = workflow.inputs.get(key=key)
                if wi.content_type:
                    model = wi.content_type.model_class()
                    obj = model.objects.get(pk=value)

                    # Add object with all useful properties
                    context["inputs"][key] = {
                        "id": obj.pk,
                        "name": getattr(obj, "name", str(obj)),
                        "slug": getattr(obj, "slug", None),
                        "description": getattr(obj, "description", None),
                        "__str__": str(obj),  # Default string representation
                    }

                    # Also make the object accessible for template rendering as just the ID (backward compatibility)
                    # This ensures "{{ inputs.tenant }}" still works for ID-based filters
                    context["inputs"][f"{key}_id"] = value
                else:
                    # Non-object field, just use the value
                    context["inputs"][key] = value
            except Exception:
                # Fall back to just the value if resolution fails
                context["inputs"][key] = value

        return context

    def get(self, request, key, child):
        """Get filtered options for a dependent field (object or choice with Jinja)."""
        qs = _get_workflow_queryset()
        wf = get_object_or_404(qs, key=key)
        try:
            wi = wf.inputs.get(key=child)
        except WorkflowInput.DoesNotExist:
            raise Http404

        # Handle object fields
        if wi.input_type in ("object", "multiobject") and wi.content_type:
            return self._handle_object_field(request, wf, wi)

        # Handle choice fields with Jinja templates
        if wi.input_type in ("choice", "multichoice") and wi.choices:
            return self._handle_choice_field(request, wf, wi)

        raise Http404

    def _handle_object_field(self, request, wf, wi):
        """Handle object field options with optional REST API search."""
        # Check if this is a server-side search request
        search_term = request.GET.get("search", "").strip()
        use_api_search = bool(search_term)

        if use_api_search:
            return self._handle_api_search(request, wf, wi, search_term)

        # For non-search requests, load first 200 entries using ORM
        return self._handle_orm_query(request, wf, wi, default_limit=200)

    def _handle_api_search(self, request, wf, wi, search_term):
        """Handle object field search using Nautobot REST API with proper authentication."""
        import requests

        try:
            # Get the model info
            app_label = wi.content_type.app_label

            api_endpoint = wi.content_type.model_class()._meta.verbose_name_plural.replace(" ", "-")

            # Build API URL
            api_path = f"/api/{app_label}/{api_endpoint}/"

            # Get the base URL
            base_url = request.build_absolute_uri("/").rstrip("/")
            api_url = f"{base_url}{api_path}"

            # Prepare API parameters
            params = {
                "q": search_term,
                "limit": int(request.GET.get("limit", 50)),
                "offset": int(request.GET.get("offset", 0)),
                "format": "json",
            }
            logger.info(f"Making API request to {api_url} with params: {params}")

            # Prepare headers with authentication
            headers = {
                "Content-Type": "application/json",
                "User-Agent": "Nautobot-Workflow-Launcher/1.0",
            }

            # Add authentication headers from the original request
            if hasattr(request, "user") and request.user.is_authenticated:
                # For session-based auth, we need to include session cookies
                session_cookies = request.COOKIES

                # If we have a session cookie, use it
                if "sessionid" in session_cookies:
                    headers["Cookie"] = f"sessionid={session_cookies['sessionid']}"

                # Also add CSRF token if available
                if "csrftoken" in session_cookies:
                    headers["X-CSRFToken"] = session_cookies["csrftoken"]

            # Make the API request
            response = requests.get(api_url, params=params, headers=headers, timeout=120)
            response.raise_for_status()

            api_data = response.json()
            results = api_data.get("results", [])
            id_list = [item["id"] for item in results]
            model = wi.content_type.model_class()
            qs = model.objects.filter(id__in=id_list)

            # Apply additional filters from wi.filter_query
            context = self._build_enhanced_context(wf, request.GET)
            from .executors import _render

            rendered_filters = {}
            if wi.filter_query:
                try:
                    rendered_filters = _render(wi.filter_query, context)
                except Exception as e:
                    logger.error(f"Error rendering filter query for API search: {e}")

            # Clean filters and apply
            clean_filters = {k: v for k, v in rendered_filters.items() if v not in (None, "")}
            if clean_filters:
                qs = qs.filter(**clean_filters)

            # Use distinct() to prevent duplicates from JOIN operations (e.g., filtering by related models)
            qs = qs.distinct()

            # Convert API response to our expected format
            data = []

            for obj in qs:
                display_name = (
                    getattr(obj, "display", None)
                    or getattr(obj, "display_name", None)
                    or getattr(obj, "name", None)
                    or getattr(obj, "label", None)
                    or getattr(obj, "prefix", None)
                    or getattr(obj, "address", None)
                    or getattr(obj, "hostname", None)
                    or str(obj)
                )
                data.append({"value": str(obj.pk), "label": display_name})

            response_data = {
                "options": data,
                "total_count": len(data),
                "has_more": bool(api_data.get("next")),
                "limit": params["limit"],
                "offset": params["offset"],
            }

            logger.info(f"API search returned {len(data)} results")
            return JsonResponse(response_data)

        except requests.RequestException as e:
            logger.error(f"API request failed: {e}")
            # Fallback to ORM query
            return self._handle_orm_query(request, wf, wi)
        except Exception as e:
            logger.error(f"Error in API search: {e}")
            # Fallback to ORM query
            return self._handle_orm_query(request, wf, wi)

    def _handle_orm_query(self, request, wf, wi, default_limit=50):
        """Handle object field options using direct ORM queries."""
        # Build enhanced context with resolved objects
        context = self._build_enhanced_context(wf, request.GET)

        # Render filter queries with enhanced context
        if wi.filter_query:
            from .executors import _render

            try:
                rendered_filters = _render(wi.filter_query, context)
            except Exception as e:
                logger.error(f"Error rendering filter query for {wi.key}: {e}")
                rendered_filters = {}
        else:
            rendered_filters = {}

        # Apply filters to queryset
        model = wi.content_type.model_class()
        qs = model.objects.all()
        if rendered_filters:
            # Filter out None values and empty strings
            clean_filters = {k: v for k, v in rendered_filters.items() if v not in (None, "")}
            if clean_filters:
                qs = qs.filter(**clean_filters)

        # Use distinct() to prevent duplicates from JOIN operations (e.g., filtering by related models like devices__isnull)
        qs = qs.distinct()

        # Handle pagination
        limit = int(request.GET.get("limit", default_limit))
        offset = int(request.GET.get("offset", 0))
        total_count = qs.count()

        # Apply pagination
        qs = qs[offset : offset + limit]

        # Use display field for consistency with API search results
        data = []
        for obj in qs:
            # Try to get a good display name, similar to API search logic
            display_name = (
                getattr(obj, "display", None)  # Nautobot's main display field
                or getattr(obj, "display_name", None)  # Alternative display field
                or getattr(obj, "name", None)  # Name field
                or getattr(obj, "label", None)  # Label field
                or getattr(obj, "prefix", None)  # For prefix objects
                or getattr(obj, "address", None)  # For IP address objects
                or getattr(obj, "hostname", None)  # For device objects
                or str(obj)  # Fallback to string representation
            )
            data.append({"value": str(obj.pk), "label": display_name})

        # Check if we're supposed to prepend a "Create New XXX" to the dropdown
        show_add_new_item = [x.lower() for x in PLUGIN_CFG.get("show_add_new_item", [])]
        if f"{wi.content_type.app_label}.{wi.content_type.name}" in show_add_new_item:
            data.insert(0, {"value": "__create__", "label": f"Create New {wi.content_type.name.title()}"})

        response_data = {
            "options": data,
            "total_count": total_count,
            "has_more": offset + limit < total_count,
            "limit": limit,
            "offset": offset,
        }

        return JsonResponse(response_data)

    def _handle_choice_field(self, request, wf, wi):
        """Handle choice field options with Jinja templating."""
        # Build enhanced context with resolved objects
        context = self._build_enhanced_context(wf, request.GET)

        try:
            import json

            from .executors import _render

            # Handle choices - could be a string (JSON) or already parsed list
            choices_value = wi.choices

            # If choices is a string, try to render it as Jinja template first
            if isinstance(choices_value, str):
                rendered_choices_str = _render(choices_value, context)
                logger.info(f"Rendered choices string for {wi.key}: {rendered_choices_str}")

                # Try to parse as JSON
                try:
                    rendered_choices = json.loads(rendered_choices_str)
                except json.JSONDecodeError as e:
                    logger.error(f"Failed to parse choices as JSON for {wi.key}: {e}")
                    logger.error(f"Choices string was: {rendered_choices_str}")
                    return JsonResponse({"options": []})
            else:
                # Choices is already a list/object, render it directly
                rendered_choices = _render(choices_value, context)

            logger.info(f"Final rendered choices for {wi.key}: {rendered_choices}")

            # Convert to options format
            if isinstance(rendered_choices, list):
                data = []
                for choice in rendered_choices:
                    if isinstance(choice, dict):
                        # Choice is a dict with value/label
                        data.append(
                            {"value": choice.get("value", ""), "label": choice.get("label", choice.get("value", ""))}
                        )
                    else:
                        # Choice is a simple value
                        data.append({"value": str(choice), "label": str(choice)})
            else:
                logger.error(f"Rendered choices is not a list for {wi.key}: {rendered_choices}")
                data = []

            return JsonResponse({"options": data})

        except Exception as e:
            logger.error(f"Error rendering choices for {wi.key}: {e}")
            import traceback

            logger.error(f"Traceback: {traceback.format_exc()}")
            return JsonResponse({"options": []})


class WorkflowRunDetailView(ObjectView):
    """Detail view for individual workflow runs."""

    queryset = WorkflowRun.objects.select_related("workflow", "requested_by")
    template_name = "nautobot_workflow_launcher/workflow_run.html"

    def get_extra_context(self, request, instance):
        """Add workflow availability context."""
        context = super().get_extra_context(request, instance)
        # Show workflow info in run view even if workflow is now disabled
        context["workflow_available"] = instance.workflow.enabled if instance.workflow else False
        return context


class WorkflowRunListView(TemplateView):
    """List workflow execution history with filtering and pagination."""

    template_name = "nautobot_workflow_launcher/workflow_run_list.html"

    def get_queryset(self):
        """Get workflow runs queryset with filtering."""
        from datetime import timedelta

        from django.utils import timezone
        from django.utils.dateparse import parse_datetime

        qs = WorkflowRun.objects.select_related("workflow", "requested_by").order_by("-started")
        permitted_run_ids = [
            wf.id for wf in qs if self.request.user.has_perm("nautobot_workflow_launcher.view_workflowrun", wf)
        ]
        qs = qs.filter(id__in=permitted_run_ids)
        # Filter by workflow if specified
        workflow_key = self.request.GET.get("workflow")
        if workflow_key:
            qs = qs.filter(workflow__key=workflow_key)

        # Filter by status if specified
        status = self.request.GET.get("status")
        if status:
            qs = qs.filter(status=status)

        # Filter by user if specified
        user = self.request.GET.get("user")
        if user:
            qs = qs.filter(requested_by__username=user)

        # Optional category filter
        category = self.request.GET.get("category")
        if category:
            if category == "__uncategorized__":
                from django.db.models import Q

                qs = qs.filter(Q(workflow__category__isnull=True) | Q(workflow__category=""))
            else:
                qs = qs.filter(workflow__category=category)

        # Optional time range filter
        time_range = self.request.GET.get("time_range", "")
        start = self.request.GET.get("start", "")
        end = self.request.GET.get("end", "")
        now = timezone.now()
        start_dt = None
        end_dt = None
        if start and end:
            sdt = parse_datetime(start)
            edt = parse_datetime(end)
            if sdt and edt:
                start_dt = sdt if sdt.tzinfo else timezone.make_aware(sdt, timezone.utc)
                end_dt = edt if edt.tzinfo else timezone.make_aware(edt, timezone.utc)
        if not start_dt or not end_dt:
            if time_range:
                days = 0
                if time_range == "7d":
                    days = 7
                elif time_range == "30d":
                    days = 30
                elif time_range == "90d":
                    days = 90
                elif time_range == "365d":
                    days = 365
                if days:
                    start_dt = now - timedelta(days=days)
                    end_dt = now
        if start_dt and end_dt:
            qs = qs.filter(started__gte=start_dt, started__lte=end_dt)

        return qs

    def get_context_data(self, **kwargs):
        """Add context data for the template."""
        context = super().get_context_data(**kwargs)

        # Add queryset
        context["object_list"] = self.get_queryset()
        context["workflow_runs"] = self.get_queryset()

        # Add filter options
        context["workflows"] = _get_workflow_queryset().order_by("name")
        context["status_choices"] = WorkflowRun.STATUS_CHOICES

        # Get users who have executed workflows
        context["users"] = (
            WorkflowRun.objects.select_related("requested_by")
            .values("requested_by__username", "requested_by__pk")
            .distinct()
            .order_by("requested_by__username")
        )

        context["selected_workflow"] = self.request.GET.get("workflow", "")
        context["selected_status"] = self.request.GET.get("status", "")
        context["selected_user"] = self.request.GET.get("user", "")

        return context


class WorkflowReportView(TemplateView):
    """Dashboard view showing workflow execution statistics and recent runs."""

    template_name = "nautobot_workflow_launcher/workflow_report.html"

    def get_context_data(self, **kwargs):
        """Add reporting data to context."""
        from datetime import timedelta

        from django.db.models import Q
        from django.db.models.functions import TruncDay, TruncWeek
        from django.utils import timezone
        from django.utils.dateparse import parse_datetime

        context = super().get_context_data(**kwargs)

        # Parse filters from GET
        selected_category = self.request.GET.get("category", "")
        selected_status = self.request.GET.get("status", "")
        selected_user = self.request.GET.get("user", "")
        selected_time_range = self.request.GET.get("time_range", "30d")
        selected_start = self.request.GET.get("start", "")
        selected_end = self.request.GET.get("end", "")

        # Compute time window
        now = timezone.now()
        start_dt = None
        end_dt = None
        if selected_start and selected_end:
            sdt = parse_datetime(selected_start)
            edt = parse_datetime(selected_end)
            if sdt and edt:
                start_dt = sdt if sdt.tzinfo else timezone.make_aware(sdt, timezone.utc)
                end_dt = edt if edt.tzinfo else timezone.make_aware(edt, timezone.utc)
        if not start_dt or not end_dt:
            # Fallback to presets
            days = 30
            if selected_time_range == "7d":
                days = 7
            elif selected_time_range == "90d":
                days = 90
            elif selected_time_range == "365d":
                days = 365
            start_dt = now - timedelta(days=days)
            end_dt = now

        # Build base queryset with permissions and filters
        base_qs = WorkflowRun.objects.select_related("workflow", "requested_by").filter(
            started__gte=start_dt, started__lte=end_dt
        )
        permitted_run_ids = [
            wf.id for wf in base_qs if self.request.user.has_perm("nautobot_workflow_launcher.view_workflowrun", wf)
        ]
        base_qs = base_qs.filter(id__in=permitted_run_ids)

        # Apply category filter
        if selected_category:
            if selected_category == "__uncategorized__":
                base_qs = base_qs.filter(Q(workflow__category__isnull=True) | Q(workflow__category=""))
            else:
                base_qs = base_qs.filter(workflow__category=selected_category)

        # Apply status filter
        if selected_status:
            base_qs = base_qs.filter(status=selected_status)

        # Apply user filter (handle UUID or integer PKs; avoid casting)
        if selected_user:
            # Compare PK as string to support UUID-based User IDs
            base_qs = base_qs.filter(requested_by__pk=str(selected_user))

        # Status summary (filtered scope)
        status_summary = base_qs.values("status").annotate(count=Count("id")).order_by("status")
        context["status_summary"] = status_summary

        # Workflow popularity (filtered scope)
        workflow_summary = (
            base_qs.values("workflow__name", "workflow__key").annotate(count=Count("id")).order_by("-count")[:10]
        )
        context["workflow_summary"] = workflow_summary

        # Category usage summary
        category_summary = base_qs.values("workflow__category").annotate(count=Count("id")).order_by("-count")
        context["category_summary"] = category_summary

        # Top users summary
        user_summary = (
            base_qs.values("requested_by__username", "requested_by__pk")
            .annotate(count=Count("id"))
            .order_by("-count")[:10]
        )
        context["user_summary"] = user_summary

        # Success rate by workflow within filtered scope
        workflows_with_stats = []
        for workflow in _get_workflow_queryset():
            wf_runs = base_qs.filter(workflow=workflow)
            total_runs = wf_runs.count()
            successful_runs = wf_runs.filter(status="success").count()
            success_rate = (successful_runs / total_runs * 100.0) if total_runs else 0.0
            workflows_with_stats.append(
                {
                    "workflow": workflow,
                    "total_runs": total_runs,
                    "successful_runs": successful_runs,
                    "success_rate": success_rate,
                }
            )
        workflows_with_stats.sort(key=lambda x: x["total_runs"], reverse=True)
        context["workflows_with_stats"] = workflows_with_stats[:10]

        # Time savings calculation (filtered scope)
        time_savings_data = self._calculate_time_savings(base_qs.filter(status="success"))
        context["time_savings"] = time_savings_data

        # Monthly time savings (last 12 months; keep existing behavior)
        context["monthly_time_savings"] = self._calculate_monthly_time_savings()

        # Success vs failure by category breakdown
        success_by_category_raw = base_qs.values("workflow__category", "status").annotate(count=Count("id"))
        success_by_category = {}
        for row in success_by_category_raw:
            cat = row["workflow__category"] or "Uncategorized"
            success_by_category.setdefault(cat, {"success": 0, "failed": 0, "running": 0, "pending": 0, "partial": 0})
            success_by_category[cat][row["status"]] = row["count"]
        success_by_category_list = []
        for cat, counts in success_by_category.items():
            total = sum(counts.values())
            success_rate = (counts.get("success", 0) / total * 100.0) if total else 0.0
            success_by_category_list.append(
                {"category": cat, "counts": counts, "total": total, "success_rate": success_rate}
            )
        success_by_category_list.sort(key=lambda x: x["total"], reverse=True)
        context["success_by_category"] = success_by_category_list

        # Usage over time buckets (daily if <=90 days, else weekly)
        window_days = max((end_dt - start_dt).days, 1)
        if window_days > 90:
            time_buckets = (
                base_qs.annotate(bucket=TruncWeek("started"))
                .values("bucket")
                .annotate(count=Count("id"))
                .order_by("bucket")
            )
        else:
            time_buckets = (
                base_qs.annotate(bucket=TruncDay("started"))
                .values("bucket")
                .annotate(count=Count("id"))
                .order_by("bucket")
            )
        usage_over_time = [
            {"label": b["bucket"].strftime("%Y-%m-%d"), "count": b["count"]} for b in time_buckets if b.get("bucket")
        ]
        context["usage_over_time"] = usage_over_time

        # Filter options for template controls
        all_categories = (
            _get_workflow_queryset()
            .exclude(category="")
            .exclude(category__isnull=True)
            .values_list("category", flat=True)
            .distinct()
            .order_by("category")
        )
        context["categories"] = list(all_categories)
        context["status_choices"] = WorkflowRun.STATUS_CHOICES
        context["users"] = (
            WorkflowRun.objects.select_related("requested_by")
            .values("requested_by__username", "requested_by__pk")
            .distinct()
            .order_by("requested_by__username")
        )

        # Selected values for form persistence
        context["selected_category"] = selected_category
        context["selected_status"] = selected_status
        context["selected_user"] = selected_user
        context["selected_time_range"] = selected_time_range
        context["selected_start"] = selected_start
        context["selected_end"] = selected_end

        # Human-readable window label for templates
        if selected_start and selected_end and start_dt and end_dt and selected_time_range == "custom":
            context["window_label"] = f"{start_dt.strftime('%Y-%m-%d')} to {end_dt.strftime('%Y-%m-%d')}"
        else:
            range_map = {
                "7d": "Last 7 Days",
                "30d": "Last 30 Days",
                "90d": "Last 90 Days",
                "365d": "Last 365 Days",
            }
            context["window_label"] = range_map.get(selected_time_range, "Selected Period")

        return context

    def _calculate_time_savings(self, recent_runs):
        """Calculate time savings from workflow automation over the last 30 days."""
        # Get runs with manual duration data and calculate totals
        runs_with_duration = recent_runs.select_related("workflow").filter(
            workflow__manual_duration_minutes__isnull=False
        )

        # Calculate total manual time that would have been required
        total_manual_minutes = 0
        total_automation_minutes = 0
        runs_count = 0

        for run in runs_with_duration:
            if run.workflow.manual_duration_minutes:
                total_manual_minutes += run.workflow.manual_duration_minutes
                runs_count += 1

                # Calculate actual workflow execution time and measured form-fill duration
                if run.started and run.finished and run.finished >= run.started:
                    execution_seconds = int((run.finished - run.started).total_seconds())
                    # Fallback to 60s (1 minute) for legacy runs without measured form duration
                    form_seconds = 60 if run.form_duration_seconds in (None, "") else int(run.form_duration_seconds)
                    total_automation_minutes += ceil((execution_seconds + form_seconds) / 60.0)

        # Calculate savings
        time_saved_minutes = total_manual_minutes - total_automation_minutes

        return {
            "total_manual_minutes": total_manual_minutes,
            "total_automation_time": total_automation_minutes,
            "total_automation_minutes": total_automation_minutes % 60,
            "total_automation_hours": floor(total_automation_minutes / 60),
            "time_saved_minutes": time_saved_minutes % 60,
            "time_saved_hours": floor(time_saved_minutes / 60),
            "time_saved_total_minutes": time_saved_minutes,
            "runs_with_duration_count": runs_count,
        }

    def _calculate_monthly_time_savings(self):
        """Aggregate time saved per month over the last 12 months.

        Returns a list of dicts sorted by month ascending (oldest to newest) with:
        - month_label: e.g. 'Jan 2025'
        - total_minutes: total time saved in that month (manual - automation)
        - hours, minutes: breakdown of total_minutes
        - percent_of_max: percent relative to maximum monthly saved minutes in the period
        """
        from datetime import timedelta

        from django.utils import timezone

        now = timezone.now()
        # Start from beginning of current month
        current_month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

        # Collect month boundaries (12 months back including current)
        month_starts = []
        cursor = current_month_start
        for _ in range(12):
            month_starts.append(cursor)
            # Move back one month: subtract one day from the first of month then set day=1
            prev_month_last_day = cursor - timedelta(days=1)
            cursor = prev_month_last_day.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        # Reverse to oldest -> newest
        month_starts.reverse()

        # Helper to get next month start
        def next_month(dt):
            if dt.month == 12:
                return dt.replace(year=dt.year + 1, month=1)
            return dt.replace(month=dt.month + 1)

        monthly = []
        # Pre-fetch successful runs in the 12-month span for efficiency
        earliest_start = month_starts[0]
        all_runs = WorkflowRun.objects.filter(started__gte=earliest_start, status="success").select_related("workflow")

        for start in month_starts:
            end = next_month(start)
            runs = [
                r for r in all_runs if r.started >= start and r.started < end and r.workflow.manual_duration_minutes
            ]
            total_manual = 0
            total_automation = 0
            for run in runs:
                total_manual += run.workflow.manual_duration_minutes or 0
                if run.started and run.finished and run.finished >= run.started:
                    execution_seconds = int((run.finished - run.started).total_seconds())
                    form_seconds = 60 if run.form_duration_seconds in (None, "") else int(run.form_duration_seconds)
                    total_automation += ceil((execution_seconds + form_seconds) / 60.0)
            time_saved = max(total_manual - total_automation, 0)
            monthly.append(
                {
                    "month_label": start.strftime("%b %Y"),
                    "total_minutes": time_saved,
                    "hours": floor(time_saved / 60),
                    "minutes": time_saved % 60,
                }
            )

        max_saved = max((m["total_minutes"] for m in monthly), default=0)
        for m in monthly:
            if max_saved > 0:
                m["percent_of_max"] = (m["total_minutes"] / max_saved) * 100
            else:
                m["percent_of_max"] = 0

            # Determine a simple CSS class for coloring in the template
            pct = m["percent_of_max"]
            if pct >= 70:
                m["bar_class"] = "best"
            elif pct >= 40:
                m["bar_class"] = "high"
            elif pct >= 20:
                m["bar_class"] = "med"
            else:
                m["bar_class"] = "low"

        return monthly
