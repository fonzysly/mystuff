"""Navigation menu configuration for the workflow launcher plugin."""

from nautobot.apps.ui import NavMenuGroup, NavMenuItem, NavMenuTab

workflow_items = (
    NavMenuItem(
        link="plugins:nautobot_workflow_launcher:workflows_list",
        name="Launch",
        permissions=["nautobot_workflow_launcher.view_workflow"],
    ),
)

reporting_items = (
    NavMenuItem(
        link="plugins:nautobot_workflow_launcher:workflow_report",
        name="Dashboard",
        permissions=["nautobot_workflow_launcher.view_workflowrun"],
    ),
    NavMenuItem(
        link="plugins:nautobot_workflow_launcher:workflow_run_list",
        name="Run History",
        permissions=["nautobot_workflow_launcher.view_workflowrun"],
    ),
)

menu_items = (
    NavMenuTab(
        name="Workflows",
        weight=375,
        groups=(
            NavMenuGroup(name="Workflows", items=workflow_items),
            NavMenuGroup(name="Reporting", items=reporting_items),
        ),
    ),
)
