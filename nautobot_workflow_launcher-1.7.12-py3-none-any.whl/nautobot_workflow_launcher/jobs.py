"""Nautobot Jobs for the workflow launcher plugin."""

from django.utils import timezone
from nautobot.apps.jobs import Job, StringVar, register_jobs
from nautobot.extras.models import Job as JobModel
from nautobot.extras.models import ScheduledJob

from .executors import run_workflow
from .models import WorkflowRun

name = "Workflow Launcher"


class OrphanedWorkflowRunCleaner(Job):
    """Clean up orphaned WorkflowRun instances."""

    class Meta:
        """Job metadata."""

        name = "Clean Orphaned Workflow Runs"
        description = "Delete WorkflowRun records that are orphaned or stuck in scheduled status"
        has_sensitive_variables = False
        hidden = True

    def run(self):
        """Identify and delete orphaned or stuck WorkflowRun instances."""
        job_model = JobModel.objects.get(
            module_name="nautobot_workflow_launcher.jobs", job_class_name="ScheduledWorkflowExecutorJob"
        )
        for workflow_run in WorkflowRun.objects.filter(status__in=["scheduled", "pending"]):
            jobs = ScheduledJob.objects.filter(job_model=job_model, kwargs={"workflow_run_id": workflow_run.id})
            if not jobs:
                self.logger.info(f"Deleted orphaned WorkflowRun instance: {workflow_run.id}")
                workflow_run.delete()


class ScheduledWorkflowExecutorJob(Job):
    """Execute a pre-created WorkflowRun at scheduled time."""

    class Meta:
        """Job metadata."""

        name = "Execute Scheduled Workflow"
        description = "Execute a workflow run that was scheduled for later execution"
        has_sensitive_variables = False
        hidden = True

    workflow_run_id = StringVar(description="WorkflowRun ID to execute")

    def run(self, workflow_run_id):
        """Execute the scheduled workflow run."""
        try:
            workflow_run = WorkflowRun.objects.select_related("workflow", "requested_by").get(
                pk=workflow_run_id, status="scheduled"
            )
            self.logger.info(
                f"Executing scheduled workflow: {workflow_run.workflow.name}",
                extra={"grouping": "workflow-execution", "object": workflow_run},
            )

            # Update status to running
            workflow_run.started = timezone.now()
            workflow_run.status = "running"
            workflow_run.save()

            # Execute the workflow using the existing run_workflow function
            run_workflow(workflow_run.workflow, workflow_run.requested_by, workflow_run.inputs, workflow_run)

            self.logger.success(
                f"Successfully executed scheduled workflow: {workflow_run.workflow.name}",
                extra={"grouping": "workflow-execution", "object": workflow_run},
            )

        except WorkflowRun.DoesNotExist:
            error_msg = f"WorkflowRun {workflow_run_id} not found or not in scheduled status"
            self.logger.error(error_msg, extra={"grouping": "workflow-execution"})
            raise Exception(error_msg)
        except Exception as e:
            error_msg = f"Error executing scheduled workflow: {e}"
            self.logger.error(error_msg, extra={"grouping": "workflow-execution"})

            # Update workflow run status to failed if we have the object
            try:
                workflow_run = WorkflowRun.objects.get(pk=workflow_run_id)
                workflow_run.status = "failed"
                workflow_run.log += f"\nScheduled execution failed: {e}"
                workflow_run.save()
                self.logger.info(
                    f"Updated WorkflowRun {workflow_run_id} status to failed",
                    extra={"grouping": "workflow-execution", "object": workflow_run},
                )
            except WorkflowRun.DoesNotExist:
                self.logger.warning(
                    f"Could not update WorkflowRun {workflow_run_id} status - object not found",
                    extra={"grouping": "workflow-execution"},
                )

            # Re-raise the exception to mark the job as failed
            raise


register_jobs(ScheduledWorkflowExecutorJob, OrphanedWorkflowRunCleaner)
